(function () {
    angular
        .module('app')
        .controller('AppInfoCtrl', AppInfoCtrl);

    AppInfoCtrl.$inject = ['$scope', '$filter', '$translate', 'navigationApi'];

    function AppInfoCtrl($scope, $filter, $translate, navigationApi) {

        var vm = this;
        vm.clientVersion = window.app.config.clientVersion;
        var date = new Date();
        vm.copyRightYear = date.getFullYear();
        vm.serverVersion = "";
        navigationApi.getServerVersion().$promise.then(function (data) {
            vm.serverVersion = data.ServerVersion;
        });

    }

})();
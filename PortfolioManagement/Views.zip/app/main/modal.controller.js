(function () {
    angular
        .module('app')
        .controller('ModalCtrl', ModalCtrl);

    ModalCtrl.$inject = ['$scope', '$modalInstance'];

    function ModalCtrl($scope, $modalInstance) {
        var vm = this;

        //The following is used to set and open the info panel of the form
        vm.infoVisible = false;
        vm.infoText = "";
        vm.infoClass = "alert alert-info";

        //Input scope values from calling page
        vm.inputScope = $scope.inputScope;

        //Callback function from form
        vm.appCallback = function (callbackAction, callbackScope) {
            var action = callbackAction || null;
            var actionScope = callbackScope || {};
            if (action) {
                if (action === "saveOk") {
                    $modalInstance.close(actionScope);                   
                }
                else if (action === "cancel") {
                    $modalInstance.dismiss('cancel');
                }
            }
        };
    };
})();
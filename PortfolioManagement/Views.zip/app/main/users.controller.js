(function () {
    angular
        .module('app')
        .controller('UsersCtrl', UsersCtrl);

    UsersCtrl.$inject = ['$scope', '$state', '$rootScope', '$filter', '$translate', '$timeout', '$modal', 'userManageApi', 'alertsManageApi', 'userProfileApi', 'labsiteManageApi', 'userQueryApi'];

    function UsersCtrl($scope, $state, $rootScope, $filter, $translate, $timeout, $modal, userManageApi, alertsManageApi, userProfileApi, labsiteManageApi, userQueryApi) {
        var vm = this;
        vm.isAuthenticated = false;
        vm.puid = window.app.puid;
        vm.hasMoreThanOneLabsiteAccess = false;
        vm.user = {
            FirstName: window.app.puid
        };

        $rootScope.$on('$stateChangeError', function (event, toState, toParams, fromState, fromParams, error) {
            if (error) {
                alert(error);
            }
        });


        var interval = window.app.config.alertsInterval;
        vm.tasks = 0;
        vm.notifications = 0;
        vm.taskRefreshTime = moment().calendar();
        vm.notificationRefreshTime = moment().calendar();

        //replace(/_START_/g, formatter.call(settings, start))


        var activateAlerts = function () {
            alertsManageApi.query().$promise.then(function (data) {
                //console.log(data);
                if (data != null) {
                    if (vm.tasks !== data.TasksCount) {
                        vm.tasks = data.TasksCount;
                        vm.taskRefreshTime = moment().calendar();
                    }
                    if (vm.notifications !== data.NotificationsCount) {
                        vm.notifications = data.NotificationsCount;
                        vm.notificationRefreshTime = moment().calendar();
                    }
                    vm.taskMessage = String($filter("trustedtranslate")("Common.Alert.TaskMessage")).replace(/_TASKS_/g, vm.tasks);
                    vm.notificationMessage = String($filter("trustedtranslate")("Common.Alert.NotificationMessage")).replace(/_NOTIFICATIONS_/g, vm.notifications);
                    $timeout(activateAlerts, interval);
                }
            });
        }


        vm.inputScope = { status: 200, statusText: 200, data: null };

        function activate() {
            return userManageApi.getByPuid(window.app.puid).then(function (data) {

                if (data.results.length === 1 && data.results[0].Puid) {
                    userQueryApi.getCurrentUserLabSites().then(function(labsites) {

                        vm.user = data.results[0];
                        userProfileApi.currentUser = data.results[0];
                        vm.user.LabSites = labsites.results;

                        if (vm.user.LabSites !== null && vm.user.LabSites.length === 0) {

                            if (vm.user.IsGlobalAdministrator) {
                                vm.user.DefaultLabSiteCode = "Global Administrator";
                                vm.hasMoreThanOneLabsiteAccess = false;
                                window.localStorage.setItem("defaultLabsite", null);
                                //$localStorage.defaultLabsite = null;
                            }
                        } else if (vm.user.LabSites.length === 1) {
                            window.localStorage.setItem("defaultLabsite", JSON.stringify(vm.user.LabSites[0]));
                            //$localStorage.defaultLabsite = vm.user.LabSites[0];
                            vm.user.DefaultLabSiteCode = vm.user.LabSites[0].Code;
                            vm.hasMoreThanOneLabsiteAccess = false;
                        } else if (vm.user.LabSites.length > 1) {
                            vm.hasMoreThanOneLabsiteAccess = true;

                            var defaultLabSiteFromLocalStorage = JSON.parse(window.localStorage.getItem("defaultLabsite"));

                            if (defaultLabSiteFromLocalStorage === undefined || defaultLabSiteFromLocalStorage === null) {                                
                                window.localStorage.setItem("defaultLabsite", JSON.stringify(vm.user.LabSites[0]));
                                //$localStorage.defaultLabsite = vm.user.LabSites.length > 0 ? defaultLabSiteFromLocalStorage : null;
                            }

                            defaultLabSiteFromLocalStorage = JSON.parse(window.localStorage.getItem("defaultLabsite"));

                            var isDefaultLabsiteInCacheIsValid = false;
                            vm.user.DefaultLabSiteCode = defaultLabSiteFromLocalStorage.Code;
                            //vm.user.DefaultLabSiteCode = $localStorage.defaultLabsite.Code;
                            for (var indx = 0; indx < vm.user.LabSites.length; indx++) {
                                if (vm.user.LabSites[indx].Code === vm.user.DefaultLabSiteCode) {
                                    isDefaultLabsiteInCacheIsValid = true;
                                    break;
                                }
                            }
                            if (!isDefaultLabsiteInCacheIsValid) {

                                window.localStorage.setItem("defaultLabsite", JSON.stringify(vm.user.LabSites[0]));
                                //$localStorage.defaultLabsite = vm.user.LabSites[0];
                                vm.user.DefaultLabSiteCode = vm.user.LabSites[0].Code;
                            }
                        }

                        userProfileApi.defaultLabsite = JSON.parse(window.localStorage.getItem("defaultLabsite"));

                        //userProfileApi.defaultLabsite = $localStorage.defaultLabsite;
                        vm.isAuthenticated = true;
                        activateAlerts();

                    });
                }
                else {
                    vm.inputScope.status = data.status;
                    vm.inputScope.statusText = data.statusText;
                    vm.inputScope.data = data.data;
                }
                $state.go('auth', { inputScope: vm.inputScope });

            }, function (data) {
                vm.inputScope.status = data.status;
                vm.inputScope.statusText = data.statusText;
                vm.inputScope.data = data.data;
                $state.go('auth', { inputScope: vm.inputScope });
            });
        }
        activate();

        vm.ChangeDefaultUserLabSite = function (labsite) {

            if (labsite.Code === vm.user.DefaultLabSiteCode) {
                return;
            }

            var modalScope = String($filter("trustedtranslate")("Common.Maintenance.ChangeLabSiteText")) + " " + labsite.Code + "?";
            
            var modalInstance = $modal.open({
                template: '<div class="modal-body"><ddbs-confirm ismodal="true" inputscope="vm.inputScope" appcallback="vm.appCallback"></ddbs-confirm></div>',
                controller: 'ModalCtrl as vm',
                backdrop: 'static',
                size: 'sm',
                windowClass: 'center-modal',
                scope: function () {
                    var scope = $scope.$new();
                    scope.inputScope = modalScope;
                    return scope;
                }()
            });
            modalInstance.result.then(function (modalReturnScope) {
                var outputScope = modalReturnScope || null;
                if (outputScope) {
                    window.localStorage.setItem("defaultLabsite", JSON.stringify(labsite));
                    //$localStorage.defaultLabsite = labsite;
                    vm.user.DefaultLabSiteCode = labsite.Code;
                    location.reload();
                }
            }, function () { });

        }

    }


})();
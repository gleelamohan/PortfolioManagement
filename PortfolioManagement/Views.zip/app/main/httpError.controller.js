(function () {
    angular
        .module('app')
        .controller('HttpErrorCtrl', HttpErrorCtrl);

    HttpErrorCtrl.$inject = ['$state', '$rootScope', 'usersApi'];

    function HttpErrorCtrl($state, $rootScope, usersApi) {
            var vm = this;
        
            vm.requestForLimsAccess = function () {

            var to = window.app.config.eLimsSupportEmail;

            console.log(window.app);

            var puid = window.app.puid;
            var bodyText = [];

            bodyText.push("Hi DDBS Support,");
            bodyText.push("\n");
            bodyText.push("\n\t Please add my user account to access LIMS application. ");
            bodyText.push("\n\t Account Information-");
            bodyText.push("\n\t\t PUID: " + puid);
            bodyText.push("\n\t\t Email: ?");
            bodyText.push("\n\t\t Role: ?");
            bodyText.push("\n\t\t Business Reason: ?");
            bodyText.push("\n");
            bodyText.push("\nThanks");
            bodyText.push("\n"+puid);

            var emailBody = "";

            for (var i = 0; i < bodyText.length; i++) {
                emailBody += bodyText[i];
            }

            var subject = "Request for eLIMS Application Access";
           
            emailBody = encodeURIComponent(emailBody);

            href = "mailto:" + to + "?Subject="+ subject +"&body=" + emailBody;

            window.location.href = href;

        };
    }


})();
(function() {
    angular
        .module('app')
        .constant('toastr', toastr)
        .constant('efLibrary', efLibrary)
        .constant('masks', {
            'date': {
                'moment': 'DD-MMM-YYYY',
                'angular': 'dd-MMM-yyyy',
                'model': {
                    'moment': 'YYYY-MM-DD',
                    'angular': 'yyyy-MM-dd'
                }
            },
            'datetime': {
                'moment': 'DD-MMM-YYYY HH:mm',
                'angular': 'dd-MMM-yyyy HH:mm',
                'model': {
                    'moment': 'YYYY-MM-DD HH:mm',
                    'angular': 'dd-MM-yyyy HH:mm'
                }
            },
            'time': {
                'moment': 'HH:mm',
                'angular': 'HH:mm',
                'model': {
                    'moment': 'HH:mm:ss.sss',
                    'angular': 'HH:mm:ss.sss'
                }
            }
        })
        .constant('queryServiceUrl', window.app.services.eLimsServiceHost + "/breeze/query");
})();
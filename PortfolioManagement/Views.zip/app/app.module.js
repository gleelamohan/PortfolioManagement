angular
    .module('app', [        
        'ngResource',                   // Service calls
        'ui.router',                    // Routing
        'ui.bootstrap',                 // Bootstrap
        'datatables',                   // dataTables
        'datePicker',                   // datePicker
        'ngGrid',                       // ngGrid
        'ngSanitize',                   // ngSanitize
        //'ngStorage',                    //ngStorage
        'pascalprecht.translate',       //transactions
        'ui.tree',                       //Angular UI Tree, nested lists
        'ui.bootstrap.datetimepicker',  // Datatimepicker
        'app.globalSearch',
        'app.limsAdmin',
        'app.tasks',
        'app.notifications',
        'app.sampleManagement',
        'app.analyticalConfiguration',
        'app.development',
        'breeze.angular',
        'efAngularLibrary.efClick',
        'efAngularLibrary.efInput',
        'efAngularLibrary.efDatetime',
        'efAngularLibrary.efSelect',
        'efAngularLibrary.efIboxTools',
        'efAngularLibrary.efTrustedTranslate',
        'efAngularLibrary.efEnter',
        'efAngularLibrary.efUiGrid',
        'efAngularLibrary.efRichTextInput'              
    ]);
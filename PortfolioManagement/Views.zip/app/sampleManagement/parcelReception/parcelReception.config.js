(function () {
    angular
        .module('app.sampleManagement.parcelReception')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider', '$translateProvider'];

    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('sampleManagement.parcelReception', {
                abstract: true,
                url: "/parcelReception",
                template: '<ui-view />'
            });
    }
})();
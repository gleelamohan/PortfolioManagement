angular
    .module('app.sampleManagement.parcelReception', [
       'app.sampleManagement.parcelReception.manage'
    ]);
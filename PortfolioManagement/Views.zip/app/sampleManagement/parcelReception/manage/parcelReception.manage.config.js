(function () {
    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('sampleManagement.parcelReception.manage', {
                url: "/manage",
                template: '<global-search searchservice="vm.searchService" refreshgrid="vm.refreshGrid"></global-search>',
                controller: "parcelReceptionCtrl",
                controllerAs: "vm"
            })
           .state('sampleManagement.parcelReception.mapParcel', {
              url: "/mapParcel",
              template: '<div class="wrapper wrapper-content animated fadeIn">' +
                        '<parcel-reception-manage ismodal="false" inputscope="vm.inputScope" appcallback="vm.appCallback" infovisible="vm.infoVisible" infotext="vm.infoText" infoclass="vm.infoClass"></parcel-reception-manage>' +
                        '</div>',
              controller: "mapParcelCtrl",
              controllerAs: "vm",
              params: { "inputScope": {} }
           });
    }
    angular.module('app.sampleManagement.parcelReception.manage')
     .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];

})();
(function () {

    function parcelReceptionManage($sce, $filter, $translate, $modal, recursionHelper, masks, enums, parcelManageApi, courierManageApi, userProfileApi, parcelQueryApi, courierQueryApi, orderQueryApi, clientQueryApi, samplemanagementmasterQueryApi) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                isModal: "@ismodal",
                inputScope: "=inputscope",
                appCallback: "=appcallback",
                infoVisible: "=infovisible",
                infoText: "=infotext",
                infoClass: "=infoclass"
            },
            controller: function ($scope) {
                var vm = this;

                vm.courierNameConfig = {
                    "allowDuplicates": false,
                    "placeholder": String($filter("trustedtranslate")("Views.Parcels.Manage.CourierNamePlaceHolder")),
                    "optionsValueField": "Id",
                    "optionsLabelField": "Name",
                    "optionsListScrollOnWideOptions": true,
                    "width": "100%"
                };

                vm.arrivalConditionConfig = {
                    "allowDuplicates": false,
                    "placeholder": String($filter("trustedtranslate")("Views.Parcels.Manage.ArrivalConditionPlaceHolder")),
                    "optionsValueField": "Id",
                    "optionsLabelField": "Condition",
                    "optionsListScrollOnWideOptions": true,
                    "width": "100%"
                };

                vm.arrivalTemperatureConfig = {
                    "allowDuplicates": false,
                    "placeholder": String($filter("trustedtranslate")("Views.Parcels.Manage.ArrivalTemperaturePlaceHolder")),
                    "optionsValueField": "Id",
                    "optionsLabelField": "Temperature",
                    "optionsListScrollOnWideOptions": true,
                    "width": "100%"
                };

                vm.specialHandlingConfig = {
                    "allowDuplicates": false,
                    "placeholder": String($filter("trustedtranslate")("Views.Parcels.Manage.SpecialHandlingPlaceHolder")),
                    "optionsValueField": "Id",
                    "optionsLabelField": "SpecialHandlingCondition",
                    "optionsListScrollOnWideOptions": true,
                    "width": "100%"
                };

                vm.discrepancyTypeConfig = {
                    "allowDuplicates": false,
                    "placeholder": String($filter("trustedtranslate")("Views.Parcels.Manage.DiscrepancyPlaceHolder")),
                    "optionsValueField": "Id",
                    "optionsLabelField": "Value",
                    "optionsListScrollOnWideOptions": true,
                    "width": "100%"
                };

                vm.storageTemperatureConfig = {
                    "allowDuplicates": false,
                    "placeholder": String($filter("trustedtranslate")("Views.Parcels.Manage.StorageTemperaturePlaceHolder")),
                    "optionsValueField": "Id",
                    "optionsLabelField": "Value",
                    "optionsListScrollOnWideOptions": true,
                    "width": "100%"
                };

                vm.orderConfig = {
                    "resultsConfig": {
                        "rowSelect": true, //For "true" the first column of the table needs to render an anchor tag which will be used by the entire row when it is selected.
                        "helpText": "Views.Parcels.Search.SearchResultsConfig.HelpText",
                        "noResultsText": "Search.SearchResultsNoResultsText",
                        "viewType": "standard", //standard or user  
                        "pageLengthOptions": [
                            { "label": "10", "value": 10 },
                            { "label": "25", "value": 25 },
                            { "label": "50", "value": 50 },
                            { "label": "100", "value": 100 },
                            { "label": "All", "value": -1 }
                        ],
                        "datatableConfig": {
                            "destroy": true,
                            "dom": "Rrtip",
                            "colReorder": {
                                "realtime": true, //Realtime ordering in the UI
                                "order": [0, 1, 2, 3, 4] //initial column ordering
                            },
                            "columnDefs": [
                                {
                                    "targets": "_all",
                                    "cellType": "td",
                                    "orderable": "true",
                                    "searchable": "true"
                                },
                                {
                                    "targets": 0,
                                    "name": "Order_OrderNo",
                                    "title": "Order Id",
                                    "data": null,
                                    "render": function (data, type, full) {
                                        return '<a onclick="angular.element(this).scope().vm.orderGridCallback(\'selectOrder\',{\'OrderId\': \'' + full.Order_OrderNo + '\'  });" title="">' + full.Order_OrderNo + '</a>';
                                    },
                                    "type": "html",
                                    "width": "20%"
                                },
                                {
                                    "targets": 1,
                                    "name": "Order_EurofinsBarcodeId",
                                    "title": "Eurofins Id",
                                    "data": null,
                                    "render": function (data, type, full) {
                                        return '<a onclick="angular.element(this).scope().vm.orderGridCallback(\'selectEurofinsId\',{\'OrderId\': \'' + full.Order_EurofinsBarcodeId + '\'  });" title="">' + full.Order_EurofinsBarcodeId + '</a>';
                                    },
                                    "type": "html",
                                    "width": "20%"
                                },
                                {
                                    "targets": 2,
                                    "name": "Order_QuoteId",
                                    "title": "Quote Id",
                                    "data": null,
                                    "render": function (data, type, full) {
                                        return '<a onclick="angular.element(this).scope().vm.orderGridCallback(\'selectQuoteId\',{\'OrderId\': \'' + full.Order_QuoteId + '\'  });" title="">' + full.Order_QuoteId + '</a>';
                                    },
                                    "type": "html",
                                    "width": "20%"
                                },
                                {
                                    "targets": 3,
                                    "name": "Order_ERPClientId",
                                    "title": "Client Id",
                                    "data": null,
                                    "render": function (data, type, full) {
                                        return '<a onclick="angular.element(this).scope().vm.orderGridCallback(\'selectClientId\',{\'OrderId\': \'' + full.Order_ERPClientId + '\'  });" title="">' + full.Order_ERPClientId + '</a>';
                                    },
                                    "type": "html",
                                    "width": "38%"
                                },
                                {
                                    "targets": 4,
                                    "name": "",
                                    "title": "",
                                    "data": null,
                                    "render": function (data, type, full) {
                                        return '<a onclick="angular.element(this).scope().vm.orderGridCallback(\'removeOrder\',{\'OrderId\': \'' + full.Order_Id + '\'  });" title="">' + '<i class="fa fa-trash-o fa-2x"></i>' + '</a>';
                                    },
                                    "type": "html",
                                    "width": "2%",
                                    "orderable": false
                                }
                            ],
                            "deferRender": true,
                            "language": {
                                "emptyTable": String($filter("trustedtranslate")("Views.Orders.Search.SearchResultsConfig.DatatableConfig.Language.EmptyTable")),
                                "info": String($filter("trustedtranslate")("Views.Orders.Search.SearchResultsConfig.DatatableConfig.Language.Info")),
                                "infoEmpty": String($filter("trustedtranslate")("Views.Orders.Search.SearchResultsConfig.DatatableConfig.Language.InfoEmpty")),
                                "infoFiltered": String($filter("trustedtranslate")("Views.Orders.Search.SearchResultsConfig.DatatableConfig.Language.InfoFiltered")),
                                "zeroRecords": String($filter("trustedtranslate")("Views.Orders.Search.SearchResultsConfig.DatatableConfig.Language.ZeroRecords"))
                            },
                            "lengthChange": true,
                            "order": [[0, "desc"]],
                            "paging": true,
                            "pageLength": 10,
                            "pagingType": "simple_numbers",
                            "searching": true
                        }
                    }
                };

                vm.documentsConfig = {
                    "resultsConfig": {
                        "rowSelect": true, //For "true" the first column of the table needs to render an anchor tag which will be used by the entire row when it is selected.
                        "helpText": "Views.Parcels.Search.SearchResultsConfig.HelpText",
                        "noResultsText": "Search.SearchResultsNoResultsText",
                        "viewType": "standard", //standard or user  
                        "pageLengthOptions": [
                            { "label": "10", "value": 10 },
                            { "label": "25", "value": 25 },
                            { "label": "50", "value": 50 },
                            { "label": "100", "value": 100 },
                            { "label": "All", "value": -1 }
                        ],
                        "datatableConfig": {
                            "destroy": true,
                            "dom": "Rrtip",
                            "colReorder": {
                                "realtime": true, //Realtime ordering in the UI
                                "order": [0, 1, 2, 3, 4] //initial column ordering
                            },
                            "columnDefs": [
                                {
                                    "targets": "_all",
                                    "cellType": "td",
                                    "orderable": "true",
                                    "searchable": "true"
                                },
                                {
                                    "targets": 0,
                                    "name": "Title",
                                    "title": String($filter("trustedtranslate")("Entity.Parcel.Document.Title.ColumnText")),
                                    "data": null,
                                    "render": function (data, type, full) {
                                        return '<a onclick="angular.element(this).scope().vm.documentGridCallback(\'selectDocument\',{\'DocumentId\': \'' + full.Id + '\'  });" title="">' + full.Title + '</a>';
                                    },
                                    "type": "html",
                                    "width": "35%"
                                },
                                {
                                    "targets": 1,
                                    "name": "Description",
                                    "title": String($filter("trustedtranslate")("Entity.Parcel.Document.Description.ColumnText")),
                                    "data": null,
                                    "render": { "_": "Description" },
                                    "type": "html",
                                    "width": "45%"
                                },
                                {
                                    "targets": 2,
                                    "name": "AttachedOn",
                                    "title": String($filter("trustedtranslate")("Entity.Parcel.Document.UploadedDate.ColumnText")),
                                    "data": null,
                                    "render": function (data, type, full) {
                                        return full.AttachedOn !== undefined && full.AttachedOn !== null ? moment(moment.utc(full.AttachedOn).toDate()).format(masks.datetime.moment) : "";
                                    },
                                    "type": "html",
                                    "width": "15%"
                                },
                                {
                                    "targets": 3,
                                    "name": "",
                                    "title": String($filter("trustedtranslate")("Entity.Parcel.Document.Attachment.ColumnText")),
                                    "data": null,
                                    "render": function (data, type, full) {
                                        return '<a onclick="angular.element(this).scope().vm.documentGridCallback(\'downloadDocument\',{\'FileName\': \'' + full.FileName + '\'  });" title=' + full.FileName + '>' + vm.getFileIcon(full.FileName) + '</a>';
                                    },
                                    "type": "html",
                                    "width": "10px",
                                    "orderable": false
                                },
                                {
                                    "targets": 4,
                                    "name": "",
                                    "title": "",
                                    "data": null,
                                    "render": function (data, type, full) {
                                        return '<a onclick="angular.element(this).scope().vm.documentGridCallback(\'removeDocument\',{\'documentId\': \'' + full.Id + '\',\'filename\': \'' + full.FileName + '\'  });" title="">' + '<i class="fa fa-trash-o fa-2x"></i>' + '</a>';
                                    },
                                    "type": "html",
                                    "width": "2%",
                                    "orderable": false
                                }
                            ],
                            "deferRender": true,
                            "language": {
                                "emptyTable": String($filter("trustedtranslate")("Views.Documents.Search.SearchResultsConfig.DatatableConfig.Language.EmptyTable")),
                                "info": String($filter("trustedtranslate")("Views.Documents.Search.SearchResultsConfig.DatatableConfig.Language.Info")),
                                "infoEmpty": String($filter("trustedtranslate")("Views.Documents.Search.SearchResultsConfig.DatatableConfig.Language.InfoEmpty")),
                                "infoFiltered": String($filter("trustedtranslate")("Views.Documents.Search.SearchResultsConfig.DatatableConfig.Language.InfoFiltered")),
                                "zeroRecords": String($filter("trustedtranslate")("Views.Documents.Search.SearchResultsConfig.DatatableConfig.Language.ZeroRecords"))
                            },
                            "lengthChange": true,
                            "order": [[2, "desc"]],
                            "paging": true,
                            "pageLength": 10,
                            "pagingType": "simple_numbers",
                            "searching": true
                        }

                    }
                };


                vm.templateUrl = "/app/sampleManagement/parcelReception/manage/parcelReception.manage.html";
                vm.isModal = Boolean($scope.isModal || "false");
                vm.inputScope = $scope.inputScope;
                vm.appCallback = $scope.appCallback;
                vm.helpVisible = false;
                vm.headerText = String($filter("trustedtranslate")("Views.Parcels.Manage.CreateParcel"));
                vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.SaveButton"));
                vm.helpText = String($filter("trustedtranslate")("Views.Parcels.Manage.HelpText"));
                vm.sendernameplaceholder = String($filter("trustedtranslate")("Views.Parcels.Manage.SearchSender"));
                vm.parcelId = $scope.inputScope.Id;
                vm.addDocumentDisabled = true;
                vm.validationIssues = [];

                vm.saveDisabled = true;
                vm.formData = {};
                vm.orders = [];
                vm.documents = [];
                vm.formData.Parcel = {};
                vm.formData.Parcel.RowVersion = "";
                vm.formData.Parcel.ParcelsOrders = [];
                vm.formData.Parcel.ParcelsArrivalConditions = [];
                vm.selectedarrivalConditions = {};
                vm.selectedsender = "";

                vm.settingsTemplateUrl = "/app/components/ddbs/datatable/ddbsDatatableSettings.html";
                vm.filterTemplateUrl = "/app/components/ddbs/datatable/ddbsDatatableFilter.html";

                //DDBS ibox-tools Settings for Order and Document Tab
                vm.iboxToolsValidationVisible = true;
                vm.iboxToolsShowHideVisibleInOtab = false;
                vm.iboxToolsInfoVisibleInOtab = false;
                vm.iboxToolsInfoToggledExternallyInOtab = false;
                vm.iboxToolsFilterVisibleInOtab = true;
                vm.iboxToolsSettingsVisibleInOtab = true;
                vm.iboxToolsHelpVisibleInOtab = false;

                //DDBS ibox-tools Settings
                vm.iboxToolsShowHideVisible = vm.isModal === true ? false : true;
                vm.iboxToolsInfoVisible = false;
                vm.iboxToolsInfoToggledExternally = false;

                vm.iboxToolsValidationToggledExternally = false;
                vm.iboxToolsFilterVisible = false;
                vm.iboxToolsSettingsVisible = false;
                vm.iboxToolsHelpVisible = true;

                //#region local functions
                function handleInfoVisibleUpdates(newData) {
                    vm.toggleInfoVisibility(newData || false);
                };

                function handleInfoTextUpdates(newData) {
                    vm.infoText = newData || "";
                };

                function handleInfoClassUpdates(newData) {
                    vm.infoClass = newData || "alert alert-info";
                };

                function loadMasterData() {

                    clientQueryApi.getClients(vm.parcelId).then(function (response) {
                        vm.clients = [];
                        if (response.results) {
                            for (var i = 0; i < response.results.length; i++) {
                                var client = {
                                    Id: response.results[i].Id,
                                    ERPClientId: response.results[i].ERPClientId,
                                    Name: response.results[i].Name,
                                    LastSyncOn: response.results[i].LastSyncOn,
                                    FullNameWithERPClientId: response.results[i].ERPClientId + '-' + response.results[i].Name
                                };
                                vm.clients.push(client);
                            }
                        }
                    });

                    courierQueryApi.getCouriers().then(function (response) {
                        vm.courierNames = response.results;
                    });

                    samplemanagementmasterQueryApi.getArrivalConditions().then(function (response) {
                        vm.arrivalConditions = response.results;
                    });

                    samplemanagementmasterQueryApi.getArrivalTemperatures().then(function (response) {
                        vm.arrivalTemperatures = response.results;
                    });

                    samplemanagementmasterQueryApi.getSpecialHandlings().then(function (response) {
                        vm.specialHandlings = response.results;
                    });

                    samplemanagementmasterQueryApi.getDiscrepancyTypes().then(function (response) {
                        vm.discrepancyTypes = response.results;
                    });

                    samplemanagementmasterQueryApi.getStorageTemperatures().then(function (response) {
                        vm.storageTemperatures = response.results;
                    });
                }

                function fillExistingOrdersForParcel(guid) {
                    parcelQueryApi.getOrderDetailsByParcelId(guid).then(function (response) {
                        vm.orders = response.results;
                    });

                }

                function fillClientFromClientSenderId(clientsSenderId) {
                    clientQueryApi.getClientBySenderId(clientsSenderId).then(function (response) {
                        vm.client = [];
                        if (response.results && response.results.length > 0) {
                            vm.client = {
                                Id: response.results[0].Client_Id,
                                ERPClientId: response.results[0].Client_ERPClientId,
                                Name: response.results[0].Client_Name,
                                FullNameWithERPClientId: response.results[0].Client_ERPClientId + '-' + response.results[0].Client_Name
                            };
                            vm.PopulateClientRelatedSender();
                        }
                    });
                }

                function fillSenderFromClientSenderId(clientsSenderId) {
                    clientQueryApi.getSenderDetailByClientSenderId(clientsSenderId).then(function (response) {
                        vm.selectedsender = [];
                        if (response.results && response.results.length > 0) {
                            vm.selectedsender = {
                                Id: response.results[0].Id,
                                CRMSenderId: response.results[0].Sender_CRMSenderId,
                                Name: response.results[0].Sender_Name,
                                FullNameWithCRMSenderId: response.results[0].Sender_CRMSenderId + '-' + response.results[0].Sender_Name
                            };
                        }
                    });
                }

                function removeOrder(orderId) {
                    for (var i = 0; i < vm.orders.length; i++) {
                        if (vm.orders[i].Order_Id === orderId) {
                            var index = vm.formData.Parcel.ParcelsOrders.map(function (obj) {
                                return obj.OrderId;
                            }).indexOf(orderId);

                            if (index > -1) {
                                vm.formData.Parcel.ParcelsOrders.splice(index, 1);
                                vm.formChanged();
                            }
                            vm.orders.splice(i, 1);
                            break;
                        }
                    }
                }

                //#endregion

                vm.iboxToolsToggleInfo = function () {
                    vm.infoVisible = !vm.infoVisible;
                };

                vm.iboxToolsToggleFilter = function () {
                };

                vm.iboxToolsToggleSettings = function () {
                };

                vm.iboxToolsToggleHelp = function () {
                    vm.helpVisible = !vm.helpVisible;
                };

                vm.iboxToolsToggleInfoInOtab = function () {
                };

                vm.iboxToolsToggleFilterInOtab = function () {
                    vm.filterVisible = !vm.filterVisible;
                };

                vm.iboxToolsToggleSettingsInOtab = function () {
                    vm.settingsVisible = !vm.settingsVisible;
                };

                vm.toggleInfoVisibility = function (visible) {
                    vm.infoVisible = visible;
                    vm.iboxToolsInfoVisible = visible || false;
                    vm.iboxToolsInfoToggledExternally = vm.infoVisible;
                }

                vm.resetInfo = function () {
                    vm.infoText = "";
                    vm.infoClass = "alert alert-info";
                    vm.toggleInfoVisibility(false);
                }

                vm.appCallback = function (callbackAction, callbackScope) {
                    console.log(callbackAction);
                    console.log(callbackScope);
                }

                vm.isNotFutureDate = function (receiveddate) {
                    return (moment(moment(), 'days').diff(receiveddate, masks.datetime.model.moment)) > -1;
                }

                vm.isValidReceiveDate = function (receiveddate, registereddate) {
                    return moment(registereddate).isAfter(receiveddate);
                }

                vm.formChanged = function () {
                    vm.saveDisabled = false;
                }

                vm.formDiscrepancyChanged = function () {
                    if (!vm.formData.Parcel.DiscrepancyTypeId) {
                        vm.resetInfo();
                        vm.validationIssues = [];
                        vm.formData.Parcel.ParcelsStorageLocation.StorageTemperatureId = null;
                        vm.formData.Parcel.ParcelsStorageLocation.Room = null;
                        vm.formData.Parcel.ParcelsStorageLocation.Freezer = null;
                        vm.formData.Parcel.ParcelsStorageLocation.Shelf = null;
                        vm.formData.Parcel.ParcelsStorageLocation.Crate = null;
                        vm.formData.Parcel.ParcelsStorageLocation.Comment = null;
                    }
                    vm.saveDisabled = false;
                }

                vm.fillClientInfo = function () {
                    vm.sender = "";
                    vm.senders = [];
                    vm.selectedsender = "";
                    vm.PopulateClientRelatedSender();
                }

                vm.PopulateClientRelatedSender = function () {
                    if (vm.client.Id) {
                        clientQueryApi.getSendersByClientId(vm.client.Id).then(function (response) {
                            vm.senders = [];
                            if (response.results && response.results.length > 0) {
                                for (var i = 0; i < response.results.length; i++) {
                                    var sender = {
                                        Id: response.results[i].Id,
                                        CRMSenderId: response.results[i].Sender_CRMSenderId,
                                        Name: response.results[i].Sender_Name,
                                        FullNameWithCRMSenderId: response.results[i].Sender_CRMSenderId + '-' + response.results[i].Sender_Name
                                    };
                                    vm.senders.push(sender);
                                }
                                vm.sendernameplaceholder = String($filter("trustedtranslate")("Views.Parcels.Manage.SearchSender"));
                            }
                            else {
                                vm.sendernameplaceholder = String($filter("trustedtranslate")("Views.Parcels.Manage.NoSenderFound"));
                            }
                        });
                    };
                }

                vm.refreshGridAfterUpdate = function (documentId, title, description) {
                  
                }

                vm.downloadDocument = function (callbackScope) {
                    parcelManageApi.downloadattachment(vm.parcelId, callbackScope);
                }

                vm.removeDocument = function (callbackScope, filename) {
                    var result = confirm(String($filter("trustedtranslate")("Views.Parcels.Manage.ConfirmationTextForDelete")));
                    if (result) {
                        var index = vm.documents.map(function(obj) {
                            return obj.Id;
                        }).indexOf(callbackScope);

                        if (index > - 1) {
                            parcelManageApi.removeattachment({ entityId: vm.parcelId, entityRowVersion: vm.formData.Parcel.RowVersion, fileName: filename }).$promise.then(function(response) {
                                if(response.RowVersion) {
                                    vm.formData.Parcel.RowVersion = response.RowVersion;
                                    vm.documents.splice(index, 1);
                                    toastr.success(String($filter("trustedtranslate")("Views.Parcels.Manage.DeleteDocumentText")));
                                }
                            });
                        }
                    }
                }

                vm.addEditDocumentModal = function (documentId, isUpdate) {
                    var modalInstance = $modal.open({
                        template: '<div class="modal-body"><manage-document ismodal="true" inputscope="vm.inputScope" appcallback="vm.appCallback" infovisible="vm.infoVisible" infotext="vm.infoText" infoclass="vm.infoClass"></manage-document></div>',
                        controller: 'ModalCtrl as vm',
                        backdrop: 'static',
                        keyboard: true,
                        scope: function () {
                            var scope = $scope.$new();
                            if (isUpdate) {
                                scope.inputScope = documentId;
                                scope.inputScope.rowVersion = vm.formData.Parcel.RowVersion;
                            } else {
                                scope.inputScope.parcelId = vm.parcelId;
                                scope.inputScope.rowVersion = vm.formData.Parcel.RowVersion;
                            }
                            return scope;
                        }()
                    });

                    modalInstance.result.then(function(modalReturnScope) {
                        var outputScope = modalReturnScope || null;
                        if (outputScope) {
                            if (outputScope.rowVersion) {
                                vm.formData.Parcel.RowVersion = outputScope.rowVersion;
                            }
                            if (isUpdate) {
                                var index = vm.documents.map(function (obj) {
                                        return obj.Id;
                                    }).indexOf(documentId);

                                if (index > -1) {
                                    vm.documents[index].Title = outputScope.title;
                                    vm.documents[index].Description = outputScope.description;
                                }
                            }
                            else {
                                vm.refreshDocumentGrid(modalReturnScope.parcelId);
                            }

                        }
                    }, function () { });
                }

                vm.refreshDocumentGrid = function (parcelId) {
                    parcelQueryApi.getAttachmentsByParcelId(parcelId).then(function(response) {
                        vm.documents = response.results;
                    });
                }

                vm.documentGridCallback = function (callbackAction, callbackScope) {
                    switch(callbackAction) {
                        case "selectDocument":
                            vm.addEditDocumentModal(callbackScope.DocumentId, true);
                            break;
                        case "downloadDocument":
                            vm.downloadDocument(callbackScope.FileName);
                            break;
                        case "removeDocument":
                            vm.removeDocument(callbackScope.documentId, callbackScope.filename);
                            break;

                        }
                }

                vm.getFileIcon = function (fileName) {
                    if((fileName != undefined) && (fileName)) {
                        var fileExt = fileName.split(".").pop().toLowerCase();
                        switch (fileExt) {
                            case "pdf":
                                return '<i class="fa fa-file-pdf-o fa-2x"></i>';
                            case "xls":
                            case "xlsx":
                                return '<i class="fa fa-file-excel-o fa-2x"></i>';
                            case "doc":
                            case "docx":
                                return '<i class="fa fa-file-word-o fa-2x"></i>';
                            case "jpeg":
                            case "png":
                            case "tif":
                            case "gif":
                            case "jpg":
                                return '<i class="fa fa-file-image-o fa-2x"></i>';
                            }
                    }
                    return '<i class="fa fa-paperclip fa-2x"></i>';
                };

                vm.orderGridCallback = function (callbackAction, callbackScope) {

                    switch(callbackAction) {
                        case "removeOrder":
                            removeOrder(callbackScope.OrderId);
                            break;
                        }
                }

                vm.searchOrder = function () {
                    var limsClient = null;
                    if (vm.client) {
                        if ((vm.client.Id) && (vm.client.Id !== null) && (vm.client.Id !== undefined)) {
                            limsClient = vm.client;
                        }
                    }

                    var modalScope = { LimsClient: limsClient }

                    var modalInstance = $modal.open({
                        template: '<div class="modal-body"><search-order ismodal="true" inputscope="vm.inputScope" appcallback="vm.appCallback" infovisible="vm.infoVisible" infotext="vm.infoText" infoclass="vm.infoClass"></search-order></div>',
                        controller: 'ModalCtrl as vm',
                        backdrop: 'static',
                        keyboard: true,
                        scope: function () {
                            var scope = $scope.$new();
                            scope.inputScope = modalScope;
                            return scope;
                        }()
                    });

                    modalInstance.result.then(function(modalReturnScope) {
                        var outputScope = modalReturnScope || null;
                        if (outputScope) {
                            var currlength = 0;
                            if (vm.orders) {
                                currlength = vm.orders.length;
                            }
                            for (var i = 0; i < outputScope.mappedOrders.length; i++) {
                                var isMatching = false;
                                for (var j = 0; j < currlength; j++) {
                                    if (outputScope.mappedOrders[i].OrderNo === vm.orders[j].Order_OrderNo) {
                                        isMatching = true;
                                        break;
                                    }
                                }
                                if (!isMatching) {
                                    var temporder = {
                                        Order_Id: outputScope.mappedOrders[i].Id, Order_OrderNo: outputScope.mappedOrders[i].OrderNo, Order_EurofinsBarcodeId: outputScope.mappedOrders[i].EurofinsBarcodeId,
                                        Order_QuoteId: outputScope.mappedOrders[i].QuoteId, Order_ERPClientId: outputScope.mappedOrders[i].ERPClientId
                                    };
                                    vm.formData.Parcel.ParcelsOrders.push({ OrderId: outputScope.mappedOrders[i].Id });
                                    vm.orders.push(temporder);
                                    vm.formChanged();
                                }
                            }
                        }
                    }, function () { });
                }

                vm.createValidationIssue = function (field, message, cssClass) {
                    return {
                        "field": field || "",
                        "message": message || "",
                        "cssClass": cssClass || ""
                    };
                }

                vm.createValidationInfoText = function (issues) {
                    var infoText = "";

                    if ((issues) && (issues.length > 0)) {
                        infoText = "<p>" +
                           String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.ParcelValidationInfoText")) +
                           "</p><ul>";

                        issues.forEach(function (issue) {
                            if (issue.message !== "")
                            infoText += ("<li>" + issue.message + "</li>");
                        });

                        infoText += "</ul>";
                    }
                    return infoText;
                }

                vm.validationCallback = function () {
                    vm.validateFormData(true);
                }

                vm.validateFormData = function (displayOkMessage) {
                    vm.resetInfo();
                    vm.validationIssues = [];
                    var issues = [];

                    var regEx = /^[a-zA-Z0-9\s]*$/;

                    if ((!vm.formData.Parcel.CourierTrakingNo) || (vm.formData.Parcel.CourierTrakingNo.length === 0) || (vm.formData.Parcel.CourierTrakingNo.trim() === "")) {
                        issues.push(vm.createValidationIssue("Parcel.CourierNo", String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.CourierTrackingNoRequired")), "has-error"));
                    }

                    if ((vm.formData.Parcel.CourierTrakingNo) && ((vm.formData.Parcel.CourierTrakingNo.length < 2) || (vm.formData.Parcel.CourierTrakingNo.length > 50))) {
                        issues.push(vm.createValidationIssue("Parcel.CourierNo", String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.CourierNoLength")), "has-error"));
                    }

                    if (!regEx.test(vm.formData.Parcel.CourierTrakingNo)) {
                        issues.push(vm.createValidationIssue("Parcel.CourierNo", String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.CourierNoSpecialCharacter")), "has-error"));
                    }

                    if (!vm.formData.Parcel.CourierId) {
                        issues.push(vm.createValidationIssue("Parcel.CourierName", String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.CourierNameRequired")), "has-error"));
                    }

                    if (vm.formData.Parcel.ReceivedDate) {
                        if ((!vm.isValidReceiveDate(vm.formData.Parcel.ReceivedDate, vm.formData.Parcel.RegisteredDate)) && (vm.formData.Parcel.RegisteredDate) && (vm.IsParcelUpdate)) {
                            issues.push(vm.createValidationIssue("Parcel.ReceivedDateTime", String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.ReceivedDateValidation")), "has-error"));
                        } else {
                            if (!vm.isNotFutureDate(vm.formData.Parcel.ReceivedDate)) {
                                issues.push(vm.createValidationIssue("Parcel.ReceivedDateTime", String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.ReceivedDateValidationWithCurrentDate")), "has-error"));
                            }
                        }
                    }
                    else {
                        issues.push(vm.createValidationIssue("Parcel.ReceivedDateTime", String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.ReceivedDateRequired")), "has-error"));
                    }

                    if ((vm.client) || (vm.selectedsender)) {
                        if (!vm.client.Id) {
                            issues.push(vm.createValidationIssue("Parcel.Client", String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.ClientNameRequired")), "has-error"));
                        }

                        if (!vm.selectedsender.Id) {
                            issues.push(vm.createValidationIssue("Parcel.SenderName", String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.SenderNameRequired")), "has-error"));
                        }

                        if ((vm.orders) && (vm.orders !== undefined) && (vm.orders.length > 0)) {
                            if ((vm.client.ERPClientId) !== (vm.orders[0].Order_ERPClientId)) {
                                issues.push(vm.createValidationIssue("Parcel.Client", String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.NotSameClient")), "has-error"));
                            }
                        }
                    }

                    if (vm.formData.Parcel.DiscrepancyTypeId) {

                        if (!vm.formData.Parcel.ParcelsStorageLocation.StorageTemperatureId) {
                            issues.push(vm.createValidationIssue("Parcel.StorageTemperature", String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.StorageTemperatureRequired")), "has-error"));
                        }
                      
                        var locationArray = [];
                        if (!vm.formData.Parcel.ParcelsStorageLocation.Room) {
                            issues.push(vm.createValidationIssue("Parcel.StorageLocationRoom", "", "has-error"));
                            locationArray.push("Room");
                        } 

                        if (!vm.formData.Parcel.ParcelsStorageLocation.Freezer) {
                            issues.push(vm.createValidationIssue("Parcel.StorageLocationFreezer","", "has-error"));
                            locationArray.push("Freezer");
                        } 
                        if (!vm.formData.Parcel.ParcelsStorageLocation.Shelf) {
                            issues.push(vm.createValidationIssue("Parcel.StorageLocationShelf", "", "has-error"));
                            locationArray.push("Shelf");
                        } 

                        if (!vm.formData.Parcel.ParcelsStorageLocation.Crate) {
                            issues.push(vm.createValidationIssue("Parcel.StorageLocationCrate", "", "has-error"));
                            locationArray.push("Crate");
                        }


                        if (locationArray.length > 0) {
                            issues.push(vm.createValidationIssue("Parcel.StorageLocation", String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.StorageLocationRequired")) + locationArray.join(", ") + String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.StorageLocations")), "has-error"));
                        }

                    }

                    if (issues.length > 0) {
                        var fieldIssues = [];
                        issues.forEach(function(issue) {
                            var fieldIssueExists = false;
                            fieldIssues.forEach(function(fieldIssue) {
                                if(fieldIssue.field === issue.field) {
                                    fieldIssueExists = true;
                                    fieldIssue.message += ("  " + issue.message);
                                }
                            });
                            if (!fieldIssueExists) {
                                fieldIssues.push(issue);
                            }
                        });

                        vm.infoText = vm.createValidationInfoText(issues);
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true);

                        vm.validationIssues = fieldIssues;
                    } else {
                        if (displayOkMessage || false) {
                            toastr.success(String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.ValidationOkText")));
                        }
                    }
                };

                vm.getFieldValidationIssue = function (field) {
                    var fieldIssue = vm.createValidationIssue("", "", "");  //Need empty issue - including cssClass
                    if ((vm.validationIssues) && (vm.validationIssues.length > 0)) {
                        for (var i = 0; i < vm.validationIssues.length; i++) {
                            if (vm.validationIssues[i].field === field) {
                                fieldIssue = vm.validationIssues[i];
                                break;
                            }
                        }
                    }
                    return fieldIssue;
                }

                vm.save = function () {
                    vm.validateFormData();

                    vm.formData.Parcel.ParcelsArrivalConditions = [];
                    if (vm.formData.Parcel.ArrivalConditions) {
                        for (var i = 0; i < vm.formData.Parcel.ArrivalConditions.length; i++) {
                            vm.formData.Parcel.ParcelsArrivalConditions.push({ ArrivalConditionId: vm.formData.Parcel.ArrivalConditions[i]});
                        }
                    }

                    vm.formData.Parcel.SenderId = vm.selectedsender.Id;
                    if (vm.validationIssues.length === 0) {
                        if (vm.formData.Parcel.Id) {
                            parcelManageApi.update({ id: vm.parcelId }, vm.formData.Parcel).$promise.then(
                             function(response) {
                                 vm.formData.Parcel.RowVersion = response.RowVersion;
                                 toastr.success(String($filter("trustedtranslate")("Views.Parcels.Manage.UpdateOkText")));
                                 vm.showSubmissionResponse(true);
                             }, function (result) {
                                 vm.showSubmissionResponse(false, result.data);
                             });
                        } else {
                            parcelManageApi.save(vm.formData.Parcel).$promise.then(
                                function(response) {
                                    vm.formData.Parcel.Id = response.EntityId;
                                    vm.parcelId = response.EntityId;
                                    vm.formData.Parcel.RowVersion = response.RowVersion;
                                    vm.addDocumentDisabled = false;
                                    toastr.success(String($filter("trustedtranslate")("Views.Parcels.Manage.SaveOkText")));
                                    vm.showSubmissionResponse(true);
                                }, function (result) {
                                    vm.addDocumentDisabled = true;
                                    vm.showSubmissionResponse(false, result.data);
                                });
                        }
                    }
                };

                vm.cancel = function () {
                    vm.appCallback('cancel', { });
                };

                vm.showSubmissionResponse = function (success, message) {
                    if(success) {
                        vm.appCallback('saveOk', { });
                    } else {
                        var issues = [];
                        issues.push(vm.createValidationIssue("", message, "has-error"));
                        vm.infoText = vm.createValidationInfoText(issues);
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true, true);
                    }
                };

                if (vm.parcelId && vm.parcelId.length > 0) {
                    parcelQueryApi.getParcelById(vm.parcelId).then(function(response) {
                        vm.formData.Parcel = response.results[0];
                        //ToDo : Remove the Hard Coded value of Received and replace with Enum value from Server                      
                        vm.formData.Parcel.RegistrationPhaseName = "Received";
                        vm.formData.Parcel.LabSiteCode = response.results[0].LabSite_Code;
                        vm.formData.Parcel.CourierId = response.results[0].Courier_Id;
                        vm.formData.Parcel.ReceptionistName = response.results[0].User_UserDetail_FirstName + ' ' + response.results[0].User_UserDetail_LastName;
                        vm.formData.Parcel.ArrivalConditions = [];
                        for (var i = 0; i < response.results[0].ParcelsArrivalConditions.length; i++) {
                            vm.formData.Parcel.ArrivalConditions.push(response.results[0].ParcelsArrivalConditions[i].ArrivalConditionId);
                        }
                        if (!vm.formData.Parcel.ParcelsStorageLocation) {
                            vm.formData.Parcel.ParcelsStorageLocation = { };
                            vm.formData.Parcel.ParcelsStorageLocation.StorageTemperatureId = null;
                            vm.formData.Parcel.ParcelsStorageLocation.Room = null;
                            vm.formData.Parcel.ParcelsStorageLocation.Freezer = null;
                            vm.formData.Parcel.ParcelsStorageLocation.Shelf = null;
                            vm.formData.Parcel.ParcelsStorageLocation.Crate = null;
                            vm.formData.Parcel.ParcelsStorageLocation.Comment = null;
                        }
                        vm.formData.Parcel.ArrivalTemperatureId = response.results[0].ArrivalTemperatureId;
                        vm.formData.Parcel.SpecialHandlingId = response.results[0].SpecialHandlingId;
                        vm.formData.Parcel.ArrivalComments = response.results[0].ArrivalComments;
                        fillExistingOrdersForParcel(vm.parcelId);
                        if (vm.formData.Parcel.SenderId != null) {
                            fillClientFromClientSenderId(vm.formData.Parcel.SenderId);
                            fillSenderFromClientSenderId(vm.formData.Parcel.SenderId);
                        }
                        if (vm.formData.Parcel.ParcelsAttachments) {
                            vm.documents = vm.formData.Parcel.ParcelsAttachments;
                        }
                        vm.addDocumentDisabled = false;
                    }).catch(function(error) {
                        console.log(error);
                    });

                    vm.IsParcelUpdate = true;
                    vm.headerText = String($filter("trustedtranslate")("Views.Parcels.Manage.UpdateParcel"));

                } else {
                    vm.formData.Parcel = {
                        "Id": null,
                        "ParcelId": null,
                        "RegistrationPhase": 0,
                        "RegistrationPhaseName": "Received",
                        "ReceptionistName": "",
                        "ReceivedLocation": "",
                        "RegisteredDate": null,
                        "ReceivedDate": null,
                        "CourierId": null,
                        "CourierTrakingNo": null,
                        "SenderId": null,
                        "ArrivalConditions": null,
                        "ArrivalTemperatureId": null,
                        "SpecialHandlingId": null,
                        "DiscrepancyTypeId": null,
                        "ArrivalComments": null
                    };

                    vm.formData.Parcel.ParcelsOrders = [];
                    vm.formData.Parcel.ParcelsArrivalConditions = [];
                    vm.IsParcelUpdate = false;
                    if (userProfileApi.currentUser) {
                        vm.formData.Parcel.ReceptionistName = userProfileApi.currentUser.FullName;
                    }
                    vm.formData.Parcel.LabSiteCode = (userProfileApi.defaultLabsite === null) ? "" : userProfileApi.defaultLabsite.Code;
                    vm.formData.Parcel.ReceivedLabsiteId = (userProfileApi.defaultLabsite === null) ? "" : userProfileApi.defaultLabsite.Id;
                    vm.formData.Parcel.ParcelsStorageLocation = { };
                    vm.formData.Parcel.ParcelsStorageLocation.StorageTemperatureId = null;
                    vm.formData.Parcel.ParcelsStorageLocation.Room = null;
                    vm.formData.Parcel.ParcelsStorageLocation.Freezer = null;
                    vm.formData.Parcel.ParcelsStorageLocation.Shelf = null;
                    vm.formData.Parcel.ParcelsStorageLocation.Crate = null;
                    vm.formData.Parcel.ParcelsStorageLocation.Comment = null;
                    vm.headerText = String($filter("trustedtranslate")("Views.Parcels.Manage.CreateParcel"));
                }

                loadMasterData();

                $scope.$watch('infoVisible', handleInfoVisibleUpdates, true);
                $scope.$watch('infoText', handleInfoTextUpdates, true);
                $scope.$watch('infoClass', handleInfoClassUpdates, true);

            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        }
    };

    angular.module('app.sampleManagement.parcelReception.manage')
           .directive('parcelReceptionManage', parcelReceptionManage);

    parcelReceptionManage.$inject = ['$sce', '$filter', '$translate', '$modal', 'recursionHelper', 'masks', 'enums', 'parcelManageApi', 'courierManageApi', 'userProfileApi', 'parcelQueryApi', 'courierQueryApi', 'orderQueryApi', 'clientQueryApi', 'samplemanagementmasterQueryApi'];
})();

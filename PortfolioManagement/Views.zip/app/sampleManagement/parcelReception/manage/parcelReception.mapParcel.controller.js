﻿(function () {
    angular
        .module('app.sampleManagement.parcelReception.manage')
        .controller('mapParcelCtrl', mapParcelCtrl);

    mapParcelCtrl.$inject = ['$scope', '$stateParams', '$translate', '$filter', '$timeout', '$modal'];

    function mapParcelCtrl($scope, $stateParams, $translate, $filter, $timeout, $modal) {
        var vm = this;


        //The following is used to set and open the info panel of the form
        vm.infoVisible = false;
        vm.infoText = "";
        vm.infoClass = "alert alert-info";

        //Input scope values from calling page
        vm.inputScope = $scope.inputScope || $stateParams.inputScope || {};
        //vm.quoteLines = sessionStorage.getItem("quoteLines");
        vm.appCallback = function (callbackAction, callbackScope) {
        }
    };
})();
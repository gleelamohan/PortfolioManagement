angular
    .module('app.sampleManagement.parcelReception.manage', []);
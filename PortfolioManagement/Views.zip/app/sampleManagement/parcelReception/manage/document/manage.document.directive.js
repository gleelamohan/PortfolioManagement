﻿(function () {

    function manageDocument($sce, $filter, $translate, recursionHelper, parcelManageApi, parcelQueryApi, toastr) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                isModal: "@ismodal",
                inputScope: "=inputscope",
                appCallback: "=appcallback",
                infoVisible: "=infovisible",
                infoText: "=infotext",
                infoClass: "=infoclass"
            },
            controller: function ($scope) {
                var vm = this;
                vm.templateUrl = "/app/sampleManagement/parcelReception/manage/document/manageDocument.html";
                vm.isModal = Boolean($scope.isModal || "false");
                vm.inputScope = $scope.inputScope;
                vm.appCallback = $scope.appCallback;
                vm.helpVisible = false;
                vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.Upload"));
                vm.saveDisabled = true;
                vm.formData = {};
                vm.formData.attachment = {
                    "EntityId": null,
                    "Title": null,
                    "Description": '',
                    "Parcel_RowVersion": null
                };
                vm.documentId = $scope.inputScope;
                vm.fileFilterType = window.app.config.FileTypes;
                vm.fileMaxSize = window.app.config.MaxFileSize;
                vm.files = [];

                //DDBS ibox-tools Settings
                vm.iboxToolsShowHideVisible = vm.isModal === true ? false : true;
                vm.iboxToolsInfoVisible = false;
                vm.iboxToolsInfoToggledExternally = false;

                vm.iboxToolsValidationToggledExternally = false;
                vm.iboxToolsFilterVisible = false;
                vm.iboxToolsSettingsVisible = false;
                vm.iboxToolsHelpVisible = true;
                vm.iboxToolsToggleInfo = function () {
                    vm.infoVisible = !vm.infoVisible;
                };
                vm.iboxToolsToggleFilter = function () { };
                vm.iboxToolsToggleSettings = function () { };
                vm.iboxToolsToggleHelp = function () {
                    vm.helpVisible = !vm.helpVisible;
                };
                vm.validationIssues = [];
                vm.iboxToolsValidationVisible = true;

                //#region local functions

                var selectedFile = [];

                var supportedFileExtensions = [];

                function handleInfoVisibleUpdates(newData) {
                    vm.toggleInfoVisibility(newData || false);
                };

                function handleInfoTextUpdates(newData) {
                    vm.infoText = newData || "";
                };

                function handleInfoClassUpdates(newData) {
                    vm.infoClass = newData || "alert alert-info";
                };

                function validateSelectedFile(file) {
                    var fileIssues = [];

                    var fileExt = "." + file.name.split(".").pop().toLowerCase();

                    if (file) {
                        if ((supportedFileExtensions.indexOf(fileExt)) === -1) {
                            var stringValidationMessageUnsupportedFormat = String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.NotSupportedFileFormat")) + vm.fileFilterType + String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.NotSupportedFileFormat1"));
                            fileIssues.push(vm.createValidationIssue("Document.Location", stringValidationMessageUnsupportedFormat, "has-error"));
                        } else {
                            //Max size mentioned in web config is in MB's.Hence to do comparision, converting the selected file size to MB .
                            if (file.size > (vm.fileMaxSize * 1048576)) {
                                var stringValidationMessageMaxSize = String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.ExceedesFileSize") + vm.fileMaxSize + String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.ExceedesFileSizeUnit")));
                                fileIssues.push(vm.createValidationIssue("Document.Location", stringValidationMessageMaxSize, "has-error"));
                            }
                            else if (file.size === 0) {
                                fileIssues.push(vm.createValidationIssue("Document.Location", String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.EmptyFileNotAllowed")), "has-error"));
                            }

                        }
                    }
                    return fileIssues;
                };

                function validateFile(selectedfile) {
                    vm.validationIssues = [];
                    var hasIssuses = validateSelectedFile(selectedfile);
                    if (hasIssuses.length > 0) {
                        vm.infoText = vm.createValidationInfoText(hasIssuses);
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true);
                        vm.validationIssues = hasIssuses;
                        selectedFile = selectedfile;
                    }
                }

                //#endregion

                $scope.getFileDetails = function (e) {
                    vm.files = [];
                    for (var i = 0; i < e.files.length; i++) {
                        validateFile(e.files[i]);
                        if (vm.validationIssues.length === 0) {
                            vm.files.push(e.files[i]);
                        }
                    }
                };                

                vm.toggleInfoVisibility = function (visible, ignoreModalCheck) {
                    vm.infoVisible = ((!(ignoreModalCheck || false)) && (vm.isModal)) ? false : visible || false;
                    vm.iboxToolsInfoVisible = visible || false;
                    vm.iboxToolsInfoToggledExternally = vm.infoVisible;
                }

                vm.formChanged = function () {
                    vm.saveDisabled = false;
                }

                vm.resetInfo = function () {
                    vm.infoText = "";
                    vm.infoClass = "alert alert-info";
                    vm.toggleInfoVisibility(false);
                }

                vm.createValidationIssue = function (field, message, cssClass) {
                    return {
                        "field": field || "",
                        "message": message || "",
                        "cssClass": cssClass || ""
                    };
                }

                vm.createValidationInfoText = function (issues) {
                    var infoText = "";

                    if ((issues) && (issues.length > 0)) {
                        infoText = "<p>" +
                           String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.ValidationHeaderText")) +
                           " " +
                           String($filter("trustedtranslate")("Common.Maintenance.ValidationHeaderSuffix")) +
                           "</p><ul>";

                        issues.forEach(function (issue) {
                            infoText += ("<li>" + issue.message + "</li>");
                        });

                        infoText += "</ul>";
                    }
                    return infoText;
                }

                vm.validationCallback = function () {
                    vm.validateFormData(true);
                }

                vm.getFieldValidationIssue = function (field) {
                    var fieldIssue = vm.createValidationIssue("", "", "");
                    if ((vm.validationIssues) && (vm.validationIssues.length > 0)) {
                        for (var i = 0; i < vm.validationIssues.length; i++) {
                            if (vm.validationIssues[i].field === field) {
                                fieldIssue = vm.validationIssues[i];
                                break;
                            }
                        }
                    }
                    return fieldIssue;
                }

                vm.validateFormData = function (displayOkMessage) {
                    vm.resetInfo();
                    vm.validationIssues = [];
                    var issues = [];
                    var fileIssues = [];
                    if (vm.isDocumentAdd) {
                        if (vm.files[0]) {
                            fileIssues = validateSelectedFile(vm.files[0]);
                        } else if (selectedFile.name) {
                            fileIssues = validateSelectedFile(selectedFile);
                        } else {
                            issues.push(vm.createValidationIssue("Document.Location", String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.FileMandatory")), "has-error"));
                        }
                        fileIssues.forEach(function (fileIssue) {
                            issues.push(fileIssue);
                        });
                    }

                    if (!vm.formData.attachment.Title) {
                        issues.push(vm.createValidationIssue("Document.Title", String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.TitleMandatory")), "has-error"));
                    }
                    if (vm.formData.attachment.Title && vm.formData.attachment.Title.length < 2) {
                        issues.push(vm.createValidationIssue("Document.Title", String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.TitleMinLength")), "has-error"));
                    }


                    if (issues.length > 0) {
                        vm.infoText = vm.createValidationInfoText(issues);
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true);

                        if (issues.length > 0) {
                            var fieldIssues = [];
                            issues.forEach(function (issue) {
                                var fieldIssueExists = false;
                                fieldIssues.forEach(function (fieldIssue) {
                                    if (fieldIssue.field === issue.field) {
                                        fieldIssueExists = true;
                                        fieldIssue.message = fieldIssue.message + issue.message;
                                    }
                                });
                                if (!fieldIssueExists) {
                                    fieldIssues.push(issue);
                                }
                            });


                            vm.validationIssues = fieldIssues;
                        }
                    } else {
                        if (displayOkMessage || false) {
                            toastr.success(String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.ValidationOkText")));
                        }
                    }
                };

                vm.save = function () {
                    vm.validateFormData();

                    if (vm.validationIssues.length === 0) {
                        if (!vm.isDocumentAdd) {
                            parcelManageApi.updateattachment({ entityId: vm.formData.attachment.EntityId, entityRowVersion: vm.formData.attachment.Parcel_RowVersion, title: vm.formData.attachment.Title, description: vm.formData.attachment.Description, fileName: vm.formData.attachment.FileName }).$promise.then(function (response) {
                                toastr.success(String($filter("trustedtranslate")("Views.Parcels.Manage.UpdateDocumentText")));
                                vm.showSubmissionResponse(true, response.RowVersion);
                            });
                        } else {
                            var data = new FormData();
                            for (var i in vm.files) {
                                if (vm.files.hasOwnProperty(i)) {
                                    data.append(vm.files[i].name, vm.files[i]);
                                }
                            }
                            parcelManageApi.addattachment({ entityId: vm.formData.attachment.EntityId, entityRowVersion: vm.formData.attachment.Parcel_RowVersion, title: vm.formData.attachment.Title, description: vm.formData.attachment.Description }, data).$promise.then(function (response) {
                                toastr.success(String($filter("trustedtranslate")("Views.Parcels.Manage.AddDocumentText")));
                                vm.showSubmissionResponse(true, response.RowVersion);
                            }, function (result) {
                                vm.showSubmissionResponse(false, null, result.data,null);
                            }
                            );
                        }
                    }
                }

                vm.cancel = function () {
                    vm.appCallback('cancel', {});
                };

                vm.showSubmissionResponse = function (success, rowVersion, message) {
                    vm.documentId = null;
                    if (success) {
                        vm.appCallback('saveOk', { parcelId: vm.formData.attachment.EntityId, rowVersion: rowVersion, title: vm.formData.attachment.Title, description: vm.formData.attachment.Description});
                    } else {
                        var issues = [];
                        issues.push(vm.createValidationIssue("", message, "has-error"));
                        vm.infoText = vm.createValidationInfoText(issues);
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true, true);
                    }              
                };


                if (vm.fileFilterType) {
                    supportedFileExtensions = vm.fileFilterType.split(",");
                }

                if ((vm.inputScope) && (vm.documentId) && (vm.documentId.length > 0) && (!vm.inputScope.parcelId)) {
                    vm.headerText = String($filter("trustedtranslate")("Views.Parcels.Manage.UpdateDocumentTitle"));
                    parcelQueryApi.getAttachmentDetailsByAttachmentlId(vm.documentId).then(function (response) {
                        vm.isDocumentAdd = false;
                        vm.formData.attachment = response.results[0];
                        vm.formData.attachment.EntityId = vm.formData.attachment.ParcelId;
                        if ((vm.formData.attachment.Description === null) || (!vm.formData.attachment.Description)) {
                            vm.formData.attachment.Description = "";
                        }
                        vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.SaveButton"));
                    });
                } else if (vm.inputScope.parcelId) {
                    vm.isDocumentAdd = true;
                    vm.headerText = String($filter("trustedtranslate")("Views.Parcels.Manage.AddDocumentTitle"));
                    vm.formData.attachment.EntityId = vm.inputScope.parcelId;
                    vm.formData.attachment.Parcel_RowVersion = vm.inputScope.rowVersion;

                }


                $scope.$watch('infoVisible', handleInfoVisibleUpdates, true);
                $scope.$watch('infoText', handleInfoTextUpdates, true);
                $scope.$watch('infoClass', handleInfoClassUpdates, true);


            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        }
    };

    angular
         .module('app.sampleManagement.parcelReception.manage')
         .directive('manageDocument', manageDocument);

    manageDocument.$inject = ['$sce', '$filter', '$translate', 'recursionHelper', 'parcelManageApi', 'parcelQueryApi', 'toastr'];


})();

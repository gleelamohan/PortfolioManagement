(function () {

    function parcelReceptionCtrl($scope, $state, $translate, $filter, $timeout, $modal, parcelManageApi, masks, enums, courierManageApi, parcelQueryApi, courierQueryApi) {

        var vm = this;

        vm.searchService = parcelManageApi;

        vm.receivedToDate = moment().format(masks.date.model.moment);
        vm.receivedFromDate = moment().subtract(7, 'days').format(masks.date.model.moment);
        vm.searchService.setDefaultSearchEntryValue("ParcelId");

        function appCallback(callbackAction, callbackScope) {
            var action = callbackAction || null;
            var actionScope = callbackScope || {};
            if (action) {
                if (action === "rowSelect") {
                    if ((actionScope.Id) && (actionScope.Id.length > 0)) {
                        $state.go("sampleManagement.parcelReception.mapParcel", { "inputScope": actionScope });
                    }
                }
                else if (action === "addNew") {
                    $state.go("sampleManagement.parcelReception.mapParcel", { "inputScope": actionScope });
                }
            }
        }

        vm.deleteCallback = function (id) {
            //var inputScope = { Id: id, action: "delete" }
            //vm.openModal(inputScope);

            var callbackAction = "rowSelect";
            var callbackScope = { "Id": id, "isDelete": "true" };
            appCallback(callbackAction, callbackScope);
        }

        vm.editCallback = function (id) {
            //var inputScope = { Id: id, action: "edit" }
            //vm.openModal(inputScope);


            var callbackAction = "rowSelect";
            var callbackScope = { Id: id };
            appCallback(callbackAction, callbackScope);

        }


        vm.addCallback = function () {
            //var inputScope = { Id: null, action: "add" }
            //vm.openModal(inputScope);
            var callbackAction = "addNew";
            var callbackScope = { Id: null };
            appCallback(callbackAction, callbackScope);


        }

        var courierNameConfig = {
            "allowDuplicates": false,
            "placeholder": String($filter("trustedtranslate")("Views.Parcels.Manage.CourierNamePlaceHolder")),
            "optionsValueField": "Id",
            "optionsLabelField": "Name",
            "optionsListScrollOnWideOptions": true,
            "width": "100%"
        };

        var parcelPhasesConfig = {
            "allowDuplicates": false,
            "placeholder": String($filter("trustedtranslate")("Entity.Parcel.RegistrationPhase.InputPlaceholder")),
            "optionsValueField": "Value",
            "optionsLabelField": "Text",
            "width": "100%"
        }

        vm.gsc123 = function () {
            return {
                "templateConfig": {
                    "pagetitle": "Views.Parcels.Search.TemplateConfig.PageTitle",
                    "searchEntryPanelTitle": "Views.Parcels.Search.TemplateConfig.SearchEntryPanelTitle",
                    "addNewText": "Views.Parcels.Search.TemplateConfig.AddNewText",
                    "searchEntryOptionsTemplateUrl": "/app/sampleManagement/parcelReception/manage/parcelReception.search.html"
                },
                "searchEntryConfig": {
                    "helpText": "Views.Parcels.Search.SearchEntryConfig.HelpText",
                    "displaySearchTermLabel": true,
                    "defaultSearchTermLabel": "Views.Parcels.Search.SearchEntryConfig.DefaultSearchTermLabel",
                    "defaultSearchTerm": "",
                    "defaultSearchTermPlaceholder": "Views.Parcels.Search.SearchEntryConfig.DefaultSearchTermPlaceholder",
                    "defaultSearchEntryOptionsTitle": "Views.Parcels.Search.SearchEntryConfig.DefaultSearchEntryOptionsTitle",
                    "searchTermMinLength": 0,
                    "searchTermMaxLength": 16,
                    "includeSearchEntryOptions": true,
                    "enableSearchEntryOptionsToggle": true,
                    "SearchEntryOptionsConfig": {
                        "ParcelPhasesConfig": parcelPhasesConfig,
                        "ParcelPhaseEnums": enums.ParcelRegistrationPhaseEnums,
                        "CourierNameConfig": courierNameConfig,
                        "ConfigServices": [courierQueryApi],
                        "ConfigServiceResults": []
                    },
                    "defaultSearchScope": {
                        "ReceivedFromDate": vm.receivedFromDate,
                        "ReceivedToDate": vm.receivedToDate,
                        "ParcelPhaseId": null,
                        "CourierId": null
                    }
                },
                "searchResultsConfig": {
                    "helpText": "Views.Parcels.Search.SearchResultsConfig.HelpText",
                    "noResultsText": "Search.SearchResultsNoResultsText",
                    "viewType": "standard", //standard or user  
                    "pageLengthOptions": [
                        { "label": "10", "value": 10 },
                        { "label": "25", "value": 25 },
                        { "label": "50", "value": 50 },
                        { "label": "100", "value": 100 },
                        { "label": "All", "value": -1 }
                    ],
                    "datatableConfig": {
                        "destroy": true,
                        "dom": "Rrtip",
                        "colReorder": {
                            "realtime": true, //Realtime ordering in the UI
                            "order": [0, 1, 2, 3, 4, 5, 6, 7] //initial column ordering
                        },
                        "columnDefs": [
                        {
                            "targets": "_all",
                            "cellType": "th",
                            "orderable": "true",
                            "searchable": "true"
                        },
                        {
                            "targets": 0,
                            "name": "ParcelId",
                            "title": String($filter("trustedtranslate")("Entity.Parcel.ID.ColumnText")),
                            "data": null,
                            //"render" : "ParcelId",
                            "render": function (data, type, full, meta) {
                                return '<a onclick="angular.element(this).scope().appCallback(\'rowSelect\', { \'Id\': \'' + full.Id + '\' });" title="">' + full.ParcelId + '</a>';
                            },
                            "type": "html",
                            "width": "10%"
                        },
                        {
                            "targets": 1,
                            "title": String($filter("trustedtranslate")("Entity.Parcel.RegistrationPhase.ColumnText")),
                            "data": null,
                            //ToDo : Remove the Hard Coded value of Received and replace with Enum value from Server
                            "render": function (data, type, full, meta) {
                                return "Received";
                            },
                            "type": "html",
                            "className": "wordWrap",
                            "width": "12%"
                        },
                            {
                                "targets": 2,
                                "name": "User_UserDetail_FirstName",
                                "title": String($filter("trustedtranslate")("Entity.Parcel.ReceptionistName.ColumnText")),
                                "data": null,
                                //"render": { "_": "User_UserDetail_FirstName" + " " + "User_UserDetail_LastName" },
                                "render": function (data, type, full, meta) {
                                    return full.User_UserDetail_FirstName + " " + full.User_UserDetail_LastName;
                                },
                                "type": "html",
                                "className": "wordWrap",
                                "width": "15%"
                            },
                            {
                                "targets": 3,
                                "name": "LabSite_Code",
                                "title": String($filter("trustedtranslate")("Entity.Parcel.ReceivedLocation.ColumnText")),
                                "data": null,
                                "render": { "_": "LabSite_Code" },
                                "type": "html",
                                "width": "12%"
                            },
                            {
                                "targets": 4,
                                "name": "RegisteredDate",
                                "title": String($filter("trustedtranslate")("Entity.Parcel.RegisteredDate.ColumnText")),
                                "data": null,
                                 //"render": { "_": "RegisteredDate" },
                                "render": function (data, type, full, meta) {
                                    //ToDo : Remove UTC from the filter attribute , after date time issue fixed by Nirjanan in efDateTime.
                                    return full.RegisteredDate !== undefined && full.RegisteredDate !== null ? moment(moment.utc(full.RegisteredDate).toDate()).format(masks.datetime.moment) : "";
                                },
                                "type": "html",
                                "width": "15%"
                            },
                            {
                                "targets": 5,
                                "name": "ReceivedDate",
                                "title": String($filter("trustedtranslate")("Entity.Parcel.ReceivedDate.ColumnText")),
                                "data": null,
                                //"render": { "_": "ReceivedDate" },
                                "render": function (data, type, full, meta) {
                                    return full.ReceivedDate !== undefined && full.ReceivedDate !== null ? moment(moment.utc(full.ReceivedDate).toDate()).format(masks.datetime.moment) : "";
                                },
                                "type": "html",
                                "width": "15%"
                            },
                            {
                                "targets": 6,
                                "name": "Courier_Name",
                                "title": String($filter("trustedtranslate")("Entity.Parcel.CourierName.ColumnText")),
                                "data": null,
                                "render": { "_": "Courier_Name" },
                                "type": "html",
                                "width": "10%"
                            },
                             {
                                 "targets": 7,
                                 "name": "CourierTrakingNo",
                                 "title": String($filter("trustedtranslate")("Entity.Parcel.CourierNo.ColumnText")),
                                 "data": null,
                                 "render": { "_": "CourierTrakingNo" },
                                 "type": "html",
                                 "width": "12%"
                             }

                        ],
                        "deferRender": true,
                        "language": {
                            "emptyTable": String($filter("trustedtranslate")("Views.Parcels.Search.SearchResultsConfig.DatatableConfig.Language.EmptyTable")),
                            "info": String($filter("trustedtranslate")("Views.Parcels.Search.SearchResultsConfig.DatatableConfig.Language.Info")),
                            "infoEmpty": String($filter("trustedtranslate")("Views.Parcels.Search.SearchResultsConfig.DatatableConfig.Language.InfoEmpty")),
                            "infoFiltered": String($filter("trustedtranslate")("Views.Parcels.Search.SearchResultsConfig.DatatableConfig.Language.InfoFiltered")),
                            "zeroRecords": String($filter("trustedtranslate")("Views.Parcels.Search.SearchResultsConfig.DatatableConfig.Language.ZeroRecords"))
                        },
                        "lengthChange": true,
                        "order": [[4, "desc"]],
                        "paging": true,
                        "pageLength": 10,
                        "pagingType": "simple_numbers",
                        "searching": true
                    }
                }
            }
        };

        vm.searchMethod123 = function (searchObject) {
            return parcelQueryApi.getParcels(searchObject);
        };

    }

    angular.module('app.sampleManagement.parcelReception.manage')
     .controller('parcelReceptionCtrl', parcelReceptionCtrl);

    parcelReceptionCtrl.$inject = ['$scope', '$state', '$translate', '$filter', '$timeout', '$modal', 'parcelManageApi', 'masks', 'enums', 'courierManageApi', 'parcelQueryApi', 'courierQueryApi'];

})();
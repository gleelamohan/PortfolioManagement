﻿(function () {
    angular
        .module('app.sampleManagement.parcelReception.manage')
        .directive('searchOrder', searchOrder);

    searchOrder.$inject = ['$sce', '$filter', '$translate', 'recursionHelper', 'toastr', 'masks', 'orderQueryApi', 'clientQueryApi'];

    function searchOrder($sce, $filter, $translate, recursionHelper, toastr, masks, orderQueryApi, clientQueryApi) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                isModal: "@ismodal",
                inputScope: "=inputscope",
                appCallback: "=appcallback",
                infoVisible: "=infovisible",
                infoText: "=infotext",
                infoClass: "=infoclass"
            },
            controller: function ($scope, $element, $attrs) {
                var vm = this;
                vm.currentLanguage = $translate.use();

                vm.templateUrl = "/app/sampleManagement/parcelReception/manage/order/searchOrder.html";
                vm.isModal = Boolean($scope.isModal || "false");
                vm.inputScope = $scope.inputScope;
                vm.appCallback = $scope.appCallback;
                vm.helpVisible = false;
                vm.isDeleteFlag = false;
                vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.SaveButton"));
                vm.helpText = String($filter("trustedtranslate")("Views.Labsites.Manage.HelpText"));

                vm.saveDisabled = true;
                vm.formData = {};

                vm.iboxToolsValidationVisible = false;


                $scope.$watch('infoVisible', handleInfoVisibleUpdates, true);
                $scope.$watch('infoText', handleInfoTextUpdates, true);
                $scope.$watch('infoClass', handleInfoClassUpdates, true);

                vm.showOrderId = false;
                vm.showQuoteId = false;
                vm.showEurofinsId = true;
                vm.showClientId = false;
                vm.showContactId = false;

                vm.toggleInfoVisibility = function (visible, ignoreModalCheck) {
                    //vm.infoVisible = ((!(ignoreModalCheck || false)) && (vm.isModal)) ? false : visible || false;
                    vm.infoVisible = visible;
                    vm.iboxToolsInfoVisible = visible || false;
                    vm.iboxToolsInfoToggledExternally = vm.infoVisible;
                }


                vm.criteriaConfig = {
                    "allowNull": false,
                    "allowDuplicates": false,
                    "placeholder": "Select one order criteria",
                    "optionsValueField": "Value",
                    "optionsLabelField": "Text",
                    "width": "100%"
                };

                vm.criteria = [{ Text: "Eurofins Bar Code ID", Value: "EurofinsBarcodeId" }, { Text: "Order ID", Value: "OrderNo" },
                                { Text: "Quote ID", Value: "QuoteId" }, { Text: "Client ID", Value: "ERPClientId" }];

                vm.selectedCriteria = "EurofinsBarcodeId";
                vm.disableFindButton = true;

                vm.criteriaChanged = function () {

                    vm.EurofinsBarCode = vm.OrderId = vm.QuoteId = vm.client = vm.contact = "";

                    vm.disableFindButton = true;

                    if (vm.selectedCriteria === "EurofinsBarcodeId") {
                        vm.showOrderId = false;
                        vm.showQuoteId = false;
                        vm.showEurofinsId = true;
                        vm.showClientId = false;
                        vm.showContactId = false;
                    }
                    else if (vm.selectedCriteria === "OrderNo") {
                        vm.showOrderId = true;
                        vm.showQuoteId = false;
                        vm.showEurofinsId = false;
                        vm.showClientId = false;
                        vm.showContactId = false;
                    }
                    else if (vm.selectedCriteria === "QuoteId") {
                        vm.showOrderId = false;
                        vm.showQuoteId = true;
                        vm.showEurofinsId = false;
                        vm.showClientId = false;
                        vm.showContactId = false;
                    }
                    else if (vm.selectedCriteria === "ERPClientId") {
                        vm.showOrderId = false;
                        vm.showQuoteId = false;
                        vm.showEurofinsId = false;
                        vm.showClientId = true;
                        vm.showContactId = true;
                    }
                }

                vm.orders = [];
                orderQueryApi.getOrders(vm.inputScope.Id).then(function (response) {
                    vm.tempOrders = response.results;
                });

                vm.orderConfig = {
                    "resultsConfig": {
                        "rowSelect": true, //For "true" the first column of the table needs to render an anchor tag which will be used by the entire row when it is selected.
                        "helpText": "Views.Parcels.Search.SearchResultsConfig.HelpText",
                        "noResultsText": "Search.SearchResultsNoResultsText",
                        "viewType": "standard", //standard or user  
                        "pageLengthOptions": [
                            { "label": "5", "value": 5 },
                            { "label": "10", "value": 10 },
                            { "label": "15", "value": 15 },
                            { "label": "25", "value": 25 },
                            { "label": "All", "value": -1 }
                        ],
                        "datatableConfig": {
                            "destroy": true,
                            "dom": "Rrtip",
                            "colReorder": {
                                "realtime": true, //Realtime ordering in the UI
                                "order": [0, 1, 2, 3, 4, 5] //initial column ordering
                            },
                            "columnDefs": [
                                {
                                    "targets": "_all",
                                    "cellType": "td",
                                    "orderable": "true",
                                    "searchable": "true"
                                },
                                {
                                    "targets": 0,
                                    "name": "OrderNo",
                                    "title": "Order Id",
                                    "data": null,
                                    "render": { "_": "OrderNo" },
                                    "type": "html",
                                    "width": "20%"
                                },
                                {
                                    "targets": 1,
                                    "name": "EurofinsBarcodeId",
                                    "title": "Eurofins Barcode ID",
                                    "data": null,
                                    "render": { "_": "EurofinsBarcodeId" },
                                    "type": "html",
                                    "width": "22%"
                                },
                                {
                                    "targets": 2,
                                    "name": "QuoteId",
                                    "title": "Quote Id",
                                    "data": null,
                                    "render": { "_": "QuoteId" },
                                    "type": "html",
                                    "width": "20%"
                                },
                                {
                                    "targets": 3,
                                    "name": "ERPClientId",
                                    "title": "Client Id",
                                    "data": null,
                                    "render": { "_": "ERPClientId" },
                                    "type": "html",
                                    "width": "18%"
                                },
                                {
                                    "targets": 4,
                                    "name": "OrderConfirmationDate",
                                    "title": "Confirmation Date",
                                    "data": null,
                                    "render": function (data, type, full, meta) {
                                        return full.OrderConfirmationDate !== undefined && full.OrderConfirmationDate !== null ? $filter('date')(full.OrderConfirmationDate, masks.date.angular) : "";
                                    },
                                    "type": "html",
                                    "width": "25%"
                                },
                                {
                                    "targets": 5,
                                    "name": "Select",
                                    "title": "",
                                    "data": null,
                                    "render": function (data, type, full, meta) {
                                        return '<input type="checkbox" onchange="angular.element(this).scope().$parent.vm.selectOrderCallback(\'rowChecked\',{\'OrderNo\': \'' + full.OrderNo + ':' + full.ERPClientId + '\'  },this);" value="' + full.OrderNo + '">';
                                    },
                                    "type": "html",
                                    "width": "10px",
                                    "orderable": false
                                }
                            ],
                            "deferRender": true,
                            "language": {
                                "emptyTable": String($filter("trustedtranslate")("Views.Orders.Search.SearchResultsConfig.DatatableConfig.Language.EmptyTable")),
                                "info": String($filter("trustedtranslate")("Views.Orders.Search.SearchResultsConfig.DatatableConfig.Language.Info")),
                                "infoEmpty": String($filter("trustedtranslate")("Views.Orders.Search.SearchResultsConfig.DatatableConfig.Language.InfoEmpty")),
                                "infoFiltered": String($filter("trustedtranslate")("Views.Orders.Search.SearchResultsConfig.DatatableConfig.Language.InfoFiltered")),
                                "zeroRecords": String($filter("trustedtranslate")("Views.Orders.Search.SearchResultsConfig.DatatableConfig.Language.ZeroRecords"))
                            },
                            "lengthChange": true,
                            "order": [[4, "desc"]],
                            "paging": true,
                            "pageLength": 5,
                            "pagingType": "simple_numbers",
                            "searching": true
                        }

                    }
                };

                vm.mapParcelToOrderGridConfig = vm.orderConfig.resultsConfig.datatableConfig;

                clientQueryApi.getClients(vm.inputScope.Id).then(function (response) {
                    vm.clients = [];
                    if (response.results) {
                        for (var i = 0; i < response.results.length; i++) {
                            var client = {
                                Id: response.results[i].Id,
                                ERPClientId: response.results[i].ERPClientId,
                                Name: response.results[i].Name,
                                LastSyncOn: response.results[i].LastSyncOn,
                                FullNameWithERPClientId: response.results[i].ERPClientId + '-' + response.results[i].Name
                            };
                            vm.clients.push(client);
                        }
                    }
                });

                vm.resetInfo = function () {
                    vm.infoText = "";
                    vm.infoClass = "alert alert-info";
                    vm.toggleInfoVisibility(false);
                }

                vm.clearContactInfo = function () {
                    if (vm.client == undefined || vm.client == null || vm.client.ERPClientId == undefined || vm.client.ERPClientId == null) {
                        vm.contact = null;
                        vm.contacts = [];
                    }

                    if (vm.client === "") {
                        vm.disableFindButton = true;
                    }

                }


                vm.fillClientInfo = function (item, model, label) {
                    vm.disableFindButton = false;
                    vm.contact = "";
                    vm.PopulateClientRelatedContacts(item.Id);
                }

                vm.fillContactInfo = function (item, model, label) {
                    vm.disableFindButton = false;
                }

                vm.PopulateClientRelatedContacts = function (selectedClientId) {

                    clientQueryApi.getContactsByClientId(selectedClientId).then(function (response) {
                        vm.contacts = [];
                        if (response.results) {
                            for (var i = 0; i < response.results.length; i++) {
                                var contact = {
                                    Id: response.results[i].Id,
                                    ERPContactId: response.results[i].ERPContactId,
                                    Name: response.results[i].Name,
                                    LastSyncOn: response.results[i].LastSyncOn,
                                    FullNameWithERPContactId: response.results[i].ERPContactId + '-' + response.results[i].Name
                                };
                                vm.contacts.push(contact);
                            }
                        }
                    });
                }


                vm.selectedOrders = [];

                vm.selectOrderCallback = function (callbackAction, callbackScope, cbxCtrl) {
                    var action = callbackAction || null;
                    var actionScope = callbackScope || {};
                    if (action === "rowChecked") {
                        if (cbxCtrl.checked) {
                            vm.selectedOrders.push(callbackScope.OrderNo);
                        } else {
                            for (var index = 0; index < vm.selectedOrders.length; index++) {
                                if (vm.selectedOrders[index] === callbackScope.OrderNo) {
                                    vm.selectedOrders.splice(index, 1);
                                    break;
                                }
                            }
                        }
                    }
                }

                function getOrdersBySearch(criteriaKey, criteriaValue) {
                    orderQueryApi.getOrdersBySearch(criteriaKey, criteriaValue).then(function (response) {
                        vm.orders = response.results;
                    });
                }

                function emptyOrders() {
                    vm.orders = [];
                }


                vm.FindOrders = function () {

                    var searchValue = {};

                    switch (vm.selectedCriteria) {
                        case "OrderNo":
                            searchValue = vm.OrderId;
                            break;
                        case "EurofinsBarcodeId":
                            searchValue = vm.EurofinsBarCode;
                            break;
                        case "QuoteId":
                            searchValue = vm.QuoteId;
                            break;
                        case "ERPClientId":
                            searchValue = (vm.client === null || vm.client === undefined || vm.contact === null) ? undefined : { ERPClientId: vm.client.ERPClientId, ERPContactId: vm.contact.ERPContactId };
                            break;
                    }

                    if (searchValue === null || searchValue === undefined || searchValue === "") {
                        emptyOrders();
                    }
                    else {
                        if (vm.selectedCriteria === "ERPClientId") {
                            if (searchValue.ERPClientId === undefined) {
                                emptyOrders();
                            }
                            else if (searchValue.ERPClientId !== undefined && (vm.contact !== "" && vm.contact.ERPContactId === undefined)) {
                                emptyOrders();
                            } else {
                                getOrdersBySearch(vm.selectedCriteria, searchValue);

                            }

                        } else {

                            getOrdersBySearch(vm.selectedCriteria, searchValue);

                        }
                    }
                }

                function handleInfoVisibleUpdates(newData) {
                    vm.toggleInfoVisibility(newData || false);
                };

                function handleInfoTextUpdates(newData) {
                    vm.infoText = newData || "";
                };

                function handleInfoClassUpdates(newData) {
                    vm.infoClass = newData || "alert alert-info";
                };

                //DDBS ibox-tools Settings
                vm.iboxToolsShowHideVisible = vm.isModal === true ? false : true;
                vm.iboxToolsInfoVisible = false;
                vm.iboxToolsInfoToggledExternally = false;

                vm.iboxToolsValidationToggledExternally = false;
                vm.iboxToolsFilterVisible = false;
                vm.iboxToolsSettingsVisible = false;
                vm.iboxToolsHelpVisible = true;
                vm.iboxToolsToggleInfo = function () {
                    vm.infoVisible = !vm.infoVisible;
                };
                vm.iboxToolsToggleFilter = function () { };
                vm.iboxToolsToggleSettings = function () { };
                vm.iboxToolsToggleHelp = function () {
                    vm.helpVisible = !vm.helpVisible;
                };

                vm.validationIssues = [];

                vm.formChanged = function () {
                    vm.disableFindButton = false;
                }

                vm.createValidationIssue = function (field, message, cssClass) {
                    return {
                        "field": field || "",
                        "message": message || "",
                        "cssClass": cssClass || ""
                    };
                }

                vm.createValidationInfoText = function (issues) {
                    var infoText = "";

                    if ((issues) && (issues.length > 0)) {
                        infoText = "<p>" +
                           String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.ParcelMapOrderValidationInfoText")) +
                           "</p><ul>";

                        issues.forEach(function (issue) {
                            infoText += ("<li>" + issue.message + "</li>");
                        });

                        infoText += "</ul>";
                    }
                    return infoText;
                }

                vm.validationCallback = function () {
                    vm.validateFormData(true);
                }

                vm.validateFormData = function (displayOkMessage) {
                    vm.resetInfo();
                    vm.validationIssues = [];
                    var issues = [];

                    // Identify Sender tab validation
                    if ((vm.selectedOrders) && (vm.selectedOrders !== undefined) && (vm.selectedOrders.length > 0)) {
                        var countLen = vm.selectedOrders[0].length;
                        var indOf = vm.selectedOrders[0].indexOf(":") + 1;
                        for (var i = 0; i < vm.selectedOrders.length - 1; i++) {
                            if ((vm.selectedOrders[i].substring(indOf, countLen)) !== (vm.selectedOrders[i + 1].substring(indOf, countLen))) {
                                issues.push(vm.createValidationIssue("Parcel.Client", String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.NotSameClientOrder")), "has-error"));
                                break;
                            }
                        }
                    }

                    if (issues.length > 0) {
                        var fieldIssues = [];
                        issues.forEach(function (issue) {
                            var fieldIssueExists = false;
                            fieldIssues.forEach(function (fieldIssue) {
                                if (fieldIssue.field === issue.field) {
                                    fieldIssueExists = true;
                                    fieldIssue.message += ("  " + issue.message);
                                }
                            });
                            if (!fieldIssueExists) {
                                fieldIssues.push(issue);
                            }
                        });

                        vm.infoText = vm.createValidationInfoText(issues);
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true);
                        vm.validationIssues = fieldIssues;
                    } else {
                        if (displayOkMessage || false) {
                            toastr.success(String($filter("trustedtranslate")("Views.Parcels.Manage.ValidationMessages.ValidationOkText")));
                        }
                    }
                };



                vm.getFieldValidationIssue = function (field) {
                    var fieldIssue = vm.createValidationIssue("", "", "");  //Need empty issue - including cssClass
                    if ((vm.validationIssues) && (vm.validationIssues.length > 0)) {
                        for (var i = 0; i < vm.validationIssues.length; i++) {
                            if (vm.validationIssues[i].field === field) {
                                fieldIssue = vm.validationIssues[i];
                                break;
                            }
                        }
                    }
                    return fieldIssue;
                }

                vm.save = function () {
                    vm.validateFormData();
                    if (vm.validationIssues.length === 0) {
                        var mappedOrders = [];
                        var countLen = vm.selectedOrders[0].length;
                        var indOf = vm.selectedOrders[0].indexOf(":") + 1;
                        for (var i = 0; i < vm.selectedOrders.length; i++) {
                            for (var j = 0; j < vm.orders.length; j++) {
                                if (vm.selectedOrders[i].substring(0, indOf -1) === vm.orders[j].OrderNo) {
                                    mappedOrders.push(vm.orders[j]);
                                }
                            }
                        }

                        vm.appCallback('saveOk', { mappedOrders: mappedOrders });
                    }
                };

                vm.cancel = function () {
                    vm.appCallback('cancel', {});
                };

                vm.showSubmissionResponse = function (success, message) {
                    if (success) {
                        vm.appCallback('saveOk', { mapedOrders: vm.selectedOrders });
                    } else {
                        if (vm.isDeleteFlag) {
                            vm.infoText = message;
                        } else {
                            var issues = [];
                            issues.push(vm.createValidationIssue("", message, "has-error"));
                            vm.infoText = vm.createValidationInfoText(issues);
                        }
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true, true);
                    }
                };
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        }
    };
})();

angular
    .module('app.sampleManagement', [
          'app.sampleManagement.parcelReception', 'app.sampleManagement.sampleIdentification'
    ]);
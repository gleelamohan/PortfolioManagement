﻿(function () {


    function sampleIdentificationCtrl($scope, $translate, $filter, $timeout, $modal, parcelManageApi) {

		var vm = this;

	}

	angular.module('app.sampleManagement.sampleIdentification.manage')
      .controller('sampleIdentificationCtrl', sampleIdentificationCtrl);
	sampleIdentificationCtrl.$inject = ['$scope', '$translate', '$filter', '$timeout', '$modal', 'parcelManageApi'];
})();
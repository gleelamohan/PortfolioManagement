angular
    .module('app.sampleManagement.sampleIdentification.manage', []);
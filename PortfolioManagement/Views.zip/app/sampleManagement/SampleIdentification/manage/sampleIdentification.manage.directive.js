﻿(function () {


    function sampleIdentification($sce, $filter, $translate, recursionHelper, toastr, $modal, parcelManageApi) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                isModal: "@ismodal",
                inputScope: "=inputscope",
                appCallback: "=appcallback",
                infoVisible: "=infovisible",
                infoText: "=infotext",
                infoClass: "=infoclass"
            },
            controller: function ($scope, $element, $attrs) {
                var vm = this;
                vm.templateUrl = "/app/sampleManagement/SampleIdentification/manage/sampleIdentification.manage.html";

                vm.iboxToolsShowHideVisible = true;
                vm.iboxToolsInfoVisible = false;
                vm.iboxToolsInfoToggledExternally = false;
                vm.iboxToolsFilterVisible = false;
                vm.iboxToolsSettingsVisible = false;
                vm.iboxToolsHelpVisible = true;
                vm.iboxToolsShowHideVisible = true;
                vm.iboxToolsCloseVisible = vm.isModal;
                vm.getResultsCallback = $scope.getResultsCallback;

                //#region functions

                function handleInfoVisibleUpdates(newData) {
                    vm.toggleInfoVisibility(newData || false);
                };

                function handleInfoTextUpdates(newData) {
                    vm.infoText = newData || "";
                };

                function handleInfoClassUpdates(newData) {
                    vm.infoClass = newData || "alert alert-info";
                };


                //#endregion

                vm.toggleInfoVisibility = function (visible) {
                    vm.infoVisible = visible || false;
                    vm.iboxToolsInfoVisible = vm.infoVisible;
                    vm.iboxToolsInfoToggledExternally = vm.infoVisible;
                }


                vm.toggleHelpVisibility = function (visible) {
                    vm.helpVisible = visible || false;
                    vm.iboxToolsHelpToggledExternally = vm.helpVisible;
                }

                vm.resetInfo = function () {
                    vm.infoText = "";
                    vm.infoClass = "alert alert-info";
                    vm.toggleInfoVisibility(false);
                }

                vm.iboxToolsToggleInfo = function () {
                    vm.infoVisible = !vm.infoVisible;
                };

                vm.iboxToolsToggleHelp = function () {
                    vm.helpVisible = !vm.helpVisible;
                };

                vm.iboxToolsToggleClose = function () {
                    vm.appCallback("close", {});
                };


                vm.getParcel = function (searchTerm) {
                    var modalScope = { "defaultSearchTerm": searchTerm || "" };
                    var modalInstance = $modal.open({
                        size: 'lg',
                        template: '<div class="modal-body"><global-search searchservice="vm.searchService" refreshgrid="vm.refreshGrid"></global-search></bpt-search></div>',
                        controller: 'parcelReceptionCtrl as vm', //parcelReceptionCtrl //MUST use inline 'as' modifier and NOT controllerAs - controllerAs only works for inline controller functions
                        scope: function () {
                            var scope = $scope.$new();
                            scope.inputScope = modalScope;
                            return scope;
                        }()
                    });

                    modalInstance.result.then(function (modalReturnScope) {
                        if (!modalReturnScope) {
                            return;
                        }

                        //vm.quotation = modalReturnScope;
                        //updateData();
                    }, function () {
                        //vm.quotation.QuotationId = "";
                        //vm.quotation.Code = "";
                        //updateData();
                    });
                };

                vm.helpText = "Help text goes here";
                vm.panelTitle = "Sample Identification";
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        }
    };
    angular.module('app.sampleManagement.sampleIdentification.manage')
    .directive('sampleIdentification', sampleIdentification);

    sampleIdentification.$inject = ['$sce', '$filter', '$translate', 'recursionHelper', 'toastr','$modal', 'parcelManageApi'];
})();

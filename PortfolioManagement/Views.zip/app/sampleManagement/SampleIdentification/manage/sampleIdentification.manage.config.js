(function () {
    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('sampleManagement.sampleIdentification.manage', {
                url: "/manage",
                //template: '<global-search searchservice="vm.searchService" refreshgrid="vm.refreshGrid"></global-search>',
                //template: '<div>hello sampleIdentification</div>',
                template: "<sample-identification></sample-identification>",
                controller: "sampleIdentificationCtrl",
                controllerAs: "vm"
            });
    }
    angular.module('app.sampleManagement.sampleIdentification.manage')
     .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];

})();
angular
    .module('app.sampleManagement.sampleIdentification', [
       'app.sampleManagement.sampleIdentification.manage'
    ]);
angular
    .module('app.limsAdmin', [
          'app.limsAdmin.role'
        , 'app.limsAdmin.labsite'
        , 'app.limsAdmin.user'
        , 'app.limsAdmin.permission'
        , 'app.limsAdmin.courier'
    ]);
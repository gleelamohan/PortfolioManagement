angular
    .module('app.limsAdmin.user', [
       'app.limsAdmin.user.manage'
    ]);
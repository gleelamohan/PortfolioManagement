(function () {
    angular
        .module('app.limsAdmin.user.manage')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];

    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('limsAdmin.user.manage', {
                url: "/manage",
                template: '<global-search searchservice="vm.searchService" refreshgrid="vm.refreshGrid"></global-search>',
                controller: "userManageCtrl",
                controllerAs: "vm"
            });
    }
})();
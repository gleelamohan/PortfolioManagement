angular
    .module('app.limsAdmin.user.manage', []);
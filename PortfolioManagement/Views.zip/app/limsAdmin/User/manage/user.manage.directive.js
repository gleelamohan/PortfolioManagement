// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
      .module('app.limsAdmin.user.manage')
      .directive('userManage', userManage);

    userManage.$inject = ['$sce', '$filter', '$translate', 'recursionHelper', 'toastr', 'userManageApi', 'labsiteManageApi', 'roleManageApi', 'labsiteQueryApi', 'roleQueryApi'];

    function userManage($sce, $filter, $translate, recursionHelper, toastr, userManageApi, labsiteManageApi, roleManageApi, labsiteQueryApi, roleQueryApi) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                isModal: "@ismodal",
            inputScope: "=inputscope",
                appCallback: "=appcallback",
                infoVisible: "=infovisible",
                infoText: "=infotext",
                infoClass: "=infoclass"
            },
            controller: function ($scope, $element, $attrs) {
                var vm = this;
                vm.currentLanguage = $translate.use();

                vm.templateUrl = "/app/limsAdmin/user/manage/user.manage.html";
                vm.isModal = Boolean($scope.isModal || "false");
                vm.inputScope = $scope.inputScope;
                vm.appCallback = $scope.appCallback;
                vm.helpVisible = false;
                vm.helpText = String($filter("trustedtranslate")("Views.Users.Manage.HelpText"));
                vm.tosterMessage = String($filter("trustedtranslate")("Views.Users.Manage.SaveOkText"));
                vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.SaveButton"));
                vm.isDeleteFlag = false;
                vm.validationIssues = [];
                vm.saveDisabled = true;
                vm.formData = {};
                vm.formData.user = {};
                vm.formData.user.UserDetail = {};
                vm.formData.user.LabSiteRolePairs = [];
                vm.IsNotActiveDirectoryUser = false;
                vm.labsites = [];
                vm.labsiteList = [];
                vm.rolesList = [];               

                $scope.$watch('infoVisible', handleInfoVisibleUpdates, true);
                $scope.$watch('infoText', handleInfoTextUpdates, true);
                $scope.$watch('infoClass', handleInfoClassUpdates, true);

                vm.toggleInfoVisibility = function (visible, ignoreModalCheck) {
                    vm.infoVisible = ((!(ignoreModalCheck || false)) && (vm.isModal)) ? false : visible || false;
                    vm.iboxToolsInfoVisible = visible || false;
                    vm.iboxToolsInfoToggledExternally = vm.infoVisible;
                }

                vm.resetInfo = function () {
                    vm.infoText = "";
                    vm.infoClass = "alert alert-info";
                    vm.toggleInfoVisibility(false);
                }

                function handleInfoVisibleUpdates(newData) {
                    vm.toggleInfoVisibility(newData || false);
                };

                function handleInfoTextUpdates(newData) {
                    vm.infoText = newData || "";
                };

                function handleInfoClassUpdates(newData) {
                    vm.infoClass = newData || "alert alert-info";
                };

                //DDBS ibox-tools Settings
                vm.iboxToolsShowHideVisible = vm.isModal === true ? false : true;
                vm.iboxToolsInfoVisible = false;
                vm.iboxToolsInfoToggledExternally = false;
                vm.iboxToolsValidationVisible = true;
                vm.iboxToolsValidationToggledExternally = false;
                vm.iboxToolsFilterVisible = false;
                vm.iboxToolsSettingsVisible = false;
                vm.iboxToolsHelpVisible = true;
                vm.iboxToolsToggleInfo = function () {
                    vm.infoVisible = !vm.infoVisible;
                };
                vm.iboxToolsToggleFilter = function () { };
                vm.iboxToolsToggleSettings = function () { };
                vm.iboxToolsToggleHelp = function () {
                    vm.helpVisible = !vm.helpVisible;
                };

                var regEx = /^[a-zA-Z0-9]*$/;

                var fillLabSites = function () {
                    labsiteQueryApi.getLabSites().then(function (response) {
                    vm.labsiteList = response.results;

                    roleQueryApi.getRoles().then(function (responseRoleList) {
                        vm.rolesList = responseRoleList.results;
               
                        for (var i = 0; i < vm.labsiteList.length; i++) {
                            var labsite = {
                                Name: vm.labsiteList[i].Name,
                                Id: vm.labsiteList[i].Id,
                                roles: []
                            };

                            for (var j = 0; j < vm.rolesList.length; j++) {
                                var rolenew = {
                                    RoleId: vm.rolesList[j].Id,
                                    RoleName: vm.rolesList[j].Name,
                                    IsSelected: false
                                }
                                labsite.roles.push(rolenew);
                            }
                            vm.labsites.push(labsite);
                        }
                    });
                }
                );}
                fillLabSites();
                if ((vm.inputScope) && (vm.inputScope.isDelete) && (vm.inputScope.isDelete === "true")) {
                    vm.isDeleteFlag = true;
                    vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.DeleteButton"));
                    vm.saveDisabled = false;
                    vm.iboxToolsValidationVisible = false;
                    vm.helpVisible = true;
                    vm.tosterMessage = String($filter("trustedtranslate")("Views.Users.Manage.DeleteOkText"));
                    vm.helpText = String($filter("trustedtranslate")("Views.Users.Manage.DeleteConfirmText"));
                    vm.headerText = String($filter("trustedtranslate")("Views.Users.Manage.DeleteHeaderText"));
                }

                if ((vm.inputScope) && (vm.inputScope.Id) && (vm.inputScope.Id.length > 0)) {
                    userManageApi.getById({ entityId: vm.inputScope.Id }).$promise.then(function (response) {
                        userManageApi.getById({ entityId: vm.inputScope.Id }).$promise.then(function (response) {
                            vm.formData.user = response.state;
                            vm.formData.user.LabSiteRolePairs = response.state.LabSiteRolePairs;
                            if (vm.formData.user.LabSiteRolePairs !== undefined || vm.formData.user.LabSiteRolePairs !== null) {
                                for (var i = 0; i < vm.labsites.length; i++) {
                                    for (var j = 0; j < vm.labsites[i].roles.length; j++) {
                                        for (var k = 0; k < vm.formData.user.LabSiteRolePairs.length; k++) {
                                            if ((vm.formData.user.LabSiteRolePairs[k].LabSiteId === vm.labsites[i].Id) && (vm.formData.user.LabSiteRolePairs[k].RoleId === vm.labsites[i].roles[j].RoleId)) {
                                                vm.labsites[i].roles[j].IsSelected = true;
                                            }
                                        }
                                    }
                                }
                            }
                        });                      
                    });

                    vm.IsUpdatingAnUser = true;

                    if (vm.isDeleteFlag !== true) {
                        vm.headerText = String($filter("trustedtranslate")("Views.Users.Manage.UpdateHeaderText"));
                    }
                } else {
                    vm.headerText = String($filter("trustedtranslate")("Views.Users.Manage.AddHeaderText"));
                    vm.IsUpdatingAnUser = false;
                    //Add Data - Initialize the values
                    vm.formData.user = {
                        "Id": null,
                        "Puid": null,
                        "Comments": null,
                        "IsActive": true,
                        "IsGlobalAdministrator": false,
                        "LabSiteRolePairs": [],
                        "UserDetail" : {}
                    };
                }

                vm.fillUserInfo = function () {
                    if ((!vm.formData.user.Puid) || (vm.formData.user.Puid.length === 0)) {
                        clearAdInfo();
                    }
                    else if ((vm.formData.user.Puid) && ((vm.formData.user.Puid.length < 4) || (vm.formData.user.Puid.length > 8))) {
                        clearAdInfo();
                    }
                    else if (!regEx.test(vm.formData.user.Puid)) {

                        clearAdInfo();
                    }
                    else {
                        var actionArguments = {
                            samAccountName: vm.formData.user.Puid
                        };
                        userManageApi.getUserFromActiveDirectoryByPuid({ "actionArguments": actionArguments }).$promise.then(function (data) {
                            if (!data.FirstName) {
                                vm.IsNotActiveDirectoryUser = true;
                                clearAdInfo();
                                toastr.warning(String($filter("trustedtranslate")("Views.Users.Manage.UserWarning")));
                            } else {
                                vm.formData.user.UserDetail = {
                                    "FirstName": data.FirstName ,
                                    "LastName": data.LastName,
                                    "EmailId":data.EmailId
                                }

                                //vm.formData.user.FirstName = data.FirstName;
                                //vm.formData.user.MiddleName = data.MiddleName;
                                //vm.formData.user.LastName = data.LastName;
                                //vm.formData.user.EmailId = data.EmailId;
                                vm.IsNotActiveDirectoryUser = false;
                                vm.validateFormData();
                            }
                        }, function (data) {
                            vm.showSubmissionResponse(false, data.data);
                            clearAdInfo();
                        });
                    }
                };

                function clearAdInfo()
                {
                    vm.IsNotActiveDirectoryUser = true;
                    vm.formData.user.UserDetail = {};
                    ////vm.formData.user.FirstName = null;
                    ////vm.formData.user.MiddleName = null;
                    ////vm.formData.user.LastName = null;
                    ////vm.formData.user.EmailId = null;
                    vm.validateFormData();
                }

                vm.formChanged = function () {
                    vm.saveDisabled = false;
                }

                vm.createValidationIssue = function (field, message, cssClass) {
                    return {
                        "field": field || "",
                        "message": message || "",
                        "cssClass": cssClass || ""
                    };
                }

                vm.createValidationInfoText = function (issues) {
                    var infoText = "";

                    if ((issues) && (issues.length > 0)) {
                        infoText = "<p>" + String($filter("trustedtranslate")("Views.Users.Manage.ValidationHeaderText")) + " " + String($filter("trustedtranslate")("Common.Maintenance.ValidationHeaderSuffix")) + "</p><ul>";

                        issues.forEach(function (issue) {
                            infoText += ("<li>" + issue.message + "</li>");
                        });

                        infoText += "</ul>";
                    }
                    return infoText;
                }

                vm.validationCallback = function () {
                    vm.validateFormData(true);
                }

                vm.validateFormData = function (displayOkMessage) {
                    vm.resetInfo();
                    vm.validationIssues = [];
                    var issues = [];
                                    
                    if ((vm.formData.user.LabSiteRolePairs.length === 0) && ((vm.formData.user.IsGlobalAdministrator === false) || (vm.formData.user.IsGlobalAdministrator === undefined))) {
                        issues.push(vm.createValidationIssue("User.Roles", String($filter("trustedtranslate")("Views.Users.Manage.ValidationMessages.UserRoleSelect")), "has-error"));
                    }

                    if ((!vm.formData.user.Puid) || (vm.formData.user.Puid.length === 0)) {
                        issues.push(vm.createValidationIssue("User.PUID", String($filter("trustedtranslate")("Views.Users.Manage.ValidationMessages.UserPUIDReqiuired")), "has-error"));
                    }
                    else if ((vm.formData.user.Puid) && ((vm.formData.user.Puid.length < 4) || (vm.formData.user.Puid.length > 8))) {
                        issues.push(vm.createValidationIssue("User.PUID", String($filter("trustedtranslate")("Views.Users.Manage.ValidationMessages.UserPUIDLength")), "has-error"));
                    }
                    else if (!regEx.test(vm.formData.user.Puid)) {
                        issues.push(vm.createValidationIssue("User.PUID", String($filter("trustedtranslate")("Views.Users.Manage.ValidationMessages.UserPUIDSpecialCharacter")), "has-error"));
                    }
                    else if (vm.IsNotActiveDirectoryUser) {
                        issues.push(vm.createValidationIssue("User.PUID", String($filter("trustedtranslate")("Views.Users.Manage.ValidationMessages.UserValidPUID")), "has-error"));
                    }
                    if ((vm.formData.user.Comments) &&(vm.formData.user.Comments.length > 500)) {
                        issues.push(vm.createValidationIssue("User.Comments", String($filter("trustedtranslate")("Views.Users.Manage.ValidationMessages.UserCommentsLength")), "has-error"));
                    }
                 
                    //Perform validations on form data                  
                    if (issues.length > 0) {
                        //Format the validation issues for display
                        var fieldIssues = [];
                        issues.forEach(function (issue) {
                            var fieldIssueExists = false;
                            fieldIssues.forEach(function (fieldIssue) {
                                if (fieldIssue.field === issue.field) {
                                    fieldIssueExists = true;
                                    fieldIssue.message += ("  " + issue.message);
                                }
                            });
                            if (!fieldIssueExists) {
                                fieldIssues.push(issue);
                            }
                        });

                        vm.infoText = vm.createValidationInfoText(issues);
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true);

                        vm.validationIssues = fieldIssues;
                    } else {
                        if (displayOkMessage || false) {
                            toastr.success(String($filter("trustedtranslate")("Views.Users.Manage.ValidationOkText")));
                        }
                    }
                };

                vm.getFieldValidationIssue = function (field) {
                    var fieldIssue = vm.createValidationIssue("", "", ""); //Need empty issue - including cssClass
                    if ((vm.validationIssues) && (vm.validationIssues.length > 0)) {
                        for (var i = 0; i < vm.validationIssues.length; i++) {
                            if (vm.validationIssues[i].field === field) {
                                fieldIssue = vm.validationIssues[i];
                                break;
                            }
                        }
                    }
                    return fieldIssue;
                }

                function getIndexOf(array, labSiteId, roleId) {
                    for (var i = 0; i < array.length; i++) {
                        if ((array[i].LabSiteId === labSiteId) && (array[i].RoleId === roleId)) {
                            return i;
                        }
                    }
                    return -1;
                }

                vm.addRemoveRole = function (isSelected, roleid, labsiteid) {
                    if (isSelected === true) {
                        vm.formData.user.LabSiteRolePairs.push({
                            LabSiteId: labsiteid,
                            RoleId: roleid
                        });
                        vm.formChanged();
                    } else {
                        var index = getIndexOf(vm.formData.user.LabSiteRolePairs, labsiteid, roleid);
                        if (index > -1) {
                            vm.formData.user.LabSiteRolePairs.splice(index, 1);
                            vm.formChanged();
                        }
                    }
                }         

                vm.save = function () {
                    if (vm.isDeleteFlag && vm.formData.user.Id.length > 0) {

                        userManageApi.remove({ entityId: vm.inputScope.Id }).$promise.then(
                            function () {
                                vm.showSubmissionResponse(true);
                            }, function (result) {
                                vm.showSubmissionResponse(false, result.data);
                            });
                    } else {

                        vm.validateFormData();

                        var updateCommand = {
                            comment: "Updating user",
                            ActionArguments: {
                                "userState": vm.formData.user
                            }
                        };

                        var addCommand = {
                            comment: "Adding user",
                            ActionArguments: {
                                "puid": vm.formData.user.Puid
                            }
                        };

                        if (vm.validationIssues.length === 0) {
                            if (vm.formData.user.Id) {
                                //Update
                                userManageApi.update({ entityId: vm.inputScope.Id, rowVersion: vm.formData.user.RowVersion }, updateCommand).$promise.then(
                                    function () {
                                        vm.showSubmissionResponse(true);
                                    }, function (result) {
                                        vm.showSubmissionResponse(false, result.data);
                                    });
                            } else {
                                //Create
                                userManageApi.save(addCommand).$promise.then(
                                        function (response) {
                                            vm.formData.user.Id = response.EntityId;
                                            vm.formData.user.RowVersion = response.RowVersion;
                                            userManageApi.update({
                                                entityId: response.EntityId,
                                                rowVersion: response.RowVersion
                                            }, updateCommand).$promise.then(
                                                function() {
                                                    //vm.showSubmissionResponse(true);
                                                }, function(result) {
                                                    vm.showSubmissionResponse(false, result.data);
                                                });


                                            vm.showSubmissionResponse(true);
                                        }, function (result) {
                                            vm.showSubmissionResponse(false, result.data);
                                        });
                            }
                        }
                    }
                };

                vm.cancel = function () {
                    vm.appCallback('cancel', {});
                };

                vm.showSubmissionResponse = function (success, message) {
                    if (success) {
                        toastr.success(vm.tosterMessage);
                        vm.appCallback('saveOk', {});
                    } else {
                        if (vm.isDeleteFlag) {
                            vm.infoText = message;
                        } else {
                            var issues = [];
                            issues.push(vm.createValidationIssue("", message, "has-error"));
                            vm.infoText = vm.createValidationInfoText(issues);
                        }
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true, true);
                    }
                };
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        }
    };
})();
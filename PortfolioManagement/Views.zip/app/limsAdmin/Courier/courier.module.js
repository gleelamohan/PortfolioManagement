angular
    .module('app.limsAdmin.courier', [
       'app.limsAdmin.courier.manage'
    ]);
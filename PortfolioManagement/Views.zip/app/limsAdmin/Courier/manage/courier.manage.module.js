angular
    .module('app.limsAdmin.courier.manage', []);
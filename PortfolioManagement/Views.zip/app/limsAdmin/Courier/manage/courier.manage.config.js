(function () {
    angular
        .module('app.limsAdmin.courier.manage')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];

    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('limsAdmin.courier.manage', {
                url: "/manage",
                template: '<global-search searchservice="vm.searchService" refreshgrid="vm.refreshGrid"></global-search>',
                controller: "courierManageCtrl",
                controllerAs: "vm"
            });
    }
})();
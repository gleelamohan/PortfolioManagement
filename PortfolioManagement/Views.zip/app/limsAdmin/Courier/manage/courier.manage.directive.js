(function () {
    angular
        .module('app.limsAdmin.courier.manage')
        .directive('courierManage', courierManage);

    courierManage.$inject = ['$sce', '$filter', '$translate', 'recursionHelper', 'toastr', 'courierManageApi'];

    function courierManage($sce, $filter, $translate, recursionHelper, toastr, courierManageApi) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                isModal: "@ismodal",
                inputScope: "=inputscope",
                appCallback: "=appcallback",
                infoVisible: "=infovisible",
                infoText: "=infotext",
                infoClass: "=infoclass"
            },
            controller: function($scope, $element, $attrs) {
                var vm = this;

                vm.templateUrl = "/app/limsAdmin/courier/manage/courier.manage.html";
                vm.isModal = Boolean($scope.isModal || "false");
                vm.inputScope = $scope.inputScope;
                vm.appCallback = $scope.appCallback;
                vm.helpVisible = false;
                vm.isDeleteFlag = false;
                vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.SaveButton"));
                vm.helpText = String($filter("trustedtranslate")("Views.Couriers.Manage.HelpText"));
                vm.saveDisabled = true;
                vm.formData = {};

                vm.iboxToolsValidationVisible = true;

                if ((vm.inputScope) && (vm.inputScope.isDelete) && (vm.inputScope.isDelete === "true")) {
                    vm.isDeleteFlag = true;
                    vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.DeleteButton"));
                    vm.saveDisabled = false;
                    vm.iboxToolsValidationVisible = false;
                    vm.helpVisible = true;
                    vm.tosterMessage = String($filter("trustedtranslate")("Views.Couriers.Manage.DeleteOkText"));
                    vm.helpText = String($filter("trustedtranslate")("Views.Couriers.Manage.DeleteConfirmText"));
                    vm.headerText = String($filter("trustedtranslate")("Views.Couriers.Manage.DeleteHeaderText"));                   
                }
                else
                { vm.headerText = String($filter("trustedtranslate")("Views.Couriers.Manage.UpdateCourier")); }

                if ((vm.inputScope) && (vm.inputScope.Id) && (vm.inputScope.Id.length > 0)) {                    
                    courierManageApi.getById({ id: vm.inputScope.Id }).$promise.then(function(response) {
                        vm.formData.courier = response;
                    });
                } else {
                    vm.formData.courier = {
                        "Id": null,
                        "Name": "",
                        "Address": ""
                    };
                    vm.headerText = String($filter("trustedtranslate")("Views.Couriers.Manage.AddCourier"));
                }

                $scope.$watch('infoVisible', handleInfoVisibleUpdates, true);
                $scope.$watch('infoText', handleInfoTextUpdates, true);
                $scope.$watch('infoClass', handleInfoClassUpdates, true);

                vm.toggleInfoVisibility = function(visible, ignoreModalCheck) {
                    vm.infoVisible = ((!(ignoreModalCheck || false)) && (vm.isModal)) ? false : visible || false;
                    vm.iboxToolsInfoVisible = visible || false;
                    vm.iboxToolsInfoToggledExternally = vm.infoVisible;
                }

                vm.resetInfo = function() {
                    vm.infoText = "";
                    vm.infoClass = "alert alert-info";
                    vm.toggleInfoVisibility(false);
                }

                function handleInfoVisibleUpdates(newData) {
                    vm.toggleInfoVisibility(newData || false);
                };

                function handleInfoTextUpdates(newData) {
                    vm.infoText = newData || "";
                };

                function handleInfoClassUpdates(newData) {
                    vm.infoClass = newData || "alert alert-info";
                };

                //DDBS ibox-tools Settings
                vm.iboxToolsShowHideVisible = vm.isModal === true ? false : true;
                vm.iboxToolsInfoVisible = false;
                vm.iboxToolsInfoToggledExternally = false;

                vm.iboxToolsValidationToggledExternally = false;
                vm.iboxToolsFilterVisible = false;
                vm.iboxToolsSettingsVisible = false;
                vm.iboxToolsHelpVisible = true;
                vm.iboxToolsToggleInfo = function() {
                    vm.infoVisible = !vm.infoVisible;
                };
                vm.iboxToolsToggleFilter = function() {};
                vm.iboxToolsToggleSettings = function() {};
                vm.iboxToolsToggleHelp = function() {
                    vm.helpVisible = !vm.helpVisible;
                };

                vm.validationIssues = [];

                vm.formChanged = function() {
                    vm.saveDisabled = false;
                }

                vm.createValidationIssue = function(field, message, cssClass) {
                    return {
                        "field": field || "",
                        "message": message || "",
                        "cssClass": cssClass || ""
                    };
                }

                vm.createValidationInfoText = function (issues) {
                    var infoText = "";

                    if ((issues) && (issues.length > 0)) {
                        infoText = "<p>" +
                           String($filter("trustedtranslate")("Views.Couriers.Manage.ValidationHeaderText")) +
                           " " +
                           String($filter("trustedtranslate")("Common.Maintenance.ValidationHeaderSuffix")) +
                           "</p><ul>";

                        issues.forEach(function (issue) {
                            infoText += ("<li>" + issue.message + "</li>");
                        });

                        infoText += "</ul>";
                    }
                    return infoText;
                }

                vm.validationCallback = function () {
                    vm.validateFormData(true);
                }

                vm.validateFormData = function (displayOkMessage) {
                    vm.resetInfo();
                    vm.validationIssues = [];
                    var issues = [];

                    if ((!vm.formData.courier.Name) || (vm.formData.courier.Name.length === 0) || (vm.formData.courier.Name.trim() === "")) {
                        issues.push(vm.createValidationIssue("courier.Name", String($filter("trustedtranslate") ("Views.Couriers.Manage.ValidationMessages.CourierNameRequired")), "has-error"));
                        }

                        if ((vm.formData.courier.Name && (vm.formData.courier.Name.trim().length < 2 || vm.formData.courier.Name.trim().length > 50))) {
                        issues.push(vm.createValidationIssue("courier.Name", String($filter("trustedtranslate") ("Views.Couriers.Manage.ValidationMessages.CourierNameLength")), "has-error"));
                            }

                        if(vm.formData.courier.Address.trim().length > 500) {
                        issues.push(vm.createValidationIssue("courier.Address", String($filter("trustedtranslate") ("Views.Couriers.Manage.ValidationMessages.CourierAddressLength")), "has-error"));
                            }
                   
                    if (issues.length > 0) {
                        var fieldIssues = [];
                        issues.forEach(function (issue) {
                            var fieldIssueExists = false;
                            fieldIssues.forEach(function (fieldIssue) {
                                if (fieldIssue.field === issue.field) {
                                    fieldIssueExists = true;
                                    fieldIssue.message += ("  " + issue.message);
                                }
                            });
                            if (!fieldIssueExists) {
                                fieldIssues.push(issue);
                            }
                        });

                        vm.infoText = vm.createValidationInfoText(issues);
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true);

                        vm.validationIssues = fieldIssues;
                    } else {
                        if (displayOkMessage || false) {
                            toastr.success(String($filter("trustedtranslate")("Views.Couriers.Manage.ValidationOkText")));
                        }
                    }
                };

                vm.getFieldValidationIssue = function (field) {
                    var fieldIssue = vm.createValidationIssue("", "", "");  //Need empty issue - including cssClass
                    if ((vm.validationIssues) && (vm.validationIssues.length > 0)) {
                        for (var i = 0; i < vm.validationIssues.length; i++) {
                            if (vm.validationIssues[i].field === field) {
                                fieldIssue = vm.validationIssues[i];
                                break;
                            }
                        }
                    }
                    return fieldIssue;
                }

                vm.save = function () {
                    if (vm.isDeleteFlag && vm.formData.courier.Id.length > 0) {

                        courierManageApi.remove({ id: vm.inputScope.Id }).$promise.then(
                               function () {
                                   toastr.success(String($filter("trustedtranslate")("Views.Couriers.Manage.DeleteOkText")));
                                   vm.showSubmissionResponse(true);
                               }, function (result) {
                                   vm.showSubmissionResponse(false, result.data);
                               });
                    }
                    else {
                        vm.validateFormData();

                        if (vm.validationIssues.length === 0) {
                            if (vm.formData.courier.Id) {
                                //Update
                                courierManageApi.update({ id: vm.inputScope.Id }, vm.formData.courier).$promise.then(
                                function () {
                                    toastr.success(String($filter("trustedtranslate")("Views.Couriers.Manage.UpdateOkText")));
                                    vm.showSubmissionResponse(true);
                                }, function (result) {
                                    vm.showSubmissionResponse(false, result.data);
                                });
                            } else {
                                //Create
                                courierManageApi.save(vm.formData.courier).$promise.then(
                                function () {
                                    toastr.success(String($filter("trustedtranslate")("Views.Couriers.Manage.SaveOkText")));
                                    vm.showSubmissionResponse(true);
                                }, function (result) {
                                    vm.showSubmissionResponse(false, result.data);
                                });
                            }
                        }
                    }
                };

                vm.cancel = function () {
                    vm.appCallback('cancel', {});
                };

                vm.showSubmissionResponse = function (success, message) {
                    if (success) {
                        vm.appCallback('saveOk', {});
                    } else {
                        if (vm.isDeleteFlag) {
                            vm.infoText = message;
                        } else {
                            var issues = [];
                            issues.push(vm.createValidationIssue("", message, "has-error"));
                            vm.infoText = vm.createValidationInfoText(issues);
                        }
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true, true);
                    }
                };
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        }
    };
})();

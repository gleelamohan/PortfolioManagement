(function () {
    angular
        .module('app.limsAdmin.courier')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider', '$translateProvider'];

    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('limsAdmin.courier', {
                abstract: true,
                url: "/courier",
                template: '<ui-view />'
            });
    }
})();
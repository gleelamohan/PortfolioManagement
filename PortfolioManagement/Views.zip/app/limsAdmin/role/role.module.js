angular
    .module('app.limsAdmin.role', [       
        'app.limsAdmin.role.manage'
    ]);
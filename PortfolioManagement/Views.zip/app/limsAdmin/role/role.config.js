(function () {
    angular
        .module('app.limsAdmin.role')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];

    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('limsAdmin.role', {
                abstract: true,
                url: "/role",
                template: '<ui-view />'
            });
    }
})();
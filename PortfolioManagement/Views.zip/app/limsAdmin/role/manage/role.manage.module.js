angular
    .module('app.limsAdmin.role.manage', []);
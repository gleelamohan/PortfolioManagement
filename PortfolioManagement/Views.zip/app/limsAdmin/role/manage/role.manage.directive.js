// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('app.limsAdmin.role.manage')
        .directive('roleManage', roleManage);

    roleManage.$inject = ['$sce', '$filter', '$translate', 'recursionHelper', 'toastr', 'roleManageApi', 'permissionApi','roleQueryApi'];

    function roleManage($sce, $filter, $translate, recursionHelper, toastr, roleManageApi, permissionApi, roleQueryApi) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                isModal: "@ismodal",
                inputScope: "=inputscope",
                appCallback: "=appcallback",
                infoVisible: "=infovisible",
                infoText: "=infotext",
                infoClass: "=infoclass"
            },
            controller: function ($scope, $element, $attrs) {
                var vm = this;

                vm.templateUrl = "/app/limsAdmin/role/manage/role.manage.html";
                vm.isModal = Boolean($scope.isModal || "false");
                vm.inputScope = $scope.inputScope;
                vm.appCallback = $scope.appCallback;
                vm.helpVisible = false;
                vm.headerText = "";
                vm.isDeleteFlag = false;
                vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.SaveButton"));
                vm.tosterMessage = String($filter("trustedtranslate")("Views.Roles.Manage.SaveOkText"));
                vm.helpText = String($filter("trustedtranslate")("Views.Roles.Manage.HelpText"));
                vm.saveDisabled = true;
                vm.formData = {};
                vm.validationIssues = [];

                $scope.$watch('infoVisible', handleInfoVisibleUpdates, true);
                $scope.$watch('infoText', handleInfoTextUpdates, true);
                $scope.$watch('infoClass', handleInfoClassUpdates, true);

                vm.toggleInfoVisibility = function (visible, ignoreModalCheck) {
                    vm.infoVisible = ((!(ignoreModalCheck || false)) && (vm.isModal)) ? false : visible || false;
                    vm.iboxToolsInfoVisible = visible || false;
                    vm.iboxToolsInfoToggledExternally = vm.infoVisible;
                }

                vm.resetInfo = function () {
                    vm.infoText = "";
                    vm.infoClass = "alert alert-info";
                    vm.toggleInfoVisibility(false);
                }

                function handleInfoVisibleUpdates(newData) {
                    vm.toggleInfoVisibility(newData || false);
                };

                function handleInfoTextUpdates(newData) {
                    vm.infoText = newData || "";
                };

                function handleInfoClassUpdates(newData) {
                    vm.infoClass = newData || "alert alert-info";
                };

                //DDBS ibox-tools Settings
                vm.iboxToolsShowHideVisible = vm.isModal === true ? false : true;
                vm.iboxToolsInfoVisible = false;
                vm.iboxToolsInfoToggledExternally = false;
                vm.iboxToolsValidationVisible = true;
                vm.iboxToolsValidationToggledExternally = false;
                vm.iboxToolsFilterVisible = false;
                vm.iboxToolsSettingsVisible = false;
                vm.iboxToolsHelpVisible = true;
                vm.iboxToolsToggleInfo = function () {
                    vm.infoVisible = !vm.infoVisible;
                };
                vm.iboxToolsToggleFilter = function () { };
                vm.iboxToolsToggleSettings = function () { };
                vm.iboxToolsToggleHelp = function () {
                    vm.helpVisible = !vm.helpVisible;
                };

                vm.formData.Role = {};
                vm.formData.Role.RolePermissions = [];
                vm.permissionGroups = [];

                    permissionApi.query().then(function (response) {
                        vm.permissionGroups = response.data;               
                        });
                 

                if ((vm.inputScope) && (vm.inputScope.isDelete) && (vm.inputScope.isDelete === "true")) {
                    vm.isDeleteFlag = true;
                    vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.DeleteButton"));
                    vm.saveDisabled = false;
                    vm.iboxToolsValidationVisible = false;
                    vm.helpVisible = true;
                    vm.tosterMessage = String($filter("trustedtranslate")("Views.Roles.Manage.DeleteOkText"));
                    vm.helpText = String($filter("trustedtranslate")("Views.Roles.Manage.DeleteConfirmText"));
                    vm.headerText = String($filter("trustedtranslate")("Views.Roles.Manage.DeleteHeaderText"));
                }

                if ((vm.inputScope) && (vm.inputScope.Id) && (vm.inputScope.Id.length > 0)) {
                    //Edit Data - Get data from service
                    if (vm.isDeleteFlag !== true) {
                        vm.headerText = String($filter("trustedtranslate")("Views.Roles.Manage.UpdateHeaderText"));
                    }

                    
                    roleManageApi.getById({ entityId: vm.inputScope.Id }).$promise.then(function (response) {
                        vm.formData.Role = response.state;

                        for (var i = 0; i < vm.permissionGroups.length; i++) {
                            for (var j = 0; j < vm.permissionGroups[i].Permissions.length; j++) {
                                vm.permissionGroups[i].Permissions[j].IsSelected = false;

                                if (vm.formData.Role.RolePermissions.length > 0) {
                                    for (var k = 0; k < vm.formData.Role.RolePermissions.length; k++) {
                                        if (vm.formData.Role.RolePermissions[k].PermissionId === vm.permissionGroups[i].Permissions[j].Id) {
                                            vm.permissionGroups[i].Permissions[j].IsSelected = true;
                                        }
                                    }
                                }
                            }
                        }

                      });
                } else {
                    //Add Data - Initialize the values
                    vm.headerText = String($filter("trustedtranslate")("Views.Roles.Manage.AddHeaderText"));

                    vm.formData.Role = {
                        "Id": null,
                        "Name": "",
                        "Description": "",
                        "RolePermissions": []
                    };
                }

                vm.addRemovePermission = function (isSelected, id) {
                    if (isSelected === true) {
                        vm.formData.Role.RolePermissions.push({ PermissionId: id });
                        vm.formChanged();
                    } else {
                        var index = vm.formData.Role.RolePermissions.map(function (obj) {
                            return obj.PermissionId;
                        }).indexOf(id);

                        if (index > -1) {
                            vm.formData.Role.RolePermissions.splice(index, 1);
                            vm.formChanged();
                        }
                    }
                }

                vm.formChanged = function () {
                    vm.saveDisabled = false;
                }

                vm.createValidationIssue = function (field, message, cssClass) {
                    return {
                        "field": field || "",
                        "message": message || "",
                        "cssClass": cssClass || ""
                    };
                }

                vm.createValidationInfoText = function (issues) {
                    var infoText = "";

                    if ((issues) && (issues.length > 0)) {
                        infoText = "<p>" + String($filter("trustedtranslate")("Views.Users.Manage.ValidationHeaderText")) + " " + String($filter("trustedtranslate")("Common.Maintenance.ValidationHeaderSuffix")) + "</p><ul>";

                        issues.forEach(function (issue) {
                            infoText += ("<li>" + issue.message + "</li>");
                        });

                        infoText += "</ul>";
                    }
                    return infoText;
                }

                vm.validationCallback = function () {
                    vm.validateFormData(true);
                }

                vm.validateFormData = function (displayOkMessage) {
                    vm.resetInfo();
                    vm.validationIssues = [];
                    var issues = [];

                    //Perform validations on form data
                    if ((!vm.formData.Role.Name) || (vm.formData.Role.Name.length === 0)) {
                        issues.push(vm.createValidationIssue("Role.Name", String($filter("trustedtranslate")("Views.Roles.Manage.ValidationMessages.RoleNameRequired")), "has-error"));
                    }

                    if ((vm.formData.Role.Name) && ((vm.formData.Role.Name.length < 2) || (vm.formData.Role.Name.length > 50))) {
                        console.log("Inside Validation for length");
                        issues.push(vm.createValidationIssue("Role.Name", String($filter("trustedtranslate")("Views.Roles.Manage.ValidationMessages.RoleNameLength")), "has-error"));
                    }

                    if ((vm.formData.Role.Description) && (vm.formData.Role.Description.length > 500)) {
                        issues.push(vm.createValidationIssue("Role.Description", String($filter("trustedtranslate")("Views.Roles.Manage.ValidationMessages.RoleDescriptionLength")), "has-error"));
                    }

                    if (vm.formData.Role.RolePermissions.length === 0) {
                        issues.push(vm.createValidationIssue("Role.Permissions", String($filter("trustedtranslate")("Views.Roles.Manage.ValidationMessages.RolePermission")), "has-error"));
                    }

                    if (issues.length > 0) {
                        //Format the validation issues for display
                        var fieldIssues = [];
                        issues.forEach(function (issue) {
                            var fieldIssueExists = false;
                            fieldIssues.forEach(function (fieldIssue) {
                                if (fieldIssue.field === issue.field) {
                                    fieldIssueExists = true;
                                    fieldIssue.message += ("  " + issue.message);
                                }
                            });
                            if (!fieldIssueExists) {
                                fieldIssues.push(issue);
                            }
                        });

                        vm.infoText = vm.createValidationInfoText(issues);
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true);

                        vm.validationIssues = fieldIssues;
                    } else {
                        if (displayOkMessage || false) {
                            toastr.success(String($filter("trustedtranslate")("Views.Roles.Manage.ValidationOkText")));
                        }
                    }
                };

                vm.getFieldValidationIssue = function (field) {
                    var fieldIssue = vm.createValidationIssue("", "", "");  //Need empty issue - including cssClass
                    if ((vm.validationIssues) && (vm.validationIssues.length > 0)) {
                        for (var i = 0; i < vm.validationIssues.length; i++) {
                            if (vm.validationIssues[i].field === field) {
                                fieldIssue = vm.validationIssues[i];
                                break;
                            }
                        }
                    }
                    return fieldIssue;
                }

             
                vm.save = function () {
                    var updateCommand = {
                        comment: "Updating role",
                        ActionArguments: {
                            "roleState": vm.formData.Role
                        }
                    };
                    var addCommand = {
                        comment: "Adding role",
                        ActionArguments: {
                            "name": vm.formData.Role.Name,
                            "description": vm.formData.Role.Description
                        }
                    };

                    if (vm.isDeleteFlag && vm.formData.Role.Id.length > 0) {

                        roleManageApi.remove({ entityId: vm.inputScope.Id }).$promise.then(
                            function () {
                                vm.showSubmissionResponse(true);
                            }, function (result) {
                                vm.showSubmissionResponse(false, result.data);
                            });
                    } else {
                        vm.validateFormData();

                        if (vm.validationIssues.length === 0) {
                            if (vm.formData.Role.Id) {
                                //Update
                                roleManageApi.update({ entityId: vm.inputScope.Id, rowVersion: vm.formData.Role.RowVersion }, updateCommand).$promise.then(
                                    function () {
                                        vm.showSubmissionResponse(true);
                                    }, function (result) {
                                        vm.showSubmissionResponse(false, result.data);
                                    });
                            } else {
                                //Create
                                roleManageApi.save(addCommand).$promise.then(function (response) {
                                    vm.formData.Role.Id = response.EntityId;
                                    vm.formData.Role.RowVersion = response.RowVersion;
                                    roleManageApi.update({
                                        entityId: response.EntityId,
                                        rowVersion: response.RowVersion
                                    }, updateCommand).$promise.then(
                                        function () {
                                        }, function (result) {
                                            vm.showSubmissionResponse(false, result.data);
                                        });

                                    vm.showSubmissionResponse(true);
                                }, function (result) {
                                    vm.showSubmissionResponse(false, result.data);
                                });
                            }
                        }
                    }
                };

                vm.cancel = function () {
                    vm.appCallback('cancel', {});
                };

                vm.showSubmissionResponse = function (success, message) {
                    if (success) {
                        toastr.success(vm.tosterMessage);
                        vm.appCallback('saveOk', {});
                    } else {
                        if (vm.isDeleteFlag) {
                            vm.infoText = message;
                        } else {
                            var issues = [];
                            issues.push(vm.createValidationIssue("", message, "has-error"));
                            vm.infoText = vm.createValidationInfoText(issues);
                        }
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true, true);
                    }
                };
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        }
    };
})();

(function () {

    function config($stateProvider, $urlRouterProvider, $httpProvider) {
        $httpProvider.defaults.withCredentials = true;
        $httpProvider.defaults.useXDomain = true;
        $urlRouterProvider.otherwise("/");
        $stateProvider
            .state('limsAdmin.role.manage', {
                url: "/manage",
                template: '<global-search searchservice="vm.searchService" refreshgrid="vm.refreshGrid"></global-search>',
                controller: "roleManageCtrl",
                controllerAs: "vm"
            });
    }
    angular.module('app.limsAdmin.role.manage')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];
})();



(function () {
  angular
      .module('app.limsAdmin')
      .config(config);

  config.$inject = ['$stateProvider', '$urlRouterProvider','$httpProvider'];

  function config($stateProvider, $urlRouterProvider, $httpProvider) {

    $httpProvider.defaults.withCredentials = true;

    $urlRouterProvider.otherwise("/");

    $stateProvider
        .state('limsAdmin', {
          abstract: true,
          url: "/limsadmin",
          template: "<ui-view />"
        });
  }
})();
angular
    .module('app.limsAdmin.labsite', [
       'app.limsAdmin.labsite.manage'
    ]);
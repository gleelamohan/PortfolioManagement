(function () {
    angular
        .module('app.limsAdmin.labsite')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider', '$translateProvider'];

    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('limsAdmin.labsite', {
                abstract: true,
                url: "/labsite",
                template: '<ui-view />'
            });
    }
})();
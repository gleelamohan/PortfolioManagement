(function () {
   
    function labsiteManageCtrl($scope, $translate, $filter, $timeout, $modal, labsiteManageApi) {

        var vm = this;

        vm.searchService = labsiteManageApi;
       
        vm.deleteCallback = function (id) {
            var inputScope = { Id: id, action: "delete" }
            vm.openModal(inputScope);
        }

        vm.editCallback = function (id) {
            var inputScope = { Id: id, action: "edit" }
            vm.openModal(inputScope);
        }


        vm.addCallback = function () {
            var inputScope = { Id: null, action: "add" }
            vm.openModal(inputScope);
        }


        vm.openModal = function (modalScope) {
            var modalInstance = $modal.open({
                template: '<div class="modal-body"><labsite-manage ismodal="true" inputscope="vm.inputScope" appcallback="vm.appCallback" infovisible="vm.infoVisible" infotext="vm.infoText" infoclass="vm.infoClass"></labsite-manage></div>',
                controller: 'ModalCtrl as vm',
                backdrop: 'static',
                keyboard: true,
                scope: function () {
                    var scope = $scope.$new();
                    scope.inputScope = modalScope;
                    return scope;
                }()
            });
            modalInstance.result.then(function (modalReturnScope) {
                var outputScope = modalReturnScope || null;
                if (outputScope) {
                    vm.refreshGrid();
                }
            }, function () { });
        }
    }
    angular
       .module('app.limsAdmin.labsite.manage')
       .controller('labsiteManageCtrl', labsiteManageCtrl);

    labsiteManageCtrl.$inject = ['$scope', '$translate', '$filter', '$timeout', '$modal', 'labsiteManageApi'];

})();
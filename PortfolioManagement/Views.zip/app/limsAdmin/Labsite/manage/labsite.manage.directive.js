(function() {
    function labsiteManage($sce, $filter, $translate, recursionHelper, toastr, labsiteManageApi) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                isModal: "@ismodal",
                inputScope: "=inputscope",
                appCallback: "=appcallback",
                infoVisible: "=infovisible",
                infoText: "=infotext",
                infoClass: "=infoclass"
            },
            controller: function($scope, $element, $attrs) {
                var vm = this;
                vm.currentLanguage = $translate.use();

                vm.templateUrl = "/app/limsAdmin/labsite/manage/labsite.manage.html";
                vm.isModal = Boolean($scope.isModal || "false");
                vm.inputScope = $scope.inputScope;
                vm.appCallback = $scope.appCallback;
                vm.helpVisible = false;
                vm.isDeleteFlag = false;
                vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.SaveButton"));
                vm.helpText = String($filter("trustedtranslate")("Views.Labsites.Manage.HelpText"));
                vm.saveDisabled = true;
                vm.formData = {};
                vm.iboxToolsValidationVisible = true;
                vm.action = null;

                if ((vm.inputScope) && (vm.inputScope.action)) {
                    vm.action = vm.inputScope.action;
                }

                function loadEntity() {
                    labsiteManageApi.getById({ entityId: vm.inputScope.Id }).$promise.then(function (response) {
                        vm.formData.Labsite = response.state;
                    });
                }

                function deleteEntity() {
                    loadEntity();
                    vm.isDeleteFlag = true;
                    vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.DeleteButton"));
                    vm.saveDisabled = false;
                    vm.iboxToolsValidationVisible = false;
                    vm.helpVisible = true;
                    vm.helpText = String($filter("trustedtranslate")("Views.Labsites.Manage.DeleteConfirmText"));;
                    vm.headerText = String($filter("trustedtranslate")("Views.Labsites.Manage.DeleteLabsite"));

                }

                function editEntity() {
                    loadEntity();
                    vm.headerText = String($filter("trustedtranslate")("Views.Labsites.Manage.UpdateLabsite"));
                }

                function addEntity() {
                    vm.formData.Labsite = {
                        "Id": null,
                        "Code": null,
                        "Name": null,
                        "Description": null,
                        "IsInUse": true

                    };
                    vm.headerText = String($filter("trustedtranslate")("Views.Labsites.Manage.AddLabsite"));
                }


                switch (vm.action) {
                case "delete":
                    deleteEntity();
                    break;
                case "edit":
                    editEntity();
                    break;
                case "add":
                    addEntity();
                    break;
                }


                vm.toggleInfoVisibility = function(visible, ignoreModalCheck) {
                    vm.infoVisible = ((!(ignoreModalCheck || false)) && (vm.isModal)) ? false : visible || false;
                    vm.iboxToolsInfoVisible = visible || false;
                    vm.iboxToolsInfoToggledExternally = vm.infoVisible;
                }

                vm.resetInfo = function() {
                    vm.infoText = "";
                    vm.infoClass = "alert alert-info";
                    vm.toggleInfoVisibility(false);
                }

                function handleInfoVisibleUpdates(newData) {
                    vm.toggleInfoVisibility(newData || false);
                };

                function handleInfoTextUpdates(newData) {
                    vm.infoText = newData || "";
                };

                function handleInfoClassUpdates(newData) {
                    vm.infoClass = newData || "alert alert-info";
                };

                //DDBS ibox-tools Settings
                vm.iboxToolsShowHideVisible = vm.isModal === true ? false : true;
                vm.iboxToolsInfoVisible = false;
                vm.iboxToolsInfoToggledExternally = false;

                vm.iboxToolsValidationToggledExternally = false;
                vm.iboxToolsFilterVisible = false;
                vm.iboxToolsSettingsVisible = false;
                vm.iboxToolsHelpVisible = true;
                vm.iboxToolsToggleInfo = function() {
                    vm.infoVisible = !vm.infoVisible;
                };
                vm.iboxToolsToggleFilter = function() {};
                vm.iboxToolsToggleSettings = function() {};
                vm.iboxToolsToggleHelp = function() {
                    vm.helpVisible = !vm.helpVisible;
                };

                vm.validationIssues = [];

                vm.formChanged = function() {
                    vm.saveDisabled = false;
                }

                vm.createValidationIssue = function(field, message, cssClass) {
                    return {
                        "field": field || "",
                        "message": message || "",
                        "cssClass": cssClass || ""
                    };
                }

                vm.createValidationInfoText = function(issues) {
                    var infoText = "";

                    if ((issues) && (issues.length > 0)) {
                        infoText = "<p>" +
                            String($filter("trustedtranslate")("Views.Labsites.Manage.ValidationHeaderText")) +
                            " " +
                            String($filter("trustedtranslate")("Common.Maintenance.ValidationHeaderSuffix")) +
                            "</p><ul>";

                        issues.forEach(function(issue) {
                            infoText += ("<li>" + issue.message + "</li>");
                        });

                        infoText += "</ul>";
                    }
                    return infoText;
                }

                $scope.$watch('infoVisible', handleInfoVisibleUpdates, true);
                $scope.$watch('infoText', handleInfoTextUpdates, true);
                $scope.$watch('infoClass', handleInfoClassUpdates, true);

                vm.validationCallback = function() {
                    vm.validateFormData(true);
                }

                vm.validateFormData = function(displayOkMessage) {
                    vm.resetInfo();
                    vm.validationIssues = [];
                    var issues = [];

                    var regEx = /^[a-zA-Z0-9]*$/;

                    if ((!vm.formData.Labsite.Code) || (vm.formData.Labsite.Code.length === 0)) {
                        issues.push(vm.createValidationIssue("Labsite.Code", String($filter("trustedtranslate")("Views.Labsites.Manage.ValidationMessages.LabsiteCodeRequired")), "has-error"));
                    }
                    else if ((vm.formData.Labsite.Code) && ((vm.formData.Labsite.Code.length < 4) || (vm.formData.Labsite.Code.length > 16))) {
                        issues.push(vm.createValidationIssue("Labsite.Code", String($filter("trustedtranslate")("Views.Labsites.Manage.ValidationMessages.LabsiteCodeLength")), "has-error"));
                    }

                    if ((!vm.formData.Labsite.Name) || (vm.formData.Labsite.Name.length === 0)) {
                        issues.push(vm.createValidationIssue("Labsite.Name", String($filter("trustedtranslate")("Views.Labsites.Manage.ValidationMessages.LabsiteNameRequired")), "has-error"));
                    }
                    else if ((vm.formData.Labsite.Name) && ((vm.formData.Labsite.Name.length < 2) || (vm.formData.Labsite.Name.length > 50))) {
                        issues.push(vm.createValidationIssue("Labsite.Name", String($filter("trustedtranslate")("Views.Labsites.Manage.ValidationMessages.LabsiteNameLength")), "has-error"));
                    }

                    if (!regEx.test(vm.formData.Labsite.Code)) {
                        issues.push(vm.createValidationIssue("Labsite.Code", String($filter("trustedtranslate")("Views.Labsites.Manage.ValidationMessages.LabsiteCodeSpecialCharacter")), "has-error"));
                    }

                    if ((vm.formData.Labsite.Description) && (vm.formData.Labsite.Description.length > 500)) {
                        issues.push(vm.createValidationIssue("Labsite.Description", String($filter("trustedtranslate")("Views.Labsites.Manage.ValidationMessages.LabsiteDescriptionLength")), "has-error"));
                    }

                    if (issues.length > 0) {
                        var fieldIssues = [];
                        issues.forEach(function(issue) {
                            var fieldIssueExists = false;
                            fieldIssues.forEach(function(fieldIssue) {
                                if (fieldIssue.field === issue.field) {
                                    fieldIssueExists = true;
                                    fieldIssue.message += ("  " + issue.message);
                                }
                            });
                            if (!fieldIssueExists) {
                                fieldIssues.push(issue);
                            }
                        });

                        vm.infoText = vm.createValidationInfoText(issues);
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true);

                        vm.validationIssues = fieldIssues;
                    } else {
                        if (displayOkMessage || false) {
                            toastr.success(String($filter("trustedtranslate")("Views.Labsites.Manage.ValidationOkText")));
                        }
                    }
                };

                vm.getFieldValidationIssue = function(field) {
                    var fieldIssue = vm.createValidationIssue("", "", ""); //Need empty issue - including cssClass
                    if ((vm.validationIssues) && (vm.validationIssues.length > 0)) {
                        for (var i = 0; i < vm.validationIssues.length; i++) {
                            if (vm.validationIssues[i].field === field) {
                                fieldIssue = vm.validationIssues[i];
                                break;
                            }
                        }
                    }
                    return fieldIssue;
                }

                switch (vm.action) {
                    case "delete":
                        deleteEntity();
                        break;
                    case "edit":
                        editEntity();
                        break;
                    case "add":
                        addEntity();
                        break;
                }
                

                vm.save = function() {
                    if (vm.action === "delete") {
                        labsiteManageApi.remove({ entityId: vm.inputScope.Id }).$promise.then(
                            function() {
                                toastr.success(String($filter("trustedtranslate")("Views.Labsites.Manage.DeleteOkText")));
                                vm.showSubmissionResponse(true);
                            }, function(result) {
                                vm.showSubmissionResponse(false, result.data);
                            });
                    } else {
                        vm.validateFormData();
                        var updateCommand = {
                            comment: "Updating Labsite",
                            ActionArguments: {
                                "labSiteState": vm.formData.Labsite
                            }
                        };

                        var addCommand = {
                            comment: "Adding Labsite",
                            ActionArguments: {
                                "code": vm.formData.Labsite.Code,
                                "name": vm.formData.Labsite.Name,
                                "description": vm.formData.Labsite.Description,
                                "isInuse": vm.formData.Labsite.IsInUse
                                
                            }
                        };

                        if (vm.validationIssues.length === 0) {

                            if (vm.formData.Labsite.Id) {
                                //Update
                                labsiteManageApi.update({ entityId: vm.inputScope.Id,rowVersion: vm.formData.Labsite.RowVersion }, updateCommand).$promise.then(
                                    function() {
                                        toastr.success(String($filter("trustedtranslate")("Views.Labsites.Manage.UpdateOkText")));
                                        vm.showSubmissionResponse(true);
                                    }, function(result) {
                                        vm.showSubmissionResponse(false, result.data);
                                    });
                            } else {
                                //Create
                                labsiteManageApi.save(addCommand).$promise.then(
                                    function() {
                                        toastr.success(String($filter("trustedtranslate")("Views.Labsites.Manage.SaveOkText")));
                                        vm.showSubmissionResponse(true);
                                    }, function(result) {
                                        vm.showSubmissionResponse(false, result.data);
                                    });
                            }
                        }
                    }
                };

                vm.cancel = function() {
                    vm.appCallback('cancel', {});
                };

                vm.showSubmissionResponse = function(success, message) {
                    if (success) {
                        vm.appCallback('saveOk', {});
                    } else {
                        if (vm.isDeleteFlag) {
                            vm.infoText = message;
                        } else {
                            var issues = [];
                            issues.push(vm.createValidationIssue("", message, "has-error"));
                            vm.infoText = vm.createValidationInfoText(issues);
                        }
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true, true);
                    }
                };
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function(element) {
                return recursionHelper.compile(element);
            }
        }
    };
    angular.module('app.limsAdmin.labsite.manage').directive('labsiteManage', labsiteManage);
    labsiteManage.$inject = ['$sce', '$filter', '$translate', 'recursionHelper', 'toastr', 'labsiteManageApi'];
})();

angular
    .module('app.limsAdmin.labsite.manage', []);
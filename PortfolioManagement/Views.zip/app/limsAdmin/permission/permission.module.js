angular
    .module('app.limsAdmin.permission', [       
        'app.limsAdmin.permission.manage'
    ]);
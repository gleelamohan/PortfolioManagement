(function () {
    angular
        .module('app.limsAdmin.permission')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];

    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('limsAdmin.permission', {
                abstract: true,
                url: "/permission",
                template: '<ui-view />'
            });
    }
})();
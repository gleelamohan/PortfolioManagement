(function () {


    function permissionManageCtrl($scope, $filter, $timeout, $modal, permissionApi) {

        var vm = this;
        vm.searchService = permissionApi;
        vm.searchResults = [];

        vm.deleteCallback = function (id) {
            //var inputScope = { Id: id, action: "delete" }
            //vm.openModal(inputScope);

            var callbackAction = "rowSelect";
            var callbackScope = { "Id": id, "isDelete": "true" };
            appCallback(callbackAction, callbackScope);
        }

        vm.editCallback = function (id) {
            //var inputScope = { Id: id, action: "edit" }
            //vm.openModal(inputScope);


            var callbackAction = "rowSelect";
            var callbackScope = { Id: id };
            appCallback(callbackAction, callbackScope);

        }

        vm.addCallback = function () {
            //var inputScope = { Id: null, action: "add" }
            //vm.openModal(inputScope);
            var callbackAction = "addNew";
            var callbackScope = { Id: null };
            appCallback(callbackAction, callbackScope);


        }

        vm.openModal = function (modalScope) {
            var modalInstance = $modal.open({
                template: '<div class="modal-body"><permission-manage ismodal="true" inputscope="vm.inputScope" appcallback="vm.appCallback" infovisible="vm.infoVisible" infotext="vm.infoText" infoclass="vm.infoClass"></permission-manage></div>',
                controller: 'ModalCtrl as vm',
                backdrop: 'static',
                keyboard: true,
                scope: function () {
                    var scope = $scope.$new();
                    scope.inputScope = modalScope;
                    return scope;
                }()
            });

            modalInstance.result.then(function (modalReturnScope) {
                var outputScope = modalReturnScope || null;
                if (outputScope) {
                    vm.refreshGrid();
                }
            }, function () { });
        }

        function getPermissions() {
            vm.searchService.query().$promise.then(function (response) {
                vm.searchResults = response;
            }, function (error) {
                console.log(error);
                vm.searchResults = [];
            });
        };

        getPermissions();

        vm.searchResultsTemplateUrl = "/app/components/globalSearch/globalSearchResult/globalSearchResult.html";
        vm.searchResultsSettingsTemplateUrl = "/app/components/globalSearch/globalSearchSettings/globalSearchSettings.html";
    }

    angular.module('app.limsAdmin.permission.manage')
        .controller('permissionManageCtrl', permissionManageCtrl);
    permissionManageCtrl.$inject = ['$scope', '$filter', '$timeout', '$modal', 'permissionApi'];
})();
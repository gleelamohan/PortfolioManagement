(function () {
    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;
        $httpProvider.defaults.useXDomain = true;

        $urlRouterProvider.otherwise("/");
        $stateProvider
            .state('limsAdmin.permission.manage', {
                url: "/manage",
                template: '<global-search-results results="vm.searchResults" ismodal="false" config="vm.searchService.globalSearchGridConfig" templateurl="vm.searchResultsTemplateUrl" settingstemplateurl="vm.searchResultsSettingsTemplateUrl" templateconfig="vm.searchService.globalSearchConfig.templateConfig" addnew="false"></global-search-results>',
                controller: "permissionManageCtrl",
                controllerAs: "vm"
            });
    }

    angular
        .module('app.limsAdmin.permission.manage')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];
})();


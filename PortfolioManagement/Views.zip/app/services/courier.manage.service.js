(function () {

    function courierManageApi($resource, datacontext, efLibrary, efUiGridApi) {

        var courierUrl = window.app.services.eLimsServiceHost + '/api/Couriers';

        var service = $resource(courierUrl, {}, {

            getById: { method: 'GET', url: courierUrl + '/getbyid', params: { id: '@id' }, isArray: false },
            update: { method: 'PUT', url: courierUrl + '/update/' + { id: '@id' }, params: { formData: '@formdata' }, isArray: false },
            save: { method: 'POST', url: courierUrl + '/add', params: { formData: '@formdata' }, isArray: false },
            remove: { method: 'DELETE', url: courierUrl + '/remove/' + { id: '@id' } }
        });

        service.query = function (searchObject) {
            var query;
            var selection = "Id, Name, Address";
            var collection = "Couriers";
            if (searchObject === null || searchObject === undefined || searchObject.searchTerm === undefined || searchObject.searchTerm === null || searchObject.searchTerm === "") {
                query = breeze.EntityQuery.from(collection).select(selection);
            } else {
                var op = breeze.FilterQueryOp;
                var p1 = new breeze.Predicate("Name", op.Contains, searchObject.searchTerm);
                var p2 = breeze.Predicate("Address", op.Contains, searchObject.searchTerm);

                var predicate = p1.or(p2);

                query = breeze.EntityQuery.from(collection).select(selection).where(predicate);
            }

            return datacontext.executeQuery(query);
        };

        service.globalSearchConfig = function () {
            return {
                "templateConfig": {
                    "pagetitle": "Views.Couriers.Search.TemplateConfig.PageTitle",
                    "searchResultPanelTitle": "Views.Couriers.Search.TemplateConfig.SearchResultsPanelTitle",
                    "searchResultsHelpText": "Common.Maintenance.SearchResultsHelpText",
                    "searchResultsNoResultsText": "Views.Couriers.Search.TemplateConfig.SearchResultsNoResultsText",
                    "addNewText": "Views.Couriers.Search.TemplateConfig.AddNewText"
                },
                "searchEntryConfig": {
                    "searchEntryPanelTitle": "Views.Couriers.Search.SearchEntryConfig.SearchEntryTitle",
                    "helpText": "Views.Couriers.Search.SearchEntryConfig.SearchEntryHelpText",
                    "defaultSearchTermLabel": "Views.Couriers.Search.SearchEntryConfig.SearchTermPlaceholder",
                    "defaultSearchTermPlaceholder": "Views.Couriers.Search.SearchEntryConfig.DefaultSearchTermPlaceholder",
                    "displaySearchTermLabel": true,
                    "defaultSearchTerm": "",
                    "searchTermMinLength": 0,
                    "searchTermMaxLength": 16,
                    "includeSearchEntryOptions": false,
                    "enableSearchEntryOptionsToggle": true,
                    "defaultSearchScope": { "selectedSeacrhScope": "" }
                }
            }
        }

        service.globalSearchGridConfig = function () {

            var gridOption = efLibrary.copyObject(efUiGridApi.exportGridConfig, true);
            var name = efUiGridApi.createReadonlyColumn("Name", "Entity.Courier.Name.ColumnText", { width: "20%" });
            var address = efUiGridApi.createReadonlyColumn("Address", "Entity.Courier.Address.ColumnText", null);
            var colEdit = efUiGridApi.createActionColDef("globalSearchResultUiGrid", "Edit", "Id", "vm.editCallback", null);
            var colDelete = efUiGridApi.createActionColDef("globalSearchResultUiGrid", "Delete", "Id", "vm.deleteCallback", "<i class=\"fa fa-trash-o\"></i>");
            gridOption.columnDefs.push(name);
            gridOption.columnDefs.push(address);
            gridOption.columnDefs.push(colEdit);
            gridOption.columnDefs.push(colDelete);
            return gridOption;
        }

        return service;
    }

    angular.module('app')
        .factory('courierManageApi', courierManageApi);

    courierManageApi.$inject = ['$resource', "datacontext", "efLibrary", "efUiGridApi"];
})();
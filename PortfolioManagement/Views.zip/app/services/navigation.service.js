(function () {
	angular.module('app').factory('navigationApi', navigationApi);

	navigationApi.$inject = ['$resource'];

	function navigationApi($resource)
	{
	    //$httpProvider.defaults.withCredentials = true;
		var ret = $resource(window.app.services.eLimsServiceHost + '/api/NavNodes/', {}, {
	        query: { method: 'GET', params: {}, isArray: false },
	        getNode: { method: 'GET', url: window.app.services.eLimsServiceHost + '/api/navnodes/:id', params: {}, isArray: false },
	        getServerVersion: { method: 'GET', url: window.app.services.eLimsServiceHost + '/api/navnodes/GetServerVersion' }
		});
        return ret;
	}



})();
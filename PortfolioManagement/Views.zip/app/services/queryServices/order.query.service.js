(function () {

    function orderQueryApi(datacontext) {
        var getOrders = function (searchObject) {
            var query = "";
            var selection = "Id,OrderNo,EurofinsBarcodeId,QuoteId,ERPClientId";
            var collection = "Orders";

            if (searchObject === null || searchObject === undefined || searchObject.searchTerm === undefined || searchObject.searchTerm === null || searchObject.searchTerm === "") {
                query = breeze.EntityQuery.from(collection).select(selection);
            } else {
                //query = breeze.EntityQuery.from(collection).select(selection).where(predicate);
            }
            return datacontext.executeQuery(query);
        };

        var getOrdersBySearch = function (searchCriteria, searchValue) {

            var selection = "Id,OrderNo,EurofinsBarcodeId,QuoteId,ERPClientId,OrderConfirmationDate, ERPContactId";
            var collection = "Orders";
            var query = breeze.EntityQuery.from(collection).select(selection);

            if (searchValue !== undefined && searchValue !== null) {

                if (searchValue.ERPClientId != undefined && searchValue.ERPContactId != undefined) {

                    var p1 = new breeze.Predicate("ERPClientId", breeze.FilterQueryOp.Equals, searchValue.ERPClientId);
                    var p2 = new breeze.Predicate("ERPContactId", breeze.FilterQueryOp.Equals, searchValue.ERPContactId);
                    query = query.where(p1.and(p2));
                }
                else if (searchValue.ERPClientId != undefined && searchValue.ERPContactId === undefined) {
                    var p3 = new breeze.Predicate(searchCriteria, breeze.FilterQueryOp.Contains, searchValue.ERPClientId);
                    query = query.where(p3);
                }
                else {

                    var p4 = new breeze.Predicate(searchCriteria, breeze.FilterQueryOp.Contains, searchValue);
                    query = query.where(p4);
                }
            }

            return datacontext.executeQuery(query);
        };


        var service = {
            "getOrders": getOrders,
            "getOrdersBySearch": getOrdersBySearch
        };
        return service;
    }

    angular
        .module('app')
        .factory('orderQueryApi', orderQueryApi);

    orderQueryApi.$inject = ['datacontext'];
})();
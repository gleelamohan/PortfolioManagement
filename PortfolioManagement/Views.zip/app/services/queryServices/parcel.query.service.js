(function () {

    function parcelQueryApi(datacontext) {
        var getParcels = function(searchObject) {            
            var selection = "Id,ParcelId,User.UserDetail.FirstName,User.UserDetail.LastName,RegistrationPhase,ReceptionistId,LabSite.Code,RegisteredDate,ReceivedDate,Courier.Id,Courier.Name,CourierTrakingNo,ParcelsOrders, ArrivalTemperatureId, SpecialHandlingId, ArrivalComments, ParcelsArrivalConditions, DiscrepancyTypeId, ParcelsStorageLocation";
            var collection = "Parcels";

            var query = breeze.EntityQuery.from(collection).select(selection);

            if (searchObject.searchTerm) {
                if (searchObject.searchTerm.split(".").length > 1) {
                    searchObject.searchTerm = "0";
                }

                var predi = new breeze.Predicate("ParcelId", breeze.FilterQueryOp.Equals, { value: searchObject.searchTerm.trim(), dataType: breeze.DataType.INT });
                query = query.where(predi);
            }

            else if (searchObject.searchScope) {

                if (searchObject.searchScope.ParcelPhaseId || searchObject.searchScope.ParcelPhaseId != undefined) {
                    var p1 = new breeze.Predicate("RegistrationPhase", breeze.FilterQueryOp.Equals, searchObject.searchScope.ParcelPhaseId);
                    query = query.where(p1);
                }
                if (searchObject.searchScope.CourierId || searchObject.searchScope.CourierId != undefined) {
                    var p2 = new breeze.Predicate("Courier.Id", breeze.FilterQueryOp.Equals, searchObject.searchScope.CourierId);
                    query = query.where(p2);
                }
                if ((searchObject.searchScope.ReceivedFromDate || searchObject.searchScope.ReceivedFromDate != undefined) && (searchObject.searchScope.ReceivedToDate || searchObject.searchScope.ReceivedToDate != undefined)) {
                    var p3 = new breeze.Predicate("ReceivedDate", breeze.FilterQueryOp.GreaterThan, searchObject.searchScope.ReceivedFromDate);
                    var p4 = new breeze.Predicate("ReceivedDate", breeze.FilterQueryOp.LessThan, moment(searchObject.searchScope.ReceivedToDate, 'YYYY/MM/DD').add('days', 1).format('YYYY/MM/DD'));
                    var predicate2 = breeze.Predicate.and([p3, p4]);

                    query = query.where(predicate2);
                } else if (searchObject.searchScope.ReceivedFromDate || searchObject.searchScope.ReceivedFromDate != undefined) {
                    var p5 = new breeze.Predicate("ReceivedDate", breeze.FilterQueryOp.GreaterThan, searchObject.searchScope.ReceivedFromDate);
                    query = query.where(p5);
                } else if (searchObject.searchScope.ReceivedToDate || searchObject.searchScope.ReceivedToDate != undefined) {
                    var p6 = new breeze.Predicate("ReceivedDate", breeze.FilterQueryOp.LessThan, moment(searchObject.searchScope.ReceivedToDate, 'YYYY/MM/DD').add('days', 1).format('YYYY/MM/DD'));
                    query = query.where(p6);
                }
            }

            query = query.expand("User.UserDetail,LabSite,Courier,ParcelsOrders, ParcelsArrivalConditions");
            return datacontext.executeQuery(query);
        };

        var getParcelById = function (guid) {
            var selection = "Id,ParcelId,User.UserDetail.FirstName,User.UserDetail.LastName,RegistrationPhase,ReceivedLabsiteId,ReceptionistId,LabSite.Code,RegisteredDate,ReceivedDate,Courier.Name,Courier.Id,CourierTrakingNo,RowVersion,ParcelsOrders,SenderId, ArrivalTemperatureId, SpecialHandlingId, ArrivalComments, ParcelsArrivalConditions, DiscrepancyTypeId, ParcelsStorageLocation,ParcelsAttachments";
            var collection = "Parcels";
            var query = breeze.EntityQuery.from(collection).select(selection);
            //query = breeze.EntityQuery.from(collection);

            if (guid != null) {
                var op = breeze.FilterQueryOp;
                var p1 = new breeze.Predicate("Id", op.Equals, guid);
                var predicate = p1;
                query = query.where(predicate);
            }
            query = query.expand("User.UserDetail,LabSite,Courier,ParcelsOrders, ParcelsArrivalConditions");
            return datacontext.executeQuery(query);
        };

       var getOrderDetailsByParcelId = function (guid) {
            var query ="";
            var selection = "Order.Id,Order.OrderNo,Order.EurofinsBarcodeId,Order.QuoteId,Order.ERPClientId";
            var collection = "ParcelsOrders";
            if (guid != null) {
                var op = breeze.FilterQueryOp;
                var p1 = new breeze.Predicate("ParcelId", op.Equals, guid);
                var predicate = p1;
                query = breeze.EntityQuery.from(collection).select(selection).where(predicate);
            }
            query = query.expand("Order");
            return datacontext.executeQuery(query);
        };

       var getAttachmentDetailsByAttachmentlId = function (guid) {
           var query = "";
           var selection = "ParcelId,Title,Description,FileName, Parcel.RowVersion";
           var collection = "ParcelsAttachments";
           if (guid != null) {
               var op = breeze.FilterQueryOp;
               var p1 = new breeze.Predicate("Id", op.Equals, guid);
               var predicate = p1;
               query = breeze.EntityQuery.from(collection).select(selection).where(predicate);
           }
           query = query.expand("Parcel");
           return datacontext.executeQuery(query);
       };
       
         var getAttachmentsByParcelId = function (guid) {
           var query = "";
           var selection = "Id,ParcelId,Title,Description,FileName,AttachedOn";
           var collection = "ParcelsAttachments";
           if (guid != null) {
               var op = breeze.FilterQueryOp;
               var p1 = new breeze.Predicate("ParcelId", op.Equals, guid);
               var predicate = p1;
               query = breeze.EntityQuery.from(collection).select(selection).where(predicate);
           }           
           return datacontext.executeQuery(query);
       };


        var service = {
            "getParcels": getParcels,
            "getParcelById" :getParcelById,
            "getOrderDetailsByParcelId": getOrderDetailsByParcelId,
            "getAttachmentDetailsByAttachmentlId": getAttachmentDetailsByAttachmentlId,
            "getAttachmentsByParcelId": getAttachmentsByParcelId
        };
        return service;
    }

    angular
        .module('app')
        .factory('parcelQueryApi', parcelQueryApi);

    parcelQueryApi.$inject = ['datacontext'];
})();
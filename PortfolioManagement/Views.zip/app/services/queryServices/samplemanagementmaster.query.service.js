(function () {

    function samplemanagementmasterQueryApi(datacontext) {
        var getArrivalConditions = function () {
            var query = breeze.EntityQuery.from("ArrivalConditions").select("Id, Condition");
            return datacontext.executeQuery(query);
        };

        var getArrivalTemperatures = function () {
            var query = breeze.EntityQuery.from("ArrivalTemperatures").select("Id, Temperature");
            return datacontext.executeQuery(query);
        };

        var getSpecialHandlings = function () {
            var query = breeze.EntityQuery.from("SpecialHandlings").select("Id, SpecialHandlingCondition");
            return datacontext.executeQuery(query);
        };

        var getDiscrepancyTypes = function () {
            var query = breeze.EntityQuery.from("ParcelDiscrepancyTypes").select("Id, Value");
            return datacontext.executeQuery(query);
        };

        var getStorageTemperatures = function () {
            var query = breeze.EntityQuery.from("StorageTemperatures").select("Id, Value");
            return datacontext.executeQuery(query);
        };

        var service = {
            "getArrivalConditions": getArrivalConditions,
            "getArrivalTemperatures": getArrivalTemperatures,
            "getSpecialHandlings": getSpecialHandlings,
            "getDiscrepancyTypes": getDiscrepancyTypes,
            "getStorageTemperatures": getStorageTemperatures
        };
        return service;
    }

    angular
        .module('app')
        .factory('samplemanagementmasterQueryApi', samplemanagementmasterQueryApi);

    samplemanagementmasterQueryApi.$inject = ['datacontext'];
})();
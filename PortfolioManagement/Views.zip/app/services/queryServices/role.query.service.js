(function () {

    function roleQueryApi(datacontext) {
        var getRoles = function (searchObject) {
            var query;
            var selection = "Id, Name, Description";
            var collection = "Roles";

            if (searchObject === null || searchObject === undefined || searchObject.searchTerm === undefined || searchObject.searchTerm === null || searchObject.searchTerm === "") {
                query = breeze.EntityQuery.from(collection).select(selection);
            } else {
                var op = breeze.FilterQueryOp;
                var p1 = new breeze.Predicate("Description", op.Contains, searchObject.searchTerm);
                var p2 = breeze.Predicate("Name", op.Contains, searchObject.searchTerm);
                var predicate = p1.or(p2);

                query = breeze.EntityQuery.from(collection).select(selection).where(predicate);
            }

            return datacontext.executeQuery(query);
        };

        var service = { "getRoles": getRoles };
        return service;
    }

    angular
        .module('app')
        .factory('roleQueryApi', roleQueryApi);

    roleQueryApi.$inject = ['datacontext'];
})();
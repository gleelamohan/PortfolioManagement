﻿(function () {

    function taskQueryApi(datacontext) {
        var getTasks = function (searchObject) {

            var selection = "Id, Name, Description, DueDate, Status";
            var collection = "Tasks";
            var query = breeze.EntityQuery.from(collection).select(selection);

            if (searchObject !== undefined && searchObject !== null) {

                if (searchObject.searchTerm) {
                    var p1 = new breeze.Predicate("Description", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    var p2 = breeze.Predicate("Name", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    query = query.where(breeze.Predicate.or([p1, p2]));
                }

                if (searchObject.searchScope) {

                    switch (searchObject.searchScope.selectedSeacrhStatus) {
                        case "Pending":
                            var p3 = new breeze.Predicate("DueDate", breeze.FilterQueryOp.LessThan, new Date());
                            var p4 = new breeze.Predicate("Status", breeze.FilterQueryOp.NotEquals, 1);
                            var p5 = new breeze.Predicate("Status", breeze.FilterQueryOp.NotEquals, 2);

                            var predicate2 = breeze.Predicate.and([p3, p4, p5]);

                            query = query.where(predicate2);
                            break;
                        case "Active":
                            var p6 = new breeze.Predicate("Status", breeze.FilterQueryOp.Equals, 0);
                            query = query.where(p6);
                            break;
                    }
                }
            }

            return datacontext.executeQuery(query);
        };

        var getTaskById = function (id) {

            //var selection = "Id, Name, Description, DueDate, Status, CreatorId, CreatedOn, RowVersion, " +
            //    "TaskAssignments.User.UserDetail.FirstName, TaskAssignments.User.UserDetail.LastName, " +
            //    "TaskAssignments.Status, TaskAssignments.LastModifiedOn, " +
            //    "TaskAssignments.AssignedOn, User.UserDetail.FirstName, User.UserDetail.LastName";

            var selection = "Id, Name, Description, DueDate, Status, CreatorId, CreatedOn, RowVersion";
            var query = breeze.EntityQuery.from("Tasks").select(selection);
            if (!id) {
                throw "Please pass a valid task id.";
            }

            var predicate = new breeze.Predicate("Id", breeze.FilterQueryOp.Equals, id);
            query = query.where(predicate);
           // query = query.expand("User.UserDetail");
            return datacontext.executeQuery(query);
        };

        var service = {
            "getTasks": getTasks ,
            "getTaskById": getTaskById
        };

        return service;
    }

    angular
        .module('app')
        .factory('taskQueryApi', taskQueryApi);

    taskQueryApi.$inject = ['datacontext'];
})();
﻿(function () {

    function notificationRecipientQueryApi(datacontext) {
        var getMyNotifications = function (searchObject) {

            var selection = "Id, ReadOn, Notification.Message, Notification.Subject, Notification.User.UserDetail.FirstName, Notification.User.UserDetail.LastName, ReceivedOn";
            var collection = "NotificationRecipients";
            var query = breeze.EntityQuery.from(collection).select(selection);

            if (searchObject !== undefined && searchObject !== null) {

                if (searchObject.searchTerm) {
                    var p1 = new breeze.Predicate("Notification.Subject", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    var p2 = breeze.Predicate("Notification.Message", breeze.FilterQueryOp.Contains, searchObject.searchTerm);

                    query = query.where(breeze.Predicate.or(p1,p2));
                }

                if (searchObject.searchScope) {

                    switch (searchObject.searchScope.selectedSeacrhStatus) {
                        case "Read":
                            var p3 = new breeze.Predicate("ReadOn", breeze.FilterQueryOp.NotEquals, null);
                            query = query.where(p3);
                            break;
                        case "Unread":
                            var p4 = new breeze.Predicate("ReadOn", breeze.FilterQueryOp.Equals, null);
                            query = query.where(p4);
                            break;       
                    }
                }
            }

            query = query.expand("Notification.User.UserDetail");
            return datacontext.executeQuery(query);
        };

        var getNotificationRecipientById = function(id) {
            var selection = "Id, RowVersion, ReadOn, " +
                "User.UserDetail.FirstName, User.UserDetail.LastName, " +
                "Notification.Message, Notification.Subject, Notification.SentOn, Notification.User.UserDetail.FirstName, Notification.User.UserDetail.LastName";
            var query = breeze.EntityQuery.from("NotificationRecipients").select(selection);

            query = query.where(new breeze.Predicate("Id", breeze.FilterQueryOp.Equals, id));

            query = query.expand("User.UserDetail, Notification.User.UserDetail");

            return datacontext.executeQuery(query);
        };

        var getNotificationRecipientsByNotificationId = function (notificationId) {
            //var selection = "Id, Message, Subject, RowVersion, SentOn, User.UserDetail.FirstName, User.UserDetail.LastName";
            var selection = "Id, RowVersion, ReadOn, NotificationId, RecipientId, " +
                "User.UserDetail.FirstName, User.UserDetail.LastName, " +
                "Notification.Message, Notification.Subject, Notification.SentOn, Notification.User.UserDetail.FirstName, Notification.User.UserDetail.LastName";

            var query = breeze.EntityQuery.from("AllNotificationRecipients").select(selection);

            query = query.where(new breeze.Predicate("NotificationId", breeze.FilterQueryOp.Equals, notificationId));

            query = query.expand("User.UserDetail, Notification.User.UserDetail");

            return datacontext.executeQuery(query);
        };


        var service = {
            "getMyNotifications": getMyNotifications,
            "getNotificationRecipientById": getNotificationRecipientById,
            "getNotificationRecipientsByNotificationId": getNotificationRecipientsByNotificationId
        };
        return service;
    }

    angular
        .module('app')
        .factory('notificationRecipientQueryApi', notificationRecipientQueryApi);

    notificationRecipientQueryApi.$inject = ['datacontext'];
})();
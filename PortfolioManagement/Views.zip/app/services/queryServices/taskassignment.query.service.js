﻿(function () {

    function taskAssignmentQueryApi(datacontext) {
        var getTaskAssignments = function (searchObject) {

            var selection = "Id, Task.Name, Task.Description, Task.User.UserDetail.FirstName, Task.User.UserDetail.LastName, Task.DueDate, Status";
            var collection = "TaskAssignments";
            var query = breeze.EntityQuery.from(collection).select(selection);

            if (searchObject !== undefined && searchObject !== null) {

                if (searchObject.searchTerm) {
                    var p1 = new breeze.Predicate("Task.Description", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    var p2 = breeze.Predicate("Task.Name", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    var predicate1 = p1.or(p2);

                    query = query.where(predicate1);
                }

                if (searchObject.searchScope) {

                    switch (searchObject.searchScope.selectedSeacrhStatus) {
                        case "Pending":
                            var p3 = new breeze.Predicate("Task.DueDate", breeze.FilterQueryOp.LessThan, new Date());
                            var p4 = new breeze.Predicate("Status", breeze.FilterQueryOp.NotEquals, 2);
                            var p5 = new breeze.Predicate("Status", breeze.FilterQueryOp.NotEquals, 3);
                            var predicate2 = breeze.Predicate.and([p3, p4, p5]);
                            query = query.where(predicate2);
                            break;
                        case "InProgress":
                            var p7 = new breeze.Predicate("Status", breeze.FilterQueryOp.Equals, 1);
                            query = query.where(p7);
                            break;
                        case "New":
                            var p8 = new breeze.Predicate("Status", breeze.FilterQueryOp.Equals, 0);
                            query = query.where(p8);
                            break;
                    }
                }
            }

            query = query.expand("Task.User.UserDetail");
            return datacontext.executeQuery(query);
        };

        var getMyTaskById = function (id) {
            var selection = "Id, AssigneeId, Status, AssignedOn, RowVersion, " +
                "User.UserDetail.FirstName, User.UserDetail.LastName, " +
                "Task.Name, Task.Description, Task.Status, Task.User.UserDetail.FirstName, Task.User.UserDetail.LastName, Task.DueDate";
            var query = breeze.EntityQuery.from("TaskAssignments").select(selection);

            if (!id) {
                throw "Please pass a valid task assignment id.";
            }

            var predicate = new breeze.Predicate("Id", breeze.FilterQueryOp.Equals, id);
            query = query.where(predicate);
            query = query.expand("Task.User.UserDetail, User.UserDetail");
            return datacontext.executeQuery(query);
        };


        var getAssignmentsByTaskId = function (taskId) {

            var selection = "Id, TaskId, AssigneeId, Status, User.UserDetail.FirstName, User.UserDetail.LastName";
            var query = breeze.EntityQuery.from("AllTaskAssignments").select(selection);

            if (!taskId) {
                throw "Please pass a valid task id.";
            }

            var predicate = new breeze.Predicate("TaskId", breeze.FilterQueryOp.Equals, taskId);
            query = query.where(predicate);
            query = query.expand("User.UserDetail");
            return datacontext.executeQuery(query);
        };

        var service = {
            "getTaskAssignments": getTaskAssignments,
            "getMyTaskById": getMyTaskById,
            "getAssignmentsByTaskId": getAssignmentsByTaskId
        };
        return service;
    }

    angular
        .module('app')
        .factory('taskAssignmentQueryApi', taskAssignmentQueryApi);

    taskAssignmentQueryApi.$inject = ['datacontext'];
})();
(function () {

    function courierQueryApi(datacontext) {
        var getCouriers = function (searchObject) {
            var query;
            var selection = "Id, Name, Address";
            var collection = "Couriers";
            if (searchObject === null || searchObject === undefined || searchObject.searchTerm === undefined || searchObject.searchTerm === null || searchObject.searchTerm === "") {
                query = breeze.EntityQuery.from(collection).select(selection);
            } else {
                var op = breeze.FilterQueryOp;
                var p1 = new breeze.Predicate("Name", op.Contains, searchObject.searchTerm);
                var p2 = breeze.Predicate("Address", op.Contains, searchObject.searchTerm);

                var predicate = p1.or(p2);

                query = breeze.EntityQuery.from(collection).select(selection).where(predicate);
            }

            return datacontext.executeQuery(query);
        };        


        var service = { "getCouriers": getCouriers };
        return service;
    }

    angular
        .module('app')
        .factory('courierQueryApi', courierQueryApi);

    courierQueryApi.$inject = ['datacontext'];
})();
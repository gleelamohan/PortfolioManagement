(function () {
    function datacontext(queryServiceUrl) {
        var dataContext = new breeze.EntityManager(queryServiceUrl);     
        return dataContext;
    }

    angular
        .module('app')
        .factory('datacontext', datacontext);

    datacontext.$inject = ['queryServiceUrl'];
})();
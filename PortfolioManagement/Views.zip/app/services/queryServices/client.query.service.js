(function () {

    function clientQueryApi(datacontext) {
        var getClients = function (searchObject) {
            var query;
            var selection = "Id, ERPClientId, Name";
            var collection = "Clients";
            if (searchObject === null || searchObject === undefined || searchObject.searchTerm === undefined || searchObject.searchTerm === null || searchObject.searchTerm === "") {
                query = breeze.EntityQuery.from(collection).select(selection);
            } else {
                var op = breeze.FilterQueryOp;
                var p1 = new breeze.Predicate("ERPClientId", op.Contains, searchObject.searchTerm);
                var p2 = breeze.Predicate("Name", op.Contains, searchObject.searchTerm);
                var predicate = p1.or(p2);

                query = breeze.EntityQuery.from(collection).select(selection).where(predicate);
            }

            return datacontext.executeQuery(query);
        };
        var getContactsByClientId = function (id) {
            var selection = "Id, ERPContactId, Name, ClientId, LastSyncOn";
            var query = breeze.EntityQuery.from("Contacts").select(selection);

            query = query.where(new breeze.Predicate("ClientId", breeze.FilterQueryOp.Equals, id));

            return datacontext.executeQuery(query);
        };

        var getSendersByClientId = function (id) {
            var selection = "Id,Sender.CRMSenderId,Sender.Name";
            var query = breeze.EntityQuery.from("ClientsSenders").select(selection);
            query = query.where(new breeze.Predicate("ClientId", breeze.FilterQueryOp.Equals, id));
            query = query.expand("Sender");
            return datacontext.executeQuery(query);
        };

        var getClientBySenderId = function (id) {
            var selection = "Client.Id,Client.ERPClientId, Client.Name";
            var query = breeze.EntityQuery.from("ClientsSenders").select(selection);
            query = query.where(new breeze.Predicate("Id", breeze.FilterQueryOp.Equals, id));
            query = query.expand("Client");
            return datacontext.executeQuery(query);
        };

        var getSenderDetailByClientSenderId = function (id) {
            var selection = "Id,Sender.CRMSenderId,Sender.Name";
            var query = breeze.EntityQuery.from("ClientsSenders").select(selection);
            query = query.where(new breeze.Predicate("Id", breeze.FilterQueryOp.Equals, id));
            query = query.expand("Sender");
            return datacontext.executeQuery(query);
        };


        var service = {
            "getClients": getClients ,
            "getContactsByClientId": getContactsByClientId,
            "getSendersByClientId": getSendersByClientId,
            "getClientBySenderId": getClientBySenderId,
            "getSenderDetailByClientSenderId": getSenderDetailByClientSenderId
        };
        return service;
    }

    angular
        .module('app')
        .factory('clientQueryApi', clientQueryApi);

    clientQueryApi.$inject = ['datacontext'];
})();
(function () {

    function labsiteQueryApi(datacontext) {
        var getLabSites = function (searchObject) {
            var query;
            var selection = "Id, Code, Name, Description, IsInUse";
            var collection = "LabSites";
            if (searchObject === null || searchObject === undefined || searchObject.searchTerm === undefined || searchObject.searchTerm === null || searchObject.searchTerm === "") {
                query = breeze.EntityQuery.from(collection).select(selection);
            } else {
                var op = breeze.FilterQueryOp;
                var p1 = new breeze.Predicate("Description", op.Contains, searchObject.searchTerm);
                var p2 = breeze.Predicate("Name", op.Contains, searchObject.searchTerm);
                var p3 = breeze.Predicate("Code", op.Contains, searchObject.searchTerm);

                var predicate = p1.or(p2).or(p3);

                query = breeze.EntityQuery.from(collection).select(selection).where(predicate);
            }

            return datacontext.executeQuery(query);
        };        

        var service = { "getLabSites": getLabSites };
        return service;
    }

    angular
        .module('app')
        .factory('labsiteQueryApi', labsiteQueryApi);

    labsiteQueryApi.$inject = ['datacontext'];
})();
(function () {

    function userQueryApi(datacontext) {

        var getUsers = function (searchObject) {            
            var selection = "Id, Puid, UserDetail.FirstName, UserDetail.LastName, UserDetail.EmailId, IsActive";
            var collection = "Users";
            var query = breeze.EntityQuery.from(collection).select(selection);

            if (searchObject !== undefined && searchObject !== null) {
                if (searchObject.searchTerm !== undefined && searchObject.searchTerm !== null && searchObject.searchTerm !== "") {
                    var p1 = new breeze.Predicate("Puid", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    var p2 = new breeze.Predicate("UserDetail.FirstName", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    var p3 = new breeze.Predicate("UserDetail.LastName", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    var p4 = new breeze.Predicate("UserDetail.EmailId", breeze.FilterQueryOp.Contains, searchObject.searchTerm);

                    var predicate = p1.or(p2).or(p3).or(p4);
                    query = breeze.EntityQuery.from(collection).select(selection).where(predicate);
                }
            }

            query = query.expand("UserDetail");

            return datacontext.executeQuery(query);
        };

        var getUsersForUserSearchControl = function () {
            var selection = "User.Id, FirstName, LastName, User.Puid";
            var collection = "UserDetails";
            var query = breeze.EntityQuery.from(collection).select(selection).expand("User");
            return datacontext.executeQuery(query);
        };

        var getCurrentUserLabSites = function() {
            var selection = "Id, Code";
            var collection = "CurrentUserLabSites";
            var query = breeze.EntityQuery.from(collection).select(selection);            
            return datacontext.executeQuery(query);
        }

        var service = {
            "getUsers": getUsers,
            "getCurrentUserLabSites": getCurrentUserLabSites,
            "getUsersForUserSearchControl": getUsersForUserSearchControl
        };

        return service;
    }

    angular
        .module('app')
        .factory('userQueryApi', userQueryApi);

    userQueryApi.$inject = ['datacontext'];
})();
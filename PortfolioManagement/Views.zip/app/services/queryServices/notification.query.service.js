﻿(function () {

    function notificationQueryApi(datacontext) {
        var getNotifications = function (searchObject) {

            var selection = "Id, Subject, Message, SentOn, NotificationRecipients";
            var collection = "Notifications";
            
            var query = breeze.EntityQuery.from(collection).select(selection);
            //var query = breeze.EntityQuery.from(collection);

            if (searchObject !== undefined && searchObject !== null) {

                if (searchObject.searchTerm) {
                    var p1 = new breeze.Predicate("Subject", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    var p2 = breeze.Predicate("Message", breeze.FilterQueryOp.Contains, searchObject.searchTerm);

                    query = query.where(breeze.Predicate.or([p1,p2]));
                }

                if (searchObject.searchScope) {

                    switch (searchObject.searchScope.selectedSeacrhStatus) {
                        case "Unread":
                            var p3 = new breeze.Predicate("NotificationRecipients", breeze.FilterQueryOp.Any, "ReadOn", breeze.FilterQueryOp.Equals, null);
                            query = query.where(p3);
                            break;
                        case "Read":
                            var p4 = new breeze.Predicate("NotificationRecipients", breeze.FilterQueryOp.All, "ReadOn", breeze.FilterQueryOp.NotEquals, null);
                            query = query.where(p4);
                            break;
                    }
                }
            }

            query = query.expand("NotificationRecipients.User.UserDetail");          

            return datacontext.executeQuery(query);
        };

        var getNotificationById = function(id) {
            var selection = "Id, Message, Subject, RowVersion, SentOn, User.UserDetail.FirstName, User.UserDetail.LastName";
            var query = breeze.EntityQuery.from("Notifications").select(selection);

            query = query.where(new breeze.Predicate("Id", breeze.FilterQueryOp.Equals, id));

            query = query.expand("User.UserDetail");

            return datacontext.executeQuery(query);
        };

        var service = {
            "getNotifications": getNotifications,
            "getNotificationById": getNotificationById
        };
        return service;
    }

    angular
        .module('app')
        .factory('notificationQueryApi', notificationQueryApi);

    notificationQueryApi.$inject = ['datacontext'];
})();
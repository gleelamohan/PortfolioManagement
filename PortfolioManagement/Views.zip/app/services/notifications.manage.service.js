(function () {
    function notificationManageApi($resource, $filter, $translate, datacontext, efLibrary, efUiGridApi, efDatetimeMasks) {

        var notificationManagementServiceUrl = window.app.services.eLimsServiceHost + '/api/smartservice/NotificationManagementService/';

        var service = $resource(notificationManagementServiceUrl, {}, {
            //getById: { method: 'GET', url: notificationUrl + '/getById', params: { id: '@id' }, isArray: false },
            save: {
                method: 'POST',
                url: notificationManagementServiceUrl + 'AddNotification',
                params: { subject: '@subject', message: '@message', recipientIds: '@recipientIds', comment: '@comment' },
                isArray: false
            },
            update: {
                method: 'PUT',
                url: notificationManagementServiceUrl + 'UpdateNotification',
                params: { notificationId: '@notificationId', rowVersion: '@rowVersion', subject: '@subject', message: '@message', recipientIds: '@recipientIds', comment: '@comment' },
                isArray: false
            }
        });

        service.query = function(searchObject) {
            var selection = "Id, Subject, Message, SentOn, NotificationRecipients";
            var collection = "Notifications";

            var query = breeze.EntityQuery.from(collection).select(selection);

            if (searchObject !== undefined && searchObject !== null) {

                if (searchObject.searchTerm) {
                    var p1 = new breeze.Predicate("Subject", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    var p2 = breeze.Predicate("Message", breeze.FilterQueryOp.Contains, searchObject.searchTerm);

                    query = query.where(breeze.Predicate.or([p1, p2]));
                }

                if (searchObject.searchScope) {

                    switch (searchObject.searchScope.selectedSeacrhStatus) {
                    case "Unread":
                        var p3 = new breeze.Predicate("NotificationRecipients", breeze.FilterQueryOp.Any, "ReadOn", breeze.FilterQueryOp.Equals, null);
                        query = query.where(p3);
                        break;
                    case "Read":
                        var p4 = new breeze.Predicate("NotificationRecipients", breeze.FilterQueryOp.All, "ReadOn", breeze.FilterQueryOp.NotEquals, null);
                        query = query.where(p4);
                        break;
                    }
                }
            }

            query = query.expand("NotificationRecipients.User.UserDetail");

            return datacontext.executeQuery(query);
        };

        service.getNotificationById = function(id) {
            var selection = "Id, Message, Subject, RowVersion, SentOn, User.UserDetail.FirstName, User.UserDetail.LastName";
            var query = breeze.EntityQuery.from("Notifications").select(selection);

            query = query.where(new breeze.Predicate("Id", breeze.FilterQueryOp.Equals, id));

            query = query.expand("User.UserDetail");

            return datacontext.executeQuery(query);
        };

        service.globalSearchConfig = function() {
            return {
                "templateConfig": {
                    "pagetitle": "Views.Notifications.Search.TemplateConfig.PageTitle",
                    "searchResultPanelTitle": "Views.Notifications.Search.TemplateConfig.SearchResultsPanelTitle",
                    "searchResultsHelpText": "Common.Maintenance.SearchResultsHelpText",
                    "searchResultsNoResultsText": "Views.Notifications.Search.TemplateConfig.SearchResultsNoResultsText",
                    "addNewText": "Views.Notifications.Search.TemplateConfig.AddNewText"
                },
                "searchEntryConfig": {
                    "searchEntryPanelTitle": "Views.Notifications.Search.SearchEntryConfig.SearchEntryTitle",
                    "helpText": "Views.Roles.Notifications.SearchEntryConfig.SearchEntryHelpText",
                    "defaultSearchTermLabel": "Views.Notifications.Search.SearchEntryConfig.SearchTermPlaceholder",
                    "defaultSearchTermPlaceholder": "Views.Notifications.Search.SearchEntryConfig.DefaultSearchTermPlaceholder",
                    "displaySearchTermLabel": true,
                    "defaultSearchTerm": "",
                    "searchTermMinLength": 0,
                    "searchTermMaxLength": 50,
                    "defaultSearchScope": { "selectedSeacrhStatus": String($filter("trustedtranslate")("Views.Notifications.Manage.StatusConfig.Unread")) },
                    "includeSearchEntryOptions": true,
                    "enableSearchEntryOptionsToggle": false,
                    "defaultSearchEntryOptionsTitle": "Views.Notifications.Search.SearchEntryConfig.DefaultSearchEntryOptionsTitle",
                    "searchEntryOptionsTemplateUrl": "/app/notifications/createdNotifications/manage/createdNotifications.search.html"
                }
            }
        }

        service.globalSearchGridConfig = function() {

            var gridOption = efLibrary.copyObject(efUiGridApi.exportGridConfig, true);
            var subject = efUiGridApi.createReadonlyColumn("Subject", "Entity.Notification.Subject.ColumnText", { width: "20%" });
            var message = efUiGridApi.createReadonlyColumn("Message", "Entity.Notification.Message.ColumnText", null);
            var status = efUiGridApi.createReadonlyColumn("NotificationRecipients", "Entity.Notification.Status.ColumnText", { width: "20%" });
            var sentOn = efUiGridApi.createReadonlyColumn("SentOn", "Entity.Notification.SentOn.ColumnText", { width: "20%" });
            var colEdit = efUiGridApi.createActionColDef("globalSearchResultUiGrid", "Edit", "Id", "vm.editCallback", null);
            sentOn.cellFilter = "date: '" + efDatetimeMasks.datetime.angular + "'";
            message.cellTooltip = true;
            status.cellFilter = "notificationReadFilter";

            gridOption.columnDefs.push(subject);
            gridOption.columnDefs.push(message);
            gridOption.columnDefs.push(status);
            gridOption.columnDefs.push(sentOn);
            gridOption.columnDefs.push(colEdit);
            return gridOption;
        }
        return service;
    }

    function notificationReadFilter() {
          return function (input) {
              if (input) {
                  for (var i = 0; i < input.length; i++) {
                      if (input[i].ReadOn === null) {
                          return "Unread";
                      }
                  }
                  return "Read";
              }              
              return "Unread";
          }
      };

    angular.module('app')
        .factory('notificationManageApi', notificationManageApi)
        .filter("notificationReadFilter", notificationReadFilter);

      notificationManageApi.$inject = ["$resource", "$filter", "$translate", "datacontext", "efLibrary", "efUiGridApi", "efDatetimeMasks"];
})();
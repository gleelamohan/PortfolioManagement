(function() {


    function userManageApi($resource, datacontext, efLibrary, efUiGridApi) {
        var smartServiceUrl = window.app.services.eLimsServiceHost + '/api/SmartEntity/User/';
        var smartStaticServiceUrl = window.app.services.eLimsServiceHost + '/api/SmartStatic/';

        var service = $resource(smartServiceUrl, {}, {
            getById: { method: 'GET', url: smartServiceUrl + '@id', isArray: false },
            getUserFromActiveDirectoryByPuid: { method: 'GET', url: smartStaticServiceUrl + 'ActiveDirectoryHelper' + '/GetActiveDirectoryUserInfo', params: { actionArguments:'@actionArguments' }, isArray: false },

            update: { method: 'PUT', url: smartServiceUrl + '@entityId' + '/' + '@rowVersion' + '/SynchronizeFromState', params: { formData: '@formdata' }, isArray: false },
            save: { method: 'POST', url: smartServiceUrl, params: { formData: '@formdata' }, isArray: false },
            remove: { method: 'DELETE', url: smartServiceUrl + '@id'}
        });

        service.getByPuid = function(puid) {
            var selection = "Id, Puid, UserDetail.FirstName, UserDetail.LastName, UserDetail.EmailId, IsActive, IsGlobalAdministrator";
            var collection = "Users";

            if (puid) {
                var query = breeze.EntityQuery.from(collection).select(selection).where("Puid", breeze.FilterQueryOp.Contains, puid).expand("UserDetail");
                return datacontext.executeQuery(query);
            } else {
                throw "Current user puid is not correct. Please contact system admin";
            }
        };

        service.query = function (searchObject) {

            var selection = "Id, Puid, UserDetail.FirstName, UserDetail.LastName, UserDetail.EmailId, IsActive";
            var collection = "Users";
            var query = breeze.EntityQuery.from(collection).select(selection);

            if (searchObject !== undefined && searchObject !== null) {
                if (searchObject.searchTerm !== undefined && searchObject.searchTerm !== null && searchObject.searchTerm !== "") {
                    var p1 = new breeze.Predicate("Puid", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    var p2 = new breeze.Predicate("UserDetail.FirstName", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    var p3 = new breeze.Predicate("UserDetail.LastName", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    var p4 = new breeze.Predicate("UserDetail.EmailId", breeze.FilterQueryOp.Contains, searchObject.searchTerm);

                    var predicate = p1.or(p2).or(p3).or(p4);
                    query = breeze.EntityQuery.from(collection).select(selection).where(predicate);
                }
            }
            query = query.expand("UserDetail");
            return datacontext.executeQuery(query);
        };

        service.getUsersForUserSearchControl = function () {
            var selection = "User.Id, FirstName, LastName, User.Puid";
            var collection = "UserDetails";
            var query = breeze.EntityQuery.from(collection).select(selection).expand("User");
            return datacontext.executeQuery(query);
        };

        service.getCurrentUserLabSites = function () {
            var selection = "Id, Code";
            var collection = "CurrentUserLabSites";
            var query = breeze.EntityQuery.from(collection).select(selection);
            return datacontext.executeQuery(query);
        }
       
        service.globalSearchConfig = function () {
            return {
                "templateConfig": {
                    "pagetitle": "Views.Users.Search.TemplateConfig.PageTitle",
                    "searchResultPanelTitle": "Views.Users.Search.TemplateConfig.SearchResultsPanelTitle",
                    "searchResultsHelpText": "Common.Maintenance.SearchResultsHelpText",
                    "searchResultsNoResultsText": "Views.Users.Search.TemplateConfig.SearchResultsNoResultsText",
                    "addNewText": "Views.Users.Search.TemplateConfig.AddNewText"
                },
                "searchEntryConfig": {
                    "searchEntryPanelTitle": "Views.Users.Search.SearchEntryConfig.SearchEntryTitle",
                    "helpText": "Views.Users.Search.SearchEntryConfig.SearchEntryHelpText",
                    "defaultSearchTermLabel": "Views.Users.Search.SearchEntryConfig.SearchTermPlaceholder",
                    "defaultSearchTermPlaceholder": "Views.Users.Search.SearchEntryConfig.DefaultSearchTermPlaceholder",
                    "displaySearchTermLabel": true,
                    "defaultSearchTerm": "",
                    "searchTermMinLength": 0,
                    "searchTermMaxLength": 16,
                    "includeSearchEntryOptions": false,
                    "enableSearchEntryOptionsToggle": true,
                    "defaultSearchScope": { "selectedSeacrhScope": "" }
                }
            }
        }

        service.globalSearchGridConfig = function () {
            var gridOption = efLibrary.copyObject(efUiGridApi.exportGridConfig, true);
            var puid = efUiGridApi.createReadonlyColumn("Puid", "Entity.User.Puid.ColumnText", { width: "10%" });
            var fname = efUiGridApi.createReadonlyColumn("UserDetail_FirstName", "Entity.User.FirstName.ColumnText", { width: "24%" });
            var lname = efUiGridApi.createReadonlyColumn("UserDetail_LastName", "Entity.User.LastName.ColumnText", { width: "24%" });
            var emailid = efUiGridApi.createReadonlyColumn("UserDetail_EmailId", "Entity.User.EmailId.ColumnText", null);
            var isActive = efUiGridApi.createReadonlyColumn("IsActive", "Entity.User.IsActive.ColumnText", { width: "10%" });
            var colEdit = efUiGridApi.createActionColDef("globalSearchResultUiGrid", "Edit", "Id", "vm.editCallback", null);
            var colDelete = efUiGridApi.createActionColDef("globalSearchResultUiGrid", "Delete", "Id", "vm.deleteCallback", "<i class=\"fa fa-trash-o\"></i>");
            gridOption.columnDefs.push(puid);
            gridOption.columnDefs.push(fname);
            gridOption.columnDefs.push(lname);
            gridOption.columnDefs.push(emailid);
            gridOption.columnDefs.push(isActive);
            gridOption.columnDefs.push(colEdit);
            gridOption.columnDefs.push(colDelete);
            return gridOption;
        }
        return service;
    }
    angular.module("app")
        .factory("userManageApi", userManageApi);
    userManageApi.$inject = ["$resource", "datacontext", "efLibrary", "efUiGridApi"];
})();
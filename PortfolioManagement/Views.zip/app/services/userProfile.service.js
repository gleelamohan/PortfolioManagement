(function () {
    angular
        .module('app')
        .factory('userProfileApi', userProfileApi);

    function userProfileApi() {

        var profile = {};

        profile.currentUser = null;

        profile.defaultLabsite = null;

        return profile;
    }
})();
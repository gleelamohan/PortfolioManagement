﻿(function () {
    function masterListEntityValuesApi($resource, $filter, $translate, datacontext, efLibrary, efUiGridApi, efDatetimeMasks) {
        //query URL
      
      
        var smartCollection = "";
        //http://localhost:50480/api/smartentity/courier/a0347ad7-80c7-48e1-ab5a-96959f0e2609

        var smartServiceUrl = window.app.services.eLimsServiceHost + '/api/SmartEntity/:entityName/' ;
        //service object with query, getbyId, update, save service api calls 
        var service = $resource(smartServiceUrl, {}, {
            //query: { method: 'GET', url: myNotificationsUrl + '/getmynotifications', params: { searchTerm: '@searchTerm', searchScope: '@searchScope' }, isArray: true },
            //getById: { method: 'GET', url: myNotificationsUrl + '/getmynotificationbyid', params: { id: '@id' }, isArray: false },
            getById: { method: 'GET', url: smartServiceUrl + ':entityId', isArray: false },
            //update: { method: 'PUT', url: smartServiceUrl + '/marknotificationasread' + "/:id", params: { id: '@id' }, isArray: false },
            //update: { method: 'PUT', url: smartServiceUrl + ':entityName/:entityId/:rowVersion' + '/ChangeBasicInfo', params: { formData: '@formdata' }, isArray: false },
            update: { method: 'PUT', url: smartServiceUrl + ':entityId' + '/' + '@rowVersion' + '/ChangeBasicInfo', params: { formData: '@formdata' }, isArray: false },
            save: { method: 'POST', url: smartServiceUrl, params: { formData: '@formdata' }, isArray: false },
            remove: { method: 'DELETE', url: smartServiceUrl + '@id' }
        });

        //'/addAttachment?entityId=:entityId&entityRowVersion=:entityRowVersion&title=:title&description=:description'
        //default service variables.
        service.loadDefaultSearchResult = false;
        service.defaultSearchterm = "";
        service.pageTitle = "";
        service.resultTitle = "";
        service.breezeCollection = "";
        service.smartCollection = "";
       

        //query method for breeze api call for entity values screen
        service.query = function (searchObject) {

            var selection = "Id, Value, RowVersion,OrderPosition,Description,IsInUse";
            var collection = service.breezeCollection;
            var query = breeze.EntityQuery.from(collection).select(selection);

            if (searchObject !== undefined && searchObject !== null) {

                if (searchObject.searchTerm) {
                    var p1 = new breeze.Predicate("Value", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    //var p2 = breeze.Predicate("Notification.Message", breeze.FilterQueryOp.Contains, searchObject.searchTerm);

                    query = query.where(breeze.Predicate.or(p1));
                }                
            }

            //query = query.expand("Notification.User.UserDetail");
            return datacontext.executeQuery(query);
        };

        //query method for entity values screen popup
        service.queryEntity = function (EntityName) {

            var selection = "Id, value,description,isactive,order";
            var collection = "EntityValues";
            var query = breeze.EntityQuery.from(collection).select(selection);

            if (EntityName !== undefined && EntityName !== null) {
                var p1 = new breeze.Predicate("EntityName", breeze.FilterQueryOp.Equals, EntityName);
                query = query.where(breeze.Predicate.Equals(p1));
            }
            //query = query.expand("Notification.User.UserDetail");
            return datacontext.executeQuery(query);
        };

      
        //default service configuration
        service.setDefaultCollection = function (inputScope) {
            if (inputScope != null) {
                service.dynamicCollection = inputScope;
                
            } 
        }
        

        //default service configuration
        service.setDefaultSearchEntryValue = function (inputScope) {
            if (inputScope != null) {
               
                service.pageTitle = "Search " + inputScope.Id;
                service.resultTitle = inputScope.Id + " Results";

                switch(inputScope.Id)
                {
                    case "Courier":
                        service.breezeCollection = "Couriers";

                        service.smartCollection = inputScope.Id;
                       
                        break;
                    case "ArrivalCondition":
                        service.breezeCollection = "ArrivalConditions";
                        
                        break;
                    case "ArrivalTemperature":
                        service.breezeCollection = "ArrivalTemperatures";
                        
                        break;
                    case "SpecialHandling":
                        service.breezeCollection = "SpecialHandlings";
                        
                        break;
                    case "StorageTemperature":
                        service.breezeCollection = "StorageTemperatures";
                       
                        break;
                    case "ParcelDiscrepancyType":
                        service.breezeCollection = "ParcelDiscrepancyTypes";
                      
                        break;
                }
            } else {
               
                service.loadDefaultSearchResult = false;
            }
        }

        //called method to Global Search directive config for Entity screen.
        service.globalSearchConfig = function () {
            return {
                
                    "templateConfig": {
                        "pagetitle": service.resultTitle,
                        "searchResultPanelTitle": service.resultTitle,
                        "searchResultsHelpText": "Views.MasterManageList.Search.TemplateConfig.SearchResultsHelpText",
                        "searchResultsNoResultsText": "Views.MasterManageList.Search.TemplateConfig.SearchResultsNoResultsText",
                        "addNewText": "Add Value"
                    },
                    "searchEntryConfig": {
                        "searchEntryPanelTitle": service.pageTitle,
                        "helpText": "Views.MasterManageList.Search.EntityValueConfig.SearchEntryHelpText",
                        "defaultSearchTermLabel": "Views.MasterManageList.Search.EntityValueConfig.SearchTermPlaceholder",
                        "defaultSearchTermPlaceholder": "Views.MasterManageList.Search.EntityValueConfig.DefaultSearchTermPlaceholder",
                        "displaySearchTermLabel": true,
                        "defaultSearchTerm": "",
                        "searchTermMinLength": 0,
                        "searchTermMaxLength": 50,
                        "includeSearchEntryOptions": false,
                        "enableSearchEntryOptionsToggle": false,
                        "defaultSearchEntryOptionsTitle": "Views.NotificationsRecipients.Search.EntityValueConfig.DefaultSearchEntryOptionsTitle",
                        "searchEntryOptionsTemplateUrl": "/app/notifications/myNotifications/manage/myNotifications.search.html",
                        "loadDefaultSearchResult": service.loadDefaultSearchResult,
                        "defaultSearchScope": service.defaultSearchterm
                    }
                    
            }
        }

        //called method to Global Search for Entity ui-grid.
        service.globalSearchGridConfig = function () {

            var gridOption = efLibrary.copyObject(efUiGridApi.exportGridConfig, true);
            var entityname = efUiGridApi.createReadonlyColumn("Value", "Value", { width: "20%" });
            var entitydesc = efUiGridApi.createReadonlyColumn("Description", "Description", null);
            var entityisActive = efUiGridApi.createReadonlyColumn("IsInUse", "IsInUse", { width: "9%" });
            var entityorder = efUiGridApi.createReadonlyColumn("OrderPosition", "Order", { width: "10%" });

            var colEdit = efUiGridApi.createActionColDef("globalSearchResultUiGrid", "", "Id", "vm.editCallback", null);
            var colDelete = efUiGridApi.createActionColDef("globalSearchResultUiGrid", "Delete", "Id", "vm.deleteCallback", "<i class=\"fa fa-trash-o\"></i>");

            gridOption.columnDefs.push(entityname);
            gridOption.columnDefs.push(entitydesc);
            gridOption.columnDefs.push(entityorder);
            gridOption.columnDefs.push(entityisActive);

            gridOption.columnDefs.push(colEdit);
            gridOption.columnDefs.push(colDelete);

            return gridOption;
        }
       
        return service;
    }

    angular.module('app')
        .factory('masterListEntityValuesApi', masterListEntityValuesApi);
    masterListEntityValuesApi.$inject = ["$resource", "$filter", "$translate", "datacontext", "efLibrary", "efUiGridApi", "efDatetimeMasks"];

})();





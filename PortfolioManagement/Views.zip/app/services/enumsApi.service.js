// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('app')
        .factory('enumsApi', enumsApi);

    enumsApi.$inject = ['$resource'];

    function enumsApi($resource) {
        return $resource(window.app.services.carbon + '/api/enums/', {}, {
            query: { method: 'GET', url: window.app.services.carbon + '/api/enums/:enumType', params: { enumType: '@enumType' }, isArray: false }
        });
    }
})();

(function () {
    angular
        .module('app')
        .factory('timeZoneEnumnsApi', timeZoneEnumnsApi);

    timeZoneEnumnsApi.$inject = ['$resource'];

    function timeZoneEnumnsApi($resource) {
        return $resource(window.app.services.carbon + '/api/timezones', {}, {
            get: { method: 'GET', params: {}, isArray: true }
        });
    }
})();

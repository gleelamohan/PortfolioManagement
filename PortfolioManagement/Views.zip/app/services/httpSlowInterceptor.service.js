// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('app')
        .factory('httpSlowInterceptor', httpSlowInterceptor);

    httpSlowInterceptor.$inject = ['$q', '$injector'];

    function httpSlowInterceptor($q, $injector) {
        var modal;
        var modalInstance = null;
        var outstandingRequestCount = 0;
        var outstandingRequests = {};
        var requestIndex = 0; //Counter for a unique ID for identifying each network request

        //When a request is received, if the request does not complete within the allowed window, show a waiting indicator
        var handleRequestReceived = function (requestConfig) {

            //skip the loading window when polling for alert
            if (requestConfig.url.indexOf("api/alerts") > -1) return;

            var timeLimitMilliseconds = 250;
            requestConfig.requestId = requestIndex;
            outstandingRequests[requestIndex] = Date.now();

            setTimeoutToCheckIfRequestIsStillRunning(timeLimitMilliseconds, requestIndex);

            requestIndex++;
            outstandingRequestCount++;
        }

        function setTimeoutToCheckIfRequestIsStillRunning(timeLimitMilliseconds, requestId) {
            setTimeout(function () {
                if (!isShowingWaitIndicator() && hasRequestExceededTimeLimit(requestId, timeLimitMilliseconds)) {
                    //Have to get the modal this way to get around a circular dependency issue with $http
                    modal = modal || $injector.get('$modal');
                    modalInstance = modal.open({
                        size: 'sm',
                        template: '<div class="modal-body"><ddbs-wait ismodal="true" inputscope="vm.inputScope"></ddbs-wait></div>',
                        backdrop: 'static',
                        windowClass: 'center-modal'
                    });
                    modalInstance.result.finally(function () {
                        modalInstance = null;
                    });
                };
            }, timeLimitMilliseconds);
        }

        //If we are showing the waiting indicator, we do not want to stop showing it until all pending network requests are completed
        function handleResponseReceived(response) {
            var requestId = response.config.requestId;

            //skip the loading window when polling for alert
            if (requestId === undefined || requestId === null) return;

            delete outstandingRequests[requestId];
            outstandingRequestCount--;

            if (isShowingWaitIndicator() && (outstandingRequestCount == 0 || isErrorStatus(response.status))) {
                modalInstance.opened.finally(function () {
                    modalInstance.dismiss();
                    modalInstance = null;
                });
            }
        }

        function isShowingWaitIndicator() {
            return modalInstance !== undefined && modalInstance != null;
        }

        function isErrorStatus(status) {
            return status >= 400;
        }

        function hasRequestExceededTimeLimit(requestId, timeLimitMilliseconds) {
            if (outstandingRequests.hasOwnProperty(requestId)) {
                var requestDate = outstandingRequests[requestId];
                return requestDate + timeLimitMilliseconds <= Date.now();
            }
            return false;
        }

        return {
            'request': function (config) {
                handleRequestReceived(config);
                return config;
            },

            'response': function (response) {
                handleResponseReceived(response);
                return response;
            },

            'responseError': function (rejection) {
                handleResponseReceived(rejection);
                return $q.reject(rejection);
            }
        }
    };
})();

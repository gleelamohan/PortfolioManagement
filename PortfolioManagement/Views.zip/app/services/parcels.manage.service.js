(function () {
    function parcelManageApi($resource, $filter, $translate, datacontext, efLibrary, efUiGridApi, efDatetimeMasks, courierManageApi, masks, enums, uiGridConstants) {

        var parcelUrl = window.app.services.eLimsServiceHost + '/api/Parcels';

        var service = $resource(parcelUrl, {}, {
            query: { method: 'GET', params: { searchTerm: '@searchTerm' }, isArray: true },
            getById: { method: 'GET', url: parcelUrl + '/getById', params: { id: '@id' }, isArray: false },
            update: { method: 'PUT', url: parcelUrl + '/update/' + { id: '@id' }, params: { formData: '@formdata' } },
            save: { method: 'POST', url: parcelUrl + '/add', params: { formData: '@formData' } },
            remove: { headers: { 'Content-Type': false }, method: 'DELETE', url: parcelUrl + '/' + { id: '@id' } },
            updateattachment: { method: 'PUT', url: parcelUrl + '/updateAttachmentAttributes', params: { entityId: '@entityId', entityRowVersion: '@entityRowVersion', title: '@title', description: '@description', fileName: '@fileName' } },
            removeattachment: { method: 'PUT', url: parcelUrl + '/removeAttachment', params: { entityId: '@entityId', entityRowVersion: '@entityRowVersion', fileName: '@fileName' } },
            addattachment: {
                headers: { "Content-Type": undefined },
                transformRequest: angular.identity,
                method: 'PUT',
                url: parcelUrl + '/addAttachment?entityId=:entityId&entityRowVersion=:entityRowVersion&title=:title&description=:description'
            }
        });
        service.downloadattachment = function(entityId, fileName) {
            var s = parcelUrl + "/GetAttachment?" + "entityId=" + entityId + "&fileName=" + fileName;
            window.open(s);
        }
        service.loadDefaultSearchResult = false;
        service.defaultSearchterm = "";
        service.setDefaultSearchEntryValue = function (inputScope) {
            if (inputScope != null) {
                service.defaultSearchterm = { "selectedSearchStatus": inputScope }
                service.loadDefaultSearchResult = false;
            } 
        }

        var receivedToDate = moment().format(masks.date.model.moment);
        var receivedFromDate = moment().subtract(7, 'days').format(masks.date.model.moment);
        var courierNameConfig = {
            "allowDuplicates": false,
            "placeholder": String($filter("trustedtranslate")("Views.Parcels.Manage.CourierNamePlaceHolder")),
            "optionsValueField": "Id",
            "optionsLabelField": "Name",
            "optionsListScrollOnWideOptions": true,
            "width": "100%"
        };
        var parcelPhasesConfig = {
            "allowDuplicates": false,
            "placeholder": String($filter("trustedtranslate")("Entity.Parcel.RegistrationPhase.InputPlaceholder")),
            "optionsValueField": "Value",
            "optionsLabelField": "Text",
            "width": "100%"
        }

        service.globalSearchConfig = function() {
            return {
                "templateConfig": {
                    "pagetitle": "Views.Parcels.Search.TemplateConfig.PageTitle",
                    "searchResultPanelTitle": "Views.Parcels.Search.TemplateConfig.SearchResultsPanelTitle",
                    "searchResultsHelpText": "Common.Maintenance.SearchResultsHelpText",
                    "searchResultsNoResultsText": "Views.Parcels.Search.TemplateConfig.SearchResultsNoResultsText",
                    "addNewText": "Views.Parcels.Search.TemplateConfig.AddNewText"
                },
                "searchEntryConfig": {
                    "searchEntryPanelTitle": "Views.Parcels.Search.SearchEntryConfig.SearchEntryTitle",
                    "helpText": "Views.Parcels.SearchEntryConfig.SearchEntryHelpText",
                    "defaultSearchTermLabel": "Views.Parcels.Search.SearchEntryConfig.SearchTermPlaceholder",
                    "defaultSearchTermPlaceholder": "Views.Parcels.Search.SearchEntryConfig.DefaultSearchTermPlaceholder",
                    "displaySearchTermLabel": true,
                    "defaultSearchTerm": "",
                    "searchTermMinLength": 0,
                    "searchTermMaxLength": 50,
                    "includeSearchEntryOptions": true,
                    "enableSearchEntryOptionsToggle": false,
                    "defaultSearchEntryOptionsTitle": "Views.Parcels.Search.SearchEntryConfig.DefaultSearchEntryOptionsTitle",
                    "searchEntryOptionsTemplateUrl": "/app/sampleManagement/parcelReception/manage/parcelReception.search.html",
                    "SearchEntryOptionsConfig": {
                        "ParcelPhasesConfig": parcelPhasesConfig,
                        "ParcelPhaseEnums": enums.ParcelRegistrationPhaseEnums,
                        "CourierNameConfig": courierNameConfig,
                        "ConfigServices": [courierManageApi],
                        "ConfigServiceResults": []
                    },
                    "defaultSearchScope": {
                        "ReceivedFromDate": receivedFromDate,
                        "ReceivedToDate": receivedToDate,
                        "ParcelPhaseId": null,
                        "CourierId": null,
                        "selectedSearchStatus": service.defaultSearchterm.selectedSearchStatus,
                        "enableSearchEntryOptionsToggle": true,
                        "defaultSearchEntryOptionsTitle": "Views.Parcels.Search.SearchEntryConfig.DefaultSearchEntryOptionsTitle",
                    },
                 
                }
            }
        }
        
        service.globalSearchGridConfig = function () {
            var gridOption = efLibrary.copyObject(efUiGridApi.exportGridConfig, true);
            var parcelId = efUiGridApi.createReadonlyColumn("ParcelId", "Entity.Parcel.ParcelId.ColumnText", { width: "2%" });
            var registrationPhase = efUiGridApi.createReadonlyColumn("User_UserDetail_FirstName", "Entity.Parcel.RegistrationPhase.ColumnText", { width: "10%" });
            var receptionistName = efUiGridApi.createReadonlyColumn("User_UserDetail_LastName", "Entity.Parcel.ReceptionistName.ColumnText", null);
            var receivedLocation = efUiGridApi.createReadonlyColumn("LabSite_Code", "Entity.Parcel.ReceivedLocation.ColumnText", { width: "8%" });
            var registeredDate = efUiGridApi.createReadonlyColumn("RegisteredDate", "Entity.Parcel.RegisteredDate.ColumnText", { width: "20%" });
            var receivedDate = efUiGridApi.createReadonlyColumn("ReceivedDate", "Entity.Parcel.ReceivedDate.ColumnText", { width: "20%" });
            var courierName = efUiGridApi.createReadonlyColumn("Courier_Name", "Entity.Parcel.CourierName.ColumnText", { width: "10%" });
            var courierNo = efUiGridApi.createReadonlyColumn("CourierTrakingNo", "Entity.Parcel.CourierNo.ColumnText", { width: "10%" });
            var colEdit = efUiGridApi.createActionColDef("globalSearchResultUiGrid", "Edit", "Id", "vm.editCallback", null);
            registeredDate.cellFilter = "date: '" + efDatetimeMasks.datetime.angular + "'";
            receivedDate.cellFilter = "date: '" + efDatetimeMasks.datetime.angular + "'";
            registrationPhase.cellTemplate = "<div class='ui-grid-cell-contents ui-grid-cell-contents-word-wrap' >Received</div>";
            receptionistName.cellTemplate = "<div class='ui-grid-cell-contents ui-grid-cell-contents-word-wrap' >{{row.entity.User_UserDetail_FirstName}} &nbsp; {{row.entity.User_UserDetail_LastName}}</div>";


            gridOption.columnDefs.push(parcelId);
            gridOption.columnDefs.push(registrationPhase);
            gridOption.columnDefs.push(receptionistName);
            gridOption.columnDefs.push(receivedLocation);
            gridOption.columnDefs.push(registeredDate);
            gridOption.columnDefs.push(receivedDate);
            gridOption.columnDefs.push(courierName);
            gridOption.columnDefs.push(courierNo);
            gridOption.columnDefs.push(colEdit);
            return gridOption;
        }

        service.query = function (searchObject) {
            var selection = "Id,ParcelId,User.UserDetail.FirstName,User.UserDetail.LastName,RegistrationPhase,ReceptionistId,LabSite.Code,RegisteredDate,ReceivedDate,Courier.Id,Courier.Name,CourierTrakingNo,ParcelsOrders, ArrivalTemperatureId, SpecialHandlingId, ArrivalComments, ParcelsArrivalConditions, DiscrepancyTypeId, ParcelsStorageLocation";
            var collection = "Parcels";

            var query = breeze.EntityQuery.from(collection).select(selection);

            if (searchObject.searchTerm) {
                if (searchObject.searchTerm.split(".").length > 1) {
                    searchObject.searchTerm = "0";
                }

                var predi = new breeze.Predicate("ParcelId", breeze.FilterQueryOp.Equals, { value: searchObject.searchTerm.trim(), dataType: breeze.DataType.INT });
                query = query.where(predi);
            }

            if (searchObject.searchScope) {

                if (searchObject.searchScope.ParcelPhaseId || searchObject.searchScope.ParcelPhaseId != undefined) {
                    var p1 = new breeze.Predicate("RegistrationPhase", breeze.FilterQueryOp.Equals, searchObject.searchScope.ParcelPhaseId);
                    query = query.where(p1);
                }
                if (searchObject.searchScope.CourierId || searchObject.searchScope.CourierId != undefined) {
                    var p2 = new breeze.Predicate("Courier.Id", breeze.FilterQueryOp.Equals, searchObject.searchScope.CourierId);
                    query = query.where(p2);
                }
                if ((searchObject.searchScope.ReceivedFromDate || searchObject.searchScope.ReceivedFromDate != undefined) && (searchObject.searchScope.ReceivedToDate || searchObject.searchScope.ReceivedToDate != undefined)) {
                    var p3 = new breeze.Predicate("ReceivedDate", breeze.FilterQueryOp.GreaterThan, searchObject.searchScope.ReceivedFromDate);
                    var p4 = new breeze.Predicate("ReceivedDate", breeze.FilterQueryOp.LessThan, moment(searchObject.searchScope.ReceivedToDate, 'YYYY/MM/DD').add('days', 1).format('YYYY/MM/DD'));
                    var predicate2 = breeze.Predicate.and([p3, p4]);

                    query = query.where(predicate2);
                } else if (searchObject.searchScope.ReceivedFromDate || searchObject.searchScope.ReceivedFromDate != undefined) {
                    var p5 = new breeze.Predicate("ReceivedDate", breeze.FilterQueryOp.GreaterThan, searchObject.searchScope.ReceivedFromDate);
                    query = query.where(p5);
                } else if (searchObject.searchScope.ReceivedToDate || searchObject.searchScope.ReceivedToDate != undefined) {
                    var p6 = new breeze.Predicate("ReceivedDate", breeze.FilterQueryOp.LessThan, moment(searchObject.searchScope.ReceivedToDate, 'YYYY/MM/DD').add('days', 1).format('YYYY/MM/DD'));
                    query = query.where(p6);
                }
            }

            query = query.expand("User.UserDetail,LabSite,Courier,ParcelsOrders, ParcelsArrivalConditions");
            return datacontext.executeQuery(query);
        };

        service.getParcelById = function (guid) {
            var selection = "Id,ParcelId,User.UserDetail.FirstName,User.UserDetail.LastName,RegistrationPhase,ReceivedLabsiteId,ReceptionistId,LabSite.Code,RegisteredDate,ReceivedDate,Courier.Name,Courier.Id,CourierTrakingNo,RowVersion,ParcelsOrders,SenderId, ArrivalTemperatureId, SpecialHandlingId, ArrivalComments, ParcelsArrivalConditions, DiscrepancyTypeId, ParcelsStorageLocation,ParcelsAttachments";
            var collection = "Parcels";
            var query = breeze.EntityQuery.from(collection).select(selection);
            //query = breeze.EntityQuery.from(collection);

            if (guid != null) {
                var op = breeze.FilterQueryOp;
                var p1 = new breeze.Predicate("Id", op.Equals, guid);
                var predicate = p1;
                query = query.where(predicate);
            }
            query = query.expand("User.UserDetail,LabSite,Courier,ParcelsOrders, ParcelsArrivalConditions");
            return datacontext.executeQuery(query);
        };

        service.getOrderDetailsByParcelId = function (guid) {
            var query = "";
            var selection = "Order.Id,Order.OrderNo,Order.EurofinsBarcodeId,Order.QuoteId,Order.ERPClientId";
            var collection = "ParcelsOrders";
            if (guid != null) {
                var op = breeze.FilterQueryOp;
                var p1 = new breeze.Predicate("ParcelId", op.Equals, guid);
                var predicate = p1;
                query = breeze.EntityQuery.from(collection).select(selection).where(predicate);
            }
            query = query.expand("Order");
            return datacontext.executeQuery(query);
        };

        service.getAttachmentDetailsByAttachmentlId = function (guid) {
            var query = "";
            var selection = "ParcelId,Title,Description,FileName, Parcel.RowVersion";
            var collection = "ParcelsAttachments";
            if (guid != null) {
                var op = breeze.FilterQueryOp;
                var p1 = new breeze.Predicate("Id", op.Equals, guid);
                var predicate = p1;
                query = breeze.EntityQuery.from(collection).select(selection).where(predicate);
            }
            query = query.expand("Parcel");
            return datacontext.executeQuery(query);
        };

        service.getAttachmentsByParcelId = function (guid) {
            var query = "";
            var selection = "Id,ParcelId,Title,Description,FileName,AttachedOn";
            var collection = "ParcelsAttachments";
            if (guid != null) {
                var op = breeze.FilterQueryOp;
                var p1 = new breeze.Predicate("ParcelId", op.Equals, guid);
                var predicate = p1;
                query = breeze.EntityQuery.from(collection).select(selection).where(predicate);
            }
            return datacontext.executeQuery(query);
        };
        return service;
    }

    angular.module('app')
        .factory('parcelManageApi', parcelManageApi)

    parcelManageApi.$inject = ["$resource", "$filter", "$translate", "datacontext", "efLibrary", "efUiGridApi", "efDatetimeMasks", "courierManageApi", "masks", "enums", "uiGridConstants"];
})();




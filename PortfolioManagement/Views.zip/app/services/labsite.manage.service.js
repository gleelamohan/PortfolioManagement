(function () {
    function labsiteManageApi($resource, datacontext, efLibrary, efUiGridApi) {
        
        var smartServiceUrl = window.app.services.eLimsServiceHost + '/api/SmartEntity/labsite/';

        var service = $resource(smartServiceUrl, {}, {
            getById: { method: 'GET', url: smartServiceUrl + '@id' , isArray: false },           
            update: { method: 'PUT', url: smartServiceUrl + '@entityId' + '/' + '@rowVersion' + '/SynchronizeFromState', params: { formData: '@formdata' }, isArray: false },           
            save: { method: 'POST', url: smartServiceUrl, params: { formData: '@formdata' }, isArray: false },           
            remove: { method: 'DELETE', url: smartServiceUrl + '@id'}
        });

        service.query = function (searchObject) {
            var query;
            var selection = "Id, Code, Name, Description, IsInUse";
            var collection = "LabSites";
            if (searchObject === null || searchObject === undefined ||
                searchObject.searchTerm === undefined || searchObject.searchTerm === null || searchObject.searchTerm === "") {
                query = breeze.EntityQuery.from(collection).select(selection);
            } else {
                var op = breeze.FilterQueryOp;
                var p1 = new breeze.Predicate("Description", op.Contains, searchObject.searchTerm);
                var p2 = breeze.Predicate("Name", op.Contains, searchObject.searchTerm);
                var p3 = breeze.Predicate("Code", op.Contains, searchObject.searchTerm);
                var predicate = p1.or(p2).or(p3);
                query = breeze.EntityQuery.from(collection).select(selection).where(predicate);
            }
            return datacontext.executeQuery(query);
        }

        service.globalSearchConfig = function () {
            return {
                "templateConfig": {
                    "pagetitle": "Views.Labsites.Search.TemplateConfig.PageTitle",
                    "searchResultPanelTitle": "Views.Labsites.Search.TemplateConfig.SearchResultsPanelTitle",
                    "searchResultsHelpText": "Common.Maintenance.SearchResultsHelpText",
                    "searchResultsNoResultsText": "Views.Labsites.Search.TemplateConfig.SearchResultsNoResultsText",
                    "addNewText": "Views.Labsites.Search.TemplateConfig.AddNewText"
               },
                "searchEntryConfig": {
                    "searchEntryPanelTitle": "Views.Labsites.Search.SearchEntryConfig.SearchEntryTitle",
                    "helpText": "Views.Labsites.Search.SearchEntryConfig.SearchEntryHelpText",
                    "defaultSearchTermLabel": "Views.Labsites.Search.SearchEntryConfig.SearchTermPlaceholder",
                    "defaultSearchTermPlaceholder": "Views.Labsites.Search.SearchEntryConfig.DefaultSearchTermPlaceholder",
                    "displaySearchTermLabel": true,
                    "defaultSearchTerm": "",
                    "searchTermMinLength": 0,
                    "searchTermMaxLength": 16,
                    "includeSearchEntryOptions": false,
                    "enableSearchEntryOptionsToggle": true,
                    "defaultSearchScope": { "selectedSeacrhScope": "" }
                }
            }
        }

        service.globalSearchGridConfig = function () {

            var gridOption = efLibrary.copyObject(efUiGridApi.exportGridConfig, true);
            var code = efUiGridApi.createReadonlyColumn("Code", "Entity.Labsite.Code.ColumnText", { width: "10%" });
            var name = efUiGridApi.createReadonlyColumn("Name", "Entity.Labsite.Name.ColumnText", { width: "20%" });
            var desc = efUiGridApi.createReadonlyColumn("Description", "Entity.Labsite.Description.ColumnText", null);
            var isuse = efUiGridApi.createReadonlyColumn("IsInUse", "Entity.Labsite.IsInUse.ColumnText", { width: "10%" });
            var colEdit = efUiGridApi.createActionColDef("globalSearchResultUiGrid", "Edit", "Id", "vm.editCallback", null);
            var colDelete = efUiGridApi.createActionColDef("globalSearchResultUiGrid", "Delete", "Id", "vm.deleteCallback", "<i class=\"fa fa-trash-o\"></i>");
            desc.cellTooltip = true;
            gridOption.columnDefs.push(code);
            gridOption.columnDefs.push(name);
            gridOption.columnDefs.push(desc);
            gridOption.columnDefs.push(isuse);
            gridOption.columnDefs.push(colEdit);
            gridOption.columnDefs.push(colDelete);

            return gridOption;
        }

        return service;
    }
    angular.module("app")
        .factory("labsiteManageApi", labsiteManageApi);
    labsiteManageApi.$inject = ["$resource", "datacontext", "efLibrary", "efUiGridApi"];
})();
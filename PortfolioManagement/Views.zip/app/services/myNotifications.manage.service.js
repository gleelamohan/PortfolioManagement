(function () {
    function myNotificationManageApi($resource, $filter, $translate, datacontext, efLibrary, efUiGridApi, efDatetimeMasks) {

        var myNotificationsUrl = window.app.services.eLimsServiceHost + '/api/notifications';

        var service = $resource(myNotificationsUrl, {}, {
            //query: { method: 'GET', url: myNotificationsUrl + '/getmynotifications', params: { searchTerm: '@searchTerm', searchScope: '@searchScope' }, isArray: true },
            getById: { method: 'GET', url: myNotificationsUrl + '/getmynotificationbyid', params: { id: '@id' }, isArray: false },
            update: { method: 'PUT', url: myNotificationsUrl + '/marknotificationasread' + "/:id", params: { id: '@id' }, isArray: false }
        });

        service.query = function (searchObject) {

            var selection = "Id, ReadOn, Notification.Message, Notification.Subject, Notification.User.UserDetail.FirstName, Notification.User.UserDetail.LastName, ReceivedOn";
            var collection = "NotificationRecipients";
            var query = breeze.EntityQuery.from(collection).select(selection);

            if (searchObject !== undefined && searchObject !== null) {

                if (searchObject.searchTerm) {
                    var p1 = new breeze.Predicate("Notification.Subject", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    var p2 = breeze.Predicate("Notification.Message", breeze.FilterQueryOp.Contains, searchObject.searchTerm);

                    query = query.where(breeze.Predicate.or(p1, p2));
                }

                if (searchObject.searchScope) {

                    switch (searchObject.searchScope.selectedSeacrhStatus) {
                        case "Read":
                            var p3 = new breeze.Predicate("ReadOn", breeze.FilterQueryOp.NotEquals, null);
                            query = query.where(p3);
                            break;
                        case "Unread":
                            var p4 = new breeze.Predicate("ReadOn", breeze.FilterQueryOp.Equals, null);
                            query = query.where(p4);
                            break;
                    }
                }
            }

            query = query.expand("Notification.User.UserDetail");
            return datacontext.executeQuery(query);
        };

        service.getNotificationRecipientById = function (id) {
            var selection = "Id, RowVersion, ReadOn, " +
                "User.UserDetail.FirstName, User.UserDetail.LastName, " +
                "Notification.Message, Notification.Subject, Notification.SentOn, Notification.User.UserDetail.FirstName, Notification.User.UserDetail.LastName";
            var query = breeze.EntityQuery.from("NotificationRecipients").select(selection);

            query = query.where(new breeze.Predicate("Id", breeze.FilterQueryOp.Equals, id));

            query = query.expand("User.UserDetail, Notification.User.UserDetail");

            return datacontext.executeQuery(query);
        };

        service.getNotificationRecipientsByNotificationId = function (notificationId) {

            var selection = "Id, RowVersion, ReadOn, NotificationId, RecipientId, " +
                "User.UserDetail.FirstName, User.UserDetail.LastName, " +
                "Notification.Message, Notification.Subject, Notification.SentOn, Notification.User.UserDetail.FirstName, Notification.User.UserDetail.LastName";

            var query = breeze.EntityQuery.from("AllNotificationRecipients").select(selection);

            query = query.where(new breeze.Predicate("NotificationId", breeze.FilterQueryOp.Equals, notificationId));

            query = query.expand("User.UserDetail, Notification.User.UserDetail");

            return datacontext.executeQuery(query);
        };

        service.loadDefaultSearchResult = false;

        service.defaultSearchterm = "";

        service.setDefaultSearchEntryValue = function (inputScope) {
            if (inputScope != null) {
                service.defaultSearchterm = { "selectedSeacrhStatus": inputScope.selectedSeacrhStatus }
                service.loadDefaultSearchResult = inputScope.loadDefaultSearchResult;
            } else {
                service.defaultSearchterm = { "selectedSeacrhStatus": String($filter("trustedtranslate")("Views.Notifications.Manage.StatusConfig.Unread")) };
                service.loadDefaultSearchResult = false;
            }
        }

        service.globalSearchConfig = function () {
            return {
                "templateConfig": {
                    "pagetitle": "Views.NotificationsRecipients.Search.TemplateConfig.PageTitle",
                    "searchResultPanelTitle": "Views.NotificationsRecipients.Search.TemplateConfig.SearchResultsPanelTitle",
                    "searchResultsHelpText": "Common.Maintenance.SearchResultsHelpText",
                    "searchResultsNoResultsText": "Views.NotificationsRecipients.Search.TemplateConfig.SearchResultsNoResultsText",
                    "addNewText": ""
                },
                "searchEntryConfig": {
                    "searchEntryPanelTitle": "Views.NotificationsRecipients.Search.SearchEntryConfig.SearchEntryTitle",
                    "helpText": "Views.NotificationsRecipients.SearchEntryConfig.SearchEntryHelpText",
                    "defaultSearchTermLabel": "Views.NotificationsRecipients.Search.SearchEntryConfig.SearchTermPlaceholder",
                    "defaultSearchTermPlaceholder": "Views.NotificationsRecipients.Search.SearchEntryConfig.DefaultSearchTermPlaceholder",
                    "displaySearchTermLabel": true,
                    "defaultSearchTerm": "",
                    "searchTermMinLength": 0,
                    "searchTermMaxLength": 50,
                    "includeSearchEntryOptions": true,
                    "enableSearchEntryOptionsToggle": false,
                    "defaultSearchEntryOptionsTitle": "Views.NotificationsRecipients.Search.SearchEntryConfig.DefaultSearchEntryOptionsTitle",
                    "searchEntryOptionsTemplateUrl": "/app/notifications/myNotifications/manage/myNotifications.search.html",
                    "loadDefaultSearchResult": service.loadDefaultSearchResult,
                    "defaultSearchScope": service.defaultSearchterm

                }
            }
        }

        service.globalSearchGridConfig = function () {

            var gridOption = efLibrary.copyObject(efUiGridApi.exportGridConfig, true);
            var subject = efUiGridApi.createReadonlyColumn("Notification_Subject", "Entity.MyNotification.Subject.ColumnText", { width: "20%" });
            var message = efUiGridApi.createReadonlyColumn("Notification_Message", "Entity.MyNotification.Message.ColumnText",null);
            var status = efUiGridApi.createReadonlyColumn("ReadOn", "Entity.MyNotification.Status.ColumnText", { width: "20%" });
            var sentby = efUiGridApi.createReadonlyColumn("Notification_User_UserDetail_FirstName", "Entity.MyNotification.SentBy.ColumnText", { width: "20%" });
            var receivedOn = efUiGridApi.createReadonlyColumn("ReceivedOn", "Entity.MyNotification.ReceivedOn.ColumnText", { width: "20%" });
            var colEdit = efUiGridApi.createActionColDef("globalSearchResultUiGrid", "Edit", "Id", "vm.editCallback", null);
            receivedOn.cellFilter = "date: '" + efDatetimeMasks.datetime.angular + "'";
            sentby.cellTemplate = "<div class='ui-grid-cell-contents ui-grid-cell-contents-word-wrap' >{{row.entity.Notification_User_UserDetail_FirstName}} &nbsp; {{row.entity.Notification_User_UserDetail_LastName}}</div>";
            status.cellFilter = "myNotificationReadFilter";

            gridOption.columnDefs.push(subject);
            gridOption.columnDefs.push(message);
            gridOption.columnDefs.push(status);
            gridOption.columnDefs.push(sentby);
            gridOption.columnDefs.push(receivedOn);
            gridOption.columnDefs.push(colEdit);
            return gridOption;
        }

        return service;
    }
    function myNotificationReadFilter() {
        return function (input) {
            if (input) {
                return "Read";
            }
            return "Unread";
        }
    };

    angular.module('app')
        .factory('myNotificationManageApi', myNotificationManageApi)
        .filter("myNotificationReadFilter", myNotificationReadFilter);

    myNotificationManageApi.$inject = ["$resource", "$filter", "$translate", "datacontext", "efLibrary", "efUiGridApi", "efDatetimeMasks"];

})();





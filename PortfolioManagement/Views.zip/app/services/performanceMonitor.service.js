(function () {
    angular
        .module('app')
        .factory('performanceMonitorApi', performanceMonitorApi);

    performanceMonitorApi.$inject = ['$resource', '$filter'];

    function performanceMonitorApi($resource, $filter) {

        var perfmonUrl = window.app.services.eLimsServiceHost + '/api/Perfmon';

        var service = $resource(perfmonUrl, {}, {
            query: { method: 'GET', params: { timetick: '@timetick' }, isArray: true },
            start: { method: 'GET', url: perfmonUrl + '/start', isArray: false },
            stop: { method: 'GET', url: perfmonUrl + '/stop', isArray: false }
        });

        return service;
    }
})();
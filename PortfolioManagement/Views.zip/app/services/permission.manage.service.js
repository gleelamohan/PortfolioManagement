/// <reference path="permission.manage.service.js" />
(function () {

    function permissionApi($resource, $http, efLibrary, efUiGridApi) {

        var permissionServiceUrl = window.app.services.eLimsServiceHost + '/api/smartservice/PermissionInfoService/';

        var service = $resource(permissionServiceUrl, {}, {
            query: { method: 'GET', url: permissionServiceUrl + 'GetAllPermissions', isArray: true },
            getAllPermissionGroups: { method: 'GET', url: permissionServiceUrl + 'GetAllPermissionGroups', isArray: true },
            getAllPermissionGroupNames: { method: 'GET', url: permissionServiceUrl + 'GetAllPermissionGroupNames', isArray: true },
            getById: { method: 'GET', url: permissionServiceUrl + '/GetById', params: { permissionId: '@permissionId' }, isArray: false }
        });


        service.query = function (searchObject) {
           return $http.get(permissionServiceUrl+'GetAllPermissionGroups');
        };


        service.globalSearchConfig = function () {
            return {
                "templateConfig": {
                    "pagetitle": "Views.Permissions.Search.TemplateConfig.PageTitle",
                    "searchResultPanelTitle": "Views.Permissions.Search.TemplateConfig.SearchResultsPanelTitle",
                    "searchResultsHelpText": "Common.Maintenance.SearchResultsHelpText",
                    "searchResultsNoResultsText": "Views.Permissions.Search.TemplateConfig.SearchResultsNoResultsText"
                }
            }
        }

        service.globalSearchGridConfig = function () {

            var gridOption = efLibrary.copyObject(efUiGridApi.exportGridConfig, true);
            var name = efUiGridApi.createReadonlyColumn("Name", "Entity.Permission.Name.ColumnText", { width: "30%" });
            var permissions = efUiGridApi.createReadonlyColumn("Permissions", "Entity.Permission.Name.ColumnText", null);
            gridOption.columnDefs.push(name);
            gridOption.columnDefs.push(description);
            gridOption.columnDefs.push(permissionGroup);

            return gridOption;
        }

        return service;
    }

    angular.module('app')
        .factory('permissionApi', permissionApi);
    permissionApi.$inject = ['$resource', "$http", "efLibrary", "efUiGridApi"];

})();


// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('app')
        .factory('enums', enums);

    function enums()
    {   
        var service = {
            TaskStatusEnums: [{ Value: "Active", Text: "Active" }, { Value: "Cancelled", Text: "Cancelled" }, { Value: "Completed", Text: "Completed" }],
            ParcelRegistrationPhaseEnums: [{ Value: "Received", Text: "Received" }, { Value: "Pickedup", Text: "Pickedup" }, { Value: "Processed", Text: "Processed" }, { Value: "Transfered", Text: "Transfered" }],
            TaskAssignmentStatusEnums: [{ Value: "New", Text: "New" }, { Value: "InProgress", Text: "In Progress" }, { Value: "Done", Text: "Done" }, { Value: "Ignored", Text: "Ignored" }],
            getEnumTextFromValue: function (iValue, enumname) {
                for (var i = 0; i < enumname.length; i++) {
                    if (enumname[i].Value === iValue) {
                        return enumname[i].Text;
                    }
                }
                return "";
            },

            getEnumValueFromText:function(iText,enumname) {
                for (var i = 0; i < enumname; i++) {
                    if (enums.enumname[i].text === iText) {
                        return enums.enumname[i].text;
                    }                      
                }
                return 0;
            }              
        };

        return service;
    }
 
})();

(function () {
    angular
        .module('app')
        .factory('navigationGate', navigationGate);

    navigationGate.$inject = ['$rootScope', '$window', 'navigationApi'];

    function navigationGate($rootScope, $window, navigationApi) {
        var eventFunction;
        $rootScope.$on("$stateChangeSuccess", function () {
            if (eventFunction) {
                eventFunction();
            }
            $window.onbeforeunload = null;
        });
        return {
            getData: function () {
                return navigationApi.query().$promise.then(function (data) {
                    return data;
                });
            },
            preventOnDirty: function(fnIsDirty, msgToDisplayBrowser) {
            $window.onbeforeunload = function () {
                if (fnIsDirty()) {
                    return msgToDisplayBrowser;
                }
            };

            eventFunction = $rootScope.$on("$stateChangeStart", function (event) {
                    if (fnIsDirty() && !$window.confirm(msgToDisplayBrowser)) 
                    event.preventDefault();
            });
        }
        }
    }
})();

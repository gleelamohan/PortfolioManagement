(function () {

    function roleManageApi($resource, datacontext, efLibrary, efUiGridApi) {

        var roleServiceUrl = window.app.services.eLimsServiceHost + '/api/SmartEntity/Role/';

        var service = $resource(roleServiceUrl, {}, {
            getById: { method: 'GET', url: roleServiceUrl + '@id', isArray: false },
            update: { method: 'PUT', url: roleServiceUrl + '@entityId' + '/' + '@rowVersion' + '/SynchronizeFromState', params: { formData: '@formdata' }, isArray: false },
            save: { method: 'POST', url: roleServiceUrl, params: { formData: '@formdata' }, isArray: false },
            remove: { method: 'DELETE', url: roleServiceUrl + '@id' }
        });




        service.query = function (searchObject) {
            var query;
            var selection = "Id, Name, Description";
            var collection = "Roles";

            if (searchObject === null || searchObject === undefined || searchObject.searchTerm === undefined || searchObject.searchTerm === null || searchObject.searchTerm === "") {
                query = breeze.EntityQuery.from(collection).select(selection);
            } else {
                var op = breeze.FilterQueryOp;
                var p1 = new breeze.Predicate("Description", op.Contains, searchObject.searchTerm);
                var p2 = breeze.Predicate("Name", op.Contains, searchObject.searchTerm);
                var predicate = p1.or(p2);

                query = breeze.EntityQuery.from(collection).select(selection).where(predicate);
            }

            return datacontext.executeQuery(query);
        };
        service.globalSearchConfig = function () {
            return {
                "templateConfig": {
                    "pagetitle": "Views.Roles.Search.TemplateConfig.PageTitle",
                    "searchResultPanelTitle": "Views.Roles.Search.TemplateConfig.SearchResultsPanelTitle",
                    "searchResultsHelpText": "Common.Maintenance.SearchResultsHelpText",
                    "searchResultsNoResultsText": "Views.Roles.Search.TemplateConfig.SearchResultsNoResultsText",
                    "addNewText": "Views.Roles.Search.TemplateConfig.AddNewText"
                },
                "searchEntryConfig": {
                    "searchEntryPanelTitle": "Views.Roles.Search.SearchEntryConfig.SearchEntryTitle",
                    "helpText": "Views.Roles.Search.SearchEntryConfig.SearchEntryHelpText",
                    "defaultSearchTermLabel": "Views.Roles.Search.SearchEntryConfig.SearchTermPlaceholder",
                    "defaultSearchTermPlaceholder": "Views.Roles.Search.SearchEntryConfig.DefaultSearchTermPlaceholder",
                    "displaySearchTermLabel": true,
                    "defaultSearchTerm": "",
                    "searchTermMinLength": 0,
                    "searchTermMaxLength": 50,
                    "includeSearchEntryOptions": false,
                    "enableSearchEntryOptionsToggle": true,
                    "defaultSearchScope": { "selectedSeacrhScope": "" }
                }
            }
        }

        service.globalSearchGridConfig = function () {

            var gridOption = efLibrary.copyObject(efUiGridApi.exportGridConfig, true);
            var name = efUiGridApi.createReadonlyColumn("Name", "Entity.Role.Name.ColumnText", { width: "20%" });
            var desc = efUiGridApi.createReadonlyColumn("Description", "Entity.Role.Description.ColumnText", null);
            var colEdit = efUiGridApi.createActionColDef("globalSearchResultUiGrid", "Edit", "Id", "vm.editCallback", null);
            var colDelete = efUiGridApi.createActionColDef("globalSearchResultUiGrid", "Delete", "Id", "vm.deleteCallback", "<i class=\"fa fa-trash-o\"></i>");
            desc.cellTooltip = true;
            gridOption.columnDefs.push(name);
            gridOption.columnDefs.push(desc);
            gridOption.columnDefs.push(colEdit);
            gridOption.columnDefs.push(colDelete);
            return gridOption;
        }

        return service;
    };
    angular.module('app')
        .factory('roleManageApi', roleManageApi);
    roleManageApi.$inject = ["$resource", "datacontext", "efLibrary", "efUiGridApi", "efUiGridConstants"];
})();


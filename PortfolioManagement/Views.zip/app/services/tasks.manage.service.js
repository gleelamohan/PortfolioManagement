(function () {
    function taskManageApi($resource, $filter, $translate, datacontext, efLibrary, efUiGridApi, efDatetimeMasks) {
        
        var taskUrl=window.app.services.eLimsServiceHost + '/api/tasks/';
        var smartServiceUrl = window.app.services.eLimsServiceHost + '/api/smartservice/TaskManagementService/';

        var service = $resource(taskUrl, {}, {
            //update: { method: 'PUT', url: taskUrl + "UpdateTask/:id", params: { formData: '@formData' }, isArray: false },
            //save: { method: 'POST', url: taskUrl + "AddTask", params: { formData: '@formData' }, isArray: false },
            //remove: { method: 'DELETE', url: taskUrl + 'Delete/' + { id: '@id' } },
            update: { method: 'PUT', url: smartServiceUrl + "UpdateTask", params: { actionArguments: '@updateActionArguments' }, isArray: false },
            save: { method: 'POST', url: smartServiceUrl + "AddTask", params: { actionArguments: '@actionArguments' }, isArray: false },
            remove: { method: 'DELETE', url: smartServiceUrl + 'DeleteTask/' + { id: '@id' } }
        });

        service.query = function (searchObject) {

            var selection = "Id, Name, Description, DueDate, Status";
            var collection = "Tasks";
            var query = breeze.EntityQuery.from(collection).select(selection);

            if (searchObject !== undefined && searchObject !== null) {

                if (searchObject.searchTerm) {
                    var p1 = new breeze.Predicate("Description", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    var p2 = breeze.Predicate("Name", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    query = query.where(breeze.Predicate.or([p1, p2]));
                }

                if (searchObject.searchScope) {

                    switch (searchObject.searchScope.selectedSeacrhStatus) {
                        case "Pending":
                            var p3 = new breeze.Predicate("DueDate", breeze.FilterQueryOp.LessThan, new Date());
                            var p4 = new breeze.Predicate("Status", breeze.FilterQueryOp.NotEquals, 1);
                            var p5 = new breeze.Predicate("Status", breeze.FilterQueryOp.NotEquals, 2);

                            var predicate2 = breeze.Predicate.and([p3, p4, p5]);

                            query = query.where(predicate2);
                            break;
                        case "Active":
                            var p6 = new breeze.Predicate("Status", breeze.FilterQueryOp.Equals, 0);
                            query = query.where(p6);
                            break;
                    }
                }
            }

            return datacontext.executeQuery(query);
        };

        service.getTaskById = function (id) {
            var selection = "Id, Name, Description, DueDate, Status, CreatorId, CreatedOn, RowVersion";
            var query = breeze.EntityQuery.from("Tasks").select(selection);
            var predicate = new breeze.Predicate("Id", breeze.FilterQueryOp.Equals, id);
            query = query.where(predicate);
            return datacontext.executeQuery(query);
        };

        service.globalSearchConfig = function () {
            return {
                "templateConfig": {
                    "pagetitle": "Views.Tasks.Search.TemplateConfig.PageTitle",
                    "searchResultPanelTitle": "Views.Tasks.Search.TemplateConfig.SearchResultsPanelTitle",
                    "searchResultsHelpText": "Common.Maintenance.SearchResultsHelpText",
                    "searchResultsNoResultsText": "Views.Tasks.Search.TemplateConfig.SearchResultsNoResultsText",
                    "addNewText": "Views.Tasks.Search.TemplateConfig.AddNewText"
                },
                "searchEntryConfig": {
                    "searchEntryPanelTitle": "Views.Tasks.Search.SearchEntryConfig.SearchEntryTitle",
                    "helpText": "Views.Tasks.SearchEntryConfig.SearchEntryHelpText",
                    "defaultSearchTermLabel": "Views.Tasks.Search.SearchEntryConfig.SearchTermPlaceholder",
                    "defaultSearchTermPlaceholder": "Views.Tasks.Search.SearchEntryConfig.DefaultSearchTermPlaceholder",
                    "displaySearchTermLabel": true,
                    "defaultSearchTerm": "",
                    "searchTermMinLength": 0,
                    "searchTermMaxLength": 50,
                    "defaultSearchScope": { "selectedSeacrhStatus": String($filter("trustedtranslate")("Views.Tasks.Manage.StatusConfig.Active")) },
                    "includeSearchEntryOptions": true,
                    "enableSearchEntryOptionsToggle": false,
                    "defaultSearchEntryOptionsTitle": "Views.Tasks.Search.SearchEntryConfig.DefaultSearchEntryOptionsTitle",
                    "searchEntryOptionsTemplateUrl": "/app/tasks/createdTasks/manage/createdTasks.search.html"
                }
            }
        }

        service.globalSearchGridConfig = function () {

            var gridOption = efLibrary.copyObject(efUiGridApi.exportGridConfig, true);
            var name = efUiGridApi.createReadonlyColumn("Name", "Entity.Task.Name.ColumnText", { width: "20%" });
            var desc = efUiGridApi.createReadonlyColumn("Description", "Entity.Task.Description.ColumnText",null);
            var status = efUiGridApi.createReadonlyColumn("Status", "Entity.Task.Status.ColumnText", { width: "20%" });
            var duedate = efUiGridApi.createReadonlyColumn("DueDate", "Entity.Task.DueDate.ColumnText", { width: "20%" });
            var colEdit = efUiGridApi.createActionColDef("globalSearchResultUiGrid", "Edit", "Id", "vm.editCallback", null);
            duedate.cellFilter = "date: '" + efDatetimeMasks.date.angular + "'";
            
            desc.cellTooltip = true;
            gridOption.columnDefs.push(name);
            gridOption.columnDefs.push(desc);
            gridOption.columnDefs.push(status);
            gridOption.columnDefs.push(duedate);
            gridOption.columnDefs.push(colEdit);
            return gridOption;
        }

        return service;
    }
    angular.module("app")
      .factory("taskManageApi", taskManageApi);
    taskManageApi.$inject = ["$resource", "$filter", "$translate", "datacontext", "efLibrary", "efUiGridApi", "efDatetimeMasks"];
})();
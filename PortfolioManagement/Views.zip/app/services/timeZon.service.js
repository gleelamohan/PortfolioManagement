(function () {
    angular
        .module('app')
        .factory('timeZoneApi', timeZoneApi);

    timeZoneApi.$inject = ['$resource', '$filter', 'enumsApi'];

    function timeZoneApi($resource, $filter, enumsApi) {
        //var service = $resource(serviceURL, {}, {
        //    getAll: { method: 'GET', params: {}, isArray: true },
        //    get: { method: 'GET', url: serviceURL + '/:accountId', params: { accountId: '@accountId' } },
        //    getAccountDetail: { method: 'GET', url: serviceURL + '/:accountId/AccountDetails', params: { accountId: '@accountId' } },
        //    query: { method: 'GET', url: serviceURL + '/search', isArray: true },
        //    update: { method: 'PUT', url: serviceURL + "/:accountId", params: { sampleTemplateId: '@accountId' } }
        //});

        var service = {};

        service.timeZones = {};

        service.setTimeZones = function () {
            enumsApi.query({ enumType: 'TimeZoneEnums' }).$promise.then(function (response) {
                delete response.NotSet;

                service.timeZones = response;
            });
        }

        service.getTimezoneOffset = function (timeZone) {
            var offSet = !service.timeZones[timeZone] || service.timeZones[timeZone].match("[+-][0-9]+$")[0] === "" ? "0" : service.timeZones[timeZone].match("[+-][0-9]+$")[0];

            return offSet;
        }

        service.setTimeZones();

        return service;
    }
})();
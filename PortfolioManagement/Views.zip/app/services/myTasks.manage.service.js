(function () {
 

    function myTaskManageApi($resource, $filter, $translate, datacontext, efLibrary, efUiGridApi, efDatetimeMasks) {

        var taskManagementServiceUrl = window.app.services.eLimsServiceHost + '/api/smartservice/TaskManagementService/';
        var service = $resource(taskManagementServiceUrl, {}, {
            update: {
                method: 'PUT',
                url: taskManagementServiceUrl + "/UpdateAssignment",
                params: { taskAssignmentId: '@taskAssignmentId', status: '@status', comment: '@comment' },
                isArray: false
            }
        });

        service.query = function (searchObject) {

            var selection = "Id, Task.Name, Task.Description, Task.User.UserDetail.FirstName, Task.User.UserDetail.LastName, Task.DueDate, Status";
            var collection = "TaskAssignments";
            var query = breeze.EntityQuery.from(collection).select(selection);

            if (searchObject !== undefined && searchObject !== null) {

                if (searchObject.searchTerm) {
                    var p1 = new breeze.Predicate("Task.Description", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    var p2 = breeze.Predicate("Task.Name", breeze.FilterQueryOp.Contains, searchObject.searchTerm);
                    var predicate1 = p1.or(p2);

                    query = query.where(predicate1);
                }

                if (searchObject.searchScope) {

                    switch (searchObject.searchScope.selectedSeacrhStatus) {
                        case "Pending":
                            var p3 = new breeze.Predicate("Task.DueDate", breeze.FilterQueryOp.LessThan, new Date());
                            var p4 = new breeze.Predicate("Status", breeze.FilterQueryOp.NotEquals, 2);
                            var p5 = new breeze.Predicate("Status", breeze.FilterQueryOp.NotEquals, 3);
                            var predicate2 = breeze.Predicate.and([p3, p4, p5]);
                            query = query.where(predicate2);
                            break;
                        case "InProgress":
                            var p7 = new breeze.Predicate("Status", breeze.FilterQueryOp.Equals, 1);
                            query = query.where(p7);
                            break;
                        case "New":
                            var p8 = new breeze.Predicate("Status", breeze.FilterQueryOp.Equals, 0);
                            query = query.where(p8);
                            break;
                    }
                }
            }

            query = query.expand("Task.User.UserDetail");
            return datacontext.executeQuery(query);
        };

        service.getMyTaskById = function (id) {
            var selection = "Id, AssigneeId, Status, AssignedOn, RowVersion, " +
                "User.UserDetail.FirstName, User.UserDetail.LastName, " +
                "Task.Name, Task.Description, Task.Status, Task.User.UserDetail.FirstName, Task.User.UserDetail.LastName, Task.DueDate";
            var query = breeze.EntityQuery.from("TaskAssignments").select(selection);

            if (!id) {
                throw "Please pass a valid task assignment id.";
            }

            var predicate = new breeze.Predicate("Id", breeze.FilterQueryOp.Equals, id);
            query = query.where(predicate);
            query = query.expand("Task.User.UserDetail, User.UserDetail");
            return datacontext.executeQuery(query);
        };

        service.getAssignmentsByTaskId = function (taskId) {

            var selection = "Id, TaskId, AssigneeId, Status, User.UserDetail.FirstName, User.UserDetail.LastName";
            var query = breeze.EntityQuery.from("AllTaskAssignments").select(selection);

            if (!taskId) {
                throw "Please pass a valid task id.";
            }

            var predicate = new breeze.Predicate("TaskId", breeze.FilterQueryOp.Equals, taskId);
            query = query.where(predicate);
            query = query.expand("User.UserDetail");
            return datacontext.executeQuery(query);
        };

        service.loadDefaultSearchResult = false;

        service.defaultSearchterm = "";

        service.setDefaultSearchEntryValue = function (inputScope) {
            if (inputScope != null) {
                service.defaultSearchterm = { "selectedSeacrhStatus": inputScope.selectedSeacrhStatus }
                service.loadDefaultSearchResult = inputScope.loadDefaultSearchResult;
            } else {
                service.defaultSearchterm = { "selectedSeacrhStatus": String($filter("trustedtranslate")("Views.Tasks.Manage.StatusConfig.Pending")) };
                service.loadDefaultSearchResult = false;
            }
        }
            
        service.globalSearchConfig = function () {
            return {
                "templateConfig": {
                    "pagetitle": "Views.TaskAssignments.Search.TemplateConfig.PageTitle",
                    "searchResultPanelTitle": "Views.TaskAssignments.Search.TemplateConfig.SearchResultsPanelTitle",
                    "searchResultsHelpText": "Common.Maintenance.SearchResultsHelpText",
                    "searchResultsNoResultsText": "Views.TaskAssignments.Search.TemplateConfig.SearchResultsNoResultsText",
                    "addNewText": null
        },
                "searchEntryConfig": {
                    "searchEntryPanelTitle": "Views.TaskAssignments.Search.SearchEntryConfig.SearchEntryTitle",
                    "helpText": "Views.TaskAssignments.SearchEntryConfig.SearchEntryHelpText",
                    "defaultSearchTermLabel": "Views.TaskAssignments.Search.SearchEntryConfig.SearchTermPlaceholder",
                    "defaultSearchTermPlaceholder": "Views.TaskAssignments.Search.SearchEntryConfig.DefaultSearchTermPlaceholder",
                    "displaySearchTermLabel": true,
                    "defaultSearchTerm": "",
                    "searchTermMinLength": 0,
                    "searchTermMaxLength": 50,
                    "includeSearchEntryOptions": true,
                    "enableSearchEntryOptionsToggle": false,
                    "defaultSearchEntryOptionsTitle": "Views.TaskAssignments.Search.SearchEntryConfig.DefaultSearchEntryOptionsTitle",
                    "searchEntryOptionsTemplateUrl": "/app/tasks/myTasks/manage/myTasks.search.html",
                    "loadDefaultSearchResult": service.loadDefaultSearchResult,
                    "defaultSearchScope": service.defaultSearchterm

                }
            }
        }

        service.globalSearchGridConfig = function () {

            var gridOption = efLibrary.copyObject(efUiGridApi.exportGridConfig, true);
            var name = efUiGridApi.createReadonlyColumn("Task_Name", "Entity.TaskAssignment.Name.ColumnText", null);
            var status = efUiGridApi.createReadonlyColumn("Status", "Entity.TaskAssignment.Status.ColumnText", { width: "10%" });
            var createdBy = efUiGridApi.createReadonlyColumn("Task_User_UserDetail_FirstName", "Entity.TaskAssignment.CreatedBy.ColumnText", { width: "20%" });
            var duedate = efUiGridApi.createReadonlyColumn("Task_DueDate", "Entity.TaskAssignment.DueDate.ColumnText", { width: "20%" });
            var colEdit = efUiGridApi.createActionColDef("globalSearchResultUiGrid", "Edit", "Id", "vm.editCallback", null);
            duedate.cellFilter = "date: '" + efDatetimeMasks.date.angular + "'";
            createdBy.cellTemplate = "<div class='ui-grid-cell-contents ui-grid-cell-contents-word-wrap' >{{row.entity.Task_User_UserDetail_FirstName}}&nbsp;{{row.entity.Task_User_UserDetail_LastName}}</div>";
            gridOption.columnDefs.push(name);
            gridOption.columnDefs.push(status);
            gridOption.columnDefs.push(createdBy);
            gridOption.columnDefs.push(duedate);
            gridOption.columnDefs.push(colEdit);
            return gridOption;
        }

        return service;
    }
    angular.module('app')
     .factory('myTaskManageApi', myTaskManageApi);

    myTaskManageApi.$inject = ["$resource", "$filter", "$translate", "datacontext", "efLibrary", "efUiGridApi", "efDatetimeMasks"];
})();
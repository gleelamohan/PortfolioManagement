(function () {
    angular
        .module('app')
        .factory('alertsManageApi', alertsManageApi);

    alertsManageApi.$inject = ['$resource', '$filter'];

    function alertsManageApi($resource, $filter) {
        var alertsUrl = window.app.services.eLimsServiceHost + '/api/alerts';
        var service = $resource(alertsUrl, {}, {
            query: { method: 'GET', isArray: false }
        });
        return service;
    }
})();
angular
    .module('app.notifications', [
          'app.notifications.createdNotifications'
        , 'app.notifications.myNotifications'
    ]);
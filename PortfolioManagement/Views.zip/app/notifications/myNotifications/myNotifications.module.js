angular
    .module('app.notifications.myNotifications', [
       'app.notifications.myNotifications.manage'
    ]);
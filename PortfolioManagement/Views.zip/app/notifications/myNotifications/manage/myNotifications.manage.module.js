angular
    .module('app.notifications.myNotifications.manage', []);

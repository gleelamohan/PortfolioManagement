(function () {
  

    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('notifications.myNotifications.manage', {
                url: "/manage",
                template: '<global-search searchservice="vm.searchService" refreshgrid="vm.refreshGrid"></global-search>',
                controller: "myNotificationsManageCtrl",
                controllerAs: "vm",
                params: { inputScope: null }
            });
    }
    angular.module('app.notifications.myNotifications.manage')
      .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];
})();
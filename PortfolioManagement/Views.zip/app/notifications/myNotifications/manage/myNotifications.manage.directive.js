(function() {
    function myNotificationManage($sce, $filter, recursionHelper, toastr, masks, myNotificationManageApi, notificationRecipientQueryApi) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                isModal: "@ismodal",
                inputScope: "=inputscope",
                appCallback: "=appcallback",
                infoVisible: "=infovisible",
                infoText: "=infotext",
                infoClass: "=infoclass"
            },
            controller: function($scope, $element, $attrs) {
                var vm = this;

                vm.templateUrl = "/app/notifications/myNotifications/manage/myNotifications.manage.html";
                vm.isModal = Boolean($scope.isModal || "false");
                vm.inputScope = $scope.inputScope;
                vm.appCallback = $scope.appCallback;
                vm.helpVisible = false;
                vm.okButtonText = String($filter("trustedtranslate")("Views.NotificationsRecipients.Manage.OkButtonText"));
                vm.helpText = String($filter("trustedtranslate")("Views.NotificationsRecipients.Manage.HelpText"));
                vm.tosterMessage = String($filter("trustedtranslate")("Views.NotificationsRecipients.Manage.UpdateOkText"));
                vm.saveDisabled = true;
                vm.formData = {};

                vm.iboxToolsValidationVisible = false;

                vm.statusConfig = {
                    "allowDuplicates": false,
                    "placeholder": "Select status...",
                    "options": [
                        { "value": 0, "label": String($filter("trustedtranslate")("Views.Notifications.Manage.StatusConfig.Unread")) },
                        { "value": 1, "label": String($filter("trustedtranslate")("Views.Notifications.Manage.StatusConfig.Read")) }
                    ],
                    "width": "100%"
                };

                if ((vm.inputScope) && (vm.inputScope.Id) && (vm.inputScope.Id.length > 0)) {
                    notificationRecipientQueryApi.getNotificationRecipientById(vm.inputScope.Id).then(function(response) {
                        vm.formData.Notification = response.results[0];
                        if (vm.formData.Notification.ReadOn == null) {
                            vm.formData.Notification.IsRead = false;
                        } else {
                            vm.formData.Notification.IsRead = true;
                        }
                        vm.CreatedOn = moment(moment.utc(vm.formData.Notification.Notification_SentOn).toDate()).format(masks.datetime.moment);
                        vm.headerText = String($filter("trustedtranslate")("Views.NotificationsRecipients.Manage.UpdateStatus"));
                    }).catch(function(error) {
                        console.log(error);
                    });
                }

                $scope.$watch('infoVisible', handleInfoVisibleUpdates, true);
                $scope.$watch('infoText', handleInfoTextUpdates, true);
                $scope.$watch('infoClass', handleInfoClassUpdates, true);

                vm.toggleInfoVisibility = function(visible, ignoreModalCheck) {
                    vm.infoVisible = ((!(ignoreModalCheck || false)) && (vm.isModal)) ? false : visible || false;
                    vm.iboxToolsInfoVisible = visible || false;
                    vm.iboxToolsInfoToggledExternally = vm.infoVisible;
                }

                vm.resetInfo = function() {
                    vm.infoText = "";
                    vm.infoClass = "alert alert-info";
                    vm.toggleInfoVisibility(false);
                }

                function handleInfoVisibleUpdates(newData) {
                    vm.toggleInfoVisibility(newData || false);
                };

                function handleInfoTextUpdates(newData) {
                    vm.infoText = newData || "";
                };

                function handleInfoClassUpdates(newData) {
                    vm.infoClass = newData || "alert alert-info";
                };

                vm.iboxToolsShowHideVisible = vm.isModal === true ? false : true;
                vm.iboxToolsInfoVisible = false;
                vm.iboxToolsInfoToggledExternally = false;
                vm.iboxToolsValidationToggledExternally = false;
                vm.iboxToolsFilterVisible = false;
                vm.iboxToolsSettingsVisible = false;
                vm.iboxToolsHelpVisible = true;
                vm.iboxToolsToggleInfo = function() {
                    vm.infoVisible = !vm.infoVisible;
                };
                vm.iboxToolsToggleFilter = function() {};
                vm.iboxToolsToggleSettings = function() {};
                vm.iboxToolsToggleHelp = function() {
                    vm.helpVisible = !vm.helpVisible;
                };

                vm.validationIssues = [];

                vm.formChanged = function() {
                    vm.saveDisabled = false;
                }

                vm.createValidationIssue = function(field, message, cssClass) {
                    return {
                        "field": field || "",
                        "message": message || "",
                        "cssClass": cssClass || ""
                    };
                }

                vm.createValidationInfoText = function(issues) {
                    var infoText = "";

                    if ((issues) && (issues.length > 0)) {
                        infoText = "<p>" + String($filter("trustedtranslate")("Views.Notifications.Manage.ValidationMessages.NotificationValidationInfoText")) + "</p><ul>";

                        issues.forEach(function(issue) {
                            infoText += ("<li>" + issue.message + "</li>");
                        });

                        infoText += "</ul>";
                    }
                    return infoText;
                }

                vm.save = function() {
                    if (vm.validationIssues.length === 0) {
                        if (vm.formData.Notification.Id) {
                            //Update
                            myNotificationManageApi.update({ notificationRecieptId: vm.formData.Notification.Id, comment: "Updating notification status" }).$promise.then(
                                function() {
                                    vm.showSubmissionResponse(true);
                                }, function(result) {
                                    vm.showSubmissionResponse(false, result.data);
                                });
                        }
                    }
                };

                vm.cancel = function() {
                    vm.appCallback('cancel', {});
                };

                vm.showSubmissionResponse = function(success, message) {
                    if (success) {
                        toastr.success(vm.tosterMessage);
                        vm.appCallback('saveOk', {});
                    } else {
                        var issues = [];
                        issues.push(vm.createValidationIssue("", message, "has-error"));
                        vm.infoText = vm.createValidationInfoText(issues);
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true, true);
                    }
                };
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function(element) {
                return recursionHelper.compile(element);
            }
        }
    }

    angular
        .module('app.notifications.myNotifications.manage')
        .directive('myNotificationManage', myNotificationManage);

    myNotificationManage.$inject = ['$sce', '$filter', 'recursionHelper', 'toastr', 'masks', 'myNotificationManageApi', 'notificationRecipientQueryApi'];;
})();

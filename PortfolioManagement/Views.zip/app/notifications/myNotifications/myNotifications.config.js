(function () {
    angular
        .module('app.notifications.myNotifications')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];

    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('notifications.myNotifications', {
                abstract: true,
                url: "/myNotifications",
                template: '<ui-view />'
            });
    }
})();


(function () {
    function createdNotificationsManage($sce, $filter, recursionHelper, toastr, masks, notificationManageApi, notificationQueryApi, notificationRecipientQueryApi) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                isModal: "@ismodal",
                inputScope: "=inputscope",
                appCallback: "=appcallback",
                infoVisible: "=infovisible",
                infoText: "=infotext",
                infoClass: "=infoclass"
            },
            controller: function ($scope, $element, $attrs) {
                var vm = this;
                vm.templateUrl = "/app/notifications/createdNotifications/manage/createdNotifications.manage.html";
                vm.isModal = Boolean($scope.isModal || "false");
                vm.inputScope = $scope.inputScope;
                vm.appCallback = $scope.appCallback;
                vm.helpVisible = false;
                vm.okButtonText = 'Save';
                vm.helpText = 'Add/Edit Notification template. Fields marked with * are required fields';
                vm.tosterMessage = 'Notification saved successfully';
                vm.saveDisabled = true;

                vm.statusConfig = {
                    "allowDuplicates": false,
                    "placeholder": "Select status...",
                    "options": [
                        { "value": 0, "label": String($filter("trustedtranslate") ("Views.Notifications.Manage.StatusConfig.Unread")) },
                        { "value": 1, "label": String($filter("trustedtranslate") ("Views.Notifications.Manage.StatusConfig.Read")) }
                    ],
                    "width": "100%"
                };

                vm.selectedStatus = null;

                vm.adUserSearchConfig = {
                    //ToDo : Change the hard coded value to enum string
                    "defaultStatusName": String($filter("trustedtranslate") ("Views.Notifications.Manage.StatusConfig.Unread")),
                    "placeholder": String($filter("trustedtranslate") ("Views.Notifications.Manage.adUserSearchConfig.PlaceHolder")),
                    "displayColumnText": [String($filter("trustedtranslate") ("Views.Notifications.Manage.adUserSearchConfig.displayColRecipientName")), String($filter("trustedtranslate") ("Views.Notifications.Manage.adUserSearchConfig.displayColStatus"))]
                };

                vm.selectedUserList = [];

                vm.formData = {};
                vm.isNotificationEditable = true;
                vm.unreadCount = 0;
                vm.readCount = 0;

                vm.calculateCountofAssignmentStatus = function () {
                    vm.totalCount = vm.assignedUsers.length;
                   
                    for (var i = 0; i < vm.totalCount; i++)
                    {
                        var readstatus = String($filter("trustedtranslate")("Views.Notifications.Manage.StatusConfig.Unread"));
                        if (vm.assignedUsers[i].ReadOn !== null) {
                            readstatus = String($filter("trustedtranslate") ("Views.Notifications.Manage.StatusConfig.Read"));
                        }

                        var selectedUser = {
                            Id: vm.assignedUsers[i].RecipientId,
                            UserFullName: vm.assignedUsers[i].User_UserDetail_FirstName + ' ' + vm.assignedUsers[i].User_UserDetail_LastName,
                            StatusName: readstatus
                        };


                        if (vm.assignedUsers[i].ReadOn !== null) {
                            vm.readCount = vm.readCount + 1;
                        }
                        else {
                            vm.unreadCount = vm.unreadCount + 1;
                        }
                        vm.selectedUserList.push(selectedUser);
                    };           
                }
               
                vm.iboxToolsValidationVisible = true;

                if ((vm.inputScope) && (vm.inputScope.Id) && (vm.inputScope.Id.length > 0)) {

                    notificationQueryApi.getNotificationById(vm.inputScope.Id).then(function (response) {
                        vm.formData.Notification = response.results[0];

                        notificationRecipientQueryApi.getNotificationRecipientsByNotificationId(vm.formData.Notification.Id).then(function (response) {

                            vm.assignedUsers = response.results;
                            vm.formData.Notification.Recipients = response.results;
                            vm.calculateCountofAssignmentStatus();
                            vm.IsUpdate = true;
                            vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.UpdateButton"));
                            vm.headerText = String($filter("trustedtranslate")("Views.Notifications.Manage.UpdateNotification"));
                            vm.NotificationTitle = String($filter("trustedtranslate")("Views.Notifications.Manage.StatusConfig.RecipientStatus"));
                        }).catch(function(error) {
                            console.log(error);
                        });
                    });
                } else {
                    vm.formData.Notification = {
                        //ToDo : Need to discuss with Team and make more error proof, then the current way of hard coding the fields of entity for new operation
                        "Id": null,
                        "Subject": "",
                        "Message": "",
                        "StatusName": "",                        
                        "RecipientIds": []
                    };
                    vm.statusConfig = {
                        "allowDuplicates": false,                      
                        "options": [
                            { "value": 0, "label": String($filter("trustedtranslate") ("Views.Notifications.Manage.StatusConfig.Unread"))}
                        ],
                        "width": "100%"
                    };
                    vm.isStatusReadOnly = true;
                    vm.isNotificationEditable = true;
                    vm.IsUpdate = false;
                    vm.formData.Notification.StatusName = String($filter("trustedtranslate") ("Views.Notifications.Manage.StatusConfig.Unread"));
                    vm.okButtonText = "Create";
                    vm.selectedUserList = [];
                    vm.headerText =  String($filter("trustedtranslate") ("Views.Notifications.Manage.CreateNotification"));
                    vm.NotificationTitle = String($filter("trustedtranslate") ("Views.Notifications.Manage.Recipients"));
                }                   

                $scope.$watch('infoVisible', handleInfoVisibleUpdates, true);
                $scope.$watch('infoText', handleInfoTextUpdates, true);
                $scope.$watch('infoClass', handleInfoClassUpdates, true);

                vm.toggleInfoVisibility = function (visible, ignoreModalCheck) {
                    vm.infoVisible = ((!(ignoreModalCheck || false)) && (vm.isModal)) ? false : visible || false;
                    vm.iboxToolsInfoVisible = visible || false;
                    vm.iboxToolsInfoToggledExternally = vm.infoVisible;
                }

                vm.resetInfo = function () {
                    vm.infoText = "";
                    vm.infoClass = "alert alert-info";
                    vm.toggleInfoVisibility(false);
                }

                function handleInfoVisibleUpdates(newData) {
                    vm.toggleInfoVisibility(newData || false);
                };

                function handleInfoTextUpdates(newData) {
                    vm.infoText = newData || "";
                };

                function handleInfoClassUpdates(newData) {
                    vm.infoClass = newData || "alert alert-info";
                };

                vm.onSelectCallback = function (users) {
                    vm.formData.Notification.Recipients = users;
                    vm.selectedUserList = users;
                    vm.formChanged();
                }

                vm.getSelectedRecipientId = function() {
                    vm.formData.Notification.RecipientIds = [];
                    for (var index = 0; index < vm.selectedUserList.length; index++) {
                        vm.formData.Notification.RecipientIds.push(vm.selectedUserList[index].Id);
                    }
                }

                vm.iboxToolsShowHideVisible = vm.isModal === true ? false : true;
                vm.iboxToolsInfoVisible = false;
                vm.iboxToolsInfoToggledExternally = false;

                vm.iboxToolsValidationToggledExternally = false;
                vm.iboxToolsFilterVisible = false;
                vm.iboxToolsSettingsVisible = false;
                vm.iboxToolsHelpVisible = true;
                vm.iboxToolsToggleInfo = function () {
                    vm.infoVisible = !vm.infoVisible;
                };
                vm.iboxToolsToggleFilter = function () { };
                vm.iboxToolsToggleSettings = function () { };
                vm.iboxToolsToggleHelp = function () {
                    vm.helpVisible = !vm.helpVisible;
                };

                vm.validationIssues = [];

                vm.compareDate = function (duedate) {
                    return (moment(duedate, masks.date.model.moment).diff(moment(), 'days')) > -1;
                }

                vm.formChanged = function () {
                    vm.saveDisabled = false;
                }

                vm.createValidationIssue = function (field, message, cssClass) {
                    return {
                        "field": field || "",
                        "message": message || "",
                        "cssClass": cssClass || ""
                    };
                }

                vm.createValidationInfoText = function (issues) {
                    var infoText = "";

                    if ((issues) && (issues.length > 0)) {
                        infoText = "<p>" +String($filter("trustedtranslate") ("Views.Notifications.Manage.ValidationMessages.NotificationValidationInfoText")) + "</p><ul>";

                        issues.forEach(function (issue) {
                            infoText += ("<li>" + issue.message + "</li>");
                        });

                        infoText += "</ul>";
                    }
                    return infoText;
                }

                vm.validationCallback = function () {
                    vm.validateFormData(true);
                }

                vm.validateFormData = function (displayOkMessage) {
                    vm.resetInfo();
                    vm.validationIssues = [];
                    var issues = [];

                    if ((!vm.formData.Notification.Subject) || (vm.formData.Notification.Subject.length === 0) || (vm.formData.Notification.Subject.trim() === "")) {
                        issues.push(vm.createValidationIssue("Notification.Subject", String($filter("trustedtranslate") ("Views.Notifications.Manage.ValidationMessages.NotificationSubjectRequired")), "has-error"));
                    }

                    if ((vm.formData.Notification.Subject) && ((vm.formData.Notification.Subject.length < 2) || (vm.formData.Notification.Subject.length > 100))) {
                        issues.push(vm.createValidationIssue("Notification.Subject", String($filter("trustedtranslate") ("Views.Notifications.Manage.ValidationMessages.NotificationSubjectValidation")), "has-error"));
                    }

                    if ((!vm.formData.Notification.Message) || (vm.formData.Notification.Message.length === 0)) {
                        issues.push(vm.createValidationIssue("Notification.Message", String($filter("trustedtranslate") ("Views.Notifications.Manage.ValidationMessages.NotificationMessageRequired")), "has-error"));
                    }

                    if ((vm.formData.Notification.Message) && ((vm.formData.Notification.Message.length < 2) || (vm.formData.Notification.Message.length > 1000))) {
                        issues.push(vm.createValidationIssue("Notification.Message", String($filter("trustedtranslate") ("Views.Notifications.Manage.ValidationMessages.NotificationMessageValidation")), "has-error"));
                    }

                    if ((!vm.formData.Notification.Recipients) || (vm.formData.Notification.Recipients.length === 0)) {
                        issues.push(vm.createValidationIssue("Notification.Recipients", String($filter("trustedtranslate") ("Views.Notifications.Manage.ValidationMessages.NotificationRecipientsValidation")), "has-error"));
                    }

                    if (issues.length > 0) {
                        var fieldIssues = [];
                        issues.forEach(function (issue) {
                            var fieldIssueExists = false;
                            fieldIssues.forEach(function (fieldIssue) {
                                if (fieldIssue.field === issue.field) {
                                    fieldIssueExists = true;
                                    fieldIssue.message += ("  " + issue.message);
                                }
                            });
                            if (!fieldIssueExists) {
                                fieldIssues.push(issue);
                            }
                        });

                        vm.infoText = vm.createValidationInfoText(issues);
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true);

                        vm.validationIssues = fieldIssues;
                    } else {
                        vm.formData.Notification.Subject = vm.formData.Notification.Subject.trim();
                        vm.formData.Notification.Message = vm.formData.Notification.Message.trim();
                        if (displayOkMessage || false) {
                            toastr.success(String($filter("trustedtranslate")("Views.Notifications.Manage.ValidationMessages.ValidationOkText")));
                        }
                    }
                };

                vm.getFieldValidationIssue = function (field) {
                    var fieldIssue = vm.createValidationIssue("", "", "");  //Need empty issue - including cssClass
                    if ((vm.validationIssues) && (vm.validationIssues.length > 0)) {
                        for (var i = 0; i < vm.validationIssues.length; i++) {
                            if (vm.validationIssues[i].field === field) {
                                fieldIssue = vm.validationIssues[i];
                                break;
                            }
                        }
                    }
                    return fieldIssue;
                }

                vm.save = function () {
                    vm.getSelectedRecipientId();
                    vm.validateFormData();

                    if (vm.validationIssues.length === 0) {
                        if (vm.formData.Notification.Id) {
                            //Update                                   
                            notificationManageApi.update({
                                notificationId: vm.formData.Notification.Id,
                                rowVersion: vm.formData.Notification.RowVersion,
                                subject: vm.formData.Notification.Subject,
                                message: vm.formData.Notification.Message,
                                recipientIds: vm.formData.Notification.RecipientIds,
                                comment: "Adding new notification"
                            }).$promise.then(
                                function () {
                                    vm.showSubmissionResponse(true);
                                }, function (result) {
                                    vm.showSubmissionResponse(false, result.data);
                                });
                        } else {
                            vm.formData.Notification.SenderId = "";
                            //Create                            
                            notificationManageApi.save({
                                subject: vm.formData.Notification.Subject,
                                message: vm.formData.Notification.Message,
                                recipientIds: vm.formData.Notification.RecipientIds,
                                comment: "Adding new notification"
                            }).$promise.then(
                                function () {
                                    vm.showSubmissionResponse(true);
                                }, function (result) {
                                    vm.showSubmissionResponse(false, result.data);
                                });
                        }
                    }
                };

                vm.cancel = function () {
                    vm.appCallback('cancel', {});
                };

                vm.showSubmissionResponse = function (success, message) {
                    if (success) {
                        toastr.success(vm.tosterMessage);
                        vm.appCallback('saveOk', {});
                    } else {
                        if (vm.isDeleteFlag) {
                            vm.infoText = message;
                        } else {
                            var issues = [];
                            issues.push(vm.createValidationIssue("", message, "has-error"));
                            vm.infoText = vm.createValidationInfoText(issues);
                        }
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true, true);
                    }
                };
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        }
    }

    angular
        .module('app.notifications.createdNotifications.manage')
        .directive('createdNotificationsManage', createdNotificationsManage);

    createdNotificationsManage.$inject = ['$sce', '$filter', 'recursionHelper', 'toastr', 'masks', 'notificationManageApi', 'notificationQueryApi', 'notificationRecipientQueryApi'];;
})();

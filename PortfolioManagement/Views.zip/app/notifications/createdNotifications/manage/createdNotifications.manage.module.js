angular
    .module('app.notifications.createdNotifications.manage', []);
angular
    .module('app.notifications.createdNotifications', [
       'app.notifications.createdNotifications.manage'
    ]);
(function () {
    angular
        .module('app.notifications.createdNotifications')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];

    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('notifications.createdNotifications', {
                abstract: true,
                url: "/createdNotifications",
                template: '<ui-view />'
            });
    }
})();
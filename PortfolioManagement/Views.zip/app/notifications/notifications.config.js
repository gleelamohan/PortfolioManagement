
(function () {
  angular
      .module('app.notifications')
      .config(config);

  config.$inject = ['$stateProvider', '$urlRouterProvider','$httpProvider'];

  function config($stateProvider, $urlRouterProvider, $httpProvider) {

    $httpProvider.defaults.withCredentials = true;

    $urlRouterProvider.otherwise("/");

    $stateProvider
        .state('notifications', {
          abstract: true,
          url: "/notifications",
          template: "<ui-view />"
        });
  }
})();

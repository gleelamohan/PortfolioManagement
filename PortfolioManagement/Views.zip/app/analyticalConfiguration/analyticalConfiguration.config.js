(function () {
  function config($stateProvider, $urlRouterProvider, $httpProvider) {
    $httpProvider.defaults.withCredentials = true;
    $urlRouterProvider.otherwise("/");
    $stateProvider
        .state('analyticalConfiguration', {
          "abstract": true,
          url: "/analyticalConfiguration",
          template: "<ui-view />"
        });
  }
    angular.module('app.analyticalConfiguration')
        .config(config);
  config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];
})();
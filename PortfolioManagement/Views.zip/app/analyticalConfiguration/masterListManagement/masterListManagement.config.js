(function () {

    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('analyticalConfiguration.masterListManagement', {
                "abstract": true,
                url: "/masterListManagement",
                template: '<ui-view />'
            });
    }

    angular.module('app.analyticalConfiguration.masterListManagement')
     .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider', '$translateProvider'];
})();
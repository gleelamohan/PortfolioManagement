angular
    .module('app.analyticalConfiguration.masterListManagement', [
       'app.analyticalConfiguration.masterListManagement.manage'
    ]);
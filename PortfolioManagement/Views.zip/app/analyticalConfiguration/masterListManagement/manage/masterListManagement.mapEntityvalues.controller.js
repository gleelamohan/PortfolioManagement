﻿(function () {
    angular
        .module('app.analyticalConfiguration.masterListManagement.manage')
        .controller('mapEntityvaluesCtrl', mapEntityvaluesCtrl);

    mapEntityvaluesCtrl.$inject = ['$scope', '$stateParams', '$translate', '$filter', '$timeout', '$modal','masterListEntityValuesApi'];

    function mapEntityvaluesCtrl($scope, $stateParams, $translate, $filter, $timeout, $modal, masterListEntityValuesApi) {
        var vm = this;

        vm.inputScope = $scope.inputScope || $stateParams.inputScope || {};

        masterListEntityValuesApi.setDefaultSearchEntryValue(vm.inputScope);
        

        // mapped masterListEntityValuesApi to the searchService of Globalserach directive.
        vm.searchService = masterListEntityValuesApi;

        //The following is used to set and open the info panel of the form
        vm.infoVisible = false;
        vm.infoText = "";
        vm.infoClass = "alert alert-info";
   

        //Input scope values from calling page
       
        //called function for the appcallback from calling function in editCallback method
        function appCallback(callbackAction, callbackScope) {

        };

        //open modal dialogue box.
        vm.openModal = function (modalScope) {
            var modalInstance = $modal.open({
                template: '<div class="modal-body"><master-list-management ismodal="true" inputscope="vm.inputScope" appcallback="vm.appCallback" infovisible="vm.infoVisible" infotext="vm.infoText" infoclass="vm.infoClass"></master-list-management></div>',
                controller: 'ModalCtrl as vm',
                backdrop: 'static',
                keyboard: true,
                scope: function () {
                    var scope = $scope.$new();
                    scope.inputScope = modalScope;
                    return scope;
                }()
            });
            modalInstance.result.then(function (modalReturnScope) {
                var outputScope = modalReturnScope || null;
                if (outputScope) {
                    vm.refreshGrid();
                }
            }, function () { });
        }


        //called method for refreshing the entity-value ui-grid
        vm.refreshGrid = function () {
            //masterListManagementApi.queryEntity().$promise.then(function (response) {
            //      vm.EntityValues = response;
            //});
        };

        //called method on click of the delete button in the ui-grid
        vm.deleteCallback = function (id) {
            var inputScope = { Id: id, EntityName: vm.inputScope.Id, action: "delete" }
            vm.openModal(inputScope);
        }

        //called method on click of the edit button in the ui-grid
        vm.editCallback = function (id) {
            var inputScope = { Id: id, EntityName: vm.inputScope.Id, action: "edit" }



            vm.openModal(inputScope);
        };

        //called method on click of the add entity value in the ui-grid.
        vm.addCallback = function () {
            var inputScope = { Id: null, EntityName: vm.inputScope.Id, action: "add" }
            vm.openModal(inputScope);
        };
    };
})();
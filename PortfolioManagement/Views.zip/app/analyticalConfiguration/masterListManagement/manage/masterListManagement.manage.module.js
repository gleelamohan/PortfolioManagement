angular
    .module('app.analyticalConfiguration.masterListManagement.manage', []);
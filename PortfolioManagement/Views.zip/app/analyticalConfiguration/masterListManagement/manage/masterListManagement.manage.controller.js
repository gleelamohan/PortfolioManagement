﻿(function () {

    function masterListManagementCtrl($scope,$state, $translate, $filter, $timeout, $modal, masterListManagementApi) {

        var vm = this;

        // mapped MasterListManagemntApi to the searchService of Globalserach directive.
        vm.searchService = masterListManagementApi;

        //called function for the appcallback from calling function in editCallback method
        function appCallback(callbackAction, callbackScope) {
            var action = callbackAction || null;
            var actionScope = callbackScope || {};
            if (action) {
                if (action === "rowSelect") {
                    if ((actionScope.Id) && (actionScope.Id.length > 0)) {
                        $state.go("analyticalConfiguration.masterListManagement.mapEntityvalues", { "inputScope": actionScope });
                    }
                }
                else if (action === "addNew") {
                    vm.openModal(actionScope);
                }
            }
        };

        //called method for edit callback.
        vm.editCallback = function (id) {
            var callbackAction = "rowSelect";
            var callbackScope = { Id: id };
            appCallback(callbackAction, callbackScope);
        };

        //called method for searching the enitity to get the entity results set  
        vm.searchMethod = function (searchObject) {
            return masterListManagementApi.getParcels(searchObject);
        };
    }

    
    angular.module('app.analyticalConfiguration.masterListManagement.manage')
      .controller('masterListManagementCtrl', masterListManagementCtrl);
    masterListManagementCtrl.$inject = ['$scope','$state', '$translate', '$filter', '$timeout', '$modal', "masterListManagementApi"];
})();
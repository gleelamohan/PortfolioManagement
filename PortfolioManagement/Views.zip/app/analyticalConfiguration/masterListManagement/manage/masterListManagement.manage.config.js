(function () {
    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('analyticalConfiguration.masterListManagement.manage', {
                url: "/manage",
                template: '<global-search searchservice="vm.searchService" refreshgrid="vm.refreshGrid"></global-search>',
                controller: "masterListManagementCtrl",
                controllerAs: "vm"
            }).state('analyticalConfiguration.masterListManagement.mapEntityvalues', {
                url: "/mapEntityvalues",
                //template: '<div class="wrapper wrapper-content animated fadeIn">' +
                //          '<master-list-management ismodal="false" inputscope="vm.inputScope" appcallback="vm.appCallback" infovisible="vm.infoVisible" infotext="vm.infoText" infoclass="vm.infoClass"></master-list-management>' +
                //          '</div>',
                template: '<global-search searchservice="vm.searchService" refreshgrid="vm.refreshGrid"></global-search>',
                controller: "mapEntityvaluesCtrl",
                controllerAs: "vm",
                params: { "inputScope": {} }
            });;
    }
    angular.module('app.analyticalConfiguration.masterListManagement.manage')
     .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];

})();
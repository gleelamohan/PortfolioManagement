﻿(function () {
    function masterListManagement($sce, $filter, $translate, recursionHelper, toastr, $modal, masterListManagementApi, masterListEntityValuesApi) {        
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                isModal: "@ismodal",
                inputScope: "=inputscope",
                appCallback: "=appcallback",
                infoVisible: "=infovisible",
                infoText: "=infotext",
                infoClass: "=infoclass"
            },
            controller: function ($scope, $element, $attrs) {
                //----------------- Global declarations----------------
                var vm = this;
                vm.templateUrl = "/app/analyticalConfiguration/masterListManagement/manage/masterListManagement.manage.html";
                vm.isModal = Boolean($scope.isModal || "false");
                vm.inputScope = $scope.inputScope;
                vm.appCallback = $scope.appCallback;
                vm.helpVisible = false;
                vm.isDeleteFlag = false;
                vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.SaveButton"));
                vm.helpText = String($filter("trustedtranslate")("Views.MasterManageList.Search.EntityValueConfig.EntityPopupHelpText"));
               
                vm.saveDisabled = true;
                vm.formData = {};
                vm.formData.lstEntity = {
                    "Id": null,
                    "Value": null,
                    "Description": null,
                    "IsInUse": false,
                    "OrderPosition": null,
                    

                };

                
                //Toolbox settings
                vm.iboxToolsShowHideVisible = vm.isModal === true ? false : true;
                vm.iboxToolsInfoVisible = false;
                vm.iboxToolsInfoToggledExternally = false;
                vm.iboxToolsValidationVisible = true;
                vm.iboxToolsValidationToggledExternally = false;
                vm.iboxToolsFilterVisible = false;
                vm.iboxToolsSettingsVisible = false;
                vm.iboxToolsHelpVisible = true;
                vm.iboxToolsToggleInfo = function () {
                    vm.infoVisible = !vm.infoVisible;
                };
                vm.iboxToolsToggleFilter = function () { };
                vm.iboxToolsToggleSettings = function () { };
                vm.iboxToolsToggleHelp = function () {
                    vm.helpVisible = !vm.helpVisible;
                };

                // Assigning input scope.
                if ((vm.inputScope) && (vm.inputScope.action)) {
                    vm.action = vm.inputScope.action;
                }


                // switch to the action as per input scope.
                switch (vm.action) {
                    case "delete":
                        deleteEntity();
                        break;
                    case "edit":
                        editEntity();
                        vm.headerTitle = String($filter("trustedtranslate")("Views.MasterManageList.Search.EntityValueConfig.PageEditTitle")) + vm.inputScope.EntityName;
                        break;
                    case "add":
                        vm.headerTitle = String($filter("trustedtranslate")("Views.MasterManageList.Search.EntityValueConfig.PageTitle")) + vm.inputScope.EntityName;
                        addEntity();
                        break;
                }
                //-----------------  End of Global declarations -----------------

                // called method to Load Entity Values to the Edit Popup.
                function loadEntity() {
                    masterListEntityValuesApi.getById({ entityName: vm.inputScope.EntityName, entityId: vm.inputScope.Id }).$promise.then(function (response) {
                          vm.formData.lstEntity  = response.state;

                    });
                    vm.saveDisabled = false;
                    //vm.formData.lstEntity = {
                    //    "Id": "1",
                    //    "value": "cm",
                    //    "description": "Test Desc",
                    //    "isactive": true,
                    //    "order": "1"

                    //};
                }

                //called method for delete Entity.
                function deleteEntity() {
                    loadEntity();
                    vm.isDeleteFlag = true;
                    vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.DeleteButton"));
                    vm.saveDisabled = false;
                    vm.iboxToolsValidationVisible = false;
                    vm.helpVisible = true;
                    vm.helpText = String($filter("trustedtranslate")("Views.Labsites.Manage.DeleteConfirmText"));;
                    vm.headerText = String($filter("trustedtranslate")("Views.Labsites.Manage.DeleteLabsite"));

                }

                //called method for enabling the save.
                vm.formChanged = function () {
                    vm.saveDisabled = false;
                };

                //Edit Entity value details to the popup.
                function editEntity() {
                    loadEntity();
                    //vm.headerText = String($filter("trustedtranslate")("Views.Labsites.Manage.UpdateLabsite"));
                }

                // Add Entity values to the popup.
                function addEntity() {
                    vm.formData.lstEntity = {
                        "Id": null,
                        "Value": null,
                        "Description": null,
                        "IsInUse": false,
                        "OrderPosition": 0,


                    };
                    //vm.headerText = String($filter("trustedtranslate")("Views.Labsites.Manage.AddLabsite"));
                }


                //called method for creating validation text message.
                vm.createValidationInfoText = function (issues) {
                    var infoText = "";

                    if ((issues) && (issues.length > 0)) {
                        infoText = "<p>" +
                            String($filter("trustedtranslate")("Views.MasterManageList.Search.Validation.ValidationHeaderText")) +
                            " " +
                            String($filter("trustedtranslate")("Views.MasterManageList.Search.Validation.ValidationHeaderSuffix")) +
                            "</p><ul>";

                        issues.forEach(function (issue) {
                            infoText += ("<li>" + issue.message + "</li>");
                        });

                        infoText += "</ul>";
                    }
                    return infoText;
                }


                //called method for creating validation issue.
                vm.createValidationIssue = function (field, message, cssClass) {
                    return {
                        "field": field || "",
                        "message": message || "",
                        "cssClass": cssClass || ""
                    };
                }

                //called method for field validation issue.
                vm.getFieldValidationIssue = function (field) {
                    var fieldIssue = vm.createValidationIssue("", "", ""); //Need empty issue - including cssClass
                    if ((vm.validationIssues) && (vm.validationIssues.length > 0)) {
                        for (var i = 0; i < vm.validationIssues.length; i++) {
                            if (vm.validationIssues[i].field === field) {
                                fieldIssue = vm.validationIssues[i];
                                break;
                            }
                        }
                    }
                    return fieldIssue;
                }

                //called method info toggle visiblilty.
                vm.toggleInfoVisibility = function (visible, ignoreModalCheck) {
                    vm.infoVisible = ((!(ignoreModalCheck || false)) && (vm.isModal)) ? false : visible || false;
                    vm.iboxToolsInfoVisible = visible || false;
                    vm.iboxToolsInfoToggledExternally = vm.infoVisible;
                }

                //called method for reset info.
                vm.resetInfo = function () {
                    vm.infoText = "";
                    vm.infoClass = "alert alert-info";
                    vm.toggleInfoVisibility(false);
                }

                //called method for validating the form data.
                vm.validateFormData = function (displayOkMessage) {
                    vm.resetInfo();
                    vm.validationIssues = [];
                    var issues = [];

                    var regEx = /^-?[0-9]\d*(d+)?$/;

                    if ((!vm.formData.lstEntity.Value) || (vm.formData.lstEntity.Value.length === 0)) {
                        issues.push(vm.createValidationIssue("lstEntity.Value", String($filter("trustedtranslate")("Views.Labsites.Manage.ValidationMessages.LabsiteCodeRequired")), "has-error"));
                    }
                    else if ((vm.formData.lstEntity.Value) && ((vm.formData.lstEntity.Value.length < 1) || (vm.formData.lstEntity.Value.length > 16))) {
                        issues.push(vm.createValidationIssue("lstEntity.Value", String($filter("trustedtranslate")("Views.Labsites.Manage.ValidationMessages.LabsiteCodeLength")), "has-error"));
                    }


                    if ((vm.formData.lstEntity.Description) && (vm.formData.lstEntity.Description.length > 500)) {
                        issues.push(vm.createValidationIssue("Labsite.Description", String($filter("trustedtranslate")("Views.Labsites.Manage.ValidationMessages.LabsiteDescriptionLength")), "has-error"));
                    }

                    if ((vm.formData.lstEntity.OrderPosition) && ((vm.formData.lstEntity.OrderPosition.length < 1) || (vm.formData.lstEntity.OrderPosition.length > 3))) {
                        issues.push(vm.createValidationIssue("lstEntity.OrderPosition", String($filter("trustedtranslate")("Views.Labsites.Manage.ValidationMessages.LabsiteCodeLength")), "has-error"));
                    }

                    if ((vm.formData.lstEntity.OrderPosition) && !regEx.test(vm.formData.lstEntity.OrderPosition)) {
                        issues.push(vm.createValidationIssue("lstEntity.OrderPosition", String($filter("trustedtranslate")("Views.Labsites.Manage.ValidationMessages.LabsiteCodeSpecialCharacter")), "has-error"));
                    }

                    if (issues.length > 0) {
                        var fieldIssues = [];
                        issues.forEach(function (issue) {
                            var fieldIssueExists = false;
                            fieldIssues.forEach(function (fieldIssue) {
                                if (fieldIssue.field === issue.field) {
                                    fieldIssueExists = true;
                                    fieldIssue.message += ("  " + issue.message);
                                }
                            });
                            if (!fieldIssueExists) {
                                fieldIssues.push(issue);
                            }
                        });

                        vm.infoText = vm.createValidationInfoText(issues);
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true);

                        vm.validationIssues = fieldIssues;
                    } else {
                        if (displayOkMessage || false) {
                            toastr.success(String($filter("trustedtranslate")("Views.MasterManageList.Search.Validation.ValidationOkText")));
                        }
                    }
                };               

                //Validation Callback .
                vm.validationCallback = function () {
                    vm.validateFormData(true);
                }

                //called method on click of cancel in the popup screen.
                vm.cancel = function () {
                    vm.appCallback('cancel', {});
                };

                //called method on click of save in the popup screen.
                vm.save = function () {
                    if (vm.action === "delete") {
                        masterListEntityValuesApi.remove({ entityName: vm.inputScope.EntityName, entityId: vm.inputScope.Id }).$promise.then(
                            function () {
                                toastr.success(String($filter("trustedtranslate")("Views.Labsites.Manage.DeleteOkText")));
                                vm.showSubmissionResponse(true);
                            }, function (result) {
                                vm.showSubmissionResponse(false, result.data);
                            });
                    } else {
                        vm.validateFormData();

                        var updateCommand = {
                            comment: "Updating MasterListEntity",
                            ActionArguments: {
                                "description": vm.formData.lstEntity.Description,
                                "orderPosition": vm.formData.lstEntity.OrderPosition == '' ? 0 : vm.formData.lstEntity.OrderPosition,
                                "isInUse": vm.formData.lstEntity.IsInUse
                            }
                        };

                       
                        var addCommand = {
                            comment: "Adding MasterListEntity",
                            ActionArguments: {
                                "value": vm.formData.lstEntity.Value,
                                "description": vm.formData.lstEntity.Description,
                                "orderPosition": vm.formData.lstEntity.OrderPosition == '' ? 0 : vm.formData.lstEntity.OrderPosition,
                                "isInUse": vm.formData.lstEntity.IsInUse

                            }
                        };

                        if (vm.validationIssues.length === 0) {

                            if (vm.formData.lstEntity.Id) {
                                //Update
                                masterListEntityValuesApi.update({ entityName: vm.inputScope.EntityName, entityId: vm.inputScope.Id, rowVersion: vm.formData.lstEntity.RowVersion }, updateCommand).$promise.then(
                                    function () {
                                        toastr.success(String($filter("trustedtranslate")("Views.Labsites.Manage.UpdateOkText")));
                                        vm.showSubmissionResponse(true);
                                    }, function (result) {
                                        vm.showSubmissionResponse(false, result.data);
                                    });
                            } else {
                                //Create
                                masterListEntityValuesApi.save({ entityName: vm.inputScope.EntityName},addCommand).$promise.then(
                                    function () {
                                        toastr.success(String($filter("trustedtranslate")("Views.Labsites.Manage.SaveOkText")));
                                        vm.showSubmissionResponse(true);
                                    }, function (result) {
                                        vm.showSubmissionResponse(false, result.data);
                                    });
                            }
                        }
                    }
                };



                vm.showSubmissionResponse = function (success, message) {
                    if (success) {
                        vm.appCallback('saveOk', {});
                    } else {
                        if (vm.isDeleteFlag) {
                            vm.infoText = message;
                        } else {
                            var issues = [];
                            issues.push(vm.createValidationIssue("", message, "has-error"));
                            vm.infoText = vm.createValidationInfoText(issues);
                        }
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true, true);
                    }
                };
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        }
        
    };
    angular.module('app.analyticalConfiguration.masterListManagement.manage')
    .directive('masterListManagement', app.customerPortfolio.customerDashboard.manage);

    masterListManagement.$inject = ['$sce', '$filter', '$translate', 'recursionHelper', 'toastr','$modal', 'masterListManagementApi','masterListEntityValuesApi'];
})();

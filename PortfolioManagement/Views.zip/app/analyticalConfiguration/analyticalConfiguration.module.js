angular
    .module('app.analyticalConfiguration', [
          'app.analyticalConfiguration.masterListManagement'
    ]);
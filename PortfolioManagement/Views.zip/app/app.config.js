(function () {
    angular
        .module('app')
        .config(config)
        .run(run);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider','$translateProvider', '$locationProvider', '$provide'];

    run.$inject = ['$rootScope'];

    extendExceptionHandler.$inject = ['$delegate', 'toastr'];


    function config($stateProvider, $urlRouterProvider, $httpProvider,$translateProvider,  $locationProvider, $provide) {

        $httpProvider.defaults.withCredentials = true;
        $httpProvider.defaults.useXDomain = true;
        $httpProvider.interceptors.push('httpSlowInterceptor');
        $locationProvider.html5Mode(true);
        $urlRouterProvider.otherwise("/");

        stateConfig($stateProvider);
        translateConfig($translateProvider);

        $provide.decorator('$exceptionHandler', extendExceptionHandler);
        
        function stateConfig($stateProvider) {
            $stateProvider
                .state('auth', {
                    url: "/auth",
                    template: '<ddbs-authentication />',
                    params: { inputScope: {} }
                });
        }
    }

    function run($rootScope) {
        $rootScope.$on('$stateChangeError', stateChangeErrorHandler);
    }

    function translateConfig($translateProvider) {
        // The following is requried if the translatePartialLoader is going to be used
        //$translateProvider.useLoader('$translatePartialLoader', {
        //    urlTemplate: '/i18n/{lang}_translations.json'
        //});
        //$translateProvider.preferredLanguage('en');
        $translateProvider.useStaticFilesLoader({
            prefix: '/i18n/',
            suffix: '_translations.json'
        });

        $translateProvider.registerAvailableLanguageKeys(['en', 'it'], {
            'en': 'en',
            'en_US': 'en',
            'en-us': 'en',
            'en_UK': 'en',
            'en-gb': 'en',
            'en-uk': 'en',
            'it': 'it',
            'it_IT': 'it',
            'it_CH': 'it'
        });
        $translateProvider.determinePreferredLanguage();
        $translateProvider.fallbackLanguage('en');
        $translateProvider.useLoaderCache(true);
    }

    function extendExceptionHandler($delegate, toastr) {
        return function (exception, cause) {
            $delegate(exception, cause);
            var errorData = {
                exception: exception,
                cause: cause
            };

            toastr.error(errorData.exception.stack, errorData.exception.message);
        };
    }

    function stateChangeErrorHandler(event, toState, toParams, fromState, fromParams, error) {
        event.preventDefault();
    }
   
})();






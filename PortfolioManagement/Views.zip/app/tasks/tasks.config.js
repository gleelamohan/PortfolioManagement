
(function () {
  angular
      .module('app.tasks')
      .config(config);

  config.$inject = ['$stateProvider', '$urlRouterProvider','$httpProvider'];

  function config($stateProvider, $urlRouterProvider, $httpProvider) {

    $httpProvider.defaults.withCredentials = true;

    $urlRouterProvider.otherwise("/");

    $stateProvider
        .state('tasks', {
          abstract: true,
          url: "/tasks",
          template: "<ui-view />"
        });
  }
})();
(function () {
    angular
        .module('app.tasks.createdTasks')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider', '$translateProvider'];

    function config($stateProvider, $urlRouterProvider, $httpProvider, $translateProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('tasks.createdTasks', {
                abstract: true,
                url: "/createdTasks",
                template: '<ui-view />'
            });
    }
})();
angular
    .module('app.tasks.createdTasks', [
       'app.tasks.createdTasks.manage'
    ]);
(function () {

    function createdTasksManageCtrl($scope, $filter, $translate, $timeout, $modal, taskManageApi) {
        var vm = this;
        vm.searchService = taskManageApi;

        function appCallback(callbackAction, callbackScope) {
            var action = callbackAction || null;
            var actionScope = callbackScope || {};
            if (action) {
                if (action === "rowSelect") {
                    if ((actionScope.Id) && (actionScope.Id.length > 0)) {
                        vm.openModal(actionScope);
                    }
                }
                else if (action === "addNew") {
                    vm.openModal(actionScope);
                }
            }
        }
        vm.deleteCallback = function (id) {
            //var inputScope = { Id: id, action: "delete" }
            //vm.openModal(inputScope);

            var callbackAction = "rowSelect";
            var callbackScope = { "Id": id, "isDelete": "true" };
            appCallback(callbackAction, callbackScope);
        }

        vm.editCallback = function (id) {
            //var inputScope = { Id: id, action: "edit" }
            //vm.openModal(inputScope);


            var callbackAction = "rowSelect";
            var callbackScope = { Id: id };
            appCallback(callbackAction, callbackScope);

        }


        vm.addCallback = function () {
            //var inputScope = { Id: null, action: "add" }
            //vm.openModal(inputScope);
            var callbackAction = "addNew";
            var callbackScope = { Id: null };
            appCallback(callbackAction, callbackScope);


        }
        vm.openModal = function (modalScope) {
            var modalInstance = $modal.open({
                template: '<div class="modal-body"><created-tasks-manage ismodal="true" inputscope="vm.inputScope" appcallback="vm.appCallback" infovisible="vm.infoVisible" infotext="vm.infoText" infoclass="vm.infoClass"></created-tasks-manage></div>',
                controller: 'ModalCtrl as vm',
                backdrop: 'static',
                keyboard: true,
                scope: function () {
                    var scope = $scope.$new();
                    scope.inputScope = modalScope;
                    return scope;
                }()
            });
            modalInstance.result.then(function (modalReturnScope) {
               
                var outputScope = modalReturnScope || null;
                if (outputScope) {
                    vm.refreshGrid();
                }
            }, function () { });
        }
     
    }
    angular.module('app.tasks.createdTasks.manage')
            .controller('createdTasksManageCtrl', createdTasksManageCtrl);
    createdTasksManageCtrl.$inject = ['$scope', '$filter', '$translate', '$timeout', '$modal', 'taskManageApi'];
})();
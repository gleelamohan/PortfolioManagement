(function() {
    function createdTasksManage($sce, $filter, $translate, recursionHelper, toastr, masks, taskManageApi, taskQueryApi, taskAssignmentQueryApi, enums) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                isModal: "@ismodal",
                inputScope: "=inputscope",
                appCallback: "=appcallback",
                infoVisible: "=infovisible",
                infoText: "=infotext",
                infoClass: "=infoclass"
            },
            controller: function($scope, $element, $attrs) {
                var vm = this;

                vm.currentLanguage = $translate.use();
                vm.TaskStatusEnums = enums.TaskStatusEnums;
                vm.templateUrl = "/app/tasks/createdTasks/manage/createdTasks.manage.html";
                vm.isModal = Boolean($scope.isModal || "false");
                vm.inputScope = $scope.inputScope;
                vm.appCallback = $scope.appCallback;
                vm.helpVisible = false;
                vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.SaveButton"));
                vm.helpText = String($filter("trustedtranslate")("Views.Tasks.Manage.HelpText"));
                vm.tosterMessage = String($filter("trustedtranslate")("Views.Tasks.Manage.SaveOkText"));
                vm.saveDisabled = true;

                vm.statusEnums = enums.TaskStatusEnums;

                vm.statusConfig = {
                    "allowDuplicates": false,
                    "placeholder": String($filter("trustedtranslate")("Views.Tasks.Manage.StatusConfig.PlaceHolder")),
                    "optionsValueField": "Value",
                    "optionsLabelField": "Text",
                    "width": "100%"
                };


                vm.selectedStatus = null;

                vm.adUserSearchConfig = {
                    "defaultStatusName": enums.getEnumTextFromValue("New", enums.TaskAssignmentStatusEnums),
                    "placeholder": "Search and Add Assignee",
                    "displayColumnText": ["Assignee Name", "Task Status"]
                };

                vm.selectedUserList = [];
                vm.formData = {};
                vm.isTaskEditable = false;
                vm.newCount = 0;
                vm.inprogressCount = 0;
                vm.ignoredCount = 0;
                vm.doneCount = 0;

                vm.calculateCountofAssignmentStatus = function() {
                    vm.totalCount = vm.assignedUsers.length;
                    for (var index = 0; index < vm.totalCount; index++) {
                        var selectedUser = {
                            Id: vm.assignedUsers[index].AssigneeId,
                            UserFullName: vm.assignedUsers[index].User_UserDetail_FirstName + ' ' + vm.assignedUsers[index].User_UserDetail_LastName,
                            StatusName: vm.assignedUsers[index].Status,
                            IsRemovable: false
                        };
                        switch (vm.assignedUsers[index].Status) {
                        case "New":
                            vm.newCount = vm.newCount + 1;
                            break;
                        case "InProgress":
                            vm.inprogressCount = vm.inprogressCount + 1;
                            break;
                        case "Ignored":
                            vm.ignoredCount = vm.ignoredCount + 1;
                            break;
                        case "Done":
                            vm.doneCount = vm.doneCount + 1;
                            break;
                        }
                        vm.selectedUserList.push(selectedUser);
                    }
                }

                vm.enableRemovableIfAllAssigneesAreNew = function() {
                    for (var index = 0; index < vm.selectedUserList.length; index++) {
                        vm.selectedUserList[index].IsRemovable = true;
                    }
                };

                vm.iboxToolsValidationVisible = true;

                if ((vm.inputScope) && (vm.inputScope.Id) && (vm.inputScope.Id.length > 0)) {

                    taskQueryApi.getTaskById(vm.inputScope.Id).then(function(response) {

                        if (!response.results[0]) {
                            throw "This task does not exists in db anymore.";
                        }

                        vm.formData.Task = response.results[0];

                        vm.assignedUsers = [];
                        taskAssignmentQueryApi.getAssignmentsByTaskId(vm.inputScope.Id).then(function(response) {
                            vm.assignedUsers = response.results;
                            vm.formData.Task.AssigneeIds = response.results;
                            if (vm.assignedUsers.length === 0) {
                                alert('inside');
                            }
                            vm.calculateCountofAssignmentStatus();

                            if (vm.newCount === vm.totalCount) {
                                vm.isTaskEditable = true;
                            }

                            if (vm.formData.Task.Status !== "Active") {
                                vm.isStatusReadOnly = true;
                                vm.isTaskEditable = false;
                            }

                            if (vm.isTaskEditable) {
                                vm.enableRemovableIfAllAssigneesAreNew();
                            }
                            vm.IsUpdate = true;
                            vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.UpdateButton"));
                            vm.headerText = String($filter("trustedtranslate")("Views.Tasks.Manage.UpdateTask"));
                            vm.AssignmentTitle = String($filter("trustedtranslate")("Views.Tasks.Manage.StatusConfig.AssignmentStatus"));

                        }).catch(function(error) {
                            console.log(error);
                        });


                    }).catch(function(error) {
                        console.log(error);
                    });
                } else {
                    vm.formData.Task = {
                        "Id": null,
                        "Name": "",
                        "Description": "",
                        "Status": "",
                        "DueDate": null,
                        "AssigneeIds": []
                    };
                    vm.isStatusReadOnly = true;
                    vm.isTaskEditable = true;
                    vm.IsUpdate = false;
                    vm.formData.Task.Status = "Active";
                    vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.CreateButton"));
                    vm.headerText = String($filter("trustedtranslate")("Views.Tasks.Manage.CreateTask"));
                    vm.AssignmentTitle = String($filter("trustedtranslate")("Views.Tasks.Manage.Assignees"));
                }

                $scope.$watch('infoVisible', handleInfoVisibleUpdates, true);
                $scope.$watch('infoText', handleInfoTextUpdates, true);
                $scope.$watch('infoClass', handleInfoClassUpdates, true);

                vm.toggleInfoVisibility = function(visible, ignoreModalCheck) {
                    vm.infoVisible = ((!(ignoreModalCheck || false)) && (vm.isModal)) ? false : visible || false;
                    vm.iboxToolsInfoVisible = visible || false;
                    vm.iboxToolsInfoToggledExternally = vm.infoVisible;
                }

                vm.resetInfo = function() {
                    vm.infoText = "";
                    vm.infoClass = "alert alert-info";
                    vm.toggleInfoVisibility(false);
                }

                function handleInfoVisibleUpdates(newData) {
                    vm.toggleInfoVisibility(newData || false);
                };

                function handleInfoTextUpdates(newData) {
                    vm.infoText = newData || "";
                };

                function handleInfoClassUpdates(newData) {
                    vm.infoClass = newData || "alert alert-info";
                };

                vm.onSelectCallback = function(users) {
                    //var selectedUser=
                    ////var assigne = {
                    ////    Id: vm.assignedUsers[index].Id,
                    ////    UserFullName: vm.assignedUsers[index].FullName,
                    ////    StatusName: vm.assignedUsers[index].StatusName,
                    ////    IsRemovable: false
                    ////};
                    ////vm.formData.Task.AssigneeIds = users;

                    //vm.formData.Task.AssigneeIds = users;
                    vm.selectedUserList = users;
                    vm.formData.Task.AssigneeIds.push(users);
                    vm.formChanged();
                }

                vm.getSelectedAssigneId = function() {
                    vm.formData.Task.AssigneeIds = [];
                    for (var index = 0; index < vm.selectedUserList.length; index++) {
                        vm.formData.Task.AssigneeIds.push(vm.selectedUserList[index].Id);
                    }
                }

                vm.iboxToolsShowHideVisible = vm.isModal === true ? false : true;
                vm.iboxToolsInfoVisible = false;
                vm.iboxToolsInfoToggledExternally = false;

                vm.iboxToolsValidationToggledExternally = false;
                vm.iboxToolsFilterVisible = false;
                vm.iboxToolsSettingsVisible = false;
                vm.iboxToolsHelpVisible = true;
                vm.iboxToolsToggleInfo = function() {
                    vm.infoVisible = !vm.infoVisible;
                };
                vm.iboxToolsToggleFilter = function() {};
                vm.iboxToolsToggleSettings = function() {};
                vm.iboxToolsToggleHelp = function() {
                    vm.helpVisible = !vm.helpVisible;
                };

                vm.validationIssues = [];

                vm.compareDate = function(duedate) {
                    return (moment(duedate, masks.date.model.moment).diff(moment(), 'days')) > -1;
                }

                vm.formChanged = function() {
                    vm.saveDisabled = false;
                }

                vm.createValidationIssue = function(field, message, cssClass) {
                    return {
                        "field": field || "",
                        "message": message || "",
                        "cssClass": cssClass || ""
                    };
                }

                vm.createValidationInfoText = function(issues) {
                    var infoText = "";

                    if ((issues) && (issues.length > 0)) {
                        infoText = "<p>" + String($filter("trustedtranslate")("Views.Tasks.Manage.ValidationMessages.TaskValidationInfoText")) + "</p><ul>";

                        issues.forEach(function(issue) {
                            infoText += ("<li>" + issue.message + "</li>");
                        });

                        infoText += "</ul>";
                    }
                    return infoText;
                }

                vm.validationCallback = function() {
                    vm.validateFormData(true);
                }

                vm.validateFormData = function(displayOkMessage) {
                    vm.resetInfo();
                    vm.validationIssues = [];
                    var issues = [];

                    if ((!vm.formData.Task.Name) || (vm.formData.Task.Name.length === 0) || (vm.formData.Task.Name.trim() === "")) {
                        issues.push(vm.createValidationIssue("Task.Name", String($filter("trustedtranslate")("Views.Tasks.Manage.ValidationMessages.TaskNameRequired")), "has-error"));
                    }

                    if (!vm.formData.Task.Name || (vm.formData.Task.Name && (vm.formData.Task.Name.trim().length < 2 || vm.formData.Task.Name.trim().length > 100))) {
                        issues.push(vm.createValidationIssue("Task.Name", String($filter("trustedtranslate")("Views.Tasks.Manage.ValidationMessages.TaskNameValidation")), "has-error"));
                    }

                    if ((!vm.formData.Task.Description) || (vm.formData.Task.Description.trim().length === 0)) {
                        issues.push(vm.createValidationIssue("Task.Description", String($filter("trustedtranslate")("Views.Tasks.Manage.ValidationMessages.TaskDescriptionRequired")), "has-error"));
                    }

                    if (!vm.formData.Task.Description || (vm.formData.Task.Description && (vm.formData.Task.Description.trim().length < 2 || vm.formData.Task.Description.trim().length > 500))) {
                        issues.push(vm.createValidationIssue("Task.Description", String($filter("trustedtranslate")("Views.Tasks.Manage.ValidationMessages.TaskDescriptionValidation")), "has-error"));
                    }

                    if ((!vm.formData.Task.DueDate) || (vm.formData.Task.DueDate.length === 0)) {
                        issues.push(vm.createValidationIssue("Task.DueDate", String($filter("trustedtranslate")("Views.Tasks.Manage.ValidationMessages.TaskDueDateRequired")), "has-error"));
                    }

                    if ((vm.formData.Task.DueDate) && (vm.formData.Task.Status === "Active")) {
                        if (!vm.compareDate(vm.formData.Task.DueDate)) {
                            issues.push(vm.createValidationIssue("Task.DueDate", String($filter("trustedtranslate")("Views.Tasks.Manage.ValidationMessages.TaskDueDateValidation")), "has-error"));
                        }
                    }

                    if ((!vm.formData.Task.AssigneeIds) || (vm.formData.Task.AssigneeIds.length === 0)) {
                        issues.push(vm.createValidationIssue("Task.Assignees", String($filter("trustedtranslate")("Views.Tasks.Manage.ValidationMessages.TaskAssignmentsValidation")), "has-error"));
                    }

                    if (issues.length > 0) {
                        var fieldIssues = [];
                        issues.forEach(function(issue) {
                            var fieldIssueExists = false;
                            fieldIssues.forEach(function(fieldIssue) {
                                if (fieldIssue.field === issue.field) {
                                    fieldIssueExists = true;
                                    fieldIssue.message += ("  " + issue.message);
                                }
                            });
                            if (!fieldIssueExists) {
                                fieldIssues.push(issue);
                            }
                        });

                        vm.infoText = vm.createValidationInfoText(issues);
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true);

                        vm.validationIssues = fieldIssues;
                    } else {
                        vm.formData.Task.Name = vm.formData.Task.Name.trim();
                        vm.formData.Task.Description = vm.formData.Task.Description.trim();
                        if (displayOkMessage || false) {
                            toastr.success(String($filter("trustedtranslate")("Views.Tasks.Manage.ValidationMessages.ValidationOkText")));
                        }
                    }
                };

                vm.getFieldValidationIssue = function(field) {
                    var fieldIssue = vm.createValidationIssue("", "", ""); //Need empty issue - including cssClass
                    if ((vm.validationIssues) && (vm.validationIssues.length > 0)) {
                        for (var i = 0; i < vm.validationIssues.length; i++) {
                            if (vm.validationIssues[i].field === field) {
                                fieldIssue = vm.validationIssues[i];
                                break;
                            }
                        }
                    }
                    5
                    return fieldIssue;
                }

                vm.save = function() {
                    vm.getSelectedAssigneId();
                    vm.validateFormData();
                    if (vm.validationIssues.length === 0) {
                        if (vm.formData.Task.Id) {
                            //Update
                            taskManageApi.update({
                                "taskId": vm.formData.Task.Id,
                                "rowVersion": vm.formData.Task.RowVersion,
                                "status": vm.formData.Task.Status,
                                "name": vm.formData.Task.Name,
                                "description": vm.formData.Task.Description,
                                "dueDate": vm.formData.Task.DueDate,
                                "assigneeIds": vm.formData.Task.AssigneeIds,
                                "comment": "Adding/Updating a new task"
                            }).$promise.then(
                                function() {
                                    vm.showSubmissionResponse(true);
                                }, function(result) {
                                    vm.showSubmissionResponse(false, result.data);
                                });
                        } else {
                            //Create
                            taskManageApi.save({
                                "name": vm.formData.Task.Name,
                                "description": vm.formData.Task.Description,
                                "dueDate": vm.formData.Task.DueDate,
                                "assigneeIds": vm.formData.Task.AssigneeIds,
                                "comment": "Adding/Updating a new task"
                            }).$promise.then(
                                function() {
                                    vm.showSubmissionResponse(true);
                                }, function(result) {
                                    vm.showSubmissionResponse(false, result.data);
                                });
                        }
                    }
                };

                vm.cancel = function() {
                    vm.appCallback('cancel', {});
                };

                vm.showSubmissionResponse = function(success, message) {
                    if (success) {
                        toastr.success(vm.tosterMessage);
                        vm.appCallback('saveOk', {});
                    } else {
                        var issues = [];
                        issues.push(vm.createValidationIssue("", message, "has-error"));
                        vm.infoText = vm.createValidationInfoText(issues);

                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true, true);
                    }
                };
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function(element) {
                return recursionHelper.compile(element);
            }
        }
    }

    angular
        .module('app.tasks.createdTasks.manage')
        .directive('createdTasksManage', createdTasksManage);

    createdTasksManage.$inject = ['$sce', '$filter', '$translate', 'recursionHelper', 'toastr', 'masks', 'taskManageApi', 'taskQueryApi', 'taskAssignmentQueryApi', 'enums'];;
})();

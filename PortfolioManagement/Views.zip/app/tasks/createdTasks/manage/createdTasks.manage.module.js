angular
    .module('app.tasks.createdTasks.manage', []);
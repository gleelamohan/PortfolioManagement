angular
    .module('app.tasks.myTasks', [
       'app.tasks.myTasks.manage'
    ]);
(function () {
    angular
        .module('app.tasks.myTasks.manage')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];

    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('tasks.myTasks.manage', {
                url: "/manage",
                template: '<global-search searchservice="vm.searchService" refreshgrid="vm.refreshGrid"></global-search>',
                controller: "myTaskManageCtrl",
                controllerAs: "vm",
                params: { inputScope: null }
            });
    }
})();
(function () {
    angular
        .module('app.tasks.myTasks.manage')
        .directive('myTaskManage', myTaskManage);

    myTaskManage.$inject = ['$sce', '$filter', '$translate', 'recursionHelper', 'toastr', 'masks', "enums", 'myTaskManageApi', 'taskAssignmentQueryApi'];

    function myTaskManage($sce, $filter, $translate, recursionHelper, toastr, masks, enums, myTaskManageApi, taskAssignmentQueryApi) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                isModal: "@ismodal",
                inputScope: "=inputscope",
                appCallback: "=appcallback",
                infoVisible: "=infovisible",
                infoText: "=infotext",
                infoClass: "=infoclass"
            },
            controller: function($scope, $element, $attrs) {
                var vm = this;

                vm.templateUrl = "/app/tasks/myTasks/manage/myTasks.manage.html";
                vm.isModal = Boolean($scope.isModal || "false");
                vm.inputScope = $scope.inputScope;
                vm.appCallback = $scope.appCallback;
                vm.helpVisible = false;
                vm.okButtonText = String($filter("trustedtranslate")("Common.Maintenance.UpdateButton"));
                vm.helpText = String($filter("trustedtranslate")("Views.TaskAssignments.Manage.HelpText"));
                vm.tosterMessage = String($filter("trustedtranslate")("Views.TaskAssignments.Manage.UpdateOkText"));
                vm.saveDisabled = true;
                vm.formData = {};

                vm.iboxToolsValidationVisible = true;
                vm.statusEnums = enums.TaskAssignmentStatusEnums;

                vm.statusConfig = {
                    "allowDuplicates": false,
                    "placeholder": String($filter("trustedtranslate")("Views.TaskAssignments.Manage.StatusConfig.PlaceHolder")),
                    "optionsValueField": "Value",
                    "optionsLabelField": "Text",
                    "width": "100%"
                };

                if ((vm.inputScope) && (vm.inputScope.Id) && (vm.inputScope.Id.length > 0)) {
                    taskAssignmentQueryApi.getMyTaskById(vm.inputScope.Id).then(function (response) {
                        vm.formData.MyTask = response.results[0];
                        vm.formData.MyTask.AssignedBy = response.results[0].Task_User_UserDetail_FirstName + ' ' + response.results[0].Task_User_UserDetail_LastName;
                        vm.TaskDueDate = moment(vm.formData.MyTask.Task_DueDate).format(masks.date.moment);
                        vm.CreatedOn = moment(moment.utc(vm.formData.MyTask.AssignedOn).toDate()).format(masks.datetime.moment);
                        vm.headerText = String($filter("trustedtranslate")("Views.TaskAssignments.Manage.UpdateStatus"));

                        if (vm.formData.MyTask.Task_Status !== "Active") {
                            vm.disableStatus = true;
                            vm.helpText = String($filter("trustedtranslate")("Views.TaskAssignments.Manage.CancelledOrCompletedTask"));
                            vm.helpVisible = true;
                        } else if (vm.formData.MyTask.Status === "Ignored" || vm.formData.MyTask.Status === "Done") {
                            vm.disableStatus = true;
                        } else {
                            vm.disableStatus = false;
                        }
                    }).catch(function(error) {
                        console.log(error);
                    });
                }

                $scope.$watch('infoVisible', handleInfoVisibleUpdates, true);
                $scope.$watch('infoText', handleInfoTextUpdates, true);
                $scope.$watch('infoClass', handleInfoClassUpdates, true);

                vm.toggleInfoVisibility = function(visible, ignoreModalCheck) {
                    vm.infoVisible = ((!(ignoreModalCheck || false)) && (vm.isModal)) ? false : visible || false;
                    vm.iboxToolsInfoVisible = visible || false;
                    vm.iboxToolsInfoToggledExternally = vm.infoVisible;
                }

                vm.resetInfo = function() {
                    vm.infoText = "";
                    vm.infoClass = "alert alert-info";
                    vm.toggleInfoVisibility(false);
                }

                function handleInfoVisibleUpdates(newData) {
                    vm.toggleInfoVisibility(newData || false);
                };

                function handleInfoTextUpdates(newData) {
                    vm.infoText = newData || "";
                };

                function handleInfoClassUpdates(newData) {
                    vm.infoClass = newData || "alert alert-info";
                };

                //DDBS ibox-tools Settings
                vm.iboxToolsShowHideVisible = vm.isModal === true ? false : true;
                vm.iboxToolsInfoVisible = false;
                vm.iboxToolsInfoToggledExternally = false;

                vm.iboxToolsValidationToggledExternally = false;
                vm.iboxToolsFilterVisible = false;
                vm.iboxToolsSettingsVisible = false;
                vm.iboxToolsHelpVisible = true;
                vm.iboxToolsToggleInfo = function() {
                    vm.infoVisible = !vm.infoVisible;
                };
                vm.iboxToolsToggleFilter = function() {};
                vm.iboxToolsToggleSettings = function() {};
                vm.iboxToolsToggleHelp = function() {
                    vm.helpVisible = !vm.helpVisible;
                };

                vm.validationIssues = [];

                vm.formChanged = function () {
                    vm.saveDisabled = false;
                }

                vm.createValidationIssue = function(field, message, cssClass) {
                    return {
                        "field": field || "",
                        "message": message || "",
                        "cssClass": cssClass || ""
                    };
                }

                vm.createValidationInfoText = function (issues) {
                    var infoText = "";

                    if ((issues) && (issues.length > 0)) {
                        infoText = "<p>" + String($filter("trustedtranslate")("Views.TaskAssignments.Manage.ValidationMessages.StatusUpdateValidationInfoText")) + "</p><ul>";

                        issues.forEach(function (issue) {
                            infoText += ("<li>" + issue.message + "</li>");
                        });

                        infoText += "</ul>";
                    }
                    return infoText;
                }

                vm.validationCallback = function () {
                    vm.validateFormData(true);
                }

                vm.validateFormData = function (displayOkMessage) {
                    vm.resetInfo();
                    vm.validationIssues = [];
                    var issues = [];
                    
                    if (vm.formData.MyTask.Status === null) {
                        issues.push(vm.createValidationIssue("TaskAssignment.Status", String($filter("trustedtranslate")("Views.TaskAssignments.Manage.ValidationMessages.StatusRequired")), "has-error"));
                    }
                          

                    if (issues.length > 0) {
                        var fieldIssues = [];
                        issues.forEach(function (issue) {
                            var fieldIssueExists = false;
                            fieldIssues.forEach(function (fieldIssue) {
                                if (fieldIssue.field === issue.field) {
                                    fieldIssueExists = true;
                                    fieldIssue.message += ("  " + issue.message);
                                }
                            });
                            if (!fieldIssueExists) {
                                fieldIssues.push(issue);
                            }
                        });

                        vm.infoText = vm.createValidationInfoText(issues);
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true);

                        vm.validationIssues = fieldIssues;
                    } else {
                        if (displayOkMessage || false) {
                            toastr.success(String($filter("trustedtranslate")("Views.TaskAssignments.Manage.ValidationMessages.ValidationOkText")));
                        }
                    }
                };

                vm.getFieldValidationIssue = function (field) {
                    var fieldIssue = vm.createValidationIssue("", "", "");  //Need empty issue - including cssClass
                    if ((vm.validationIssues) && (vm.validationIssues.length > 0)) {
                        for (var i = 0; i < vm.validationIssues.length; i++) {
                            if (vm.validationIssues[i].field === field) {
                                fieldIssue = vm.validationIssues[i];
                                break;
                            }
                        }
                    }
                    return fieldIssue;
                }

                vm.save = function () {
                    vm.validateFormData();

                    if (vm.validationIssues.length === 0) {
                        if (vm.formData.MyTask.Id) {
                            //Update
                            myTaskManageApi.update({ taskAssignmentId: vm.formData.MyTask.Id, status: vm.formData.MyTask.Status, comment: "Updating my task assignment status" }).$promise.then(
                            function () {
                                vm.showSubmissionResponse(true);
                            }, function (result) {
                                vm.showSubmissionResponse(false, result.data);
                            });
                        }
                    }
                };

                vm.cancel = function () {
                    vm.appCallback('cancel', {});
                };

                vm.showSubmissionResponse = function (success, message) {
                    if (success) {
                        toastr.success(vm.tosterMessage);
                        vm.appCallback('saveOk', {});
                    } else {
                        var issues = [];
                        issues.push(vm.createValidationIssue("", message, "has-error"));
                        vm.infoText = vm.createValidationInfoText(issues);
                        vm.infoClass = "alert alert-danger";
                        vm.toggleInfoVisibility(true, true);
                    }
                };
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        }
    };
})();

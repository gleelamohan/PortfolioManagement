angular
    .module('app.tasks.myTasks.manage', []);

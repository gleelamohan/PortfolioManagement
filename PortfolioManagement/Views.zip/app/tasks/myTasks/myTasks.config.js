(function () {
    angular
        .module('app.tasks.myTasks')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];

    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('tasks.myTasks', {
                abstract: true,
                url: "/myTasks",
                template: '<ui-view />'
            });
    }
})();
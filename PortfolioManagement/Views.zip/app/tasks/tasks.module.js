angular
    .module('app.tasks', [
          'app.tasks.createdTasks'
        , 'app.tasks.myTasks'        
    ]);
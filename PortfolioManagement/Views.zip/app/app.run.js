(function () {

    function runBlock($rootScope, $state) {
        $rootScope.$state = $state;
    }

    angular
        .module('app')
        .run(runBlock)
        .run(['breeze', function (breeze) { }]);

    runBlock.$inject = ['$rootScope', '$state'];
})();
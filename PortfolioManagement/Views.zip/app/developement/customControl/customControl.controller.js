(function() {
    angular
        .module('app.development.customControl')
        .controller('CustomControlCtrl', CustomControlCtrl);

    CustomControlCtrl.$inject = ['$scope', '$state'];

    function CustomControlCtrl($scope, $state) {
        var vm = this;


        vm.loadEfUigridDemo = function () {
            $state.go("development.efUiGridDemo");
        }

        vm.loadContextUi=function() {
            $state.go("development.contextUiDemo");
        }

        vm.loadContextUI = function () {
            $state.go("development.contextUi");
        }
      
    }

})();


﻿(function () {


    function localDate() {
        return function(input) {
            console.log(input);
            return "Received";
            //return new Date(input).toLocaleString();
        }
    }


    function EfuiGridDemoController($scope, $state, $sanitize, $parse, $filter, $timeout, $compile, $http, $interval, toastr, efLibrary, efEntityApi, efUiGridApi, uiGridConstants, efUiGridConstants, uiGridExporterService, uiGridExporterConstants, efDatetimeMasks) {
        var vm = this;
        vm.rows = 100;

        //C:\EurofinsCollection\eLIMS-BPT\Phase 1\Eurofins.Helium\Eurofins.Helium.UI\app\sampleRegistration\incomingParcel\pendingParcels\incomingParcel.pendingParcelsList.directive.js
        function updateFilterVisibility() {
            $(".ui-grid-filter-input").css("display", vm.filterVisible ? "" : "none");

            //if (vm.filterVisible === false) {
            //    vm.gridOptions.enableFiltering = false;
            //    vm.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
            //}


            //if (vm.filterVisible === true) {
            //    vm.gridOptions.enableFiltering = true;
            //    vm.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
            //}
        }


        //vm.filterVisible = false;
        vm.toggleFiltering = function () {
            vm.filterVisible = !vm.filterVisible;
            if (vm.gridApi !== undefined && vm.gridApi !== null) {
                vm.gridApi.core.clearAllFilters();
            }
            updateFilterVisibility();
            //vm.gridOptions.enableFiltering = !vm.gridOptions.enableFiltering;
            //vm.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
            //$scope.pendingParcelsGridApi.core.clearAllFilters();
           
        }


        function populateGridData(rows) {
            vm.originalTreeModel = [];
            for (var x = 1; x < rows; x++) {
                var project = "DDBS - " + x;
                var name = "Niranjan  Niranjan    Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  Niranjan  - " + x * 2;
                var dat = new Date();
                dat.setDate(dat.getDate() + x);
                var data = { "project": project, "id": x, "name": name, "enddate" : dat }
                vm.originalTreeModel.push(data);
            }
        }

        vm.loadEfUigridDemo = function () {

            //var grid = efLibrary.copyObject(efUiGridApi.defaultGridConfig, true);

            //var columnOrderNumber = efUiGridApi.getColumnDef("id", "id", "id", true, uiGridConstants.ASC, false);
            //columnOrderNumber.headerCellClass = "uiGrid_Column_Center";
            //columnOrderNumber.headerCellTemplate = "#";
            //columnOrderNumber.headerTooltip = true;
            //columnOrderNumber.cellClass = "uiGrid_Column_Center";
            //columnOrderNumber.enableColumnMenu = true;
            //columnOrderNumber.enableColumnMoving = true;
            //columnOrderNumber.enableColumnResizing = false;
            //columnOrderNumber.width = "60";
            //columnOrderNumber.minWidth = "60";
            //grid.columnDefs.push(columnOrderNumber);


            //var columnProject = efUiGridApi.getColumnDef("project", "project", "project", false, null, true);
            ////columnProject.cellFilter = "efLookupValue: 'vm.taskTemplateNameSelectConfig.options':'value':'label':this";
            //columnProject.enableColumnMenu = true;
            //columnProject.enableHiding = true;
            //columnProject.enableColumnMoving = true;
            //columnProject.width = "*";   //Auto width = "*" or ""
            //columnProject.minWidth = "300";
            //grid.columnDefs.push(columnProject);


            //var columnName = efUiGridApi.getColumnDef("name", "name", "name", false, null, true);
            ////columnName.cellFilter = "efLookupValue: 'vm.taskTemplateNameSelectConfig.options':'value':'label':this";
            //columnName.enableColumnMenu = true;
            //columnName.enableHiding = true;
            //columnName.enableColumnMoving = true;
            //columnName.width = "*";   //Auto width = "*" or ""
            //columnName.minWidth = "300";
            //grid.columnDefs.push(columnName);


            //var displayGridActionConfig = efUiGridApi.getActionColumnsConfig("efuigridDemo1", vm.taskTemplatesIdField);
            ////DEVELOPER NOTE - If your table has multiple linkOut buttons, you will need to create a seperate Action Columns Config for each linkOut!!
            //displayGridActionConfig.linkOut.displayAction = true;
            //displayGridActionConfig.linkOut.callback = "vm.linkOutCallback";



            ////grid.columnDefs.push(efUiGridApi.getActionColumnDef(efUiGridConstants.actionColumns.LINKOUT, displayGridActionConfig, "id"));

            //vm.gridOptions = grid;
            //alert('Hello');
            //vm.gridData = JSON.parse(JSON.stringify(vm.originalTreeModel));
            $timeout(updateFilterVisibility);
            populateGridData(vm.rows);
            vm.gridData = vm.originalTreeModel; //JSON.parse(JSON.stringify(vm.originalTreeModel));
            //if (vm.gridApi !== undefined && vm.gridApi!==null) {
            //    vm.gridApi.core.on.columnVisibilityChanged($scope, function (column) {
            //        column.filterHeaderTemplate = null;
            //        //column.filter
            //        //updateFilterVisibility();
            //    });
            //}
        }

        vm.linkOutCallback = function (id) {

            toastr.info("vm.linkOutCallback() was called for id: " + id);

        }

        vm.deleteCallback = function (id) {

            toastr.info("vm.deleteCallback() was called for id: " + id);

        }

       

  
        vm.gridApi = null;
        

        vm.gridOptions=efLibrary.copyObject(efUiGridApi.defaultGridConfig, true);
        vm.gridOptions.enableGridMenu = true;
        vm.gridOptions.enableFiltering = true;
        vm.gridOptions.enableSelectAll = true;
        //vm.gridOptions.exporterMenuCsv = false;
        vm.gridOptions.exporterMenuPdf = false;
        vm.gridOptions.exporterCsvFilename = 'ddbs-lims-export.csv';
        vm.gridOptions.exporterPdfDefaultStyle = { fontSize: 9 };
        vm.gridOptions.exporterPdfTableStyle = { margin: [20, 20, 20, 20] };
        vm.gridOptions.exporterPdfTableHeaderStyle = { fontSize: 10, bold: true, italics: true, color: 'red' };
        vm.gridOptions.exporterPdfHeader = { text: "DDBS-LIMS", style: 'headerStyle' };
            vm.gridOptions.exporterPdfFooter = function(currentPage, pageCount) {
                return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            };
            vm.gridOptions.exporterPdfCustomFormatter = function(docDefinition) {
                docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                return docDefinition;
            };
        vm.gridOptions.exporterPdfOrientation = 'portrait';
        vm.gridOptions.exporterPdfPageSize = 'LETTER';
        vm.gridOptions.exporterPdfMaxGridWidth = 450;
        vm.gridOptions.exporterCsvLinkElement = angular.element(document.querySelectorAll(".custom-csv-link-location"));

        var columnProjectId = efUiGridApi.getColumnDef("id", "id", "id", true, uiGridConstants.ASC, false);
        columnProjectId.enableColumnMenu = false;
        columnProjectId.enableHiding = false;
        columnProjectId.enableColumnMoving = false;
        columnProjectId.enableColumnResizing = false;
        columnProjectId.enableSorting = true;
       //columnProjectId.headerTooltip = true;
        //columnProjectId.filterCellFiltered = true;
        //columnProjectId.enableFiltering = true;
        //columnProjectId.headerCellClass = "uiGrid_Column_Center";
        columnProjectId.cellClass = "uiGrid_Column_Center";
        columnProjectId.width = "*";
        columnProjectId.minWidth = "10";
        columnProjectId.orderCellClass = "<div class='ui-grid-cell-contents ui-grid-cell-contents-word-wrap' ><a ef-click=\"vm.linkOutCallback('{{row.entity.id}}')\" >{{row.entity.id}}<a></div>";
        vm.gridOptions.columnDefs.push(columnProjectId);

        var columnProjectName = efUiGridApi.getColumnDef("project", "project", "project", true, uiGridConstants.ASC, false);
        columnProjectName.enableColumnMenu = true;
        columnProjectName.enableHiding = true;
        columnProjectName.enableColumnMoving = true;
        columnProjectName.enableSorting = true;
        //columnProjectName.headerTooltip = true;
        //columnProjectName.enableFiltering = true;
        columnProjectName.width = "25%";
        columnProjectName.minWidth = "100";
        vm.gridOptions.columnDefs.push(columnProjectName);

        var columnProjectManager = efUiGridApi.getColumnDef("name", "name", "name", true, uiGridConstants.ASC, false);
        columnProjectManager.enableColumnMenu = true;
        columnProjectManager.enableHiding = true;
        columnProjectManager.enableColumnMoving = true;
        //columnProjectManager.enableFiltering = true;
        //columnProjectManager.enableSorting = true;
        //columnProjectManager.suppressRemoveSort= true,
        //columnProjectManager.headerTooltip = true;
        columnProjectManager.cellTooltip = true;
        columnProjectManager.width = "25%";
        columnProjectManager.minWidth = "100";
        vm.gridOptions.columnDefs.push(columnProjectManager);


        var columnProjectEndDate = efUiGridApi.getColumnDef("enddate", "enddate", "enddate", true, uiGridConstants.ASC, false);
        columnProjectEndDate.enableColumnMenu = true;
        columnProjectEndDate.cellFilter = "date: '" + efDatetimeMasks.datetime.angular + "'";
        columnProjectEndDate.enableHiding = true;
        columnProjectEndDate.enableColumnMoving = true;
        //columnProjectManager.enableFiltering = true;
        //columnProjectManager.enableSorting = true;
        //columnProjectManager.suppressRemoveSort= true,
        //columnProjectEndDate.headerTooltip = true;
        columnProjectEndDate.cellTooltip = true;
        columnProjectEndDate.width = "25%";
        columnProjectEndDate.minWidth = "100";
        vm.gridOptions.columnDefs.push(columnProjectEndDate);


        //registrationPhase.cellTemplate = "<div class='ui-grid-cell-contents ui-grid-cell-contents-word-wrap' >{{service.parcelPhaseCallback()}}</div>";
        //    registrationPhase.cellFilter = 'localDate';
        //    registrationPhase.filter = {
        //condition: uiGridConstants.filter.STARTS_WITH,
        //placeholder: 'starts with'
    



        //vm.gridOptions.columnDefs = [
                //{
                //    name: 'id',
                //    field: 'id',
                //    displayName: 'id',
                //    headerTooltip: false,
                //    cellTooltip: false,
                //    enableColumnMenu: false,
                //    enableFiltering: false,
                //    enableHiding: false,
                //    enableSorting: false,
                //    suppressRemoveSort: true,
                //    allowCellFocus: true,
                //    visible: false,
                //    width: '0%'
                //},
                //{
                //    name: 'project',
                //    field: 'project',
                //    displayName: 'Project',
                //    headerTooltip: false,
                //    cellTooltip: false,
                //    enableColumnMenu: false,
                //    enableFiltering: false,
                //    enableHiding: false,
                //    enableSorting: false,
                //    suppressRemoveSort: true,
                //    allowCellFocus: true,
                //    visible: true,
                //    width: '20%'
                //},
                //{
                //    name: 'name',
                //    field: 'name',
                //    displayName: 'Name',
                //    headerTooltip: true,
                //    cellTooltip: true,
                //    enableColumnMenu: true,
                //    enableFiltering: true,
                //    enableHiding: true,
                //    enableSorting: true,
                //    suppressRemoveSort: true,
                //    allowCellFocus: true,
                //    visible: true,
                //    width: '*'
                //}
            //];
        //DEVELOPER NOTE - If your table has multiple linkOut buttons, you will need to create a seperate Action Columns Config for each linkOut!!




        var editGridActionConfig = efUiGridApi.getActionColumnsConfig("efuigridDemo1", "id");
        editGridActionConfig.linkOut.displayAction = true;
        editGridActionConfig.linkOut.callback = "vm.linkOutCallback";
        var colEdit = efUiGridApi.getActionColumnDef(efUiGridConstants.actionColumns.LINKOUT, editGridActionConfig, "id");
        colEdit.enableFiltering = false;
        colEdit.exporterSuppressExport = true;
        colEdit.name = "Edit";

        var deleteGridActionConfig = efUiGridApi.getActionColumnsConfig("efuigridDemo1", "id");
        deleteGridActionConfig.linkOut.displayAction = true;
        deleteGridActionConfig.linkOut.callback = "vm.deleteCallback";
        deleteGridActionConfig.linkOut.alternateLabel = "<i class=\"fa fa-trash-o\"></i>";
        var colDelete = efUiGridApi.getActionColumnDef(efUiGridConstants.actionColumns.LINKOUT, deleteGridActionConfig, "id");
        colDelete.enableFiltering = false;
        colDelete.exporterSuppressExport = true;
        colDelete.name = "Delete";

        vm.gridOptions.columnDefs.push(colEdit);
        vm.gridOptions.columnDefs.push(colDelete);

        vm.loadEfUigridDemo();
        
        vm.selectedCallback = function () {
          
        }

        
        vm.exportToCsv = function () {
            var myElement = angular.element(document.querySelectorAll(".custom-csv-link-location"));
            vm.gridApi.exporter.csvExport(uiGridExporterConstants.ALL, uiGridExporterConstants.ALL, myElement);
        };

        vm.exportVisibleToCsv = function () {
            var myElement = angular.element(document.querySelectorAll(".custom-csv-link-location"));
            vm.gridApi.exporter.csvExport(uiGridExporterConstants.VISIBLE, uiGridExporterConstants.ALL, myElement);
        };



        vm.exportToPdf = function () {
            var myElement = angular.element(document.querySelectorAll(".custom-csv-link-location"));
            vm.gridApi.exporter.pdfExport(uiGridExporterConstants.ALL, uiGridExporterConstants.ALL, myElement);
        };

        vm.exportVisibleToPdf = function () {
            var myElement = angular.element(document.querySelectorAll(".custom-csv-link-location"));
            vm.gridApi.exporter.pdfExport(uiGridExporterConstants.VISIBLE, uiGridExporterConstants.ALL, myElement);
        };

       

        ////Original copy of data
        //vm.originalTreeModel = [
        //    {"label": "Batch2", "id": "33", "name": "niranjan1"},
        //    { "label": "Batch3", "id": "29", "name" : "niranjan2"}
        //];

        //vm.selectedCallback = function () {
        //    if (vm.gridSelected && vm.gridSelected.length > 0) {
        //        var result = $.grep(vm.treeModel, function (e) { return e.label.indexOf('Batch') == 0 && e.id == vm.gridSelected[0]; });
        //        if (result.length > 0) {
        //            $("#example2log").append('row ' + result[0].label + ', id: ' + result[0].id + ', was selected in the grid.' + "<br />");
        //            vm.selectNode2(result[0], true, true);
        //            $scope.$apply();
        //        }
        //    } else {
        //        vm.selectedNode2 = undefined;
        //    }
        //}

        //vm.gridApi.core.on.columnVisibilityChanged($scope, function (column) {
        //    // do something
        //});
       

    }

       angular
        .module('app.development.customControl')
        .controller('EfuiGridDemoController', EfuiGridDemoController)
        .filter('localDate', localDate);

    EfuiGridDemoController.$inject = ['$scope', '$state', '$sanitize', '$parse', '$filter', '$timeout', '$compile', '$http', '$interval', 'toastr', 'efLibrary', 'efEntityApi', 'efUiGridApi', 'uiGridConstants', 'efUiGridConstants', 'uiGridExporterService', 'uiGridExporterConstants', 'efDatetimeMasks'];


})();


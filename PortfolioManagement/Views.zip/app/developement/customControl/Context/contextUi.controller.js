﻿

(function () {
    angular
        .module('app.development.customControl')
        .controller('ContextUiController', ContextUiController);

    ContextUiController.$inject = ['$scope', '$state', '$sanitize', '$parse', '$filter', '$timeout', '$compile', '$http', '$interval', 'toastr', 'efLibrary', 'efEntityApi', 'efUiGridApi', 'uiGridConstants', 'efUiGridConstants', 'uiGridExporterService', 'uiGridExporterConstants', 'efDatetimeMasks'];

    function ContextUiController($scope, $state, $sanitize, $parse, $filter, $timeout, $compile, $http, $interval, toastr, efLibrary, efEntityApi, efUiGridApi, uiGridConstants, efUiGridConstants, uiGridExporterService, uiGridExporterConstants, efDatetimeMasks) {
        var vm = this;


        vm.showhidevisible = true;
        vm.showcontent = true;
        vm.contentdisabled = false;



        vm.iboxToolsShowHideVisible = true;
        vm.iboxToolsShowHideVisible1 = true;
        vm.showContent = true;
        vm.showContent1 = true;

        vm.toggleShowHide = function () {
            console.log("hi");
        }

    }

})();


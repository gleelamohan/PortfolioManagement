(function () {
    angular
        .module('app.development.customControl')
        .config(config);
    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];
    function config($stateProvider, $urlRouterProvider, $httpProvider) {
        $httpProvider.defaults.withCredentials = true;
        $httpProvider.defaults.useXDomain = true;
        $urlRouterProvider.otherwise("/");
        $stateProvider
            .state('development.customControl', {
                url: "/customControl",
                templateUrl: "/app/developement/customControl/customControl.html",
                controller: "CustomControlCtrl",
                controllerAs: "vm"
            }).state('development.efUiGridDemo', {
                url: "/efUiGridDemo",
                templateUrl: "/app/developement/customControl/efUiGridDemo/efUiGridDemo.html",
                controller: "EfuiGridDemoController",
                controllerAs: "vm"
            }).state('development.contextUiDemo', {
                url: "/contextUiDemo",
                templateUrl: "/app/developement/customControl/ContextUI/contextUiDemo.html",
                controller: "ContextUiDemoController",
                controllerAs: "vm"
            }).state('development.contextUi', {
                url: "/context",
                templateUrl: "/app/developement/customControl/ContextUI/contextUiDemo.html",
                controller: "ContextUiController",
                controllerAs: "vm"
            });

        
    }
})();


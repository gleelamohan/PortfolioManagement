(function () {
    function GenericQueryCtrl($scope, $state, toastr, datacontext) {
        var vm = this;
        vm.entities = [];
        vm.fields = [];
        vm.field = "";
        vm.condition = "";
        vm.keyword = "";
        vm.collection = "";
        vm.entity = "";       

        var errorLogger = function () {
            toastr.error("Error occurred! Please check your query expression.");
        };

        vm.getData = function (pageSize, page) {
            setTimeout(function () {
                var query = "";

                if (vm.collection.trim().length === 0) {
                    toastr.error("Please specify a collection you want to query.");
                    return;
                }

                if (vm.entity.trim().length === 0) {
                    toastr.error("Please specify an entity type you want to query.");
                    return;
                }

                ////if (vm.expand.trim().length === 0) {
                ////    toastr.error("Please specify an entity type you want to query.");
                ////    return;
                ////}

                var skipCount = vm.pagingOptions.currentPage * vm.pagingOptions.pageSize - vm.pagingOptions.pageSize;
                if (vm.field.trim().length !== 0 && vm.condition.trim().length !== 0 && vm.keyword.trim().length !== 0) {
                    query = breeze.EntityQuery.from(vm.collection.trim()).skip(skipCount).take(vm.pagingOptions.pageSize).where(vm.field.trim(), vm.condition.trim(), vm.keyword.trim());
                } else {
                    query = breeze.EntityQuery.from(vm.collection.trim()).skip(skipCount).take(vm.pagingOptions.pageSize);
                }

                if (vm.select) {
                    query = query.select(vm.select);
                }

                if (vm.expand) {
                    query = query.expand(vm.expand);
                }

                datacontext.executeQuery(query).then(function (data) {
                        vm.fields = [];
                        datacontext.metadataStore.getEntityType(vm.entity.trim()).dataProperties.forEach(function(field) {
                            vm.fields.push({ "field": field.name });
                        });
                    vm.entities = data.results;
                })
                    .catch(errorLogger);
            }, 100);
        }

        vm.filterOptions = {
            filterText: "",
            useExternalFilter: false
        };

        vm.totalServerItems = 10000;
        vm.pagingOptions = {
            pageSizes: [1000,2000, 5000],
            pageSize: 1000,
            currentPage: 1
        };

        $scope.$watch('vm.pagingOptions', function (newVal, oldVal) {
            if (newVal !== oldVal && newVal.currentPage !== oldVal.currentPage) {
                vm.getData(vm.pagingOptions.pageSize, vm.pagingOptions.currentPage);
            }
        }, true);

        vm.gridOptions = {
            data: 'vm.entities',
            columnDefs: 'vm.fields',
            showGroupPanel: true,
            enablePaging: true,
            showFooter: true,
            pagingOptions: vm.pagingOptions
        };
    }

    angular
        .module('app.development.breezeDemo')
        .controller('GenericQueryCtrl', GenericQueryCtrl);

    GenericQueryCtrl.$inject = ['$scope', '$state', 'toastr', 'datacontext'];
})();


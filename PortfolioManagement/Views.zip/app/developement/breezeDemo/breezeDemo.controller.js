(function() {
    angular
        .module('app.development.breezeDemo')
        .controller('BreezeDemoCtrl', BreezeDemoCtrl);

    BreezeDemoCtrl.$inject = ['$scope', '$state'];

    function BreezeDemoCtrl($scope, $state) {
        var vm = this;

        vm.auditLogs = function () {
            $state.go("development.auditLogsQuery");
        }

        vm.auditLogDetails = function () {
            $state.go("development.auditLogDetailsQuery");
        }

        vm.tasks = function () {
            $state.go("development.taskQuery");
        }

        vm.notifications = function () {
            $state.go("development.notificationQuery");
        }

        vm.genericQuery = function () {
            $state.go("development.genericQuery");
        }
    }

})();


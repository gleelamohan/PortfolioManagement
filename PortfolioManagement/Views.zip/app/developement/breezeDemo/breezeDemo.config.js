(function() {
    angular
        .module('app.development.breezeDemo')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];

    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;
        $httpProvider.defaults.useXDomain = true;
        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('development.breezeDemo', {
                url: "/breezeDemo",
                templateUrl: "/app/developement/breezeDemo/breezeDemo.html",
                controller: "BreezeDemoCtrl",
                controllerAs: "vm"
            })
            ////.state('development.auditLogsQuery', {
            ////    url: "/auditLogsQuery",
            ////    templateUrl: "/app/developement/breezeDemo/auditLogsQuery/auditLogsQuery.html",
            ////    controller: "AuditLogsQueryCtrl",
            ////    controllerAs: "vm"
            ////})
            ////.state('development.auditLogDetailsQuery', {
            ////    url: "/auditLogDetailsQuery",
            ////    templateUrl: "/app/developement/breezeDemo/auditLogDetailsQuery/auditLogDetailsQuery.html",
            ////    controller: "AuditLogDetailsQueryCtrl",
            ////    controllerAs: "vm"
            ////})
            ////.state('development.taskQuery', {
            ////    url: "/taskQuery",
            ////    templateUrl: "/app/developement/breezeDemo/taskQuery/taskQuery.html",
            ////    controller: "TaskQueryCtrl",
            ////    controllerAs: "vm"
            ////})
            ////.state('development.notificationQuery', {
            ////    url: "/notificationQuery",
            ////    templateUrl: "/app/developement/breezeDemo/notificationQuery/notificationQuery.html",
            ////    controller: "NotificationQueryCtrl",
            ////    controllerAs: "vm"
            ////})
            .state('development.genericQuery', {
                url: "/genericQuery",
                templateUrl: "/app/developement/breezeDemo/genericQuery/genericQuery.html",
                controller: "GenericQueryCtrl",
                controllerAs: "vm"
            });
    }
})();


angular
    .module('app.development.breezeDemo', []);
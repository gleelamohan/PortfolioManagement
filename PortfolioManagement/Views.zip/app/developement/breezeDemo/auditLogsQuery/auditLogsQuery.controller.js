(function () {
    angular
        .module('app.development.breezeDemo')
        .controller('AuditLogsQueryCtrl', AuditLogsQueryCtrl);

    AuditLogsQueryCtrl.$inject = ['$scope', '$state', 'toastr', 'queryServiceUrl'];

    function AuditLogsQueryCtrl($scope, $state, toastr, queryServiceUrl) {
        var vm = this;
        vm.entities =[];
        vm.fields = [];
        vm.field = "";
        vm.condition = "";
        vm.keyword = "";
        vm.collection = "";
        vm.entity = "";

        vm.em = new breeze.EntityManager(queryServiceUrl);

        var errorLogger = function() {
            vm.result = "Error occurred! Please check your query expression.";
        };

        vm.getData = function() {
            var query = "";

            if (vm.collection.trim().length === 0) {
                toastr.error("Please specify a collection you want to query.");
                return;
            }

            if (vm.entity.trim().length === 0) {
                toastr.error("Please specify an entity type you want to query.");
                return;
            }

            if (vm.field.trim().length !== 0 && vm.condition.trim().length !== 0 && vm.keyword.trim().length !== 0) {
                query = breeze.EntityQuery.from(vm.collection.trim()).where(vm.field.trim(), vm.condition.trim(), vm.keyword.trim());
            } else {
                query = breeze.EntityQuery.from(vm.collection.trim());
            }

            vm.em.executeQuery(query).then(function(data) {
                    vm.fields = vm.em.metadataStore.getEntityType(vm.entity.trim()).dataProperties;
                    vm.entities = data.results;
                })
                .catch(errorLogger);
        }
    }
})();


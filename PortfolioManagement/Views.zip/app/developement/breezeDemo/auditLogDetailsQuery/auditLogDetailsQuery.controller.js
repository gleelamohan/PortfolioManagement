(function () {
    angular
        .module('app.development.breezeDemo')
        .controller('AuditLogDetailsQueryCtrl', AuditLogDetailsQueryCtrl);

    AuditLogDetailsQueryCtrl.$inject = ['$scope', '$state', 'breezeAuditUrl'];

    function AuditLogDetailsQueryCtrl($scope, $state, breezeAuditUrl) {
        var vm = this;
        vm.em = new breeze.EntityManager(breezeAuditUrl);

        var errorLogger = function () {
            vm.result = "Error occurred! Please check your query expression.";
        };

        vm.getData = function () {
            var collection = vm.collection;
            var predicate = vm.predicate;
            var query = "";

            if (collection === null || collection === undefined) {
                vm.result = "Please specify a collection you want to query.";
                return;
            }

            if (predicate !== null && predicate !== undefined && predicate.trim().length > 0) {
                query = breeze.EntityQuery.from(collection);
            } else {
                query = breeze.EntityQuery.from(collection).where(predicate.trim());
            }

            vm.em.executeQuery(query).then(function (data) {
                vm.result = data.results;
            })
                .catch(errorLogger);
        }

        vm.gridOptions = { data: 'vm.result' };
    }

})();


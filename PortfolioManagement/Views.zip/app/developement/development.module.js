angular
    .module('app.development', ['app.development.chartAndGraph', 'app.development.customControl', 'app.development.printAndExport', 'app.development.breezeDemo']);
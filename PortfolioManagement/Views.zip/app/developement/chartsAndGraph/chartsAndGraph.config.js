(function () {
    angular
        .module('app.development.chartAndGraph')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];

    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;
        $httpProvider.defaults.useXDomain = true;
        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('development.chartAndGraph', {
                url: "/chartAndGraph",
                templateUrl: "/app/developement/chartsAndGraph/chartsAndGraphBase.html",
                controller: "ChartAndGraphCtrl",
                controllerAs: "vm"
            })
            .state('development.performanceMonitor', {
                url: "/performanceMonitor",
                templateUrl: "/app/developement/chartsAndGraph/performanceMonitor.html",
                controller: "PerformanceMonitorCtrl",
                controllerAs: "vm"
            })
            .state('development.lineChart', {
                url: "/lineChart",
                templateUrl: "/app/developement/chartsAndGraph/lineChart.html",
                controller: "LineChartCtrl",
                controllerAs: "vm"
            })
            .state('development.loadingAnimations', {
                url: "/loadingAnimations",
                templateUrl: "/app/developement/chartsAndGraph/loadingAnimations.html",
                controller: "LoadingAnimationsCtrl",
                controllerAs: "vm"
        });
    }
})();


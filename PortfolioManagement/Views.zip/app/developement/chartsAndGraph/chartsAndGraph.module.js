angular
    .module('app.development.chartAndGraph', []);
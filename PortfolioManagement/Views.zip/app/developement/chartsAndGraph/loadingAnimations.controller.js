(function () {
    angular
        .module('app.development.chartAndGraph')
        .controller('LoadingAnimationsCtrl', LoadingAnimationsCtrl);

    LoadingAnimationsCtrl.$inject = ['$scope'];

    function LoadingAnimationsCtrl($scope) {
        var vm = this;
    }

})();


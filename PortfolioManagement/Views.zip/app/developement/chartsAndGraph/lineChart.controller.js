(function () {
    angular
        .module('app.development.chartAndGraph')
        .controller('LineChartCtrl', LineChartCtrl);


    LineChartCtrl.$inject = ['$timeout'];
    function LineChartCtrl($timeout) {

        var vm = this;
        vm.Track = false;
        vm.flotChartData = [
            {
                label: "Temperature",
                data: [
                    [1, 34],
                    [2, 25],
                    [3, 19],
                    [4, 34],
                    [5, 32],
                    [6, 94],
                    [7, 4],
                    [8, 74],
                    [9, 14],
                    [10, 54],
                    [11, 64],
                    [12, 12],
                    [13, 104]
                ]
            }
        ];


        vm.flotLineOptions = {
            series: {
                lines: {
                    show: true,
                    lineWidth: 2,
                    fill: true,
                    fillColor: {
                        colors: [
                            {
                                opacity: 0.0
                            },
                            {
                                opacity: 0.0
                            }
                        ]
                    }
                }
            },
            xaxis: {
                tickDecimals: 0
            },
            colors: ["#1ab394"],
            grid: {
                color: "#999999",
                hoverable: true,
                clickable: true,
                tickColor: "#D4D4D4",
                borderWidth: 0
            },
            legend: {
                show: false
            },
            tooltip: true,
            tooltipOpts: {
                content: "x: %x, y: %y"
            }
        };


        var interval = 1000;
        vm.flotChartDataLive = [
            {
                label: "Temp",
                data: [
                    [1, 34],
                    [2, 25],
                    [3, 19],
                    [4, 34],
                    [5, 32],
                    [6, 94],
                    [7, 4],
                    [8, 74],
                    [9, 14],
                    [10, 54],
                    [11, 64],
                    [12, 12],
                    [13, 104]
                ]
            }
        ];

        var x = 13;
        var y = 50;

        var xctr = 1;
        var yctr = 10;

        var getTemparature = function() {
            x = x + xctr;
            y = y + yctr;
            yctr = yctr + 5;
            if (y > 100) {
                yctr = 5;
                y = 10;
            }
            if (x > 60) {
                x = 1;
                vm.flotChartDataLive[0].data = [];
            }
            var d = [x, y];

            vm.flotChartDataLive[0].data.push(d);
            //vm.flotChartDataLive[0].data.splice(0, 1);
            if (vm.Track) {
                $timeout(getTemparature, interval);
            }
        }

       
        vm.trackChanged = function() {
            getTemparature();
        }

        vm.flotLineOptionsLive = {
            series: {
                lines: {
                    show: true,
                    lineWidth: 2,
                    fill: true,
                    fillColor: {
                        colors: [
                            {
                                opacity: 0.0
                            },
                            {
                                opacity: 0.0
                            }
                        ]
                    }
                },
                points: {
                    show: true,
                    fill: true,
                    radius: 3,
                    fillColor: "#dc143c"
                }

            },
            xaxis: {
                tickDecimals: 0,
                min: 0,
                max: 60,
                color: "#800000",
                ticks: [0, 60],
                font: {
                    size: 11,
                    lineHeight: 13,
                    style: "italic",
                    weight: "bold",
                    family: "sans-serif",
                    variant: "small-caps",
                    color: "#800000"
                }
            },
            colors: ["#1ab394"],
            grid: {
                color: "#999999",
                hoverable: true,
                clickable: true,
                tickColor: "#D4D4D4",
                borderWidth: 0
            },
            legend: {
                show: true
            },
            tooltip: true,
            tooltipOpts: {
                content: "x: %x, y: %y"
            }
        };

        vm.TimeDuration = 2;
        vm.Intervarl = 1;
        vm.Track = false;

     


        vm.flotChartDataT = [
         {
             label: "Temp",
             data: [[1441391750790, 58], [1441391751790, 95], [1441391752790, 78], [1441391753790, 69], [1441391754790, 8], [1441391755790, 95], [1441391756790, 100], [1441391757790, 90], [1441391758790, 87], [1441391759790, 59], [1441391760790, 56], [1441391761790, 57], [1441391762790, 38], [1441391763790, 40], [1441391764790, 26], [1441391765790, 77], [1441391766790, 66], [1441391767790, 19], [1441391768790, 71], [1441391769790, 23], [1441391770790, 34], [1441391771790, 13], [1441391772790, 56], [1441391773790, 75], [1441391774790, 21], [1441391775790, 79], [1441391776790, 43], [1441391777790, 97], [1441391778790, 48], [1441391779790, 69], [1441391780790, 66], [1441391781790, 35], [1441391782790, 27], [1441391783790, 77], [1441391784790, 54], [1441391785790, 13], [1441391786790, 25], [1441391787790, 71], [1441391788790, 4], [1441391789790, 78], [1441391790790, 35], [1441391791790, 9], [1441391792790, 56], [1441391793790, 90], [1441391794790, 56], [1441391795790, 74], [1441391796790, 93], [1441391797790, 16], [1441391798790, 20], [1441391799790, 5], [1441391800790, 6], [1441391801790, 45], [1441391802790, 73], [1441391803790, 12], [1441391804790, 75], [1441391805790, 88], [1441391806790, 36], [1441391807790, 50], [1441391808790, 17], [1441391809790, 28], [1441391810790, 48], [1441391811790, 89], [1441391812790, 85], [1441391813790, 99], [1441391814790, 39], [1441391815790, 84], [1441391816790, 5], [1441391817790, 29], [1441391818790, 9], [1441391819790, 29], [1441391820790, 58], [1441391821790, 39], [1441391822790, 19], [1441391823790, 42], [1441391824790, 60], [1441391825790, 4], [1441391826790, 79], [1441391827790, 42], [1441391828790, 93], [1441391829790, 28], [1441391830790, 52], [1441391831790, 97], [1441391832790, 82], [1441391833790, 14], [1441391834790, 19], [1441391835790, 2], [1441391836790, 54], [1441391837790, 16], [1441391838790, 55], [1441391839790, 19], [1441391840790, 45], [1441391841790, 80], [1441391842790, 14], [1441391843790, 43], [1441391844790, 53], [1441391845790, 14], [1441391846790, 21], [1441391847790, 80], [1441391848790, 96], [1441391849790, 99], [1441391850790, 35], [1441391851790, 34], [1441391852790, 61], [1441391853790, 63], [1441391854790, 52], [1441391855790, 53], [1441391856790, 99], [1441391857790, 61], [1441391858790, 77], [1441391859790, 73], [1441391860790, 50], [1441391861790, 52], [1441391862790, 24], [1441391863790, 85], [1441391864790, 68], [1441391865790, 81], [1441391866790, 45], [1441391867790, 17], [1441391868790, 34], [1441391869790, 32]]
         }
        ];



        function substractMinutes(date, minutes) {
            return new Date(date.getTime() - minutes * 60000);
        }

        vm.maxX = 1441391750790;
        vm.minX = 1441391869790;

        vm.timeSeries = function () {
            vm.temperData = [];
            var maxDate = new Date();
            var minDate = substractMinutes(maxDate, vm.TimeDuration);
            vm.maxX = maxDate.getTime();
            vm.minX = minDate.getTime();

            var seriesLength = vm.TimeDuration * 60;
            var x, y;
            x = vm.minX;
            for (var ctr = 0; ctr < seriesLength; ctr++) {
                x = x + 1000;
                y = Math.floor((Math.random() * 100) + 1);
                vm.temperData.push([x, y]);
            }

            vm.flotLineOptionsT.xaxis.ticks = [vm.minX, vm.maxX];
            vm.flotLineOptionsT.xaxis.min = vm.minX;
            vm.flotLineOptionsT.xaxis.max = vm.maxX;
            vm.flotChartDataT[0].data = vm.temperData;


            //alert((new Date()).getTime());
            //getTemparature();
        }



        //vm.timeSeries();

        //vm.flotChartData = [
        //  {
        //      label: "Temp",
        //      data: [temperData]
        //  }
        //];


        vm.flotLineOptionsT = {
            series: {
                lines: {
                    show: true,
                    lineWidth: 2,
                    fill: true,
                    fillColor: {
                        colors: [
                            {
                                opacity: 0.0
                            },
                            {
                                opacity: 0.0
                            }
                        ]
                    }
                },
                points: {
                    show: true,
                    fill: true,
                    radius: 3,
                    fillColor: "#dc143c"
                }

            },
            xaxis: {
                tickDecimals: 0,
                min: 1441391750790,
                max: 1441391869790,
                mode: "time",
                timeformat: "%H:%M:%S",
                color: "#800000",
                ticks: [1441391750790, 1441391869790],
                font: {
                    size: 11,
                    lineHeight: 13,
                    style: "italic",
                    weight: "bold",
                    family: "sans-serif",
                    variant: "small-caps",
                    color: "#800000"
                }
            },
            colors: ["#1ab394"],
            grid: {
                color: "#999999",
                hoverable: true,
                clickable: true,
                tickColor: "#D4D4D4",
                borderWidth: 0
            },
            legend: {
                show: true
            },
            tooltip: true,
            tooltipOpts: {
                content: "x: %x, y: %y"
            }
        };

    }


})();

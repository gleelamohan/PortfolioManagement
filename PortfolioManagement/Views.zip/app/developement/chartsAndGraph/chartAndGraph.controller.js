(function() {
    angular
        .module('app.development.chartAndGraph')
        .controller('ChartAndGraphCtrl', ChartAndGraphCtrl);

    ChartAndGraphCtrl.$inject = ['$scope', '$state'];

    function ChartAndGraphCtrl($scope, $state) {
        var vm = this;

        vm.loadingAnimations = function() {
            $state.go("development.loadingAnimations");
        }

        vm.performanceMonitor = function () {
            $state.go("development.performanceMonitor");
        }

        vm.lineChart = function () {
            $state.go("development.lineChart");
        }

    }

})();


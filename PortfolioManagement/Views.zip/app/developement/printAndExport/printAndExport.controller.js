(function() {
    angular
        .module('app.development.printAndExport')
        .controller('PrintAndExportCtrl', PrintAndExportCtrl);

    PrintAndExportCtrl.$inject = ['$scope'];

    function PrintAndExportCtrl($scope) {
        var vm = this;
    }

})();


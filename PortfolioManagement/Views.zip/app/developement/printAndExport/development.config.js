
(function () {
    angular
        .module('app.development')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];

    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('development', {
                abstract: true,
                url: "/development",
                template: "<ui-view />"
            });
    }
})();
(function () {
    angular
        .module('app.development.printAndExport')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];

    function config($stateProvider, $urlRouterProvider, $httpProvider) {

        $httpProvider.defaults.withCredentials = true;
        $httpProvider.defaults.useXDomain = true;
        //delete $httpProvider.defaults.headers.common['X-Requested-With'];

        $urlRouterProvider.otherwise("/");
        $stateProvider
            .state('development.printAndExport', {
                url: "/printAndExport",
                //template: '<global-search refreshgrid="vm.refreshGrid" appcallback="vm.appCallback" gsc="vm.gsc" searchservice="vm.searchService" ></global-search>',
                template: "<div>Print And Export</div>",
                controller: "PrintAndExportCtrl",
                controllerAs: "vm"
            });
    }
})();


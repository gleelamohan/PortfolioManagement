﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc directive
 * @name efAngularLibrary.efRichTextEditor.directive:efRichTextEditor
 * @scope
 * @restrict AEC
 * @requires recursionHelper
 * @requires toastr
 * @requires Summernote
 * @requires angular-summernote
 * @description 
 * 
 * efRichTextEditor is an Angular directive input control for editing rich text.  
 * 
 * This directive uses the summernote and angular-summernote components for the editing of the rich text data.  See <a href="http://summernote.org/#/" target="_blank">http://summernote.org/#/</a> for complete Summernote details.  See <a href="https://github.com/summernote/angular-summernote" target="_blank">https://github.com/summernote/angular-summernote</a> for complete angular-summernote details.
 * 
 * @param {object|string} ngModel The Angular model for the control.
 * @param {string=} width The HTML valid width for the control.  If not provided, then the default HTML/Bootstrap wdith is used.
 * @param {object} inputscope The setting/scope object that will be used to setup the control.
 * @param {function} appcallback The callback method to execute when the editing has been completed or canceled.
 * @param {boolean=} embedded Flag to determine if the control is embedded in another component.  If not provided or null then the value is false.
**/
(function () {
    angular
        .module('efAngularLibrary.efRichTextEditor')
        .directive('efRichTextEditor', efRichTextEditor);

    efRichTextEditor.$inject = ['$sce', '$filter', '$translate', '$timeout', 'recursionHelper', 'toastr'];

    function efRichTextEditor($sce, $filter, $translate, $timeout, recursionHelper, toastr) {
        return {
            restrict: 'AEC',
            replace: true, //This is being deprecated (https://github.com/angular/angular.js/commit/eec6394a342fb92fba5270eee11c83f1d895e9fb)
            transclue: true,
            scope: {
                ngModel: "=",                   //Bound model value for the field
                width: "@?",                    //Sets the width of the directive.  The width of the individual input controls can be set in the config.
                inputScope: "=inputscope",
                appCallback: "=appcallback",
                embedded: "@?"
            },
            controller: function ($scope) {
                var vm = this;
                $scope.grid = {};   //Added to support UI.grid

                vm.templateUrl = "/app/components/efRichTextEditor/efRichTextEditor.html";

                vm.currentLanguage = $translate.use();
                vm.callbackTimeout = 0;
                vm.setFocus = false;
                vm.inputScope = $scope.inputScope;
                vm.appCallback = $scope.appCallback;
                vm.isEmbedded = $scope.embedded === true || $scope.embedded === "true" || $scope.embedded === 1;
                vm.model = null;

                if (vm.isEmbedded === true) {
                    vm.model = $scope.ngModel;
                }

                vm.save = function () {
                    var richTextValue = {
                        "htmlRichText": $('.summernote').code()
                    }
                    var plainText = String(richTextValue.htmlRichText).replace(/<[^>]+>/gm, '');
                    if (plainText && plainText.length > vm.inputScope.maxLength) {
                        toastr.error("Exceeds the maximum length of " + vm.inputScope.maxLength);
                    } else {
                        //vm.appCallback('saveOk', $sce.trustAsHtml(getText));
                        vm.appCallback('saveOk', richTextValue);
                    }

                }

                vm.cancel = function () {
                    vm.appCallback('cancel', {});
                }

                //Only called when vm.isEmbedded = true
                function updateModel() {
                    vm.model = String($('.summernote').code());
                    $scope.ngModel = vm.model;
                    if (vm.appCallback)
                        vm.appCallback('onChange', vm.model);
                };

                window.setTimeout(function () {

                    var tmpl = $.summernote.renderer.getTemplate();

                    $.summernote.addPlugin({
                        buttons: { // buttons
                            superscriptList: function () {

                                var list = '            <ul class="dropdown-menu">';
                                list += '                <li style="width: 450px;">';
                                list += '                    <ul class="list-unstyled col-md-2">';
                                list += '                        <li><a href="#" style="pointer-events: none; cursor: default;"><u>Numbers</u></a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="⁰">⁰</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="¹">¹</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="²">²</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="³">³</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="⁴">⁴</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="⁵">⁵</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="⁶">⁶</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="⁷">⁷</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="⁸">⁸</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="⁹">⁹</a></li>';
                                list += '                    </ul>';
                                list += '                    <ul class="list-unstyled col-md-2">';
                                list += '                        <li><a href="#" style="pointer-events: none; cursor: default;"><u>Symbols</u></a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="⁺">⁺</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="⁻">⁻</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="⁼">⁼</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="⁽">⁽</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="⁾">⁾</a></li>';
                                list += '                    </ul>';
                                list += '                    <ul class="list-unstyled col-md-3">';
                                list += '                        <li><a href="#" style="pointer-events: none; cursor: default;"><u>Lower Case</u></a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᵃ">ᵃ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᵇ">ᵇ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᶜ">ᶜ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᵈ">ᵈ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᵉ">ᵉ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᶠ">ᶠ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᵍ">ᵍ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ʰ">ʰ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ⁱ">i</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ʲ">ʲ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᵏ">ᵏ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ˡ">ˡ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᵐ">ᵐ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ⁿ">ⁿ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᵒ">ᵒ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᵖ">ᵖ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ʳ">ʳ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ˢ">ˢ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᵗ">ᵗ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᵘ">ᵘ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᵛ">ᵛ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ʷ">ʷ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ˣ">ˣ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ʸ">ʸ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᶻ">ᶻ</a></li>';
                                list += '                    </ul>';
                                list += '                    <ul class="list-unstyled col-md-3">';
                                list += '                        <li><a href="#" style="pointer-events: none; cursor: default;"><u>Upper Case</u></a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᴬ">ᴬ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᴮ">ᴮ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᴰ">ᴰ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᴱ">ᴱ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᴳ">ᴳ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᴴ">ᴴ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᴵ">ᴵ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᴶ">ᴶ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᴷ">ᴷ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᴸ">ᴸ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᴹ">ᴹ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᴺ">ᴺ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᴼ">ᴼ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᴾ">ᴾ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᴿ">ᴿ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᵀ">ᵀ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᵁ">ᵁ</a></li>';
                                list += '                        <li><a data-event="superscriptList" class="col-md-2" href="#" data-value="ᵂ">ᵂ</a></li>';
                                list += '                    </ul>';
                                list += '                </li>';
                                list += '            </ul>';
                                var superscriptDropdown = list;

                                return tmpl.iconButton('fa fa-superscript', {
                                    title: 'Super Script',
                                    hide: true,
                                    dropdown: superscriptDropdown
                                });
                            },
                            subscriptList: function () {

                                var list = '            <ul class="dropdown-menu">';
                                list += '                <li style="width: 300px;">';
                                list += '                    <ul class="list-unstyled col-md-3">';
                                list += '                        <li><a href="#" style="pointer-events: none; cursor: default;"><u>Numbers</u></a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="₀">₀</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="₁">₁</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="₂">₂</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="₃">₃</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="₄">₄</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="₅">₅</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="₆">₆</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="₇">₇</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="₈">₈</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="₉">₉</a></li>';
                                list += '                    </ul>';
                                list += '                    <ul class="list-unstyled col-md-3">';
                                list += '                        <li><a href="#" style="pointer-events: none; cursor: default;"><u>Symbols</u></a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="₊">₊</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="₋">₋</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="₌">₌</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="₍">₍</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="₎">₎</a></li>';
                                list += '                    </ul>';
                                list += '                    <ul class="list-unstyled col-md-4">';
                                list += '                        <li><a href="#" style="pointer-events: none; cursor: default;"><u>Lower Case</u></a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="ₐ">ₐ</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="ₑ">ₑ</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="ᵢ">ᵢ</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="ₒ">ₒ</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="ᵣ">ᵣ</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="ᵤ">ᵤ</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="ᵥ">ᵥ</a></li>';
                                list += '                        <li><a data-event="subscriptList" class="col-md-2" href="#" data-value="ₓ">ₓ</a></li>';
                                list += '                    </ul>';

                                list += '                </li>';
                                list += '            </ul>';
                                var subscriptList = list;

                                return tmpl.iconButton('fa fa-subscript', {
                                    title: 'Subscript',
                                    hide: true,
                                    dropdown: subscriptList
                                });
                            },
                            symbolList: function () {

                                var list = '            <ul class="dropdown-menu">';
                                list += '                <li style="width: 300px;">';
                                list += '                    <ul class="list-unstyled col-md-3">';
                                list += '                        <li><a href="#" style="pointer-events: none; cursor: default;"><u>Greek sub/sup</u></a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ᵅ">ᵅ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ᵝ">ᵝ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ᵞ">ᵞ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ᵟ">ᵟ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ᵋ">ᵋ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ᶿ">ᶿ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ᶥ">ᶥ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ᶲ">ᶲ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ᵠ">ᵠ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ᵡ">ᵡ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ᵦ">ᵦ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ᵧ">ᵧ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ᵨ">ᵨ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ᵩ">ᵩ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ᵪ">ᵪ</a></li>';
                                list += '                    </ul>';
                                list += '                    <ul class="list-unstyled col-md-2">';
                                list += '                        <li><a href="#" style="pointer-events: none; cursor: default;"><u>Greek</u></a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="α">α</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="β">β</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="γ">γ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="δ">δ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ε">ε</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ζ">ζ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="η">η</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="θ">θ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ι">ι</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="κ">κ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="λ">λ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="μ">μ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ν">ν</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ξ">ξ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ο">ο</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="π">π</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ρ">ρ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="σ">σ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="τ">τ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="υ">υ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="φ">φ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="χ">χ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ψ">ψ</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="ω">ω</a></li>';
                                list += '                    </ul>';
                                list += '                    <ul class="list-unstyled col-md-3">';
                                list += '                        <li><a href="#" style="pointer-events: none; cursor: default;"><u>Symbols</u></a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="°">Degree °</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="≥">≥</a></li>';
                                list += '                        <li><a data-event="symbolList" class="col-md-2" href="#" data-value="≤">≤</a></li>';
                                list += '                    </ul>';
                                list += '                </li>';
                                list += '            </ul>';
                                var symbolList = list;

                                return tmpl.iconButton('fa fa-dropbox', {
                                    title: 'Greek List',
                                    hide: true,
                                    dropdown: symbolList
                                });
                            }
                        },

                        /**
                         * @property {Object} events 
                         * @property {Function} events.hello  run function when button that has a 'hello' event name  fires click
                         * @property {Function} events.helloDropdown run function when button that has a 'helloDropdown' event name  fires click
                         * @property {Function} events.helloImage run function when button that has a 'helloImage' event name  fires click
                         */
                        events: { // events
                            superscriptList: function (event, editor, layoutInfo, value) {
                                // Get current editable node
                                var $editable = layoutInfo.editable();

                                //editor.insertText($editable, value);
                                editor.pasteHTML($editable, value);
                            },
                            subscriptList: function (event, editor, layoutInfo, value) {
                                // Get current editable node
                                var $editable = layoutInfo.editable();

                                //editor.insertText($editable, value);
                                editor.pasteHTML($editable, value);
                            },
                            symbolList: function (event, editor, layoutInfo, value) {
                                // Get current editable node
                                var $editable = layoutInfo.editable();

                                //editor.insertText($editable, value);
                                editor.pasteHTML($editable, value);
                            }
                        }
                    });

                    function getBindingText() {
                        return $scope.inputScope !== undefined && vm.isEmbedded === false ? $scope.inputScope.htmlText : (vm.model !== undefined && vm.isEmbedded === true ? vm.model : "");
                    }

                    $('.summernote')
                        .summernote({
                            height: 400,
                            tabsize: 2,
                            toolbar: [['fontsize', ['fontsize']],
                                      ['style', ['bold', 'italic', 'underline', 'strikethrough', 'clear']],
                                      ['group', ['superscriptList']],
                                      ['group', ['subscriptList']],
                                      ['group', ['symbolList']],
                                      ['para', ['ul', 'ol', 'paragraph']]
                            ]
                        })
                        .code(getBindingText());
                    if (vm.isEmbedded === true) {
                        $('.summernote').on('summernote.change', function (customEvent, nativeEvent) {
                            updateModel();
                        });
                    }
                }, vm.isEmbedded === true ? 0 : 1000);
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        };
    }
})();

﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc overview
 * @name efAngularLibrary.efRichTextEditor
 * @description 
 * 
 * efRichTextEditor module provides an Angular directive input control for editing rich text.
 * 
**/
(function () {
    angular.module('efAngularLibrary.efRichTextEditor', [
        'summernote'    // angular-summernote
    ]);
})();
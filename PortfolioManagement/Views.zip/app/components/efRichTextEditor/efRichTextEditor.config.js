﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efRichTextEditor')
        .config(config);

    config.$inject = ['$stateProvider'];

    function config($stateProvider) {
        $stateProvider
            .state('efAngularLibrary.efRichTextEditor', {
                abstract: true,
                url: "/efRichTextEditor",
                template: "<ui-view />"
            });
    };
})();
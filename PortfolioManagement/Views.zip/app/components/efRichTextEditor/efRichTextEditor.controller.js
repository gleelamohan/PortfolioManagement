﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc controller
 * @name efAngularLibrary.efRichTextEditor.controller:efRichTextEditorCtrl
 * @description 
 * 
 * efRichTextEditorCtrl is an Angular controller for opening the efRichTextEditor.directive in a modal window.
 * 
**/
(function () {
    angular
        .module('efAngularLibrary.efRichTextEditor')
        .controller('efRichTextEditorCtrl', efRichTextEditorCtrl);

    efRichTextEditorCtrl.$inject = ['$scope', '$modalInstance'];

    function efRichTextEditorCtrl($scope, $modalInstance) {
        var vm = this;

        //Input scope values from calling page
        vm.inputScope = $scope.inputScope;

        //Callback function from form
        vm.appCallback = function (callbackAction, callbackScope) {
            var action = callbackAction || null;
            var actionScope = callbackScope || {};
            if (action) {
                if (action === "saveOk") {
                    $modalInstance.close(actionScope);
                }
                else if ((action === "cancel") || (action === "close")) {
                    $modalInstance.dismiss('cancel');
                }
            }
        };

    };
})();
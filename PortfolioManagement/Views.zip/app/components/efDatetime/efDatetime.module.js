﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc overview
 * @name efAngularLibrary.efDatetime
 * @description 
 * 
 * efDatetime module provides an Angular directive input control for capturing date and time values.
 * 
 * <a href="/app/#/demo/efDatetime/demo">For complete implmentation details see the demo page.</a>
 * 
 * 
**/
(function () {
    angular.module('efAngularLibrary.efDatetime', [
        'ui.bootstrap.datetimepicker'              // angular-bootstrap-datetimepicker
    ]);
})();
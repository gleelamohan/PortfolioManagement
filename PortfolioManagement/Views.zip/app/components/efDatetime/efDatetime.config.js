﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efDatetime')
        .config(config);

    config.$inject = ['$stateProvider'];

    function config($stateProvider) {
        $stateProvider
            .state('efAngularLibrary.efDatetime', {
                abstract: true,
                url: "/efDatetime",
                template: "<ui-view />"
            })
            .state('efAngularLibrary.efDatetime.demo', {
                url: "/demo",
                templateUrl: "/app/components/efDatetime/demo/efDatetime.demo.html",
                controller: "EfDatetimeDemoCtrl",
                controllerAs: "vm"
            });
    };
})();
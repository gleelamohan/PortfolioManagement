﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
       .module('efAngularLibrary.efDatetime')
       /**
           * @ngdoc interface
           * @name efAngularLibrary.efDatetime.efDatetimeMasks
           * @description 
           * 
           * efDatetimeMasks has been setup as a constant so that it can be injected into other Angular components as a dependency. This object contains the current date and time masks used by the efAngularLibrary components. 
           * 
           * Please see the "/app/components/efDatetime/efDatetime.constants.js" file for implementation details.  
           * 
       **/
        .constant('efDatetimeMasks', {
            /**
             * @ngdoc property
             * @name efAngularLibrary.efDatetime.efDatetimeMasks.#date 
             * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
             * @returns {object} Object of 'date' masks.
            **/
            'date': {
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efDatetime.efDatetimeMasks.#date.moment 
                 * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                 * @returns {string} String of the 'date' mask to use with the moment.js library. See the <a href="http://momentjs.com/docs/#/displaying/" target="_blank">moment.js documentation of display masks</a> for details.
                **/
                'moment': 'DD-MMM-YYYY',
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efDatetime.efDatetimeMasks.#date.angular 
                 * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                 * @returns {String} String of the 'date' mask to use with AngularJS. See the <a href="https://docs.angularjs.org/api/ng/filter/date" target="_blank">AngularJS documentation of date masks</a> for details.
                **/
                'angular': 'dd-MMM-yyyy',
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efDatetime.efDatetimeMasks.#date.model 
                 * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                 * @returns {object} Object of 'date' masks to use when formating the model/service/database values.
                **/
                'model': {
                    /**
                     * @ngdoc property
                     * @name efAngularLibrary.efDatetime.efDatetimeMasks.#date.model.moment 
                     * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                     * @returns {object} String of the 'date' mask to use when formating the model/service/database values with the moment.js library. See the <a href="http://momentjs.com/docs/#/displaying/" target="_blank">moment.js documentation of display masks</a> for details.
                    **/
                    'moment': 'YYYY-MM-DD',
                    /**
                     * @ngdoc property
                     * @name efAngularLibrary.efDatetime.efDatetimeMasks.#date.model.angular 
                     * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                     * @returns {object} String of the 'date' mask to use when formating the model/service/database values with AngularJS. See the <a href="https://docs.angularjs.org/api/ng/filter/date" target="_blank">AngularJS documentation of date masks</a> for details.
                    **/
                    'angular': 'yyyy-MM-dd'
                }
            },
            /**
             * @ngdoc property
             * @name efAngularLibrary.efDatetime.efDatetimeMasks.#datetime 
             * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
             * @returns {object} Object of 'datetime' masks.
            **/
            'datetime': {
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efDatetime.efDatetimeMasks.#datetime.moment 
                 * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                 * @returns {string} String of the 'datetime' mask to use with the moment.js library. See the <a href="http://momentjs.com/docs/#/displaying/" target="_blank">moment.js documentation of display masks</a> for details.
                **/
                'moment': 'DD-MMM-YYYY HH:mm ZZ',
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efDatetime.efDatetimeMasks.#datetime.angular 
                 * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                 * @returns {String} String of the 'datetime' mask to use with AngularJS. See the <a href="https://docs.angularjs.org/api/ng/filter/date" target="_blank">AngularJS documentation of date masks</a> for details.
                **/
                'angular': 'dd-MMM-yyyy HH:mm Z',
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efDatetime.efDatetimeMasks.#datetime.model 
                 * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                 * @returns {object} Object of 'datetime' masks to use when formating the model/service/database values.
                **/
                'model': {
                    /**
                     * @ngdoc property
                     * @name efAngularLibrary.efDatetime.efDatetimeMasks.#datetime.model.moment 
                     * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                     * @returns {object} String of the 'datetime' mask to use when formating the model/service/database values with the moment.js library. See the <a href="http://momentjs.com/docs/#/displaying/" target="_blank">moment.js documentation of display masks</a> for details.
                    **/
                    'moment': 'YYYY-MM-DD[T]HH:mm:ss.sssZZ',
                    /**
                     * @ngdoc property
                     * @name efAngularLibrary.efDatetime.efDatetimeMasks.#datetime.model.angular 
                     * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                     * @returns {object} String of the 'datetime' mask to use when formating the model/service/database values with AngularJS. See the <a href="https://docs.angularjs.org/api/ng/filter/date" target="_blank">AngularJS documentation of date masks</a> for details.
                    **/
                    'angular': 'yyyy-MM-dd\'T\'HH:mm:ss.sssZ'
                }
            },

            'datetimeLocal': {
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efDatetime.efDatetimeMasks.#datetime.moment 
                 * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                 * @returns {string} String of the 'datetime' mask to use with the moment.js library. See the <a href="http://momentjs.com/docs/#/displaying/" target="_blank">moment.js documentation of display masks</a> for details.
                **/
                'moment': 'DD-MMM-YYYY HH:mm',
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efDatetime.efDatetimeMasks.#datetime.angular 
                 * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                 * @returns {String} String of the 'datetime' mask to use with AngularJS. See the <a href="https://docs.angularjs.org/api/ng/filter/date" target="_blank">AngularJS documentation of date masks</a> for details.
                **/
                'angular': 'dd-MMM-yyyy HH:mm',
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efDatetime.efDatetimeMasks.#datetime.model 
                 * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                 * @returns {object} Object of 'datetime' masks to use when formating the model/service/database values.
                **/
                'model': {
                    /**
                     * @ngdoc property
                     * @name efAngularLibrary.efDatetime.efDatetimeMasks.#datetime.model.moment 
                     * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                     * @returns {object} String of the 'datetime' mask to use when formating the model/service/database values with the moment.js library. See the <a href="http://momentjs.com/docs/#/displaying/" target="_blank">moment.js documentation of display masks</a> for details.
                    **/
                    'moment': 'YYYY-MM-DD[T]HH:mm:ss.sss',
                    /**
                     * @ngdoc property
                     * @name efAngularLibrary.efDatetime.efDatetimeMasks.#datetime.model.angular 
                     * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                     * @returns {object} String of the 'datetime' mask to use when formating the model/service/database values with AngularJS. See the <a href="https://docs.angularjs.org/api/ng/filter/date" target="_blank">AngularJS documentation of date masks</a> for details.
                    **/
                    'angular': 'yyyy-MM-dd\'T\'HH:mm:ss.sss'
                }
            },
            /**
             * @ngdoc property
             * @name efAngularLibrary.efDatetime.efDatetimeMasks.#time 
             * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
             * @returns {object} Object of 'time' masks.
            **/
            'time': {
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efDatetime.efDatetimeMasks.#time.moment 
                 * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                 * @returns {string} String of the 'time' mask to use with the moment.js library. See the <a href="http://momentjs.com/docs/#/displaying/" target="_blank">moment.js documentation of display masks</a> for details.
                **/
                'moment': 'HH:mm',
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efDatetime.efDatetimeMasks.#time.angular 
                 * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                 * @returns {String} String of the 'time' mask to use with AngularJS. See the <a href="https://docs.angularjs.org/api/ng/filter/date" target="_blank">AngularJS documentation of date masks</a> for details.
                **/
                'angular': 'HH:mm',
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efDatetime.efDatetimeMasks.#time.model 
                 * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                 * @returns {object} Object of 'time' masks to use when formating the model/service/database values.
                **/
                'model': {
                    /**
                     * @ngdoc property
                     * @name efAngularLibrary.efDatetime.efDatetimeMasks.#time.model.moment 
                     * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                     * @returns {object} String of the 'time' mask to use when formating the model/service/database values with the moment.js library. See the <a href="http://momentjs.com/docs/#/displaying/" target="_blank">moment.js documentation of display masks</a> for details.
                    **/
                    'moment': 'HH:mm:ss.sss',
                    /**
                     * @ngdoc property
                     * @name efAngularLibrary.efDatetime.efDatetimeMasks.#time.model.angular 
                     * @propertyOf efAngularLibrary.efDatetime.efDatetimeMasks
                     * @returns {object} String of the 'time' mask to use when formating the model/service/database values with AngularJS. See the <a href="https://docs.angularjs.org/api/ng/filter/date" target="_blank">AngularJS documentation of date masks</a> for details.
                    **/
                    'angular': 'HH:mm:ss.sss'
                }
            }
        });
})();
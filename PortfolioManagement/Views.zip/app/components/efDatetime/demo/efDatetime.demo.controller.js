﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efDatetime')
        .controller('EfDatetimeDemoCtrl', EfDatetimeDemoCtrl);

    EfDatetimeDemoCtrl.$inject = ['$scope', '$state', '$sanitize', '$parse', '$filter', '$timeout'];

    function EfDatetimeDemoCtrl($scope, $state, $sanitize, $parse, $filter, $timeout) {
        var vm = this;

        vm.disabled = false;

        //vm.datetimeModel = null;
        vm.datetimeModel = "2015-05-26T13:28:38.1896714-04:00";

        vm.datetimePlaceholder = "Select Date and Time...";

        vm.datetimeChangeCallback = function (message) {
            if (message !== undefined && message !== null && message.length > 0) {
                toastr.info(message);
            } else {
                toastr.info("efDatetime ngChange Called");
            }
        }

        vm.dateModel = null;
        //vm.dateModel = "2015-05-26";

        vm.datePlaceholder = "Select Date...";

        vm.dateChangeCallback = function (message) {
            if (message !== undefined && message !== null && message.length > 0) {
                toastr.info(message);
            } else {
                toastr.info("efDatetime ngChange Called");
            }
        }

        vm.timeModel = null;
        //vm.timeModel = "13:28";

        vm.timePlaceholder = "Select Time...";

        vm.timeChangeCallback = function (message) {
            if (message !== undefined && message !== null && message.length > 0) {
                toastr.info(message);
            } else {
                toastr.info("efDatetime ngChange Called");
            }
        }
    };
})();

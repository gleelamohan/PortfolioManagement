﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc directive
 * @name efAngularLibrary.efDatetime.directive:efDatetime
 * @scope
 * @restrict AEC
 * @requires efAngularLibrary.efFocus.directive:efFocus
 * @requires efAngularLibrary.efDatetime.efDatetimeMasks
 * @requires efLibrary
 * @requires recursionHelper
 * @requires toastr
 * @requires angular-bootstrap-datetimepicker
 * @description 
 * 
 * efDatetime is an Angular directive that renders an input control that allows the user to select Date & Time, Date, or Time.
 * 
 * <a href="/app/#/demo/efDatetime/demo">For complete implmentation details see the demo page.</a>   
 * 
 * See <a href="http://dalelotts.github.io/angular-bootstrap-datetimepicker/" target="_blank">http://dalelotts.github.io/angular-bootstrap-datetimepicker/</a> for complete angular-bootstrap-datetimepicker details.
 * 
 * @param {string=} id Unique ID for the rendered control to use to identify itself.
 * @param {object=} config JSON Object with configuration options.  See <a href="http://dalelotts.github.io/angular-bootstrap-datetimepicker/" target="_blank">http://dalelotts.github.io/angular-bootstrap-datetimepicker/</a> for complete details.
 * @param {object|string} ngModel The Angular model for the control.
 * @param {expression|method=} ngChange The method to execute when the model has been changed.
 * @param {expression|boolean=} ngDisabled Flag to enable/disable the field.  If not provided, then the control is enabled.
 * @param {string=} placeholder The placeholder text to display within the control.  Please note that this text must already be translated into the user's target language.
 * @param {string=} width The HTML valid width for the control.  If not provided, then the default HTML/Bootstrap wdith is used.
 * @param {boolean=} now Flag to display/hide the "Now" button.
 * @param {boolean=} inGrid Flag that tells the control if it is being rendered within a grid.  This parameter should not be set by the developer, but rather let the grid/parent control determine its value.
 * @param {expression|boolean=} ngDisableFutureDates Flag to enable/disable the entry of future dates/times.  If not provided, then the value is false.
 * @param {expression|boolean=} ngDisablePastDates Flag to enable/disable the entry of past dates/times.  If not provided, then the value is false.
 * @param {integer=} timeZoneOffset The numeric timezone offset to use when setting the date/time.  If not provided, then the value is 0.
**/
(function () {
    angular
        .module('efAngularLibrary.efDatetime')
        .directive('efDatetime', efDatetime);

    efDatetime.$inject = ['$sce', '$filter', '$translate', '$timeout', 'recursionHelper', 'toastr', 'efDatetimeMasks', 'efLibrary'];

    function efDatetime($sce, $filter, $translate, $timeout, recursionHelper, toastr, efDatetimeMasks, efLibrary) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                id: "@?",
                config: "@?",
                ngModel: "=",
                ngChange: "&",
                ngDisabled: "=?",
                placeholder: "@?",
                width: "@?",
                now: "@?",
                inGrid: "@?",
                ngDisableFutureDates: "=?",
                ngDisablePastDates: "=?"
            },
            controller: function ($scope) {
                var vm = this;
                $scope.grid = {};   //Added to support UI.grid

                vm.currentLanguage = $translate.use();
                vm.changeCallbackTimeout = 100;
                vm.focus = false;

                vm.templateUrl = "/app/components/efDatetime/efDatetime.html";

                function handleDisabledUpdates(newValue) {
                    vm.disabled = newValue !== undefined && newValue !== null ? newValue : null;
                }
                $scope.$watch('ngDisabled', handleDisabledUpdates, true);

                $scope.displayModel = "";

                vm.futureDatesDisabled = false;
                vm.pastDatesDisabled = false;

                //#region support functions
                vm.getDateTimeMasks = function () {
                    var displayModelMask = efDatetimeMasks.datetime.moment;
                    var modelMask = efDatetimeMasks.datetime.model.moment;
                    var mode = "datetime";
                    var actionIcon = "fa-calendar fa-fw";
                    var actionIcon2 = "";
                    if (vm.config !== undefined && vm.config !== null && vm.config.length > 0) {
                        var cfg = JSON.parse(JSON.stringify(eval("(" + vm.config + ")")));
                        if (cfg.startView !== undefined && cfg.startView !== null && cfg.startView.length > 0) {
                            if (cfg.startView.toLowerCase() === "year" || cfg.startView.toLowerCase() === "month" || cfg.startView.toLowerCase() === "day") {
                                if (cfg.minView !== undefined && cfg.minView !== null && cfg.minView.length > 0) {
                                    if (cfg.minView.toLowerCase() === "year" || cfg.minView.toLowerCase() === "month" || cfg.minView.toLowerCase() === "day") {
                                        //Display as Date
                                        displayModelMask = efDatetimeMasks.date.moment;
                                        modelMask = efDatetimeMasks.date.model.moment;
                                        mode = "date";
                                        actionIcon = "fa-calendar fa-fw";
                                    } else if (cfg.minView.toLowerCase() === "hour" || cfg.minView.toLowerCase() === "minute") {
                                        //Display as DateTime
                                        displayModelMask = efDatetimeMasks.datetime.moment;
                                        modelMask = efDatetimeMasks.datetime.model.moment;
                                        mode = "datetime";
                                        actionIcon = "fa-calendar fa-fw efDatetimeActionButtonLeft";
                                        actionIcon2 = "fa-clock-o fa-fw efDatetimeActionButtonRight";
                                    }
                                }
                            } else if (cfg.startView.toLowerCase() === "hour" || cfg.startView.toLowerCase() === "minute") {
                                //Display as Time
                                displayModelMask = efDatetimeMasks.time.moment;
                                modelMask = efDatetimeMasks.time.model.moment;
                                mode = "time";
                                actionIcon = "fa-clock-o fa-fw";
                            }
                        }
                    }

                    vm.displayModelMask = displayModelMask;
                    vm.modelMask = modelMask;
                    vm.mode = mode;
                    vm.actionIcon = actionIcon;
                    vm.actionIcon2 = actionIcon2;
                }

                vm.beforeRenderCallback = function ($view, $dates, $leftDate, $upDate, $rightDate) {
                    if ($dates && (vm.futureDatesDisabled === true || vm.pastDatesDisabled === true)) {
                        //var timeZoneOffset = eval(timeZoneApi.getTimezoneOffset(usersApi.userProfile.DefaultLabSiteTimeZone)) * 3600000;
                        var timeZoneOffset = efLibrary.isValid($scope.timeZoneOffset) ? $scope.timeZoneOffset : 0;
                        var localOffset = moment().utcOffset() * 60000;
                        for (var i = 0; i < $dates.length; i++) {
                            var labTime = $dates[i].localDateValue() + (localOffset + timeZoneOffset); //Apply the sum between the lab's offset and the local offset to the local date/time to get the current time at the lab relative to the user's actual location.
                            if (vm.futureDatesDisabled === true && (labTime > moment().valueOf()))
                                $dates[i].selectable = false;
                            if (vm.pastDatesDisabled === true && (labTime < moment().valueOf()))
                                $dates[i].selectable = false;
                        }
                    };
                }
                //#endregion

                vm.getDateTimeMasks();

                vm.id = $scope.id !== undefined && $scope.id !== null ? $scope.id : ('efdatetime' + String(Math.floor((Math.random() * 1000000) + 1)));

                function updateDisplayModel() {
                    var displayModel = "";

                    if ($scope.ngModel !== undefined && $scope.ngModel !== null) {
                        var model = $scope.ngModel;
                        if (vm.mode === "time" && model.indexOf("T") === -1) {
                            //The model does not have a date component, will not parse. Add the current date to the time so moment can parse it.
                            model = moment().format(efDatetimeMasks.date.model.moment) + "T" + model;
                        }
                        displayModel = moment(model).format(vm.displayModelMask);
                    }

                    $scope.displayModel = displayModel;
                }

                function handleDisplayModelUpdates(newDisplayModel) {
                    vm.displayModel = newDisplayModel !== undefined && newDisplayModel !== null ? newDisplayModel : [];
                }
                $scope.$watch('displayModel', handleDisplayModelUpdates, true);

                function handleConfigUpdates(newConfig) {
                    var cfg = newConfig !== undefined && newConfig !== null ? newConfig : { startView: 'day', minView: 'minute', minuteStep: 5 };
                    var cfgObj = JSON.parse(JSON.stringify(eval("(" + cfg + ")")));
                    cfgObj.dropdownSelector = (vm.id !== undefined && vm.id !== null && vm.id.length > 0 ? ("#" + vm.id) : moment().format("YYYYMMDDHHmmss_sss"));
                    vm.config = JSON.stringify(cfgObj);
                    vm.getDateTimeMasks();
                    updateDisplayModel();
                }
                $scope.$watch('config', handleConfigUpdates, true);

                function handleModelUpdates(newModel) {
                    vm.model = newModel !== undefined && newModel !== null ? JSON.parse(JSON.stringify(newModel)) : null;
                    updateDisplayModel();
                }
                $scope.$watch('ngModel', handleModelUpdates, true);

                function updateDirectiveModel(model) {
                    var returnValue = false;
                    var updatedModel = model !== undefined && model !== null ? model : (vm.model !== undefined && vm.model !== null ? vm.model : null);

                    if ($scope.ngModel !== undefined) {
                        $scope.ngModel = moment(updatedModel).format(vm.modelMask);
                        returnValue = true;
                        vm.postModelUpdate(true);
                    } else {
                        vm.displayErrorMessage(String($filter("trustedtranslate")("efAngularLibrary.efDatetime.ModelUndefinedError")));
                    }
                    return returnValue;
                }

                function handleChangeCallbackUpdates(newChangeCallback) {
                    vm.changeCallback = newChangeCallback !== undefined && newChangeCallback !== null ? newChangeCallback : function () { };
                }
                $scope.$watch('ngChange', handleChangeCallbackUpdates, true);

                function handleDisableFutureDates(disable) {
                    vm.futureDatesDisabled = (disable === true || disable === "true") ? true : false;
                }
                $scope.$watch('ngDisableFutureDates', handleDisableFutureDates, true);

                function handleDisablePastDates(disable) {
                    vm.pastDatesDisabled = (disable === true || disable === "true") ? true : false;
                }
                $scope.$watch('ngDisablePastDates', handleDisablePastDates, true);

                vm.placeholder = $scope.placeholder !== undefined && $scope.placeholder !== null ? $scope.placeholder : "";

                vm.width = $scope.width !== undefined && $scope.width !== null ? $scope.width : "";
                vm.widthStyle = vm.width !== undefined && vm.width !== null && vm.width.length > 0 ? JSON.parse("{\"width\": \"" + vm.width + "\"}") : "";

                vm.now = efLibrary.toBoolean($scope.now, true);
                vm.nowLabel = String($filter("trustedtranslate")("efAngularLibrary.efDatetime.NowButton"));

                //vm.inGrid is set from HTML attribute
                vm.inGrid = efLibrary.toBoolean($scope.inGrid, false);

                //#region Button/Link Functions

                vm.postModelUpdate = function () {
                    $('[ef-datetime] > .open').removeClass('open');
                    vm.focus = true;
                    $timeout(function () {
                        vm.changeCallback();
                        vm.focus = false;
                    }, vm.changeCallbackTimeout);
                    if (vm.inGrid) {
                        $timeout(function () {
                            efLibrary.simulateDatatableTabKeyPress();
                            vm.focus = false;
                        }, vm.changeCallbackTimeout);
                    }
                }

                vm.modelDelete = function () {
                    if ($scope.ngModel !== undefined) {
                        $scope.ngModel = null;
                        vm.postModelUpdate();
                    }
                }

                vm.modelUpdate = function () {
                    updateDirectiveModel(vm.model);
                }

                vm.setNow = function () {
                    //var timeZoneOffset = eval(timeZoneApi.getTimezoneOffset(usersApi.userProfile.DefaultLabSiteTimeZone)) * 3600000;
                    var timeZoneOffset = efLibrary.isValid($scope.timeZoneOffset) ? $scope.timeZoneOffset : 0;
                    var localOffset = moment().utcOffset() * 60000;
                    updateDirectiveModel(moment().valueOf() - (localOffset + timeZoneOffset));
                }

                //#endregion

                //#region support functions

                vm.displayErrorMessage = function (message) {
                    toastr.error(message);
                }

                //Stops any propogation or default behavior defined for the event
                vm.stopProcessingEvent = function (event) {
                    event.stopPropagation();
                    event.preventDefault();
                }

                //#endregion
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        };
    }
})();

﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc overview
 * @name efAngularLibrary.efTrustedTranslate
 * @description 
 * 
 * efTrustedTranslate module augments the <a href="https://angular-translate.github.io/">angular-translate</a> language translation service to allow for HTML tags to be rendered within the translated values.
 * 
 * efTrustedTranslate takes a tranlation key, looks up the key within the correct langugage specific translation file/service, then returns the translated value (including any browser safe HTML tags).  The settings for angular-translate can found in the root AngularJS config file.
 * 
**/
(function () {
    angular.module('efAngularLibrary.efTrustedTranslate', [
        //The following should be included in the main application module as a dependency
        //'pascalprecht.translate'    // Translations
    ]);
})();
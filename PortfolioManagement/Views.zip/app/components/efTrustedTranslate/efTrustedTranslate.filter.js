﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc filter
 * @name efAngularLibrary.efTrustedTranslate.filter:trustedtranslate
 * @description 
 * 
 * trustedtranslate is an Angular filter that augments the <a href="https://angular-translate.github.io/">angular-translate</a> language translation service to allow for HTML tags to be rendered within the translated values.
 * 
 * trustedtranslate takes a tranlation key, looks up the key within the correct langugage specific translation file/service, then returns the translated value (including any browser safe HTML tags).  The settings for angular-translate can found in the root AngularJS config file.
 * 
 * Inline HTML Filter Example:
 * <pre>
 * {{'My.Translation.Key' | trustedtranlate'}}
 * </pre>
 *  
 * Javascript Code Example:
 * <pre>
 * var myTranslatedValue = String($filter('trustedtranslate')('My.Translation.Key'));
 * </pre>
 * 
 * @param {string} val Valid translation key.
 * @returns {string|HTML} Language specific translated value/HTML.
**/
(function () {
    angular
        .module('efAngularLibrary.efTrustedTranslate')
        .filter('trustedtranslate', efTrustedTranslate);

    efTrustedTranslate.$inject = ['$sce', '$filter'];

    function efTrustedTranslate($sce, $filter) {
        return function (val) {
            return $sce.trustAsHtml($filter('translate')(val));
        };
    }
})();
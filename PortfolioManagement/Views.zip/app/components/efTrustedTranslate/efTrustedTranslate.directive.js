﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc directive
 * @name efAngularLibrary.efTrustedTranslate.directive:trustedtranslate
 * @restrict AE
 * @description 
 * 
 * trustedtranslate is an Angular directive that augments the <a href="https://angular-translate.github.io/">angular-translate</a> language translation service to allow for HTML tags to be rendered within the translated values.
 * 
 * trustedtranslate takes a tranlation key, looks up the key within the correct langugage specific translation file/service, then returns the translated value (including any browser safe HTML tags).  The settings for angular-translate can found in the root AngularJS config file.
 * 
 * Element Example:
 * <pre>
 * <trustedtranslate>My.Translation.Key</trustedtranslate>
 * </pre>
 *  
 * Attribute Example:
 * <pre>
 * <span trustedtranslate>My.Translation.Key</span>
 * </pre>
 *
 * Alternate Attribute Example:
 * <pre>
 * <span trustedtranslate="My.Translation.Key"></span>
 * </pre>
 * 
**/
(function () {
    angular
        .module('efAngularLibrary.efTrustedTranslate')
        .directive('trustedtranslate', efTrustedTranslate);

    efTrustedTranslate.$inject = ['$sce', '$filter'];

    function efTrustedTranslate($sce, $filter) {
        return {
            restrict: 'AE',
            replace: false,
            link: function ($scope, tElem, tAttrs) {
                tElem.html($filter('translate')(((tAttrs['trustedtranslate']) && (tAttrs['trustedtranslate'].length)) > 0 ? tAttrs['trustedtranslate'] : tElem.html()));
                //Keeping the atrribute (when provided) is consistent with the Angular-Translate translate directive
                //tElem.removeAttr('trustedtranslate');
            },
        };
    }
})();
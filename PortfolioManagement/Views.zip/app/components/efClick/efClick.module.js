﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc overview
 * @name efAngularLibrary.efClick
 * @description 
 * 
 * efClick module provides an Angular directive that allows an method to be located within the current Angular scope hierarchy and then executed when the "click" event of the HTML element is called.
 * 
**/
(function () {
    angular.module('efAngularLibrary.efClick', []);
})();
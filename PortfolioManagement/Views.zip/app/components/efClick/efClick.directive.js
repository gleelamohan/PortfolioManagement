﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc directive
 * @name efAngularLibrary.efClick.directive:efClick
 * @scope
 * @restrict A
 * @requires efLibrary
 * @description 
 * 
 * efClick is an Angular directive that allows an method to be located within the current Angular scope hierarchy and then executed when the "click" event of the HTML element is called.
 * 
 * Example:
 * <pre>
 * <input type="button" ef-click="vm.MyFunction('MyFunctionInputValue')">
 * </pre>
 * 
 * @param {method|string} efClick The string-based representation of the method (inlcuding input parameters), that will be executed when the the "click" event of the HTML element is called.
**/
(function () {
    angular
        .module('efAngularLibrary.efClick')
        .directive('efClick', efClick);

    efClick.$inject = ['$sce', '$filter', 'efLibrary'];

    function efClick() {
        return {
            restrict: 'A',
            scope: {
                efClick: "@?"
            },
            link: function (scope, element, attrs) {
                element.bind("click", function (event) {
                    if (efLibrary.isValid(scope.efClick, true)) {
                        efLibrary.executeFunctionThroughAngularScope(scope, scope.efClick);
                    }
                });
            }
        };
    }
})();
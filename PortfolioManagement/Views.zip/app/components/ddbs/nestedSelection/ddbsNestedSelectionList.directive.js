// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('app')
        .directive('ddbsNestedSelectionList', ddbsNestedSelectionList);

    ddbsNestedSelectionList.$inject = [];
    ddbsNestedSelectionListCtrl.$inject = ['$scope'];

    function ddbsNestedSelectionList() {
        return {
            restrict: 'E',
            replace: true,
            scope: {
                list: '=list',
                options: '=options',
            },
            templateUrl: '/app/components/ddbs/nestedSelection/ddbsnestedselectionlist.html',
            controller: ddbsNestedSelectionListCtrl,
            controllerAs: 'vm'
        };
    }

    function ddbsNestedSelectionListCtrl($scope) {
        var vm = this;
        if (!$scope.list.length > 0) {
            return;
        }
        vm.internalList = $scope.list;
        vm.options = $scope.options;

        vm.treeOptions = {
            dropped: function (event) {
                //only perform removal check if the flag is enabled
                if (!vm.options && !vm.options.keepInList) {
                    return;
                }

                //no removal check if in the same list
                if (event.source.nodesScope === event.dest.nodesScope) {
                    return;
                }

                var original = event.source.nodeScope;
                var originalList = event.source.nodesScope;

                originalList.$modelValue.splice(event.source.index, 0, original.item);
            }
        }
    }
})();
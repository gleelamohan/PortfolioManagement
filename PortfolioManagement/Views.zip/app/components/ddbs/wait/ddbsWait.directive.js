// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('app')
        .directive('ddbsWait', ddbsWait);

    ddbsWait.$inject = ['$translate', 'recursionHelper'];

    function ddbsWait($translate, recursionHelper) {
        return {
            restrict: 'E',
            replace: true,
            priority: 1,
            controller: function () {
                var vm = this;
                vm.currentLanguage = $translate.use();
                vm.templateUrl = "/app/components/ddbs/wait/ddbsWait.html";
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        }
    }
})();
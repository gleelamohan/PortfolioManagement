// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module("app")
        .directive("ddbsConfirm", ddbsConfirm);

    ddbsConfirm.$inject = ["$filter", "$translate", "recursionHelper"];

    function ddbsConfirm($filter, $translate, recursionHelper) {
        return {
            restrict: "E",
            replace: true,
            scope: {
                inputScope: "=inputscope",
                appCallback: "=appcallback"
            },
            priority: 1,
            controller: function ($scope) {
                var vm = this;
                vm.yesButtonText = String($filter("trustedtranslate")("Common.Maintenance.YesButton"));
                vm.noButtonText = String($filter("trustedtranslate")("Common.Maintenance.NoButton"));

                vm.currentLanguage = $translate.use();
                vm.templateUrl = "/app/components/ddbs/confirm/confirm.html";
                vm.inputScope = $scope.inputScope;
                vm.appCallback = $scope.appCallback;

                vm.confirmYes = function () {
                    vm.appCallback("saveOk", {});
                };

                vm.confirmNo = function () {
                    vm.appCallback("cancel", {});
                };


            },
            controllerAs: "vm",
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        }
    }
})();
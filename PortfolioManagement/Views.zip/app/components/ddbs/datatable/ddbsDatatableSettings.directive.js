// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('app')
        .directive('ddbsDatatableSettings', ddbsDatatableSettings);

    ddbsDatatableSettings.$inject = ['$sce', 'recursionHelper'];

    function ddbsDatatableSettings($sce, recursionHelper) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                appCallback: "=appcallback",
                templateUrl: "=templateurl",
                viewType: "=viewtype",
                pageLength: "=pagelength",
                pageLengthOptions: "=pagelengthoptions",
                columnVisibilityOptions: "=columnvisibilityoptions",
                changePageLengthCallback: "=changepagelengthcallback",
                changeViewCallback: "=changeviewcallback",
                saveViewCallback: "=saveviewcallback",
                exportExcelCallback: "=exportexcelcallback",
                changeColumnVisibilityCallback: "=changecolumnvisibilitycallback"
            },
            controller: function ($scope, $element, $attrs, $transclude) {
                var vm = this;
                vm.appCallback = $scope.appCallback;
                vm.templateUrl = $scope.templateUrl;
                vm.viewType = $scope.viewType;
                vm.changePageLengthCallback = $scope.changePageLengthCallback;
                vm.changeViewCallback = $scope.changeViewCallback;
                vm.saveViewCallback = $scope.saveViewCallback;
                vm.exportExcelCallback = $scope.exportExcelCallback;
                vm.changeColumnVisibilityCallback = $scope.changeColumnVisibilityCallback;

                vm.convertToSelectedView = function (view) {
                    if (view) {
                        if (view == "standard") {
                            return "Left";
                        } else if (view == "user") {
                            return "Right";
                        } else {
                            return "";
                        }
                    } else {
                        return "";
                    }
                };

                vm.convertToCurrentView = function (view) {
                    if (view) {
                        if (view == "Left") {
                            return "standard";
                        } else if (view == "Right") {
                            return "user";
                        } else {
                            return "";
                        }
                    } else {
                        return "";
                    }
                };

                $scope.$watch('viewType', handleViewTypeUpdates, true);
                function handleViewTypeUpdates(newView) {
                    var view = newView || null;
                    if (view) {
                        vm.selectedView = vm.convertToSelectedView(view);
                    }
                };

                vm.getSelectedPageLengthOptionIndex = function(options, valueToFind) {
                    var i = 0;
                    var index = -1;
                    if (options) {
                        for (i = 0; i < options.length; i++) {
                            if (options[i].value == valueToFind) {
                                index = i;
                                break;
                            }
                        }
                    }
                    return index;
                };

                vm.setSelectedPageLengthOption = function() {
                    var index = vm.getSelectedPageLengthOptionIndex(vm.pageLengthOptions, vm.pageLength);
                    if (index >= 0) {
                        vm.selectedPageLengthOption = vm.pageLengthOptions[index];
                    } else {
                        vm.selectedPageLengthOption = {};
                    }
                }

                $scope.$watch('pageLength', handlePageLengthUpdates, true);
                function handlePageLengthUpdates(newPageLength) {
                    vm.pageLength = newPageLength || 10;
                    vm.setSelectedPageLengthOption();
                };

                $scope.$watch('pageLengthOptions', handlePageLengthOptionsUpdates, true);
                function handlePageLengthOptionsUpdates(newPageLengthOptions) {
                    vm.pageLengthOptions = newPageLengthOptions || [{ "label": "10", "value": 10 }];
                    vm.setSelectedPageLengthOption();
                };

                $scope.$watch('columnVisibilityOptions', handleColumnVisibilityOptionsUpdates, true);
                function handleColumnVisibilityOptionsUpdates(newColumnVisibilityOptions) {
                    vm.columnVisibilityOptions = newColumnVisibilityOptions || [];
                };

                vm.changeSelectedView = function () {
                    if (vm.selectedView) {
                        vm.changeViewCallback(vm.convertToCurrentView(vm.selectedView));
                    }
                };

                vm.changeColumnVisibility = function () {
                    if (vm.columnVisibilityOptions) {
                        vm.changeColumnVisibilityCallback(vm.columnVisibilityOptions);
                    }
                };

                vm.changePageLength = function() {
                    if (vm.selectedPageLengthOption.value) {
                        $scope.pageLength = vm.selectedPageLengthOption.value;
                        vm.changePageLengthCallback(vm.selectedPageLengthOption.value);
                    }
                };

            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        }
    };
})();

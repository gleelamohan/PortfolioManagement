// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('app')
        .directive('ddbsDatatableFilter', ddbsDatatableFilter);

    ddbsDatatableFilter.$inject = ['$sce', 'recursionHelper'];

    function ddbsDatatableFilter($sce, recursionHelper) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                appCallback: "=appcallback",
                templateUrl: "=templateurl",
                filterCallback: "=filtercallback",
                filterTerm: "=filterterm"
            },
            controller: function ($scope, $element, $attrs) {
                var vm = this;
                vm.appCallback = $scope.appCallback;
                vm.templateUrl = $scope.templateUrl;
                vm.filterTerm = ($scope.filterTerm !== undefined || $scope.filterTerm !== null) ? $scope.filterTerm : "";
                vm.filterCallback = $scope.filterCallback;
                
                vm.filter = function (term, field) {
                    if (term === undefined) {

                        term = "";
                    }
                    if (field === undefined) {
                        field = null;
                    }
                    $scope.filterTerm = vm.filterTerm;
                    vm.filterCallback(term, field);
                }
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        }
    };
})();

// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('app')
        .directive('ddbsDatatable', ddbsDatatable);

    ddbsDatatable.$inject = ['$sce', '$filter', 'toastr' ];

    function ddbsDatatable($sce, $filter, toastr) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                appCallback: "=appcallback",
                config: "=config",
                eventFunctions: "=eventfunctions",
                results: "=results",
                viewType: "=viewtype",
                rowSelect: "=rowselect",
                multiRowSelect: "=multiRowSelect",
                filterCallback: "=filtercallback",
                changePageLengthCallback: "=changepagelengthcallback",
                changeViewCallback: "=changeviewcallback",
                saveViewCallback: "=saveviewcallback",
                exportExcelCallback: "=exportexcelcallback",
                changeColumnVisibilityCallback: "=changecolumnvisibilitycallback"
            },
            controller: function ($scope, $element, $attrs) {
                var vm = this;
                var featureNotImplemented = String($filter('trustedtranslate')("Common.FeatureNotImplmented"));

                vm.appCallback = $scope.appCallback;
                vm.dataTableElement = $element;

                $scope.$watch('viewType', handleViewTypeUpdates, true);
                function handleViewTypeUpdates(newView) {
                    vm.viewType = newView || "standard";
                };

                $scope.$watch('rowSelect', handleRowSelectUpdates, true);
                function handleRowSelectUpdates(newVal) {
                    vm.rowSelect = ((newVal === undefined) || (newVal === null) ? false : ((newVal === true) || (newVal === "true") ? true : false));
                    if (vm.rowSelect) {
                        vm.multiRowSelect = false;
                    }
                };

                $scope.$watch('multiRowSelect', handleMultiRowSelectUpdates, true);
                function handleMultiRowSelectUpdates(newVal) {
                    vm.multiRowSelect = ((newVal === undefined) || (newVal === null) ? false : ((newVal === true) || (newVal === "true") ? true : false));
                    if (vm.multiRowSelect) {
                        vm.rowSelect = false;
                    }
                };


                vm.filterCallback = function (filterTerm, filterScope) {
                    if (filterScope) {
                        vm.dataTableElement.DataTable().columns((filterScope + ":name")).search(filterTerm).draw();
                    } else {
                        vm.dataTableElement.DataTable().search(filterTerm).draw();
                    }
                }

                vm.changePageLengthCallback = function (pageLength) {
                    if (pageLength) {
                        vm.dataTableElement.DataTable().page.len(pageLength).draw();
                    }
                }

                vm.changeViewCallback = function (view) {
                    if ((view) && (view != $scope.viewType)) {
                        toastr.info(featureNotImplemented);
                        //reset to standard view
                        $scope.viewType = "standard";
                    }
                }

                vm.saveViewCallback = function () {
                    toastr.info(featureNotImplemented);
                }

                vm.exportExcelCallback = function () {
                    toastr.info(featureNotImplemented);
                }

                vm.changeColumnVisibilityCallback = function (columnVisibilityOptions) {
                    if (columnVisibilityOptions) {
                        toastr.info(featureNotImplemented);
                    }
                }

                $scope.filterCallback = vm.filterCallback;
                $scope.changePageLengthCallback = vm.changePageLengthCallback;
                $scope.changeViewCallback = vm.changeViewCallback;
                $scope.saveViewCallback = vm.saveViewCallback;
                $scope.exportExcelCallback = vm.exportExcelCallback;
                $scope.changeColumnVisibilityCallback = vm.changeColumnVisibilityCallback;

                //Initialize the DataTable

                if ($scope.eventFunctions !== undefined && $scope.eventFunctions !== null && $scope.eventFunctions.length > 0) {
                    for (var counter = 0; counter < $scope.eventFunctions.length; counter++) {
                        vm.dataTableElement.on($scope.eventFunctions[counter].event, $scope.eventFunctions[counter].eventFunction);
                    }
                }

                vm.dataTableElement.DataTable($scope.config);

                $scope.$watch('results', handleResultsUpdates, true);

                function handleResultsUpdates(newData) {
                    var data = (newData !== undefined && newData !== null && newData.length > 0) ? newData : [];
                    if (data.length > 0) {
                        vm.dataTableElement.DataTable()
                            .clear()
                            .rows.add(data)
                            .draw();
                        if (vm.rowSelect) {
                            vm.dataTableElement.rowlink();
                        } else if (vm.multiRowSelect) {
                            var test = vm.dataTableElement;
                        }
                    } else {
                        vm.dataTableElement.DataTable()
                        .clear()
                        .draw();
                    }
                }

            },
            controllerAs: "vm"
        }
    };
})();

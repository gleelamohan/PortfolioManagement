// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('app')
        .directive('ddbsEditableDatatable', ddbsEditableDatatable);

    ddbsEditableDatatable.$inject = ['$sce', '$filter', '$timeout', 'toastr'];

    function ddbsEditableDatatable($sce, $filter, $timeout, toastr) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                appCallback: "=appcallback",
                config: "=config",
                eventFunctions: "=eventfunctions",
                editorConfig: "=editorconfig",
                editorDependentFunctions: "=editordependentfunctions",
                editorEventFunctions: "=editoreventfunctions",
                inlineEditing: "=inlineediting",
                inlineEditingTabNavigation: "=inlineeditingtabnavigation",
                results: "=results",
                viewType: "=viewtype",
                filterCallback: "=filtercallback",
                changePageLengthCallback: "=changepagelengthcallback",
                changeViewCallback: "=changeviewcallback",
                saveViewCallback: "=saveviewcallback",
                exportExcelCallback: "=exportexcelcallback",
                changeColumnVisibilityCallback: "=changecolumnvisibilitycallback",
                datatableEditor: "=datatableeditor",
                editorCloseCallback: "=editorclosecallback"
            },
            controller: function ($scope, $element, $attrs, $transclude) {
                var vm = this;
                var featureNotImplemented = String($filter('trustedtranslate')("Common.FeatureNotImplmented"));

                vm.appCallback = $scope.appCallback;
                vm.dataTableElement = $element;

                vm.dataTableInitialized = false;
                vm.ignoreHandleResultsUpdates = true;

                $scope.$watch('viewType', handleViewTypeUpdates, true);
                function handleViewTypeUpdates(newView) {
                    vm.viewType = newView || "standard";
                };

                vm.filterCallback = function (filterTerm, filterScope) {
                    if (filterScope) {
                        vm.dataTableElement.DataTable().columns((filterScope + ":name")).search(filterTerm).draw();
                    } else {
                        vm.dataTableElement.DataTable().search(filterTerm).draw();
                    }
                }

                vm.changePageLengthCallback = function (pageLength) {
                    if (pageLength) {
                        vm.dataTableElement.DataTable().page.len(pageLength).draw();
                    }
                }

                vm.changeViewCallback = function (view) {
                    if ((view) && (view != $scope.viewType)) {
                        toastr.info(featureNotImplemented);
                        //reset to standard view
                        $scope.viewType = "standard";
                    }
                }

                vm.saveViewCallback = function () {
                    toastr.info(featureNotImplemented);
                }

                vm.exportExcelCallback = function () {
                    toastr.info(featureNotImplemented);
                }

                vm.changeColumnVisibilityCallback = function (columnVisibilityOptions) {
                    if (columnVisibilityOptions) {
                        toastr.info(featureNotImplemented);
                    }
                }

                $scope.filterCallback = vm.filterCallback;
                $scope.changePageLengthCallback = vm.changePageLengthCallback;
                $scope.changeViewCallback = vm.changeViewCallback;
                $scope.saveViewCallback = vm.saveViewCallback;
                $scope.exportExcelCallback = vm.exportExcelCallback;
                $scope.changeColumnVisibilityCallback = vm.changeColumnVisibilityCallback;

                vm.updateTableData = function (newData) {
                    var data = (newData !== undefined && newData !== null && newData.length > 0) ? newData : [];
                    if (data.length > 0) {
                        vm.dataTableElement.DataTable()
                            .clear()
                            .rows.add(data)
                            .draw();
                    }
                }
                
                //Initialize the DataTable
                //vm.dataTableElement.DataTable($scope.config);

                vm.datatableTableName = "";
                vm.datatableEditable = false;
                vm.dataTableEditor = null;
                if ($scope.editorConfig !== undefined && $scope.editorConfig !== null && $scope.editorConfig.table !== undefined && $scope.editorConfig.table !== null) {
                    vm.datatableTableName = $scope.editorConfig.table;
                    vm.datatableEditable = true;
                    //vm.dataTableEditor = vm.dataTableElement.DataTable().Editor($scope.editorConfig);
                    vm.dataTableEditor = new $.fn.dataTable.Editor($scope.editorConfig);
                    if ($scope.inlineEditing !== undefined && $scope.inlineEditing !== null && $scope.inlineEditing === true) {
                        if ($scope.inlineEditingTabNavigation !== undefined && $scope.inlineEditingTabNavigation !== null && $scope.inlineEditingTabNavigation === true) {
                            vm.dataTableEditor.on('open', function (e, type) {
                                if (type === 'inline') {
                                    // Listen for a tab key event when inline editing
                                    $(document).on('keydown.editor', function (e) {
                                        if (e.keyCode === 9) {
                                            e.preventDefault();

                                            // Find the cell that is currently being edited
                                            var cell = $('div.DTE').parent();

                                            if (e.shiftKey && cell.prev().length && cell.prev().index() !== 0) {
                                                // One cell to the left (skipping the first column)
                                                cell.prev().click();
                                            }
                                            else if (e.shiftKey) {
                                                // Up to the previous row
                                                cell.parent().prev().children().last(0).click();
                                            }
                                            else if (cell.next().length) {
                                                // One cell to the right
                                                cell.next().click();
                                            }
                                            else {
                                                // Down to the next row
                                                cell.parent().next().children().eq(1).click();
                                            }
                                        }
                                    });
                                }
                            })
                            .on('close', function () {
                                $(document).off('keydown.editor');
                                $scope.editorCloseCallback();
                            });
                        }

                        $(vm.datatableTableName).on('click', 'td.editable', function (e) {
                            vm.dataTableEditor.inline(this, {
                                "submitOnBlur": true
                            });
                        });

                        //The following event fires after the datatable is fully initialized
                        //$(vm.datatableTableName).on('init.dt', function (e) {
                        //});
                    }

                    if ($scope.editorDependentFunctions !== undefined && $scope.editorDependentFunctions !== null && $scope.editorDependentFunctions.length > 0) {
                        for (var counter = 0; counter < $scope.editorDependentFunctions.length; counter++) {
                            vm.dataTableEditor.dependent($scope.editorDependentFunctions[counter].field, $scope.editorDependentFunctions[counter].dependentFunction);
                        }
                    }

                    if ($scope.editorEventFunctions !== undefined && $scope.editorEventFunctions !== null && $scope.editorEventFunctions.length > 0) {
                        for (var counter = 0; counter < $scope.editorEventFunctions.length; counter++) {
                            vm.dataTableEditor.on($scope.editorEventFunctions[counter].event, $scope.editorEventFunctions[counter].eventFunction);
                        }
                    }

                    if ($scope.eventFunctions !== undefined && $scope.eventFunctions !== null && $scope.eventFunctions.length > 0) {
                        for (var counter = 0; counter < $scope.eventFunctions.length; counter++) {
                            $(vm.datatableTableName).on($scope.eventFunctions[counter].event, $scope.eventFunctions[counter].eventFunction);
                        }
                    }

                    var cfg = $scope.config;
                    $(vm.datatableTableName).DataTable($scope.config);

                    if ($scope.results !== undefined && $scope.results !== null && $scope.results.length > 0) {
                        vm.updateTableData($scope.results);
                    }

                    $scope.datatableEditor = vm.dataTableElement.DataTable();

                    vm.dataTableInitialized = true;
                }

                $scope.$watch('results', handleResultsUpdates, true);
                function handleResultsUpdates(newData) {
                    if (!vm.ignoreHandleResultsUpdates) {
                        if (vm.dataTableInitialized) {
                            vm.updateTableData(newData);
                        }
                    } else {
                        vm.ignoreHandleResultsUpdates = false;
                    }
                }
            },
            controllerAs: "vm"
        }
    };
})();

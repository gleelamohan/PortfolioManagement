// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('app')
        .directive('ddbsPageHeader', ddbsPageHeader);

    ddbsPageHeader.$inject = [];
    ddbsPageHeaderCtrl.$inject = ['$scope', '$element', '$transclude'];

    function ddbsPageHeader() {
        return {
            scope: {
                primary: '@primary',
                secondary: '@secondary'
            },
            templateUrl: '/app/components/ddbs/pageHeader/ddbsPageHeader.html',
            controller: ddbsPageHeaderCtrl,
            controllerAs: 'vm',
            transclude: true
        };
    }

    function ddbsPageHeaderCtrl($scope, $element, $transclude) {
        var vm = this;
        vm.primaryText = $scope.primary;
        vm.secondaryText = $scope.secondary;

        $transclude(function(clone) {
            var customPanel = $element.find('.custom');
            if (customPanel) {
                customPanel.append(clone);
            }
        });
    }
})();
(function () {
    angular.module('app').directive('navigationitem', navigationitem);

    navigationitem.$inject = ['recursionHelper'];

    function navigationitem(recursionHelper) {

        navigationItemCtrl.$inject = ['$scope', '$state', '$rootScope'];

        return {
            restrict: 'E',
            replace: true,
            scope: {
                node: '=',
                level: '='
            },
            require: '^navigation',
            templateUrl: '/app/components/navigation/navigationItem.html',
            compile: function (element) {
                return recursionHelper.compile(element, link);
            },
            controller: navigationItemCtrl
        };

        function link(scope, ele, attrs, parentNavCtrl) {            
            parentNavCtrl.counter.current++;
            //console.log(parentNavCtrl.counter.current);
        };

        function navigationItemCtrl($scope, $state, $rootScope) {



            $scope.childClasses = getChildClasses();

            $scope.gotoState = function () {
                if ($scope.node.Sref) {
                    //console.log($scope.node.Sref);
                    $state.go($scope.node.Sref);
                }
            }

            $rootScope.$on('$stateChangeError', function (event, toState, toParams, fromState, fromParams, error) {
                if (error) {
                    alert(error);
                }
            });



            //console.log('inside nav item ctrl');
            //console.log($scope.node);
            //console.log($scope.node.Children);

            function getChildClasses() {
                if (!$scope.node.Children || $scope.node.Children.length == 0) {
                    return "";
                }
                var classes = [];
                classes.push('nav');
                classes.push(getLevelText());
                if ($scope.level >= 1) {
                    classes.push('collapse');
                }
                var dat = classes.join(' ');
                //console.log(dat);
                return dat;

            }
            function getLevelText() {
                var result = '';
                //console.log($scope.level);
                switch ($scope.level) {
                    case 1:
                        result = 'nav-second-level';
                        break;
                    case 2:
                        result = 'nav-third-level';
                        break;
                    default:
                        result = '';
                }
                return result;
            }
        };
    }
})();
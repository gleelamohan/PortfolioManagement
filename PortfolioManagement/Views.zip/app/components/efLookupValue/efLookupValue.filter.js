﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc filter
 * @name efAngularLibrary.efLookupValue.filter:efLookupValue
 * @requires efLibrary
 * @description 
 * 
 * efLookupValue is an Angular filter that lookups and returns a value from an object within the current Angular scope or within the current current Angular scope hierarchy. 
 * <a href="/app/#/demo/efLookupValue/demo">For complete implmentation details see the demo page.</a>
 * 
 * Example:
 * <pre>
 * <div ng-bind-html="vm.lookupValue | efLookupValue:'vm.lookupOptions':'valueFieldName':'labelFieldName':this"></div>
 * </pre>
 * 
 * @param {any} value The lookup value to search for.
 * @param {Array|string} options Object array that will be the lookup source.  This can also be a string value of the object array.  When this is provided as a string type, then the current angular scope hierarchy will be searched for the named object.
 * @param {string} optionsValueField Field name in the options object array that will be used as the value field.  The provided value will be search for within this field.
 * @param {string} optionsLookupField Field name in the options object array that will be used as the lookup field.  For the found entry, this is the field that will be returned.
 * @param {scope} scope The scope object to be used to find the options object.  If options is provided as a string, then this will be the scope start object for the hoerarchial options search.
 * @returns {string|HTML} The found lookup data.  The lookup data contain HTML that is considered safe to render.  If nothing is found, then the return value is an empty string.
**/
(function () {
    angular
        .module('efAngularLibrary.efLookupValue')
        .filter('efLookupValue', efLookupValue);

    efLookupValue.$inject = ['$sce', '$filter', 'efLibrary'];

    function efLookupValue($sce, $filter, efLibrary) {
        return function (value, options, optionsValueField, optionsLookupField, scope) {
            var html = "";
            var opts = null;
            if (efLibrary.isValid(options, true)) {
                var optionsType = typeof options;
                if (efLibrary.isValid(optionsType, true) && optionsType === 'string') {
                    opts = efLibrary.getObjectThroughAngularScope(scope, options);
                } else if (Array.isArray(options)) {
                    opts = efLibrary.copyObject(options);
                }
            }
            var valueField = efLibrary.isValid(optionsValueField, true) ? optionsValueField : "value";
            var lookupField = efLibrary.isValid(optionsLookupField, true) ? optionsLookupField : "label";
            var lookupOption = efLibrary.getFirstObjectById(valueField, value, opts);
            if (efLibrary.isValid(lookupOption) && efLibrary.isValid(lookupOption[lookupField])) {
                html = lookupOption[lookupField];
            }
            return $sce.trustAsHtml(html);
        };
    }
})();
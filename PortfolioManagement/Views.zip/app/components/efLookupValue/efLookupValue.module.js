﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc overview
 * @name efAngularLibrary.efLookupValue
 * @description 
 * 
 * efLookupValue module provides an Angular filter that lookups and returns a value from an object within the current Angular scope or within the current current Angular scope hierarchy. 
 * 
 * <a href="/app/#/demo/efLookupValue/demo">For complete implmentation details see the demo page.</a>
**/
(function () {
    angular.module('efAngularLibrary.efLookupValue', []);
})();
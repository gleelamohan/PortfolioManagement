﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efLookupValue')
        .config(config);

    config.$inject = ['$stateProvider'];

    function config($stateProvider) {
        $stateProvider
            .state('efAngularLibrary.efLookupValue', {
                abstract: true,
                url: "/efLookupValue",
                template: "<ui-view />"
            })
            .state('efAngularLibrary.efLookupValue.demo', {
                url: "/demo",
                templateUrl: "/app/components/efLookupValue/demo/efLookupValue.demo.html",
                controller: "EfLookupValueDemoCtrl",
                controllerAs: "vm"
            });
    };
})();
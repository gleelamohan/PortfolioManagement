﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efLookupValue')
        .controller('EfLookupValueDemoCtrl', EfLookupValueDemoCtrl);

    EfLookupValueDemoCtrl.$inject = ['$scope', '$state', '$sanitize', '$parse', '$filter', '$timeout', 'efLookupValueDemoApi'];

    function EfLookupValueDemoCtrl($scope, $state, $sanitize, $parse, $filter, $timeout, efLookupValueDemoApi) {
        var vm = this;

        vm.lookupValueObject = "362ee905-6a47-48ba-bde9-1dbfe5d793bc";
        vm.lookupValueString = "2747bc5b-e546-4046-8dda-66bfeffc6051";
        vm.options = efLookupValueDemoApi.courierTypes;
    };
})();

(function () {
    angular
        .module('app')
        .directive('ddbsUserSearch', ddbsUserSearch);

    ddbsUserSearch.$inject = ['$sce', '$filter', 'recursionHelper', 'userQueryApi'];

    function ddbsUserSearch($sce, $filter, recursionHelper, userQueryApi) {
        return {
            restrict: 'AEC',
            replace: false,
            scope: {
                selectedUsers: "=selectedusers",
                onSelectCallBack: "=onselectcallback",
                config: "=?",
                ngDisabled: "=?"
            },
            controller: function ($scope, userQueryApi) {
                var vm = this;
                vm.disabled = false;
                vm.placeholder = "";
              
                function handleDisabledUpdates(newValue) {
                    vm.disabled = newValue !== undefined && newValue !== null ? newValue : null;
                    if (vm.disabled)
                        vm.placeholder = "";
                }

                function handleSelectedResultUpdates(newData) {
                    var data = newData || null;
                    if (data) {
                        vm.selectedUsers = data;
                        //mapObject(data);
                    }
                };

                function handleConfigUpdates(newConfig) {
                    var config = bptIsValid(newConfig) ? newConfig : null;
                    vm.config = config !== undefined && config !== null ? config : {};
                    vm.placeholder = vm.config !== undefined && vm.config !== null && vm.config.placeholder !== undefined && vm.config.placeholder !== null && vm.config.placeholder.length > 0 ? vm.config.placeholder : "";
                    vm.defaultStatusName = vm.config !== undefined && vm.config !== null && vm.config.defaultStatusName !== undefined && vm.config.defaultStatusName !== null && vm.config.defaultStatusName.length > 0 ? vm.config.defaultStatusName : "";
                    vm.displayColumnText = (vm.config !== undefined && vm.config !== null && vm.config.displayColumnText !== undefined && vm.config.displayColumnText !== null && vm.config.displayColumnText.length > 0 ? JSON.parse(JSON.stringify(vm.config.displayColumnText)) : []);
                    }

                $scope.$watch('config', handleConfigUpdates, true);
                $scope.$watch('selectedUsers', handleSelectedResultUpdates, true);
                $scope.$watch('ngDisabled', handleDisabledUpdates, true);
                
                function getAllUsers() {                    
                    userQueryApi.getUsersForUserSearchControl().then(function (response) {
                        vm.users =[];
                        if (response.results) {
                            for (var i = 0; i < response.results.length; i++) {
                                var user = {
                                        Id: response.results[i].User_Id,
                                        FullNameWithPuid: response.results[i].FirstName + ' ' + response.results[i].LastName + '(' + response.results[i].User_Puid + ')',
                                        FullName : response.results[i].FirstName + ' ' +response.results[i].LastName
                                };
                                vm.users.push(user);
                            }
                        }
                        //vm.users = response.results;                        
                    }).catch(function(error) {
                        console.log(error);
                    });
                };

                getAllUsers();

                vm.fillUserInfo = function (item, model, label) {                    
                    vm.selected = "";
                    if (vm.selectedUsers === null)
                        vm.selectedUsers = [];

                    var isDuplicate = false;
                    for (var index = 0; index < vm.selectedUsers.length; index++) {
                        if (vm.selectedUsers[index].Id === model.Id) {
                            isDuplicate = true;
                            break;
                        }

                        //if (vm.selectedUsers[index].RecipientId === model.Id) {
                        //    isDuplicate = true;
                        //    break;
                        //}
                    }
                    if (!isDuplicate) {
                        var user = { Id: model.Id, UserFullName: model.FullName, StatusName: vm.defaultStatusName, IsRemovable: true };
                        vm.selectedUsers.push(user);
                    }
                    $scope.onSelectCallBack(vm.selectedUsers);

                }

                vm.removeUser = function (rowIndex) {
                    vm.selectedUsers.splice(rowIndex, 1);
                    $scope.onSelectCallBack(vm.selectedUsers);
                }

            },
            controllerAs: 'vm',
            templateUrl: '/app/components/ddbsUserSearch/ddbsUserSearch.html',
            compile: function (element) {
                return recursionHelper.compile(element);

            }
        };
    }
})();
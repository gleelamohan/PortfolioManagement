﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc directive
 * @name efAngularLibrary.efFocus.directive:efFocus
 * @scope
 * @restrict AC
 * @description 
 * 
 * efFocus is an Angular directive that allows an HTML tag to conditionally receive focus.
 * 
 * Example:
 * <pre>
 * <input type="text" ef-focus="vm.InputFocusBooleanVariable">
 * </pre>
 * 
 * @param {expression|boolean} efFocus The boolean expression/variable, that when evaluated to true, will give the associated HTML tag focus.
**/
(function () {
    angular
        .module('efAngularLibrary.efFocus')
        .directive('efFocus', efFocus);

    function efFocus() {
        return {
            restrict: 'AC',
            scope: {
                focusValue: "=efFocus"
            },
            link: function ($scope, $element, attrs) {
                $scope.$watch("focusValue", function (currentValue, previousValue) {
                    //if (currentValue === true && !previousValue) {
                    //    $element[0].focus();
                    //} else if (currentValue === false && previousValue) {
                    //    $element[0].blur();
                    //}
                    if (currentValue === true) {
                        $element[0].focus();
                        $scope.focusValue = false;
                    }
                });
            }
        };
    }
})();
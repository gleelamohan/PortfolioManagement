﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efFocus')
        .config(config);

    config.$inject = ['$stateProvider'];

    function config($stateProvider) {
        $stateProvider
            .state('efAngularLibrary.efFocus', {
                abstract: true,
                url: "/efFocus",
                template: "<ui-view />"
            });
    };
})();
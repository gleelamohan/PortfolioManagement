﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc overview
 * @name efAngularLibrary.efFocus
 * @description 
 * 
 * efFocus module provides an Angular directive that allows an HTML tag to conditionally receive focus.
 * 
**/
(function () {
    angular.module('efAngularLibrary.efFocus', []);
})();
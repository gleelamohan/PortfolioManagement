﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efUiGrid')
        .controller('EfUiGridDemoCtrl', EfUiGridDemoCtrl);

    EfUiGridDemoCtrl.$inject = ['$scope', '$state', '$sanitize', '$parse', '$filter', '$timeout', '$compile', '$http', '$interval', 'toastr', 'efLibrary', 'efEntityApi', 'efUiGridApi', 'efUiGridDemoApi', 'uiGridConstants'];

    function EfUiGridDemoCtrl($scope, $state, $sanitize, $parse, $filter, $timeout, $compile, $http, $interval, toastr, efLibrary, efEntityApi, efUiGridApi, efUiGridDemoApi, uiGridConstants) {
        var vm = this;
        vm.callbackTimeout = 0;

        //#region Setup Demo Options

        vm.modeSelectConfig = {
            "allowDuplicates": false,
            "placeholder": "Select efUiGrid mode...",
            "options": [
                { "value": "display", "label": "Display only" },
                { "value": "select", "label": "Display only w/ single row select" },
                { "value": "multiselect", "label": "Display only w/ multi row select" },
                { "value": "editable", "label": "Editable" },
                { "value": "editableselect", "label": "Editable w/ single row select" },
                { "value": "editablemultiselect", "label": "Editable w/ multi row select" },
                { "value": "custom", "label": "Custom Configuration Mode" },
            ],
            "width": "100%"
        };

        //#endregion

        //#region Screen Update Functions

        vm.updateScreenWithChanges = function () {
            $timeout(function () {
                vm.taskTemplatesEntity.checkForChanges();
            }, vm.callbackTimeout);
        }

        //#endregion

        //#region Grid Action Callbacks & Settings

        vm.selectedCallback = function () {
            var selectedCount = 0;
            if (efLibrary.isValid(vm.gridSelected)) {
                selectedCount = vm.gridSelected.length;
            }
            toastr.info("efUiGrid.selectedCallback() was called.  " + selectedCount + " rows selected.");
        }

        //vm.beginCellEditCallback gets called before EVERY cell edit
        vm.beginCellEditCallback = function (rowEntity, colDef, triggerEvent) {
            //var cellEditMessage = '*** Begin Cell Edit ***<br/>Edited row id: ' + rowEntity.TaskListTemplateTaskTemplateId + '<br/>Column: ' + colDef.name;
            //toastr.info(cellEditMessage);
        }

        //vm.afterCellEditCallback gets called after EVERY cell edit regardless if a value was changed or not
        vm.afterCellEditCallback = function (rowEntity, colDef, newValue, oldValue) {
            //var cellEditMessage = '*** After Cell Edit ***<br/>Edited row id: ' + rowEntity.TaskListTemplateTaskTemplateId + '<br/>Column: ' + colDef.name + '<br/>newValue: ' + newValue + '<br/>oldValue: ' + oldValue;
            //toastr.info(cellEditMessage);
        }

        //vm.afterCellChangedCallback gets called after a cell edit only when the value was changed
        vm.afterCellChangedCallback = function (rowEntity, colDef, newValue, oldValue) {
            //Get editModelField first (if avilable), otherwise field 
            var editColumn = efLibrary.isValid(colDef.editModelField, true) ? colDef.editModelField : (efLibrary.isValid(colDef.field, true) ? colDef.field : null);
            if (efLibrary.isValid(editColumn, true)) {
                if (editColumn === "TaskTemplateId") {
                    //TaskTemplateId is a drop down and given that TaskTemplate.Name is in the DTO we need to get th value for the current TaskTemplateId
                    //To do this, we need to make sure the TaskTemplate default object in the data
                    rowEntity.TaskTemplate = (efLibrary.isValid(vm.taskTemplatesEntity.defaultDataTemplate) && efLibrary.isValid(vm.taskTemplatesEntity.defaultDataTemplate.TaskTemplate)) ? vm.taskTemplatesEntity.copyObject(vm.taskTemplatesEntity.defaultDataTemplate.TaskTemplate) : {};
                    rowEntity.TaskTemplate.TaskTemplateId = newValue;
                    rowEntity.TaskTemplate.Name = String($filter("efLookupValue")(newValue, vm.taskTemplateNameSelectConfig.options));
                }

                if (editColumn === "IsTimeDependent" && newValue !== true) {
                    //This clears out the TimeDuration and TimeUnit fields when IsTimeDependent is false
                    rowEntity.TimeDuration = null;
                    rowEntity.TimeUnit = null;
                }

                //AdministrativeCustomerFrameworkId uses the efSelect modelData (via the getModelData attribute) to get the name and status
                if (editColumn === "AdministrativeCustomerFrameworkId") {
                    if (efLibrary.isValid(vm.administrativeCustomerFrameworkSearchModelData) &&
                        efLibrary.isValid(vm.administrativeCustomerFrameworkSearchModelData.data)) {
                        rowEntity.AdministrativeCustomerFrameworkName = efLibrary.isValid(vm.administrativeCustomerFrameworkSearchModelData.data.Name, true) ? vm.administrativeCustomerFrameworkSearchModelData.data.Name : null;
                        rowEntity.AdministrativeCustomerFrameworkStatus = efLibrary.isValid(vm.administrativeCustomerFrameworkSearchModelData.data.Status, true) ? vm.administrativeCustomerFrameworkSearchModelData.data.Status : null;
                    } else {
                        rowEntity.AdministrativeCustomerFrameworkName = null;
                        rowEntity.AdministrativeCustomerFrameworkStatus = null;
                    }
                }

                rowEntity.DataState = "Modified";

                vm.updateScreenWithChanges();

                // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                // If have updateEntity = true on efInput, you can either do nothing or save to service tier here if you need to.
                // If have updateEntity = false on efInput, you can call vm.taskTemplatesEntity.changeFieldData(editColumn, rowEntity, "edit", true, true) and process the outcome
                // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                //if (vm.taskTemplatesEntity.changeFieldData(editColumn, rowEntity, "edit", true, true)) {
                //    //Change Ok!
                //} else {
                //    //Change Failed - Rollback the change!
                //}
            }

            var cellChangedMessage = '*** After Cell Changed ***' +
                '<br/>Edited row id: ' + rowEntity.TaskListTemplateTaskTemplateId +
                    '<br/>Column: ' + colDef.editModelField +
                    '<br/>newValue: ' + newValue +
                    '<br/>oldValue: ' + oldValue;
            toastr.info(cellChangedMessage);
        }

        vm.isTimeDependentCellEditableCondition = function (scope) {
            var returnValue = false;
            if (efLibrary.isValid(scope) &&
                efLibrary.isValid(scope.row) &&
                efLibrary.isValid(scope.row.entity)) {
                returnValue = efLibrary.toBoolean(scope.row.entity.IsTimeDependent, false);
            }
            return returnValue;
        }

        vm.taskTemplatesMoveRowButtonIdPrefix = "efTaskTemplates";
        vm.taskTemplatesOrderPositionField = "OrderNumber";
        vm.taskTemplatesDisableOnChangesExistCssClass = "efTaskTemplatesDisableOnChangesExist";
        vm.taskTemplatesIdField = "TaskListTemplateTaskTemplateId";

        //See the efSelect.config.json file for all available options
        vm.taskTemplateNameSelectConfig = {
            "mode": "select",
            "placeholder": String($filter("trustedtranslate")("Entity.TaskTemplate.Name.SelectPlaceholder")),
            "options": [],  //This is set below after the list of TaskTemplates is retrieved (but before the editable DT is configured)
            "optionsListMaxWidth": "300px",
            "optionsListMaxHeight": "200px",
            "optionsListScrollOnWideOptions": true,
            "width": "100%"
        };

        var displayGridActionConfig = efUiGridApi.getActionColumnsConfig("taskListTemplateGrid", vm.taskTemplatesIdField);
        //DEVELOPER NOTE - If your table has multiple linkOut buttons, you will need to create a seperate Action Columns Config for each linkOut!!
        displayGridActionConfig.linkOut.displayAction = true;
        displayGridActionConfig.linkOut.callback = "vm.linkOutCallback";

        var editableGridActionConfig = efUiGridApi.getActionColumnsConfig("taskListTemplateGrid", vm.taskTemplatesIdField, vm.taskTemplatesDisableOnChangesExistCssClass);
        editableGridActionConfig.moveRow.displayAction = true;
        editableGridActionConfig.moveRow.callback = "vm.moveRowCallback";
        editableGridActionConfig.moveRow.moveRowButtonIdPrefix = vm.taskTemplatesMoveRowButtonIdPrefix;
        editableGridActionConfig.moveRow.orderPositionField = vm.taskTemplatesOrderPositionField;

        editableGridActionConfig.insertRow.displayAction = true;
        editableGridActionConfig.insertRow.callback = "vm.insertRowCallback";

        editableGridActionConfig.saveRow.displayAction = true;
        editableGridActionConfig.saveRow.callback = "vm.saveRowCallback";

        editableGridActionConfig.copyRow.displayAction = true;
        editableGridActionConfig.copyRow.callback = "vm.insertRowCallback";

        editableGridActionConfig.deleteRow.displayAction = true;
        editableGridActionConfig.deleteRow.callback = "vm.deleteRowCallback";
        //editableGridActionConfig.deleteRow.disableButtonOnEdit = false;

        //DEVELOPER NOTE - If your table has multiple linkOut buttons, you will need to create a seperate Action Columns Config for each linkOut!!
        editableGridActionConfig.linkOut.displayAction = true;
        editableGridActionConfig.linkOut.callback = "vm.linkOutCallback";
        editableGridActionConfig.linkOut.alternateLabel = "<i class=\"fa fa-indent\"></i>";

        vm.linkOutCallback = function (id) {
            toastr.info("vm.linkOutCallback() was called for id: " + id);
        }

        vm.moveRowCallback = function (id, newOrderNumber) {
            toastr.info("vm.moveRowCallback() was called for id: " + id + "<br/>New order number: " + String(newOrderNumber));
        }

        vm.saveRowCallback = function (id) {
            toastr.info("vm.saveRowCallback() was called for id: " + id);
        }

        //vm.deleteRowCallback = function (id) {
        //    toastr.info("vm.deleteRowCallback() was called for id: " + id);
        //}

        //#endregion

        //#region Setup Grid Options

        vm.gridMode = "editable";
        vm.gridView = "standard";
        vm.gridSelected = [];
        vm.setSelectedValues = ["d5989204-5716-4b6e-bda3-dfe76b438c89", "f16fb6e1-78a2-403e-ac3c-85d59b432543"];

        vm.gridOptions = null;
        vm.templateUrl = null;

        vm.taskTemplateIdCellEditorTemplate = {
            "type": "efSelect",
            "mode": "select",
            "getConfig": "efLibrary.getObjectThroughAngularScope($scope, 'vm.taskTemplateNameSelectConfig')",
            "getOptions": "efLibrary.getObjectThroughAngularScope($scope, 'vm.taskTemplateNameSelectConfig.options')",
            "width": "200px"
        };

        vm.isTimeDependentCellEditorTemplate = {
            "type": "checkbox"
        };

        vm.timeDurationCellEditorTemplate = {
            "type": "number",
            "placeholder": String($filter("trustedtranslate")("Entity.TaskTemplate.TimeDuration.InputPlaceholder")),
            "min": "0",
            "max": "999.99",
            "width": "100px"
        };

        vm.timeUnitCellEditorTemplate = [
            {
                "type": "radio",
                "placeholder": "Hours",
                "name": "TimeUnit",
                "value": "Hours",
                "suffixHTML": "&nbsp;"
            },
            {
                "type": "radio",
                "placeholder": "Days",
                "name": "TimeUnit",
                "value": "Days"
            }
        ];

        vm.taskStartDateTimeTemplate = {
            "type": "efDatetime",
            "config": { startView: 'day', minView: 'minute', minuteStep: 1 },
            "placeholder": "Select Task Date Time",
            "width": "250px"
        };

        vm.getGridSettings = function (mode) {
            vm.templateUrl = null;
            //Developer note! - If you change the grid's configuration at runtime, you need to first reset the gridOptions JSON object to null before making the changes.  
            vm.gridOptions = null;
            if (efLibrary.isValid(mode, true)) {
                if (mode.toLowerCase() === "custom") {
                    //Please note that when templateUrl is used, it MUST be set before vm.gridOptions
                    vm.templateUrl = "/app/components/efUiGrid/demo/efUiGrid.demo.custom.html";
                }

                switch (mode.toLowerCase()) {
                    case "display":
                    case "select":
                    case "multiselect":
                        vm.gridOptions = efUiGridDemoApi.uiGridDisplayConfig(displayGridActionConfig);
                        break;
                    case "editable":
                    case "editableselect":
                    case "editablemultiselect":
                        vm.gridOptions = efUiGridDemoApi.uiGridEditableConfig(editableGridActionConfig, vm.isTimeDependentCellEditableCondition);
                        break;
                    case "custom":
                        //Please note that when templateUrl is used, it MUST be set before vm.gridOptions
                        vm.gridOptions = efUiGridDemoApi.uiGridCustomConfig();
                        break;
                    default:
                        vm.gridOptions = null;
                        break;
                }
            }
        }
        vm.getGridSettings(vm.gridMode);

        vm.setSelectedClick = function () {
            vm.gridSelected = vm.setSelectedValues;
        }

        //#endregion

        //#region Setup Entity Object

        //Task Templates
        vm.taskTemplatesEntity = efEntityApi.createEntityHelper();
        vm.taskTemplatesEntity.idField = vm.taskTemplatesIdField;
        vm.taskTemplatesEntity.prefixFieldForErrorDisplayText = "TaskTemplate.Name";

        vm.taskTemplatesEntity.orderPositionField = vm.taskTemplatesOrderPositionField;
        vm.taskTemplatesEntity.disableOnChangesExistCssClass = vm.taskTemplatesDisableOnChangesExistCssClass;
        vm.taskTemplatesEntity.moveRowButtonIdPrefix = vm.taskTemplatesMoveRowButtonIdPrefix;

        vm.taskTemplatesEntity.i18nMessages.errorTextHeader = String($filter("trustedtranslate")("Views.TaskTemplate.TaskTemplateValidationHeaderText"));
        vm.taskTemplatesEntity.i18nMessages.errorTextHeaderSuffix = String($filter("trustedtranslate")("efAngularLibrary.Common.Maintenance.ValidationHeaderSuffix"));
        vm.taskTemplatesEntity.i18nMessages.noErrorsFound = String($filter("trustedtranslate")("Views.TaskTemplate.TaskTemplateValidationOkText"));

        var ttValidations = efUiGridDemoApi.taskTemplatesFieldValidations(vm.currentLanguage);
        if (ttValidations !== undefined && ttValidations !== null) {
            vm.taskTemplatesEntity.validationFunctions = ttValidations;
        }

        vm.taskTemplatesEntity.defaultDataTemplate = efUiGridDemoApi.defaultTaskTemplate();

        //#endregion

        //#region Get Task List Templates

        vm.getTaskListTemplates = function () {
            //Reset all existing data (except for supplemental data)
            vm.taskTemplatesEntity.initAllData(false);

            var taskTemplates = efUiGridDemoApi.taskListTemplate.TaskTemplates;

            //Add datetime and acf fields for testing purposes
            for (var i = 0; i < taskTemplates.length; i++) {
                taskTemplates[i].TaskStartDateTime = moment();
                taskTemplates[i].AdministrativeCustomerFrameworkId = null;
                taskTemplates[i].AdministrativeCustomerFrameworkName = null;
                taskTemplates[i].AdministrativeCustomerFrameworkStatus = null;
            }

            //Set recordMultiplier <= 1 for orginal records
            //Set recordMultiplier > 1 for "n" copies of the orginal records
            var recordMultiplier = 1;
            //recordMultiplier = 100;
            if (recordMultiplier > 1) {
                var tempTaskTemplates = efLibrary.copyObject(taskTemplates);
                for (var i = 0; i < recordMultiplier; i++) {
                    for (var ii = 0; ii < tempTaskTemplates.length; ii++) {
                        taskTemplates.push(efLibrary.copyObject(tempTaskTemplates[ii]));
                    }
                }
                for (var i = 0; i < taskTemplates.length; i++) {
                    taskTemplates[i][vm.taskTemplatesEntity.orderPositionField] = i + 1;
                }
            }

            //Set the first record's TaskTemplateId to test for model load validation
            if (taskTemplates.length > 1) {
                taskTemplates[0].TaskTemplateId = null;
            }

            taskTemplates.sort(function (a, b) { return a[vm.taskTemplatesEntity.orderPositionField] < b[vm.taskTemplatesEntity.orderPositionField]; });
            vm.taskTemplatesEntity.setServiceData(taskTemplates);
            vm.taskTemplatesEntity.setData(taskTemplates);

            //If the only record is a new record then add it to changes and run checkForChanges
            if (vm.taskTemplatesEntity.data.length === 1 && vm.taskTemplatesEntity.data[0].DataState === "Created") {
                vm.taskTemplatesEntity.addToChanges(vm.taskTemplatesEntity.data[0]);
                vm.taskTemplatesEntity.checkForChanges();
            } else {
                vm.updateScreenWithChanges();
            }
        }

        //#endregion

        //#region Get supplemental data and then get TLT data

        var data = efUiGridDemoApi.taskTemplates;
        data.sort(function (a, b) { return a.Name.localeCompare(b.Name); });
        var availableTaskTemplates = {
            "id": "availableTaskTemplates",
            "data": vm.taskTemplatesEntity.copyObject(vm.taskTemplatesEntity.getLabelValueArray("Name", "TaskTemplateId", data))
        };
        vm.taskTemplatesEntity.addToSupplementalData(availableTaskTemplates);

        //Set the options for the Editable Datatable TaskTemplate bptSelect field
        vm.taskTemplateNameSelectConfig.options = vm.taskTemplatesEntity.getFirstValueById("id", "availableTaskTemplates", "data", vm.taskTemplatesEntity.supplementalData);

        vm.getTaskListTemplates();

        //#endregion

        //#region cancel button

        var refresh = function () {
            vm.refresh = true;
            $timeout(function () {
                vm.refresh = false;
            }, 0);
        };

        vm.gridCancel = function () {
            vm.taskTemplatesEntity.initChanges();
            vm.taskTemplatesEntity.setData(vm.taskTemplatesEntity.serviceData);
            refresh();
            vm.updateScreenWithChanges();
        }

        vm.getNewTaskTemplateEntity = function (taskListTemplateId) {
            var newData = JSON.parse((vm.taskTemplatesEntity.defaultDataTemplate !== undefined && vm.taskTemplatesEntity.defaultDataTemplate != null ? JSON.stringify(vm.taskTemplatesEntity.defaultDataTemplate) : "{}"));

            //Set the initial idField to something unique for the table (the actual id value will be set by the POST service)
            newData[vm.taskTemplatesEntity.idField] = efLibrary.newGuid();
            newData.OrderNumber = 0;
            newData.DataState = "Created";

            if (taskListTemplateId != undefined) {
                newData.TaskListTemplateId = taskListTemplateId;
            } else {
                newData.TaskListTemplateId = efUiGridDemoApi.taskListTemplate.TaskListTemplateId;
            }

            return newData;
        }

        vm.insertRowCallback = function (id, copyExisting) {
            var newData = vm.getNewTaskTemplateEntity();
            var rows = [];
            var row = null;
            if (!!id && id.length > 0) {
                rows = $.grep(vm.taskTemplatesEntity.data, function (e) { return e[vm.taskTemplatesEntity.idField] === id; });
                if (!!rows && rows.length > 0) {
                    row = rows[0];
                }
                if (!!row) {
                    newData.OrderNumber = ((!!row.OrderNumber) ? (parseInt(row.OrderNumber) + 1) : 0);
                    if (efLibrary.toBoolean((copyExisting, false))) {

                        //Add the fields in this section that you want included in the copy operation
                        newData.TaskTemplateId = row.TaskTemplateId;
                        newData.TaskTemplate = row.TaskTemplate;
                        newData.IsTimeDependent = row.IsTimeDependent;
                        newData.TimeDuration = row.TimeDuration;
                        newData.TimeUnit = row.TimeUnit;
                        newData.isRowNoModified = true;
                    }
                }

            }
            vm.taskTemplatesEntity.addToData(newData);

            //for (var i = 0; i < vm.gridOptions.data.length; i++) {
            //    if (vm.taskTemplatesEntity.serviceData[i][vm.taskTemplatesEntity.idField] === id) {
            //        vm.taskTemplatesEntity.serviceData[i] = vm.taskTemplatesEntity.copyObject(data);
            //    }
            //}

            $interval(function () {
                vm.gridApi.rowEdit.setRowsDirty([vm.taskTemplatesEntity.data[0]]);
                // vm.gridApi.rowEdit.setRowsDirty(vm.gridApi.grid, [newData]);
            }, 1, 1);
            refresh();

        }

        var moveRow = function (id, newRowNo, moveUp) {
            if (newRowNo !== 0) {

                if (id !== undefined && id !== null && id.length > 0 &&
                    newRowNo !== undefined && newRowNo !== null && !isNaN(newRowNo)) {

                    var rows = $.grep(vm.taskTemplatesEntity.data, function (e) { return e[vm.taskTemplatesEntity.idField] === id; });
                    var oldRowNo = rows[0].Row;
                    // rows[0].Row = newRowNo;
                    var existingRow = null;
                    while (existingRow === null) {
                        for (var i = 0; i < vm.taskTemplatesEntity.data.length; i++) {
                            if (vm.taskTemplatesEntity.data[i].OrderNumber === newRowNo) {
                                vm.taskTemplatesEntity.data[i].OrderNumber = oldRowNo;
                                vm.taskTemplatesEntity.data[i].isRowNoModified = true;
                                existingRow = (vm.taskTemplatesEntity.data[i]);
                            }

                        }
                        if (existingRow === null)
                            if (moveUp === true) {
                                newRowNo++;
                            } else {
                                newRowNo--;
                            }
                        else {

                            break;
                        }


                    }
                    rows.push(existingRow);
                    rows[0].OrderNumber = newRowNo;;
                    for (var i = 0; i < rows.length; i++) {

                        rows[i].DataState = 'Modified';
                    }

                }
            }
        }
        vm.gridApi;

        vm.moveRowCallback = function (id, newOrderNumber, moveUp) {
            if (!id || newOrderNumber == null || newOrderNumber < 0) return;

            var oldOrderNumber;

            for (var i = 0; i < vm.taskTemplatesEntity.data.length; i++) {
                if (vm.taskTemplatesEntity.data[i][vm.taskTemplatesEntity.idField] === id) {
                    oldOrderNumber = vm.taskTemplatesEntity.data[i].OrderNumber;
                    vm.taskTemplatesEntity.data[i].OrderNumber = newOrderNumber;
                    vm.taskTemplatesEntity.data[i].isOrderNumberModified = true;
                    vm.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
                    break;
                }
            }
            refresh();
        };


        vm.isRowSelectable = function (rowEntity) {
            if (!!rowEntity.TimeDuration)
                return true;
            else
                return false;
        }

        var deletedRows = [];

        vm.deleteRowCallback = function (id) {

            for (var i = 0; i < vm.taskTemplatesEntity.data.length; i++) {
                if (vm.taskTemplatesEntity.data[i][vm.taskTemplatesEntity.idField] === id) {
                    vm.taskTemplatesEntity.data[i].DataState = 'Deleted';
                    deletedRows.push(vm.taskTemplatesEntity.data[i]);
                    vm.taskTemplatesEntity.removeData(id);
                    refresh();
                }
            }
        }


        //#endregion

    };
})();

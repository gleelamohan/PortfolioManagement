﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efUiGrid')
        .factory('efUiGridDemoApi', efUiGridDemoApi);

    efUiGridDemoApi.$inject = ['$resource', '$filter', 'uiGridConstants', 'efLibrary', 'efUiGridConstants', 'efUiGridApi', 'efDatetimeMasks'];

    function efUiGridDemoApi($resource, $filter, uiGridConstants, efLibrary, efUiGridConstants, efUiGridApi, efDatetimeMasks) {
        var service = {};

        //#region efUiGrid Display Configuration 

        service.uiGridDisplayConfig = function (actionConfig) {

            //See http://ui-grid.info/docs/#/api for complete grid options

            var grid = efLibrary.copyObject(efUiGridApi.defaultGridConfig, true);
            grid.enableGridMenu = true; //The grid menu is displayed over the upper, right-hand portion of the last column

            var columnOrderNumber = efUiGridApi.getColumnDef("OrderNumber", "OrderNumber", String($filter("trustedtranslate")("Entity.TaskTemplate.OrderNumber.ColumnText")), true, uiGridConstants.ASC, false);
            columnOrderNumber.headerCellClass = "uiGrid_Column_Center";
            columnOrderNumber.headerCellTemplate = String($filter("efUiGridTemplateHeader")("#"));
            columnOrderNumber.headerTooltip = true;
            columnOrderNumber.cellClass = "uiGrid_Column_Center";
            columnOrderNumber.enableColumnMenu = true;
            columnOrderNumber.enableColumnMoving = true;
            columnOrderNumber.enableColumnResizing = false;
            columnOrderNumber.width = "60";
            columnOrderNumber.minWidth = "60";
            grid.columnDefs.push(columnOrderNumber);

            var columnTaskTemplateId = efUiGridApi.getColumnDef("TaskTemplateId", "TaskTemplateId", String($filter("trustedtranslate")("Entity.TaskTemplate.Name.ColumnText")), false, null, true);
            columnTaskTemplateId.cellFilter = "efLookupValue: 'vm.taskTemplateNameSelectConfig.options':'value':'label':this";
            columnTaskTemplateId.enableColumnMenu = true;
            columnTaskTemplateId.enableHiding = true;
            columnTaskTemplateId.enableColumnMoving = true;
            columnTaskTemplateId.width = "*";   //Auto width = "*" or ""
            columnTaskTemplateId.minWidth = "300";
            grid.columnDefs.push(columnTaskTemplateId);

            var columnIsTimeDependent = efUiGridApi.getColumnDef("IsTimeDependent", "IsTimeDependent", String($filter("trustedtranslate")("Entity.TaskTemplate.IsTimeDependent.ColumnText")), false, null, true);
            columnIsTimeDependent.headerCellTemplate = String($filter('efUiGridTemplateHeader')('<i class="fa fa-clock-o"></i>'));
            columnIsTimeDependent.headerTooltip = true;
            columnIsTimeDependent.headerCellClass = "uiGrid_Column_Center";
            columnIsTimeDependent.cellTemplate = String($filter('efUiGridTemplateCellBoolean')('IsTimeDependent'));
            columnIsTimeDependent.cellClass = "uiGrid_Column_Center";
            columnIsTimeDependent.enableColumnMenu = true;
            columnIsTimeDependent.enableHiding = true;
            columnIsTimeDependent.enableColumnMoving = true;
            columnIsTimeDependent.enableColumnResizing = false;
            columnIsTimeDependent.width = "60";
            columnIsTimeDependent.minWidth = "60";
            grid.columnDefs.push(columnIsTimeDependent);

            var columnTimeDuration = efUiGridApi.getColumnDef("TimeDuration", "TimeDuration", String($filter("trustedtranslate")("Entity.TaskTemplate.TimeDuration.ColumnText")), false, null, true);
            columnTimeDuration.headerCellClass = "uiGrid_Column_Center";
            columnTimeDuration.cellClass = "uiGrid_Column_Center";
            columnTimeDuration.enableColumnMenu = true;
            columnTimeDuration.enableHiding = true;
            columnTimeDuration.enableColumnMoving = true;
            columnTimeDuration.width = "*";   //Auto width = "*" or ""
            columnTimeDuration.minWidth = "150";
            grid.columnDefs.push(columnTimeDuration);

            var columnTimeUnit = efUiGridApi.getColumnDef("TimeUnit", "TimeUnit", String($filter("trustedtranslate")("Entity.TaskTemplate.TimeUnit.ColumnText")), false, null, true);
            columnTimeUnit.headerCellClass = "uiGrid_Column_Center";
            columnTimeUnit.cellClass = "uiGrid_Column_Center";
            columnTimeUnit.enableColumnMenu = true;
            columnTimeUnit.enableHiding = true;
            columnTimeUnit.enableColumnMoving = true;
            columnTimeUnit.width = "15%";
            columnTimeUnit.width = "*";   //Auto width = "*" or ""
            columnTimeUnit.minWidth = "150";
            grid.columnDefs.push(columnTimeUnit);

            //DEVELOPER NOTE - If your table has multiple linkOut buttons, you will need to create a seperate Action Columns Config for each linkOut!!
            grid.columnDefs.push(efUiGridApi.getActionColumnDef(efUiGridConstants.actionColumns.LINKOUT, actionConfig, "TaskListTemplateTaskTemplateId"));

            //See http://ui-grid.info/docs/#/tutorial/121_grid_menu for Grid Menu Details
            grid.gridMenuCustomItems = [
                {
                    title: 'Hide\\Show \'' + String($filter("trustedtranslate")("Entity.TaskTemplate.IsTimeDependent.ColumnText")) + '\' Columns',
                    action: function ($event) {
                        //You must copy the 'this.grid.options.columnDefs' first, then set the desired values to the copy, then set 'this.grid.options.columnDefs' to the copy
                        var columnDefs = efLibrary.copyObject(this.grid.options.columnDefs, true);
                        efUiGridApi.toggleColumnVisibility("IsTimeDependent", columnDefs);
                        efUiGridApi.toggleColumnVisibility("TimeDuration", columnDefs);
                        efUiGridApi.toggleColumnVisibility("TimeUnit", columnDefs);
                        this.grid.options.columnDefs = columnDefs;
                    },
                    order: 210      //See http://ui-grid.info/docs/#/tutorial/121_grid_menu for 'order' values
                },
                {
                    title: 'Hide \'' + String($filter("trustedtranslate")("Entity.TaskTemplate.Name.ColumnText")) + '\' Column',
                    action: function ($event) {
                        //Alternative use of efUiGridApi.toggleColumnVisibility:  add a 3rd boolean parameter to force set the column visibility to a given state, rather than toggle from true and false

                        //You must copy the 'this.grid.options.columnDefs' first, then set the desired values to the copy, then set 'this.grid.options.columnDefs' to the copy
                        var columnDefs = efLibrary.copyObject(this.grid.options.columnDefs, true);
                        efUiGridApi.toggleColumnVisibility("TaskTemplateId", columnDefs, false);
                        this.grid.options.columnDefs = columnDefs;
                    },
                    order: 220      //See http://ui-grid.info/docs/#/tutorial/121_grid_menu for 'order' values
                },
                {
                    title: 'Show \'' + String($filter("trustedtranslate")("Entity.TaskTemplate.Name.ColumnText")) + '\' Column',
                    action: function ($event) {
                        //Alternative use of efUiGridApi.toggleColumnVisibility:  add a 3rd boolean parameter to force set the column visibility to a given state, rather than toggle from true and false

                        //You must copy the 'this.grid.options.columnDefs' first, then set the desired values to the copy, then set 'this.grid.options.columnDefs' to the copy
                        var columnDefs = efLibrary.copyObject(this.grid.options.columnDefs, true);
                        efUiGridApi.toggleColumnVisibility("TaskTemplateId", columnDefs, true);
                        this.grid.options.columnDefs = columnDefs;
                    },
                    order: 230      //See http://ui-grid.info/docs/#/tutorial/121_grid_menu for 'order' values
                }
            ];

            return grid;
        }

        //#endregion

        //#region efUiGrid Editable Configuration 

        service.uiGridEditableConfig = function (actionConfig, isTimeDependentCellEditableCondition) {

            //See http://ui-grid.info/docs/#/api for complete grid options

            var grid = efLibrary.mergeObjects(efUiGridApi.defaultGridConfig, efUiGridApi.defaultGridEditorConfig);
            grid.rowHeight = "70";  //Extra height needed to display an validation messages
            grid.rowEditWaitInterval = -1;
            grid.enableFullRowSelection = false;

            var orderCellClass = function (grid, row, col, rowIndex, colIndex) {

                if (efLibrary.toBoolean(row.entity.isOrderNumberModified, false)) {
                    return 'grid-modified-rowNo';
                } else if (row.entity.DataState === 'UnChanged') {
                    return 'uiGrid_Column_Center';
                }
            }


            grid.columnDefs.push(efUiGridApi.getActionColumnDef(efUiGridConstants.actionColumns.PREFIX, actionConfig, "TaskListTemplateTaskTemplateId"));

            var columnOrderNumber = efUiGridApi.getColumnDef("OrderNumber", "OrderNumber", String($filter("trustedtranslate")("Entity.TaskTemplate.OrderNumber.ColumnText")), true, uiGridConstants.ASC, false);
            columnOrderNumber.headerCellClass = "uiGrid_Column_Center";
            columnOrderNumber.headerCellTemplate = String($filter("efUiGridTemplateHeader")("#"));
            columnOrderNumber.headerTooltip = true;
            columnOrderNumber.cellClass = orderCellClass;  //TO DO
            columnOrderNumber.enableColumnMenu = true;
            columnOrderNumber.enableColumnMoving = true;
            columnOrderNumber.enableColumnResizing = false;
            columnOrderNumber.width = "60";
            columnOrderNumber.minWidth = "60";
            grid.columnDefs.push(columnOrderNumber);

            //DEVELOPER NOTE - If your table has multiple linkOut buttons, you will need to create a seperate Action Columns Config for each linkOut!!
            var columnLinkOut = efUiGridApi.getActionColumnDef(efUiGridConstants.actionColumns.LINKOUT, actionConfig, "TaskListTemplateTaskTemplateId");
            columnLinkOut.enableColumnMoving = true;
            grid.columnDefs.push(columnLinkOut);

            var columnTaskTemplateId = efUiGridApi.getColumnDef("TaskTemplateId", "TaskTemplateId", String($filter("trustedtranslate")("Entity.TaskTemplate.Name.ColumnText")), false, null, true);
            columnTaskTemplateId.cellFilter = "efLookupValue: 'vm.taskTemplateNameSelectConfig.options':'value':'label':this";
            columnTaskTemplateId.width = "*";   //Auto width = "*" or ""
            columnTaskTemplateId.minWidth = "210";
            columnTaskTemplateId.editableCellTemplate = String($filter("efUiGridTemplateCellEditorEfInput")("vm.taskTemplateIdCellEditorTemplate", "vm.taskTemplatesEntity", "validate-after-model-change=\"true\" validate-after-edit=\"true\" update-entity=\"true\" update-model-on-error=\"true\" display-error=\"true\" "));
            grid.columnDefs.push(columnTaskTemplateId);

            var columnIsTimeDependent = efUiGridApi.getColumnDef("IsTimeDependent", "IsTimeDependent", String($filter("trustedtranslate")("Entity.TaskTemplate.IsTimeDependent.ColumnText")), false, null, true);
            columnIsTimeDependent.headerCellTemplate = String($filter('efUiGridTemplateHeader')('<i class="fa fa-clock-o"></i>'));
            columnIsTimeDependent.headerTooltip = true;
            columnIsTimeDependent.headerCellClass = "uiGrid_Column_Center";
            columnIsTimeDependent.cellTemplate = String($filter('efUiGridTemplateCellBoolean')('IsTimeDependent'));
            columnIsTimeDependent.cellClass = "uiGrid_Column_Center";
            columnIsTimeDependent.enableColumnResizing = false;
            columnIsTimeDependent.width = "60";
            columnIsTimeDependent.minWidth = "60";
            columnIsTimeDependent.editableCellTemplate = String($filter("efUiGridTemplateCellEditorEfInput")("vm.isTimeDependentCellEditorTemplate", "vm.taskTemplatesEntity", "validate-after-model-change=\"true\" validate-after-edit=\"true\" update-entity=\"true\" update-model-on-error=\"true\" display-error=\"true\" "));
            grid.columnDefs.push(columnIsTimeDependent);

            var columnTimeDuration = efUiGridApi.getColumnDef("TimeDuration", "TimeDuration", String($filter("trustedtranslate")("Entity.TaskTemplate.TimeDuration.ColumnText")), false, null, true);
            columnTimeDuration.headerCellClass = "uiGrid_Column_Center";
            columnTimeDuration.cellClass = "uiGrid_Column_Center";
            columnTimeDuration.width = "*";   //Auto width = "*" or ""
            columnTimeDuration.minWidth = "110";
            columnTimeDuration.cellEditableCondition = isTimeDependentCellEditableCondition;
            columnTimeDuration.editableCellTemplate = String($filter("efUiGridTemplateCellEditorEfInput")("vm.timeDurationCellEditorTemplate", "vm.taskTemplatesEntity", "validate-after-model-change=\"true\" validate-after-edit=\"true\" update-entity=\"true\" update-model-on-error=\"true\" display-error=\"true\" "));
            grid.columnDefs.push(columnTimeDuration);

            var columnTimeUnit = efUiGridApi.getColumnDef("TimeUnit", "TimeUnit", String($filter("trustedtranslate")("Entity.TaskTemplate.TimeUnit.ColumnText")), false, null, true);
            columnTimeUnit.headerCellClass = "uiGrid_Column_Center";
            columnTimeUnit.cellClass = "uiGrid_Column_Center";
            columnTimeUnit.width = "*";   //Auto width = "*" or ""
            columnTimeUnit.minWidth = "125";
            columnTimeUnit.cellEditableCondition = isTimeDependentCellEditableCondition;
            columnTimeUnit.editableCellTemplate = String($filter("efUiGridTemplateCellEditorEfInput")("vm.timeUnitCellEditorTemplate", "vm.taskTemplatesEntity", "validate-after-model-change=\"true\" validate-after-edit=\"true\" update-entity=\"true\" update-model-on-error=\"true\" display-error=\"true\" width=\"100%\" "));
            grid.columnDefs.push(columnTimeUnit);

            //The following field was added for demonstration purposes only to show the use of the efDatetime control
            //In a production scenario, displayName and the placeholder in the editableCellTemplate should be a translated value
            var columnTaskStartDateTime = efUiGridApi.getColumnDef("TaskStartDateTime", "TaskStartDateTime", "Start Date/Time", false, null, true);
            columnTaskStartDateTime.cellFilter = "date: '" + efDatetimeMasks.datetime.angular + "'";
            columnTaskStartDateTime.width = "*";   //Auto width = "*" or ""
            columnTaskStartDateTime.minWidth = "260";
            columnTaskStartDateTime.editableCellTemplate = String($filter("efUiGridTemplateCellEditorEfInput")("vm.taskStartDateTimeTemplate", "vm.taskTemplatesEntity"));
            grid.columnDefs.push(columnTaskStartDateTime);

            //The follow can be placed in the table for debugging purposes
            //var columnDataState = efUiGridApi.getColumnDef("DataState", "DataState", "Data State");
            //columnDataState.headerCellClass = "uiGrid_Column_Center";
            //columnDataState.cellClass = "uiGrid_Column_Center";
            //columnDataState.width = "75";
            //columnDataState.minWidth = "75";
            //grid.columnDefs.push(columnDataState);

            grid.columnDefs.push(efUiGridApi.getActionColumnDef(efUiGridConstants.actionColumns.SUFFIX, actionConfig, "TaskListTemplateTaskTemplateId"));

            return grid;
        }

        //#endregion

        //#region efUiGrid Custom Configuration 

        service.uiGridCustomConfig = function () {

            //See http://ui-grid.info/docs/#/api for complete grid options

            var grid = {};
            grid.enableSorting = true;
            grid.enableHorizontalScrollbar = 0; //0=never, 1 = always, 2 = when needed
            grid.enableVerticalScrollbar = 0; //0=never, 1 = always, 2 = when needed

            grid.columnDefs = [
                {
                    name: 'OrderNumber',
                    field: 'OrderNumber',
                    displayName: String($filter("trustedtranslate")("Entity.TaskTemplate.OrderNumber.ColumnText")),
                    headerCellTemplate: String($filter("efUiGridTemplateHeader")("#")),
                    headerCellClass: 'uiGrid_Column_Center',
                    headerTooltip: true,
                    cellClass: 'uiGrid_Column_Center',
                    cellTooltip: false,
                    enableColumnMenu: true,
                    enableFiltering: true,
                    enableHiding: false,
                    enableSorting: true,
                    suppressRemoveSort: true,
                    sort: {
                        direction: uiGridConstants.ASC,
                        ignoreSort: false
                    },
                    allowCellFocus: true,
                    visible: true,
                    width: '5%'
                },
                {
                    name: 'TaskTemplateId',
                    field: 'TaskTemplate.Name',
                    displayName: String($filter("trustedtranslate")("Entity.TaskTemplate.Name.ColumnText")),
                    headerCellClass: 'uiGrid_Column_Left',
                    headerTooltip: false,
                    cellClass: 'uiGrid_Column_Left',
                    cellTooltip: false,
                    enableColumnMenu: false,
                    enableFiltering: true,
                    enableHiding: false,
                    enableSorting: false,
                    suppressRemoveSort: false,
                    allowCellFocus: true,
                    visible: true,
                    width: '*'
                },
                {
                    name: 'IsTimeDependent',
                    field: 'IsTimeDependent',
                    displayName: String($filter("trustedtranslate")("Entity.TaskTemplate.IsTimeDependent.ColumnText")),
                    headerCellTemplate: String($filter('efUiGridTemplateHeader')('<i class="fa fa-clock-o"></i>')),
                    headerCellClass: 'uiGrid_Column_Center',
                    headerTooltip: true,
                    cellTemplate: String($filter('efUiGridTemplateCellBoolean')('IsTimeDependent')),
                    cellClass: 'uiGrid_Column_Center',
                    cellTooltip: false,
                    enableColumnMenu: false,
                    enableFiltering: true,
                    enableHiding: false,
                    enableSorting: false,
                    suppressRemoveSort: false,
                    allowCellFocus: true,
                    visible: true,
                    width: '5%'
                },
                {
                    name: 'TimeDuration',
                    field: 'TimeDuration',
                    displayName: String($filter("trustedtranslate")("Entity.TaskTemplate.TimeDuration.ColumnText")),
                    headerCellClass: 'uiGrid_Column_Center',
                    headerTooltip: false,
                    cellClass: 'uiGrid_Column_Center',
                    cellTooltip: false,
                    enableColumnMenu: false,
                    enableFiltering: true,
                    enableHiding: false,
                    enableSorting: false,
                    suppressRemoveSort: false,
                    allowCellFocus: true,
                    visible: true,
                    width: '15%'
                },
                {
                    name: 'TimeUnit',
                    field: 'TimeUnit',
                    displayName: String($filter("trustedtranslate")("Entity.TaskTemplate.TimeUnit.ColumnText")),
                    headerCellClass: 'uiGrid_Column_Center',
                    headerTooltip: false,
                    cellClass: 'uiGrid_Column_Center',
                    cellTooltip: false,
                    enableColumnMenu: false,
                    enableFiltering: true,
                    enableHiding: false,
                    enableSorting: false,
                    suppressRemoveSort: false,
                    allowCellFocus: true,
                    visible: true,
                    width: '15%'
                }
            ];

            //Selection Options - Will only be used when "custom" mode is selected.
            grid.enableRowSelection = true;             //Enable/disable selction by clicking on the row             
            grid.enableFullRowSelection = true;         //Enable/disable selction by clicking on the row  
            grid.enableRowHeaderSelection = false;       //Enable/disable selection row and header
            grid.noUnselect = false;                    //Enable/disable the abilility to unselect a row (true = no unselect)
            grid.multiSelect = true;                    //Enable/Disable multi-select
            grid.enableSelectAll = false;                //Enable/disable select-all in header
            grid.modifierKeysToMultiSelect = false;     //Enable/disable the us on ctrl key on multi-selects

            grid.enableCellEdit = false;
            grid.enableCellEditOnFocus = false;

            return grid;
        }

        //#endregion

        //#region Field Validations

        service.taskTemplatesFieldValidations = function (currentLanguage) {
            return [
                {
                    "field": "TimeDuration",
                    "validationFunction": function (val, data, ignoreDependentRules) {
                        var returnValue = [];
                        if (!isNaN(val)) {
                            var numVal = Number(val);
                            if (numVal < 0 || numVal > 999.999) {
                                returnValue.push({
                                    "name": "TimeDuration",
                                    "status": String($filter("trustedtranslate")("Views.TaskTemplate.ValidationMessages.TimeDurationFormat"))
                                });
                            }
                        } else {
                            returnValue.push({
                                "name": "TimeDuration",
                                "status": String($filter("trustedtranslate")("Views.TaskTemplate.ValidationMessages.TimeDurationFormat"))
                            });
                        }

                        //The following rules are dependent on other field data
                        if (!ignoreDependentRules &&
                            data !== undefined && data !== null &&
                            data.IsTimeDependent !== undefined && data.IsTimeDependent !== null &&
                            data.IsTimeDependent == true) {

                            if (val === undefined || val === null || val.length === 0) {
                                returnValue.push({
                                    "name": "TimeDuration",
                                    "status": String($filter("trustedtranslate")("Views.TaskTemplate.ValidationMessages.TimeDurationRequired"))
                                });
                            }

                        }
                        return returnValue;
                    }
                },
                {
                    "field": "TimeUnit",
                    "validationFunction": function (val, data, ignoreDependentRules) {
                        var returnValue = [];

                        //The following rules are dependent on other field data
                        if (!ignoreDependentRules &&
                            data !== undefined && data !== null &&
                            data.IsTimeDependent !== undefined && data.IsTimeDependent !== null &&
                            data.IsTimeDependent == true) {

                            if (val === undefined || val === null || val.length === 0) {
                                returnValue.push({
                                    "name": "TimeUnit",
                                    "status": String($filter("trustedtranslate")("Views.TaskTemplate.ValidationMessages.TimeUnitRequired"))
                                });
                            }

                        }

                        return returnValue;
                    }
                },
                {
                    "field": "TaskTemplateId",
                    "validationFunction": function (val, data, ignoreDependentRules) {
                        var returnValue = [];
                        if (val === undefined || val === null || val.length === 0) {
                            returnValue.push({
                                "name": "TaskTemplateId",
                                "status": String($filter("trustedtranslate")("Views.TaskTemplate.ValidationMessages.TaskTemplateIdRequired"))
                            });
                        }
                        return returnValue;
                    }
                },
            ];
        }

        //#endregion

        //#region Default Entity Object

        service.defaultTaskTemplate = function () {
            return {
                "TaskListTemplateTaskTemplateId": null,
                "TaskListTemplateId": null,
                "TaskTemplateId": null,
                "TaskTemplate": {
                    "TaskTemplateId": null,
                    "Name": null,
                    "Description": null,
                    "DataState": "Unchanged"
                },
                "OrderNumber": 0,
                "IsTimeDependent": false,
                "TimeDuration": null,
                "TimeUnit": null,
                "DataState": "Created"
            };
        }

        //#endregion

        //#region Service Data

        service.taskListTemplate = {
            "TaskListTemplateId": "6254c43e-fa1b-428f-bfdb-0e32fcb2e061",
            "Name": "Method 0493 - Ecoli Presence/Absence",
            "AdministrativeCustomerFrameworkId": "e700dcc3-e10e-4c85-8024-2ef5c2b77689",
            "AdministrativeCustomerFramework": {
                "AdministrativeCustomerFrameworkId": "e700dcc3-e10e-4c85-8024-2ef5c2b77689",
                "Name": "General Microbiology Task List Templates",
                "Description": null,
                "CommercialCustomerFrameworkId": null,
                "CommercialCustomerFramework": null,
                "OrganizationalFrameworkId": null,
                "OrganizationalFramework": null,
                "Code": "UPDATE_CODE",
                "Status": "Active",
                "DataState": "Unchanged"
            },
            "TaskTemplates": [
                {
                    "TaskListTemplateTaskTemplateId": "1fffc272-851c-4157-8419-6e90dcdfb4cf",
                    "TaskListTemplateId": "6254c43e-fa1b-428f-bfdb-0e32fcb2e061",
                    "TaskTemplateId": "9a17904f-15e5-414a-a501-f4095e5e62f5",
                    "TaskTemplate": {
                        "TaskTemplateId": "9a17904f-15e5-414a-a501-f4095e5e62f5",
                        "Name": "Micro-Prep (Transfer)",
                        "Description": null,
                        "DataState": "Unchanged"
                    },
                    "OrderNumber": 4,
                    "IsTimeDependent": false,
                    "TimeDuration": null,
                    "TimeUnit": null,
                    "DataState": "Unchanged"
                },
                {
                    "TaskListTemplateTaskTemplateId": "fdcacc1e-cc75-4197-ae38-7276a93a71b5",
                    "TaskListTemplateId": "6254c43e-fa1b-428f-bfdb-0e32fcb2e061",
                    "TaskTemplateId": "ab74d67d-40dd-41f4-bd51-2cbb1a1fe50f",
                    "TaskTemplate": {
                        "TaskTemplateId": "ab74d67d-40dd-41f4-bd51-2cbb1a1fe50f",
                        "Name": "Micro-Incubate",
                        "Description": null,
                        "DataState": "Unchanged"
                    },
                    "OrderNumber": 5,
                    "IsTimeDependent": true,
                    "TimeDuration": 5,
                    "TimeUnit": "Hours",
                    "DataState": "Unchanged"
                },
                {
                    "TaskListTemplateTaskTemplateId": "f16fb6e1-78a2-403e-ac3c-85d59b432543",
                    "TaskListTemplateId": "6254c43e-fa1b-428f-bfdb-0e32fcb2e061",
                    "TaskTemplateId": "0bab66a1-7233-43ba-9bac-89161c33f52b",
                    "TaskTemplate": {
                        "TaskTemplateId": "0bab66a1-7233-43ba-9bac-89161c33f52b",
                        "Name": "Micro-Prep (Streak)",
                        "Description": null,
                        "DataState": "Unchanged"
                    },
                    "OrderNumber": 6,
                    "IsTimeDependent": false,
                    "TimeDuration": null,
                    "TimeUnit": null,
                    "DataState": "Unchanged"
                },
                {
                    "TaskListTemplateTaskTemplateId": "4f95abf3-5ed3-45a2-8377-8acf0475b70a",
                    "TaskListTemplateId": "6254c43e-fa1b-428f-bfdb-0e32fcb2e061",
                    "TaskTemplateId": "68486aec-eb3f-4e77-9b3d-d193afc208f7",
                    "TaskTemplate": {
                        "TaskTemplateId": "68486aec-eb3f-4e77-9b3d-d193afc208f7",
                        "Name": "Micro-Read MAC Plates",
                        "Description": null,
                        "DataState": "Unchanged"
                    },
                    "OrderNumber": 8,
                    "IsTimeDependent": false,
                    "TimeDuration": null,
                    "TimeUnit": null,
                    "DataState": "Unchanged"
                },
                {
                    "TaskListTemplateTaskTemplateId": "943d31b6-f055-4ac9-9a81-a52a5aad002e",
                    "TaskListTemplateId": "6254c43e-fa1b-428f-bfdb-0e32fcb2e061",
                    "TaskTemplateId": "ab74d67d-40dd-41f4-bd51-2cbb1a1fe50f",
                    "TaskTemplate": {
                        "TaskTemplateId": "ab74d67d-40dd-41f4-bd51-2cbb1a1fe50f",
                        "Name": "Micro-Incubate",
                        "Description": null,
                        "DataState": "Unchanged"
                    },
                    "OrderNumber": 7,
                    "IsTimeDependent": true,
                    "TimeDuration": 2,
                    "TimeUnit": "Days",
                    "DataState": "Unchanged"
                },
                {
                    "TaskListTemplateTaskTemplateId": "94243e79-68fa-4534-a56f-dbfd68cacaa6",
                    "TaskListTemplateId": "6254c43e-fa1b-428f-bfdb-0e32fcb2e061",
                    "TaskTemplateId": "ab74d67d-40dd-41f4-bd51-2cbb1a1fe50f",
                    "TaskTemplate": {
                        "TaskTemplateId": "ab74d67d-40dd-41f4-bd51-2cbb1a1fe50f",
                        "Name": "Micro-Incubate",
                        "Description": null,
                        "DataState": "Unchanged"
                    },
                    "OrderNumber": 1,
                    "IsTimeDependent": false,
                    "TimeDuration": null,
                    "TimeUnit": null,
                    "DataState": "Unchanged"
                },
                {
                    "TaskListTemplateTaskTemplateId": "d5989204-5716-4b6e-bda3-dfe76b438c89",
                    "TaskListTemplateId": "6254c43e-fa1b-428f-bfdb-0e32fcb2e061",
                    "TaskTemplateId": "ab74d67d-40dd-41f4-bd51-2cbb1a1fe50f",
                    "TaskTemplate": {
                        "TaskTemplateId": "ab74d67d-40dd-41f4-bd51-2cbb1a1fe50f",
                        "Name": "Micro-Incubate",
                        "Description": null,
                        "DataState": "Unchanged"
                    },
                    "OrderNumber": 2,
                    "IsTimeDependent": true,
                    "TimeDuration": 18,
                    "TimeUnit": "Hours",
                    "DataState": "Unchanged"
                }
            ],
            "DataState": "Unchanged"
        };

        service.taskTemplates = [
            {
                "TaskTemplateId": "a38451f4-821d-4d64-b2f0-08c2fb634220",
                "Name": "Chrm-Impurity Data Proc",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "0cf840ef-26eb-4e90-840f-0beac4518c6a",
                "Name": "Micro-Prep (Weigh&Dilute)",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "af32954b-8693-4351-974d-0c57291e6704",
                "Name": "Inst-HPLCA/R - uv",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "1cd3dfa5-a05b-49bc-a70f-0d42325186c4",
                "Name": "Task Templa 10",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "8ebd0ea8-f5dd-44d5-bf42-0e22acffae29",
                "Name": "Inst- volumetric Karl Fisher",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "6b964c68-68f7-4b83-857b-1337bfe33f98",
                "Name": "Micro-Plate Count",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "e7d7b7cb-6305-4445-84a5-14d60486753a",
                "Name": "Inst-HPLC A/R - ELSD",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "56f43b44-85c0-48b1-8751-1818fdff90c9",
                "Name": "Micro-ID by MicroSEQ",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "2066c00e-3d4c-4569-bfe7-273b1854f308",
                "Name": "TaskTemplate2",
                "Description": "Description for template2",
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "e656d845-98f3-4a02-9ffd-28b29f023171",
                "Name": "GenChem-Data Reporting",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "ab74d67d-40dd-41f4-bd51-2cbb1a1fe50f",
                "Name": "Micro-Incubate",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "46ee04f2-1825-4fca-8c31-33e848c4111c",
                "Name": "GenChem-Prep (difficult)",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "fe60149e-7639-4b52-879f-3b33e13cc598",
                "Name": "Task Template - Sample Reg",
                "Description": "Task Template - Sample Reg",
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "d62f5b34-196d-4a20-bba5-3c0ccf113296",
                "Name": "TaskTemplate1",
                "Description": "Description for template1",
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "6fda93e7-da87-4fad-a259-3f13b8ef7018",
                "Name": "Micro-Colony Morphology",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "3edf35c6-a9d1-4ba4-a6dc-4ad8afae6e22",
                "Name": "Inst-GC Direct Impur-TCD",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "c373f288-dd2a-4da5-b6bf-5106695794b9",
                "Name": "UDJ3-04-09-TT",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "ad6d4a71-7f7c-4d1f-90e2-51731886dffa",
                "Name": "Chrm-Reference Std Prep",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "f69d0a4c-60a7-4ed4-b07e-5a152b903527",
                "Name": "Inst-Autotitration",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "24b3f9ac-e439-4d1b-88f2-5feb3e634434",
                "Name": "US_QA_Task_Template",
                "Description": "Task Template creation",
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "7a05fc7e-8e54-4aff-a8d7-64494f43ee3a",
                "Name": "task temp[late",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "ed25951e-9d89-4ad9-866d-767b2398b4f9",
                "Name": "Micro-Sample Prep (Plating)",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "868a7dae-117c-42d2-a033-88d9b442d853",
                "Name": "Task Template TED Testing Scenario 1",
                "Description": "Task Template TED Testing Scenario 1",
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "0bab66a1-7233-43ba-9bac-89161c33f52b",
                "Name": "Micro-Prep (Streak)",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "e2222382-6c2e-4b16-9741-93de8922e517",
                "Name": "Inst-GC Direct A/R - FID",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "0620edfa-8dd0-43d6-b251-94945ec89009",
                "Name": "Inst-HPLC A/R - RI",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "0dcf0504-6b35-4fbe-aa6f-96db3e77cf71",
                "Name": "GenChem-Prep (typical)",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "dfe51b12-3e39-4317-9f13-9bdc6c19de36",
                "Name": "Inst-GC Headspace A/R - FID",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "d1eb43a1-d6d3-4ab9-a505-a55c954e472c",
                "Name": "Inst- HPLC Impurities-RI",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "25e46770-f5a5-4ea1-b157-b76fcd3aded4",
                "Name": "Inst-Karl Fischer oven",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "023148bd-b192-498e-9ae9-bed062117cbb",
                "Name": "Chrm-A/R Data Proc",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "fa169443-2c0c-4d9a-a741-bf8bdbca9ba8",
                "Name": "Chrm-Reagent & GW Prep",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "f8c5a679-8b43-42be-bacd-c2bd2affc9b4",
                "Name": "Inst-coulometric Karl Fisher ",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "d8a5ef40-be68-4da9-bad2-cd4f6aae5f97",
                "Name": "Inst-GC Headspace A/R - TCD",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "68486aec-eb3f-4e77-9b3d-d193afc208f7",
                "Name": "Micro-Read MAC Plates",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "433a7a25-3a3f-46ba-96a3-d35ee34113f9",
                "Name": "UDJ3-08-20",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "12e111b7-8253-46d2-ba7f-e421b302eeaf",
                "Name": "testte",
                "Description": "st",
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "f70a11f5-2aea-4300-8e97-ea4f4c3aee33",
                "Name": "Inst-GC Direct A/R - TCD",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "7bd47f7f-aaef-4baf-a2af-eaa1eebe85f8",
                "Name": "Inst-HPLC Impurities-ELSD",
                "Description": "check impurities",
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "9a17904f-15e5-414a-a501-f4095e5e62f5",
                "Name": "Micro-Prep (Transfer)",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "b2ffdcf7-048a-4add-a07b-f4805fc1e0f9",
                "Name": "Inst-HPLC Impurities-uv",
                "Description": null,
                "DataState": "Unchanged"
            },
            {
                "TaskTemplateId": "661cc5c8-ef05-41d5-9a91-ff179943359a",
                "Name": "Inst-GC Direct Impur-FID",
                "Description": null,
                "DataState": "Unchanged"
            }
        ];

        //#endregion

        return service;
    }
})();
﻿(function () {
    angular
        .module('efAngularLibrary.efUiGrid')
        /**
        * @ngdoc interface
        * @name efAngularLibrary.efUiGrid.efUiGridConstants
        * @description 
        * 
        * efUiGridConstants has been setup as a constant so that it can be injected into other Angular components as a dependency. This object contains the current default application-level settings and constant values for the efUiGrid set of components.
        * 
        * Please see the "/app/components/efUiGrid/efUiGrid.constants.js" file for implementation details.  
        * 
        **/
        .constant('efUiGridConstants', {
            /**
             * @ngdoc property
             * @name efAngularLibrary.efUiGrid.efUiGridConstants.#virtualizationThreshold 
             * @propertyOf efAngularLibrary.efUiGrid.efUiGridConstants
             * @returns {object} Object of 'virtualizationThreshold' default constants/settings.
            **/
            "virtualizationThreshold": {
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efUiGrid.efUiGridConstants.#virtualizationThreshold.DEFAULT
                 * @propertyOf efAngularLibrary.efUiGrid.efUiGridConstants
                 * @returns {integer} Number of rows the Ui-Grid will allocate/virtualize by default.
                **/
                "DEFAULT": 50,
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efUiGrid.efUiGridConstants.#virtualizationThreshold.MAX
                 * @propertyOf efAngularLibrary.efUiGrid.efUiGridConstants
                 * @returns {integer} Maximum number of rows the Ui-Grid will allocate/virtualize if no other virtualizationThreshold can be calculated within efUiGrid.
                **/
                "MAX": 999999
            },
            /**
             * @ngdoc property
             * @name efAngularLibrary.efUiGrid.efUiGridConstants.#columnVirtualizationThreshold 
             * @propertyOf efAngularLibrary.efUiGrid.efUiGridConstants
             * @returns {object} Object of 'columnVirtualizationThreshold' default constants/settings.
            **/
            "columnVirtualizationThreshold": {
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efUiGrid.efUiGridConstants.#columnVirtualizationThreshold.DEFAULT
                 * @propertyOf efAngularLibrary.efUiGrid.efUiGridConstants
                 * @returns {integer} Number of columns the Ui-Grid will allocate/virtualize by default.
                **/
                "DEFAULT": 25
            },
            /**
             * @ngdoc property
             * @name efAngularLibrary.efUiGrid.efUiGridConstants.#events 
             * @propertyOf efAngularLibrary.efUiGrid.efUiGridConstants
             * @returns {object} Object of custom 'events' used within efUiGrid.
            **/
            "events": {
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efUiGrid.efUiGridConstants.#events.END_UI_GRID_CELL_EDIT
                 * @propertyOf efAngularLibrary.efUiGrid.efUiGridConstants
                 * @returns {string} The event name that gets called by any custom controls or processes to tell UI-Grid to end/complete the cell-level edit process.
                **/
                "END_UI_GRID_CELL_EDIT": "endUiGridCellEdit",
                //"BEGIN_UI_GRID_CELL_EDIT": "beginUiGridCellEdit",
                //"COMPLETE_OPEN_UI_GRID_CELL_EDIT": "completeOpenUiGridCellEdit"
            },
            /**
             * @ngdoc property
             * @name efAngularLibrary.efUiGrid.efUiGridConstants.#actionColumns 
             * @propertyOf efAngularLibrary.efUiGrid.efUiGridConstants
             * @returns {object} Object of available 'actionColumns' used within efUiGrid.
            **/
            "actionColumns": {
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efUiGrid.efUiGridConstants.#actionColumns.PREFIX
                 * @propertyOf efAngularLibrary.efUiGrid.efUiGridConstants
                 * @returns {string} This is used to identify the "prefix" action column.
                **/
                "PREFIX": "prefix",
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efUiGrid.efUiGridConstants.#actionColumns.SUFFIX
                 * @propertyOf efAngularLibrary.efUiGrid.efUiGridConstants
                 * @returns {string} This is used to identify the "suffix" action column.
                **/
                "SUFFIX": "suffix",
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efUiGrid.efUiGridConstants.#actionColumns.LINKOUT
                 * @propertyOf efAngularLibrary.efUiGrid.efUiGridConstants
                 * @returns {string} This is used to identify the "linkOut" action column.
                **/
                "LINKOUT": "linkOut"
            }
        });
})();
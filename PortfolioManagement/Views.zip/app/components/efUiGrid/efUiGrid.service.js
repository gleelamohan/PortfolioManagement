﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.


/**
 * @ngdoc service
 * @name efAngularLibrary.efUiGrid.service:efUiGridApi
 * @requires efAngularLibrary.efUiGrid.efUiGridConstants
 * @requires efAngularLibrary.efUiGrid.filter:efUiGridTemplateCell
 * @requires efAngularLibrary.efUiGrid.filter:efUiGridTemplateCellEditorEfInput
 * @requires efAngularLibrary.efClick.directive:efClick
 * @requires efAngularLibrary.efLookupValue.filter:efLookupValue
 * @requires efLibrary
 * @requires angular-ui-grid
 * @description 
 * 
 * The efUiGridApi provides an Angular Factory that helps in the creation and management of the efUiGrid.
 * 
 * This factory uses features of the <a href="http://ui-grid.info/" target="_blank">angular-ui-grid</a>.  Please visit this control's web site for complete implementation details.
 * 
**/
(function () {
    angular
        .module('efAngularLibrary.efUiGrid')
        .factory('efUiGridApi', efUiGridApi);

    efUiGridApi.$inject = ['$resource', '$filter', '$compile', 'efLibrary', 'uiGridConstants', 'efUiGridConstants'];

    function efUiGridApi($resource, $filter, $compile, efLibrary, uiGridConstants, efUiGridConstants) {

        var uiGridApi = {};

        /**
         * @ngdoc property
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#enumValueCache
         * @propertyOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The enumValueCache is an array of enum value objects.
         * 
         * @returns {Array} Array of enum value objects.
        **/
        uiGridApi.enumValueCache = [];

        //#region Grid and Column Configurations

        /**
         * @ngdoc property
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#defaultGridConfig
         * @propertyOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The defaultGridConfig is an object of default angular-ui-grid grid config settings for all grid types.  For complete documentation of the settings, please see the <a href="http://ui-grid.info/docs/#/api" target="_blank">angular-ui-grid API web site</a>
         * 
         * @returns {object} Default angular-ui-grid grid config settings for all grid types.
        **/
        uiGridApi.defaultGridConfig = {
            enableSorting: true,
            enableHorizontalScrollbar: 0, //0=never, 1 = always, 2 = when needed
            enableVerticalScrollbar: 0, //0=never, 1 = always, 2 = when needed
            columnDefs: [],
            enablePagination: true,
            enablePaginationControls: true,
            paginationPageSizes: [10, 25, 50, 100],
            paginationPageSize: 25,
            enableColumnResizing: true,
            enablePinning: true
        }


        //#region Grid and Column Configurations

        /**
         * @ngdoc property
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#exportGridConfig
         * @propertyOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The exportGridConfig is an object of default angular-ui-grid grid config settings for all grid types.  For complete documentation of the settings, please see the <a href="http://ui-grid.info/docs/#/api" target="_blank">angular-ui-grid API web site</a>
         * 
         * @returns {object} Default angular-ui-grid grid config settings for all grid types.
        **/
        uiGridApi.exportGridConfig = {
            enableSorting: true,
            enableHorizontalScrollbar: 0, //0=never, 1 = always, 2 = when needed
            enableVerticalScrollbar: 0, //0=never, 1 = always, 2 = when needed
            columnDefs: [],
            enablePagination: true,
            enablePaginationControls: true,
            paginationPageSizes: [10, 25, 50, 100],
            paginationPageSize: 25,
            enableColumnResizing: true,
            enablePinning: true,
            //enableGridMenu: true,
            enableFiltering: true,
            enableSelectAll: true,
            //vm.gridOptions.exporterMenuCsv : false,
            exporterMenuPdf: false,
            exporterCsvFilename: "ddbs-lims-export.csv",
            exporterPdfDefaultStyle: { fontSize: 9 },
            exporterPdfTableStyle: { margin: [20, 20, 20, 20] },
            exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: "red" },
            exporterPdfHeader: { text: "DDBS-LIMS", style: "headerStyle" },
            exporterPdfFooter: function(currentPage, pageCount) {
                return { text: currentPage.toString() + " of " + pageCount.toString(), style: "footerStyle" };
            },
            exporterPdfCustomFormatter: function(docDefinition) {
                docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                return docDefinition;
            },
            exporterPdfOrientation: "portrait",
            exporterPdfPageSize: "LETTER",
            exporterPdfMaxGridWidth: 450,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location"))
        }

        /**
         * @ngdoc property
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#defaultGridEditorConfig
         * @propertyOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The defaultGridEditorConfig is an object of default angular-ui-grid grid config settings for editable grid types.  For complete documentation of the settings, please see the <a href="http://ui-grid.info/docs/#/api" target="_blank">angular-ui-grid API web site</a>
         * 
         * @returns {object} Default angular-ui-grid grid config settings for editable grid types.
        **/
        uiGridApi.defaultGridEditorConfig = {
            rowHeight: 35,
            enableCellEdit: false,
            enableCellEditOnFocus: false
        }

        /**
         * @ngdoc property
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#defaultColumnDef
         * @propertyOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The defaultColumnDef is an object of default angular-ui-grid column definition settings.  For complete documentation of the settings, please see the <a href="http://ui-grid.info/docs/#/api" target="_blank">angular-ui-grid API web site</a>.
         * 
         * @returns {object} Default angular-ui-grid column definition settings.
        **/
        uiGridApi.defaultColumnDef = {
            name: null,
            field: null,
            displayName: null,
            headerCellTemplate: null,
            headerCellClass: "uiGrid_Column_Left",
            headerTooltip: false,
            cellTemplate: String($filter('efUiGridTemplateCell')()),
            cellClass: "uiGrid_Column_Left",
            cellTooltip: false,
            enableColumnMenu: false,
            enableFiltering: true,
            enableHiding: false,
            enableSorting: true,
            //suppressRemoveSort: true,
            allowCellFocus: true,
            enableColumnResizing: true,
            enableColumnMoving: false,
            visible: true,
            width: "*", //Auto width = "*" or ""
            enableCellEdit: false,
            enableCellEditOnFocus: false
        }

        /**
         * @ngdoc property
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#defaultColumnDefSortEnabled
         * @propertyOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The defaultColumnDefSortEnabled is an object of default angular-ui-grid column definition settings for sorted enabled columns.  For complete documentation of the settings, please see the <a href="http://ui-grid.info/docs/#/api" target="_blank">angular-ui-grid API web site</a>.
         * 
         * @returns {object} Default angular-ui-grid column definition settings for sorted enabled columns.
        **/
        uiGridApi.defaultColumnDefSortEnabled = {
            enableSorting: true,
            suppressRemoveSort: true
        }

        /**
         * @ngdoc property
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#defaultColumnDefSortAscending
         * @propertyOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The defaultColumnDefSortAscending is an object of default angular-ui-grid column definition settings for ascending sorted columns.  For complete documentation of the settings, please see the <a href="http://ui-grid.info/docs/#/api" target="_blank">angular-ui-grid API web site</a>.
         * 
         * @returns {object} Default angular-ui-grid column definition settings for ascending sorted columns.
        **/
        uiGridApi.defaultColumnDefSortAscending = {
            sort: {
                direction: uiGridConstants.ASC,
                ignoreSort: false
            }
        }

        /**
         * @ngdoc property
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#defaultColumnDefSortDescending
         * @propertyOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The defaultColumnDefSortDescending is an object of default angular-ui-grid column definition settings for descending sorted columns.  For complete documentation of the settings, please see the <a href="http://ui-grid.info/docs/#/api" target="_blank">angular-ui-grid API web site</a>.
         * 
         * @returns {object} Default angular-ui-grid column definition settings for descending sorted columns.
        **/
        uiGridApi.defaultColumnDefSortDescending = {
            sort: {
                direction: uiGridConstants.ASC,
                ignoreSort: false
            }
        }

        /**
         * @ngdoc property
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#defaultColumnDefEditable
         * @propertyOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The defaultColumnDefEditable is an object of default angular-ui-grid column definition settings for editable columns.  For complete documentation of the settings, please see the <a href="http://ui-grid.info/docs/#/api" target="_blank">angular-ui-grid API web site</a>.
         * 
         * @returns {object} Default angular-ui-grid column definition settings for editable columns.
        **/
        uiGridApi.defaultColumnDefEditable = {
            enableCellEdit: true,
            enableCellEditOnFocus: true,
            editModelField: null,
            editableCellTemplate: null
        }

        /**
        * @ngdoc property
        * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#defaultCellTemplateAdditionalParameters
        * @propertyOf efAngularLibrary.efUiGrid.service:efUiGridApi
        * @description 
        * 
        * The defaultCellTemplateAdditionalParameters is a list of default additional HTML cell parameters.
        * 
        * @returns {string} A list of default additional HTML cell parameters.
        **/
        uiGridApi.defaultCellTemplateAdditionalParameters = "validate-after-model-change=\"false\" validate-after-edit=\"true\" update-entity=\"true\" update-model-on-error=\"true\" display-error=\"true\" width=\"100%\" ";

        //#endregion

        //#region Grid Helper Functions

        /**
         * @ngdoc method
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#getVirtualizationThreshold
         * @methodOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The getVirtualizationThreshold function returns the optimal angular-ui-grid virtualizationThreshold value for the current grid configuration.  For complete documentation of the virtualizationThreshold setting, please see the <a href="http://ui-grid.info/docs/#/api/ui.grid.class:GridOptions" target="_blank">angular-ui-grid GridOptions API web site</a>.
         * 
         * @param {object} config Current angular-ui-grid configuration object.
         * @returns {integer} Optimal angular-ui-grid virtualizationThreshold value for the current grid configuration.
        **/
        uiGridApi.getVirtualizationThreshold = function (config) {
            var returnValue = efUiGridConstants.virtualizationThreshold.DEFAULT;
            if (efLibrary.isValid(config)) {
                if (efLibrary.toBoolean(config.enablePagination, false)) {
                    if (efLibrary.isValid(config.paginationPageSizes, true)) {
                        returnValue = Math.max.apply(null, config.paginationPageSizes) + 1;
                    } else {
                        returnValue = efUiGridConstants.virtualizationThreshold.MAX;
                    }
                } else {
                    returnValue = efUiGridConstants.virtualizationThreshold.MAX;
                }
            }
            return returnValue;
        }

        /**
         * @ngdoc method
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#getColumnVirtualizationThreshold
         * @methodOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The getColumnVirtualizationThreshold function returns the optimal angular-ui-grid columnVirtualizationThreshold value for the current grid configuration.  For complete documentation of the columnVirtualizationThreshold setting, please see the <a href="http://ui-grid.info/docs/#/api/ui.grid.class:GridOptions" target="_blank">angular-ui-grid GridOptions API web site</a>.
         * 
         * @param {object} config Current angular-ui-grid configuration object.
         * @returns {integer} Optimal angular-ui-grid columnVirtualizationThreshold value for the current grid configuration.
        **/
        uiGridApi.getColumnVirtualizationThreshold = function (config) {
            var returnValue = efUiGridConstants.columnVirtualizationThreshold.DEFAULT;
            if (efLibrary.isValid(config) && efLibrary.isValid(config.columnDefs)) {
                returnValue = config.columnDefs.length + 1;
            }
            return returnValue;
        }

        //#endregion

        //#region Column Helper Functions

        /**
         * @ngdoc method
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#getColumnDef
         * @methodOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The getColumnDef function returns the angular-ui-grid columnDef object, pre-populated with default and supplied values.  For complete documentation of the settings, please see the <a href="http://ui-grid.info/docs/#/api" target="_blank">angular-ui-grid API web site</a>.
         * 
         * @param {string=} name Name of the column. 
         * @param {string=} field Field name within the entity/data associated with the column.
         * @param {string=} displayName The pre-translated display name for the column.  If not provided, null, or blank, then the value provided in the name parameter will be used.
         * @param {boolean=} sortEnabled Flag to enable/disable sorting for the column.  If not provided or null, then sorting will be disabled.
         * @param {string=} sortDirection The sort direction for the column.  This should be set using the angular-ui-grid uiGridConstants value.  Allowed values are uiGridConstants.ASC or uiGridConstants.DESC.  This is only used when sortEnabled is true.  If not provided or null, then no sort direction will be set.  For complete documentation of the angular-ui-grid sort direction setting, please see the columnDef.sort property on the <a href="http://ui-grid.info/docs/#/api/ui.grid.class:GridOptions" target="_blank">angular-ui-grid GridOptions API web site</a>.
         * @param {boolean=} editable Flag to enable/disable editing of the column.  If not provided or null, then editing will be disabled. 
         * @param {object=} defaultColumnDef Object of custom default columnDef options to use.  If not provided or null, then the options in the efUiGridApi.defaultColumnDef will be used. 
         * @returns {object} Angular-ui-grid columnDef object, pre-populated with default and supplied values.
        **/
        uiGridApi.getColumnDef = function (name, field, displayName, sortEnabled, sortDirection, editable, defaultColumnDef) {
            var columnDef = efLibrary.isValid(defaultColumnDef) ? efLibrary.copyObject(defaultColumnDef, true) : efLibrary.copyObject(uiGridApi.defaultColumnDef, true);
            if (efLibrary.isValid(name, true)) {
                columnDef.name = name;
            }
            if (efLibrary.isValid(field, true)) {
                columnDef.field = field;
            }
            if (efLibrary.isValid(displayName, true)) {
                columnDef.displayName = displayName;
                columnDef.headerCellTemplate = String($filter('efUiGridTemplateHeader')());
            } else {
                columnDef.displayName = efLibrary.isValid(name) ? name : "";
                columnDef.headerCellTemplate = String($filter('efUiGridTemplateHeader')('&nbsp;'));
            }

            if (efLibrary.toBoolean(sortEnabled, false)) {
                columnDef = efLibrary.mergeObjects(columnDef, uiGridApi.defaultColumnDefSortEnabled);
            }
            if (efLibrary.toBoolean(sortEnabled, false) && efLibrary.isValid(sortDirection)) {
                if (sortDirection === uiGridConstants.ASC) {
                    columnDef = efLibrary.mergeObjects(columnDef, uiGridApi.defaultColumnDefSortAscending);
                } else if (sortDirection === uiGridConstants.DESC) {
                    columnDef = efLibrary.mergeObjects(columnDef, uiGridApi.defaultColumnDefSortDescending);
                }
            }
            if (efLibrary.toBoolean(editable, false)) {
                columnDef = efLibrary.mergeObjects(columnDef, uiGridApi.defaultColumnDefEditable);
                if (efLibrary.isValid(field)) {
                    columnDef.editModelField = field;
                }
            }

            return columnDef;
        }

        //Sets the width and minwidth for the column based on the provided widthOptions object

        /**
         * @ngdoc method
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#setColumnWidths
         * @methodOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The setColumnWidths function sets the width and minWidth options of a column to the supplied values.
         * 
         * widthOptions object format:
         * <pre>
         *  {
         *      "width": "*", //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *      "minWidth": "50" //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *  }
         * </pre>
         * 
         * @param {object} column columnDef object of the column you want to set the width and minWidth to.
         * @param {object=} widthOptions Object of width options to set on the supplied column.  Please see the method description for widthOptions format details.
        **/
        uiGridApi.setColumnWidths = function (column, widthOptions) {
            if (widthOptions === undefined || widthOptions === null) {
                column.width = "*"; //Auto size
                column.minWidth = 50; //pixels
            } else {
                column.width = uiGridApi.getDesiredWidth(widthOptions.width, "*");
                column.minWidth = uiGridApi.getDesiredWidth(widthOptions.minWidth, "50");
            }
        }

        /**
         * @ngdoc method
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#createTextColumn
         * @methodOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The createTextColumn function generates a column for displaying or editing text values.
         * 
         * widthOptions object format:
         * <pre>
         *  {
         *      "width": "*", //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *      "minWidth": "50" //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *  }
         * </pre>
         * 
         * @param {object} controller The controller for the directive consuming (ex: vm). Required as we have to attach some variables to the controller in order for the control to work.
         * @param {string} fieldName The name of the field to bind to in the data source.
         * @param {string} boundObject The name of the entity object that the fields are bound to (ex: "vm.aliquotsEntity").
         * @param {string} columnHeaderTranslationKey The translation key to use to render the column header text for the column.
         * @param {object=} widthOptions Object of width options to set on the column.  Please see the method description for widthOptions format details.
         * @param {string=} inputControlWidth Valid HTML width value for the input control.  If not provided or null, then "100%" will be used.
         * @returns {object} Angular-ui-grid columnDef object, pre-populated with default and supplied values. 
        **/
        uiGridApi.createTextColumn = function (controller, fieldName, boundObject, columnHeaderTranslationKey, widthOptions, inputControlWidth) {
            var columnName = fieldName.replace(".", "_");
            var column = uiGridApi.getColumnDef(columnName, fieldName, String($filter("trustedtranslate")(columnHeaderTranslationKey)), true, null, true);
            uiGridApi.setColumnWidths(column, widthOptions);
            column.searchable = false;
            column.cellClass = "uiGrid_Column_Left uiGrid_Cell_EnsureContentDisplay";

            var configName = columnName + "CellEditorTemplate";
            controller[configName] = {
                "type": "text",
                "placeholder": String($filter("trustedtranslate")("Entity.Test.Portions.InputPlaceholder")),
                "width": !efLibrary.isNotSet(inputControlWidth) ? inputControlWidth : "100%"
            };

            column.editableCellTemplate = String($filter("efUiGridTemplateCellEditorEfInput")("vm." + configName, boundObject, uiGridApi.defaultCellTemplateAdditionalParameters));

            return column;
        }

        /**
         * @ngdoc method
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#createNumberColumn
         * @methodOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The createNumberColumn function generates a column for displaying or editing numeric values.
         * 
         * widthOptions object format:
         * <pre>
         *  {
         *      "width": "*", //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *      "minWidth": "50" //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *  }
         * </pre>
         * 
         * @param {object} controller The controller for the directive consuming (ex: vm). Required as we have to attach some variables to the controller in order for the control to work.
         * @param {string} fieldName The name of the field to bind to in the data source.
         * @param {string} boundObject The name of the entity object that the fields are bound to (ex: "vm.aliquotsEntity").
         * @param {string} columnHeaderTranslationKey The translation key to use to render the column header text for the column.
         * @param {number} minValue The minimum value allowed to be entered.
         * @param {number} maxValue The maximum value allowed to be entered.
         * @param {object=} widthOptions Object of width options to set on the column.  Please see the method description for widthOptions format details.
         * @param {string=} inputControlWidth Valid HTML width value for the input control.  If not provided or null, then "100%" will be used.
         * @returns {object} Angular-ui-grid columnDef object, pre-populated with default and supplied values. 
        **/
        uiGridApi.createNumberColumn = function (controller, fieldName, boundObject, columnHeaderTranslationKey, minValue, maxValue, widthOptions, inputControlWidth) {
            var columnName = fieldName.replace(".", "_");
            var column = uiGridApi.getColumnDef(columnName, fieldName, String($filter("trustedtranslate")(columnHeaderTranslationKey)), true, null, true);
            uiGridApi.setColumnWidths(column, widthOptions);
            column.searchable = false;
            column.cellClass = "uiGrid_Column_Left uiGrid_Cell_EnsureContentDisplay";

            var configName = columnName + "CellEditorTemplate";
            controller[configName] = {
                "type": "number",
                "placeholder": String($filter("trustedtranslate")("Entity.Test.Portions.InputPlaceholder")),
                "min": minValue,
                "max": maxValue,
                "width": !efLibrary.isNotSet(inputControlWidth) ? inputControlWidth : "100%"
            };

            column.editableCellTemplate = String($filter("efUiGridTemplateCellEditorEfInput")("vm." + configName, boundObject, uiGridApi.defaultCellTemplateAdditionalParameters));

            return column;
        }

        /**
         * @ngdoc method
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#createReadonlyColumn
         * @methodOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The createReadonlyColumn function generates a display-only column, which can be used for further customization.
         * 
         * widthOptions object format:
         * <pre>
         *  {
         *      "width": "*", //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *      "minWidth": "50" //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *  }
         * </pre>
         * 
         * @param {string} fieldName The name of the field to bind to in the data source.
         * @param {string} columnHeaderTranslationKey The translation key to use to render the column header text for the column.
         * @param {object=} widthOptions Object of width options to set on the column.  Please see the method description for widthOptions format details.
         * @returns {object} Angular-ui-grid columnDef object, pre-populated with default and supplied values. 
        **/
        uiGridApi.createReadonlyColumn = function (fieldName, columnHeaderTranslationKey, widthOptions) {
            var columnName = fieldName.replace(".", "_");
            var column = uiGridApi.getColumnDef(columnName, fieldName, String($filter("trustedtranslate")(columnHeaderTranslationKey)), true, null, false);
            uiGridApi.setColumnWidths(column, widthOptions);
            column.searchable = false;

            return column;
        }

        /**
         * @ngdoc method
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#createHyperlinkColumn
         * @methodOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The createHyperlinkColumn function generates a column for displaying a hyperlink, by using one of the columns on the data source for the URL to go to when the URL is clicked.
         * 
         * widthOptions object format:
         * <pre>
         *  {
         *      "width": "*", //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *      "minWidth": "50" //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *  }
         * </pre>
         * 
         * @param {string} fieldName The name of the field to bind to in the data source as the display text.
         * @param {string} columnHeaderTranslationKey The translation key to use to render the column header text for the column.
         * @param {string} urlFieldName The name of the field to bind to in the data source as the url.
         * @param {object=} widthOptions Object of width options to set on the column.  Please see the method description for widthOptions format details.
         * @param {string} target The valid HTML anchor target attribute value for the hyperlink (example:  "_blank").
         * @returns {object} Angular-ui-grid columnDef object, pre-populated with default and supplied values. 
        **/
        uiGridApi.createHyperlinkColumn = function (fieldName, columnHeaderTranslationKey, urlFieldName, widthOptions, target) {
            var columnName = fieldName.replace(".", "_");

            var column = uiGridApi.getColumnDef(columnName, fieldName, String($filter("trustedtranslate")(columnHeaderTranslationKey)), false, null, false);
            uiGridApi.setColumnWidths(column, widthOptions);
            column.cellTemplate = '<a href={{row.entity.' + urlFieldName + '}} target="' + target + '">{{row.entity.' + fieldName + '}}<i class="fa fa-external-link"></i></a>';
            column.cellClass = "uiGrid_Column_Center";

            return column;
        }

        /**
         * @ngdoc method
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#createHyperlinkActionColumn
         * @methodOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The createHyperlinkActionColumn function generates a column for displaying a hyperlink that executes the supplied callback when clicked.
         * 
         * widthOptions object format:
         * <pre>
         *  {
         *      "width": "*", //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *      "minWidth": "50" //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *  }
         * </pre>
         * 
         * @param {string} fieldName The name of the field to bind to in the data source as the display text.
         * @param {string} columnHeaderTranslationKey The translation key to use to render the column header text for the column.
         * @param {string} clickCallback The name of the callback function to call when the hyperlink is clicked.  Example: <pre>vm.navigateToAliquotDetails('{{row.entity.AliquotId}}')"</pre>
         * @param {object=} widthOptions Object of width options to set on the column.  Please see the method description for widthOptions format details.
         * @returns {object} Angular-ui-grid columnDef object, pre-populated with default and supplied values. 
        **/
        uiGridApi.createHyperlinkActionColumn = function (fieldName, columnHeaderTranslationKey, clickCallback, widthOptions) {
            var columnName = fieldName.replace(".", "_");

            var column = {};
            column.name = columnName;
            uiGridApi.setColumnWidths(column, widthOptions);
            column.cellTemplate = '<a ef-click="' + clickCallback + '">{{row.entity.' + fieldName + '}} <i class="fa fa-external-link"></i></a>';
            column.cellClass = "uiGrid_Column_Center";

            return column;
        }

        /**
         * @ngdoc method
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#createDropDownColumn
         * @methodOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The createDropDownColumn function generates a column for displaying an efSelect drop-down control.
         * 
         * widthOptions object format:
         * <pre>
         *  {
         *      "width": "*", //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *      "minWidth": "50" //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *  }
         * </pre>
         * 
         * @param {object} controller The controller for the directive consuming (ex: vm). Required as we have to attach some variables to the controller in order for the control to work.
         * @param {string} fieldName The name of the field to bind to in the data source.
         * @param {string} boundObject The name of the entity object that the fields are bound to (ex: "vm.aliquotsEntity").
         * @param {string} columnOptionsSource A string representing where on the controller to find the options to display in the drop-down (ex: vm.aliquotTypeEnums). Must be a LabelValue array.
         * @param {string} columnHeaderTranslationKey The translation key to use to render the column header text for the column.
         * @param {string} valuePlaceholderTranslationKey The translation key to use to render as the efSelect placeholder text.
         * @param {boolean} allowNull Flag to enable/disable null values to be set.  Setting to false will make the field required once the initial value is set.
         * @param {object=} widthOptions Object of width options to set on the column.  Please see the method description for widthOptions format details.
         * @param {string=} inputControlWidth Valid HTML width value for the input control.  If not provided or null, then "100%" will be used.
         * @param {string} mode The valid efSelect mode for the column.
         * @returns {object} Angular-ui-grid columnDef object, pre-populated with default and supplied values. 
        **/
        uiGridApi.createDropDownColumn = function (controller, fieldName, boundObject, columnOptionsSource, columnHeaderTranslationKey, valuePlaceholderTranslationKey,
            allowNull, widthOptions, selectControlWidth, mode) {
            allowNull = allowNull === true ? "true" : "false";

            var column = uiGridApi.getColumnDef(fieldName, fieldName, String($filter("trustedtranslate")(columnHeaderTranslationKey)), false, null, true);
            column.cellClass = "uiGrid_Column_Left uiGrid_Cell_EnsureContentDisplay";
            uiGridApi.setColumnWidths(column, widthOptions);
            if (mode !== "customselect") {
                column.cellFilter = "efLookupValue: '" + columnOptionsSource + "':'value':'label':this";
            }
            column.enableCellEditOnFocus = true;

            var configName = fieldName + "SelectConfig";
            var getConfig = "efLibrary.getObjectThroughAngularScope($scope, 'vm." + configName + "')";
            var getOptions = "efLibrary.getObjectThroughAngularScope($scope, '" + columnOptionsSource + "')";

            controller[configName] = {
                "type": "efSelect",
                "mode": mode,
                "placeholder": String($filter("trustedtranslate")(valuePlaceholderTranslationKey)),
                "getConfig": getConfig,
                "getOptions": getOptions,
                "allowNull": allowNull,
                "width": !efLibrary.isNotSet(selectControlWidth) ? selectControlWidth : "100%"
            };

            column.editableCellTemplate = String($filter("efUiGridTemplateCellEditorEfInput")("vm." + configName, boundObject, uiGridApi.defaultCellTemplateAdditionalParameters));
            return column;
        }

        /**
         * @ngdoc method
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#createSelectColumn
         * @methodOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The createSelectColumn function generates a column for displaying an efSelect drop-down control using the efSelect "select" mode.
         * 
         * widthOptions object format:
         * <pre>
         *  {
         *      "width": "*", //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *      "minWidth": "50" //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *  }
         * </pre>
         * 
         * @param {object} controller The controller for the directive consuming (ex: vm). Required as we have to attach some variables to the controller in order for the control to work.
         * @param {string} fieldName The name of the field to bind to in the data source.
         * @param {string} boundObject The name of the entity object that the fields are bound to (ex: "vm.aliquotsEntity").
         * @param {string} columnOptionsSource A string representing where on the controller to find the options to display in the drop-down (ex: vm.aliquotTypeEnums). Must be a LabelValue array.
         * @param {string} columnHeaderTranslationKey The translation key to use to render the column header text for the column.
         * @param {string} valuePlaceholderTranslationKey The translation key to use to render as the efSelect placeholder text.
         * @param {boolean} allowNull Flag to enable/disable null values to be set.  Setting to false will make the field required once the initial value is set.
         * @param {object=} widthOptions Object of width options to set on the column.  Please see the method description for widthOptions format details.
         * @param {string=} inputControlWidth Valid HTML width value for the input control.  If not provided or null, then "100%" will be used.
         * @returns {object} Angular-ui-grid columnDef object, pre-populated with default and supplied values. 
        **/
        uiGridApi.createSelectColumn = function (controller, fieldName, boundObject, columnOptionsSource, columnHeaderTranslationKey, valuePlaceholderTranslationKey, allowNull, columnMinWidth, selectControlWidth) {
            return uiGridApi.createDropDownColumn(controller, fieldName, boundObject, columnOptionsSource, columnHeaderTranslationKey, valuePlaceholderTranslationKey, allowNull, columnMinWidth, selectControlWidth, "select");
        }

        /**
         * @ngdoc method
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#getDesiredWidth
         * @methodOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The getDesiredWidth function returns a correctly formatted column width as required by angular-ui-grid (which only supports auto, percentages, and pixel values).
         * 
         * @param {string=} columnWidth The column width to convert to the angular-ui-grid valid width.
         * @param {string=} defaultWidth The default wdith to be used if the columnWidth cannot be converted correctly, or columnWidth is not provided.  If not provided or null, then angular-ui-grid's auto width ("*") will be used.
         * @returns {string} The angular-ui-grid valid width.
        **/
        uiGridApi.getDesiredWidth = function (columnWidth, defaultWidth) {
            if (defaultWidth === null) {
                defaultWidth = "*"; //Auto Size
            }

            if (efLibrary.isNotSet(columnWidth)) {
                return defaultWidth;
            }
            else if (columnWidth.toString().indexOf("%") !== -1) {
                return columnWidth; //Is specified in percent
            }
            else if (columnWidth.toString().indexOf("px") !== -1) {
                return columnWidth.toString().substr(0, columnWidth.length - 2); //Specified in pixels, do not pass in the px
            } else {
                return columnWidth; //Will be processed as pixels
            }
        }

        //Generates a column definition for displaying a drop-down control for selecting a value with all of the values being the values for the specified enum.
        //controller: The controller for the directive consuming (ex: vm). Required as we have to attach some variables to the controller in order for the control to work
        //fieldName: The name of the property to bind to in the bound data source
        //boundObject: The name of the object that the properties are bound to (ex: vm.aliquotsEntity)
        //columnHeaderTranslationKey: the key to be translated for the column header (ex: Views.SampleRegistration.SampleConfiguration.ValidationHeaderText)
        //valuePlaceholderTranslationKey: the key to be translated for what to show if no options are selected (ex: Entity.Role.ColumnText)
        //enumName: The name of the enum to use. This method takes care of getting any additional data about the enum, including translations (ex: AliquotStorageConditionEnums)
        //allowNull: Whether or not null values are allowed. Will show an "X" in the UI if set to True (null allowed)
        //widthOptions: Object that can have width and/or minWidth properties. Width can be in px or % or "*" (default), minwidth should not have a unit and is always used as pixels (default of 50).
        //selectControlWidth: the desired width of the select control, including the units (%, em, etc). Defaults to 100%.
        //uiGridApi.createSelectColumnForEnum = function (controller, fieldName, boundObject, enumName, columnHeaderTranslationKey, valuePlaceholderTranslationKey, allowNull, widthOptions, selectControlWidth) {
        //    var key = enumName + "CachedEnums";
        //    if (uiGridApi.enumValueCache[key] === undefined) {
        //        enumsApi.query({ enumType: enumName, languageIso: undefined }).$promise.then(function (response) {
        //            uiGridApi.enumValueCache[key] = efLibrary.getLabelValueArrayFromObject(response);
        //            controller[key] = uiGridApi.enumValueCache[key];
        //        });
        //    } else {
        //        controller[key] = uiGridApi.enumValueCache[key];
        //    }

        //    var column = uiGridApi.createSelectColumn(controller, fieldName, boundObject, "vm." + key, columnHeaderTranslationKey, valuePlaceholderTranslationKey, allowNull, widthOptions, selectControlWidth);
        //    return column;
        //}

        /**
         * @ngdoc method
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#createCheckboxColumn
         * @methodOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The createCheckboxColumn function generates a column for displaying an efInput checkbox column.
         * 
         * widthOptions object format:
         * <pre>
         *  {
         *      "width": "*", //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *      "minWidth": "50" //Valid options include "*"(auto size), "xxx%"(percentage), or "xxx"(pixels)
         *  }
         * </pre>
         * 
         * @param {object} controller The controller for the directive consuming (ex: vm). Required as we have to attach some variables to the controller in order for the control to work.
         * @param {string} fieldName The name of the field to bind to in the data source.
         * @param {string} boundObject The name of the entity object that the fields are bound to (ex: "vm.aliquotsEntity").
         * @param {string} columnHeaderTranslationKey The translation key to use to render the column header text for the column.
         * @param {object=} widthOptions Object of width options to set on the column.  Please see the method description for widthOptions format details.
         * @returns {object} Angular-ui-grid columnDef object, pre-populated with default and supplied values. 
        **/
        uiGridApi.createCheckboxColumn = function (controller, fieldName, boundObject, columnHeaderTranslationKey, widthOptions) {
            var column = uiGridApi.getColumnDef(columnName, fieldName, String($filter("trustedtranslate")(columnHeaderTranslationKey)), false, null, true);
            uiGridApi.setColumnWidths(column, widthOptions);
            column.cellClass = "uiGrid_Column_Center";

            var configName = fieldName + "CheckboxTemplate";

            controller[configName] = {
                "type": "checkbox"
            };

            column.cellTemplate = String($filter('efUiGridTemplateCellBoolean')(fieldName));

            column.editableCellTemplate = String($filter("efUiGridTemplateCellEditorEfInput")("vm." + configName, boundObject, uiGridApi.defaultCellTemplateAdditionalParameters));

            return column;
        }



        uiGridApi.createActionColDef = function (gridName, colName, fieldName, clickCallback, displayIcon) {

            var editGridActionConfig = uiGridApi.getActionColumnsConfig(gridName, fieldName);
            editGridActionConfig.linkOut.displayAction = true;
            editGridActionConfig.linkOut.callback = clickCallback;

            if (displayIcon != null)
                editGridActionConfig.linkOut.alternateLabel = displayIcon;

            var colEdit = uiGridApi.getActionColumnDef(efUiGridConstants.actionColumns.LINKOUT, editGridActionConfig, fieldName);
            colEdit.enableFiltering = false;
            colEdit.enableSorting = false;
            colEdit.exporterSuppressExport = true;
            colEdit.name = colName;
            return colEdit;
        }


  
           
            
        


        /**
         * @ngdoc method
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#toggleColumnVisibility
         * @methodOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The toggleColumnVisibility function toggles the column visibility of an angular-ui-grid column.
         * 
         * @param {string} columnName The name of the column to toggle visibility on.
         * @param {object} columnDefs The angular-ui-grid columnDefs object array that contains the column identified in the columnName parameter.
         * @param {boolean} visibilityValue Flag to toggle visibility of the column.  A value of true will make the column visible.  A value of false will hide the column.
        **/
        uiGridApi.toggleColumnVisibility = function (columnName, columnDefs, visibilityValue) {
            if (efLibrary.isValid(columnName, true) && efLibrary.isValid(columnDefs)) {
                var pos = columnDefs.map(function (e) { return e.field; }).indexOf(columnName);
                columnDefs[pos].visible = efLibrary.isValid(visibilityValue) ? visibilityValue : !columnDefs[pos].visible;
            }
        }

        //#endregion

        //#region Default Action Columns and Button Configurations

        /**
         * @ngdoc property
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#defaultActionColumnsConfig
         * @propertyOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The defaultActionColumnsConfig is an object of default efUiGrid.actionColumnConfig settings.  For complete settings details, see the {@link efAngularLibrary.efUiGrid.actionColumnConfig actionColumnConfig} documentation page.
         * 
         * @returns {object} Default efUiGrid.actionColumnConfig settings.
        **/
        uiGridApi.defaultActionColumnsConfig = {
            "linkOut": {
                //Displays the link-out action as the last column
                "displayAction": false,
                "callback": null,
                "returnFullDataObject": false,
                "alternateLabel": null
            },
            "moveRow": {
                //Displays the move row buttons in the prefix actions column
                "displayAction": false,
                "callback": null,
                "returnFullDataObject": false,
                "moveRowButtonIdPrefix": null,
                "orderPositionField": null
            },
            "insertRow": {
                //Displays the insert row button in the prefix actions column
                "displayAction": false,
                "callback": null,
                "returnFullDataObject": false
            },
            "saveRow": {
                //Displays the save row button in the suffix actions column
                "displayAction": false,
                "callback": null,
                "returnFullDataObject": false
            },
            "copyRow": {
                //Displays the copy row button in the suffix actions column
                "displayAction": false,
                "callback": null,
                "returnFullDataObject": false
            },
            "deleteRow": {
                //Displays the delete row button in the suffix actions column
                "displayAction": false,
                "callback": null,
                "returnFullDataObject": false,
                "disableButtonOnEdit": true
            },
            "cancelRow": {
                //Displays the cancel row button in the suffix actions column
                "displayAction": false,
                "callback": null,
                "returnFullDataObject": false
            },
            "disableOnChangesExistCssClass": null, //Any action assigned this CSS will be disabled with changes exists within the source efEntity object.
            "idField": null,     //Name of the ID field to use within the action buttons
            "tableName": null    //Unique name assigend to the table in the HTML tag's "id" attribute
        };

        /**
         * @ngdoc property
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#defaultActionButtonConfig
         * @propertyOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The defaultActionButtonConfig is an object of default efUiGrid.actionButtonConfig settings.  For complete settings details, see the {@link efAngularLibrary.efUiGrid.filter:efUiGridTemplateActionButton efUiGridTemplateActionButton} filter documentation page.
         * 
         * @returns {object} Default efUiGrid.actionButtonConfig settings.
        **/
        uiGridApi.defaultActionButtonConfig = {
            "label": "",                //Label to display - this is required!
            "id": "",                   //HTML selector for the control
            "class": "",                //CSS class(es) for the control
            "onClick": "",              //Function to execute when clicked
            "additionalParameters": ""  //Any addiation HTML parameters to add to the control (including the disabled flag)
        };

        //#endregion

        //#region Action Columns Helper Functions 

        /**
         * @ngdoc method
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#getActionColumnsConfig
         * @methodOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The getActionColumnsConfig function generates the default efUiGrid.actionColumnConfig settings for the supplied parameters.  For complete settings details, see the {@link efAngularLibrary.efUiGrid.actionColumnConfig actionColumnConfig} documentation page.
         * 
         * @param {string} tableName The unique name assigend to the table in the HTML tag's "id" attribute.  This must be provided if multiple efUiGrids using action buttons are used on a page at the same time.
         * @param {string} idField The name of the idField for the row's within the grid.  This must be provided for action buttons to work properly.
         * @param {string=} disableOnChangesExistCssClass The CSS class for the HTML elements that efEntity will search for and disable when changes exist.  This will be applied to the appropriate buttons as they are rendered.  If null or missing, then nothing is used.
         * @returns {efAngularLibrary.efUiGrid.actionColumnConfig} Object contains all of the possible configuration settings/options for the efUiGrid's action columns.
        **/
        uiGridApi.getActionColumnsConfig = function (tableName, idField, disableOnChangesExistCssClass) {
            var config = efLibrary.copyObject(uiGridApi.defaultActionColumnsConfig, true);
            if (efLibrary.isValid(tableName, true)) {
                config.tableName = tableName;
            }
            if (efLibrary.isValid(idField, true)) {
                config.idField = idField;
            }
            if (efLibrary.isValid(disableOnChangesExistCssClass, true)) {
                config.disableOnChangesExistCssClass = disableOnChangesExistCssClass;
            }
            return config;
        }

        /**
         * @ngdoc method
         * @name efAngularLibrary.efUiGrid.service:efUiGridApi.#getActionColumnDef
         * @methodOf efAngularLibrary.efUiGrid.service:efUiGridApi
         * @description 
         * 
         * The getActionColumnDef function generates the columnDef object for the selected action column.
         * 
         * @param {string} actionColumnType The action column type you want to generate the columnDef for.  The value for this parameter must be from the {@link efAngularLibrary.efUiGrid.efUiGridConstants efUiGridConstants.actionColumns} constants.
         * @param {efAngularLibrary.efUiGrid.actionColumnConfig} actionConfig The populated {@link efAngularLibrary.efUiGrid.actionColumnConfig actionColumnConfig} containing the settings for the supplied actionColumnType. 
         * @param {string} field The entoty field the action column will be bound to.  For action columns, this is typically the entity's/row's unique ID field.
         * @returns {object} Angular-ui-grid columnDef object for the action column.
        **/
        uiGridApi.getActionColumnDef = function (actionColumnType, actionConfig, field) {
            var columnName = null;
            var filterName = null;
            switch (actionColumnType) {
                case efUiGridConstants.actionColumns.PREFIX:
                    columnName = "prefixColumn";
                    filterName = "efUiGridTemplateCellPrefixColumn";
                    break;
                case efUiGridConstants.actionColumns.SUFFIX:
                    columnName = "suffixColumn";
                    filterName = "efUiGridTemplateCellSuffixColumn";
                    break;
                case efUiGridConstants.actionColumns.LINKOUT:
                    columnName = "linkOutColumn";
                    filterName = "efUiGridTemplateCellLinkOutColumn";
                    break;
            }
            var columnDef = null;
            if (efLibrary.isValid(columnName, true) && efLibrary.isValid(filterName, true) && efLibrary.isValid(actionConfig) && efLibrary.isValid(field, true)) {
                columnDef = uiGridApi.getColumnDef(columnName, field);
                columnDef.cellTemplate = String($filter(filterName)(actionConfig));
                columnDef.cellClass = "uiGrid_Column_Center";
                columnDef.enableColumnResizing = false;

                //Calculate width
                var width = "*";   //Default Width
                var buttonCount = 0;
                switch (actionColumnType) {
                    case efUiGridConstants.actionColumns.PREFIX:
                        if (efLibrary.isValid(actionConfig.moveRow) && efLibrary.toBoolean(actionConfig.moveRow.displayAction, false)) {
                            buttonCount += 2;   //moveRow is 2 buttons
                        }
                        if (efLibrary.isValid(actionConfig.insertRow) && efLibrary.toBoolean(actionConfig.insertRow.displayAction, false)) {
                            buttonCount += 1;
                        }
                        break;
                    case efUiGridConstants.actionColumns.SUFFIX:
                        if (efLibrary.isValid(actionConfig.saveRow) && efLibrary.toBoolean(actionConfig.saveRow.displayAction, false)) {
                            buttonCount += 1;
                        }
                        if (efLibrary.isValid(actionConfig.copyRow) && efLibrary.toBoolean(actionConfig.copyRow.displayAction, false)) {
                            buttonCount += 1;
                        }
                        if (efLibrary.isValid(actionConfig.deleteRow) && efLibrary.toBoolean(actionConfig.deleteRow.displayAction, false)) {
                            buttonCount += 1;
                        }
                        if (efLibrary.isValid(actionConfig.cancelRow) && efLibrary.toBoolean(actionConfig.cancelRow.displayAction, false)) {
                            buttonCount += 1;
                        }
                        break;
                    case efUiGridConstants.actionColumns.LINKOUT:
                        if (efLibrary.isValid(actionConfig.linkOut) && efLibrary.toBoolean(actionConfig.linkOut.displayAction, false)) {
                            buttonCount += 1;
                        }
                        break;
                }
                if (buttonCount > 0) {
                    //width should be 25 x the number of action buttons to display (add an extra 5 if only 1 button to display)
                    width = String((buttonCount * 25) + (buttonCount === 1 ? 5 : 0));
                }
                columnDef.width = width;
                columnDef.minWidth = width;
                columnDef.maxWidth = width;
            }

            return columnDef;
        }


        //#endregion

        return uiGridApi;
    }
})();
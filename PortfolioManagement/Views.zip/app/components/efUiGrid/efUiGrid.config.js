﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efUiGrid')
        .config(config);

    config.$inject = ['$stateProvider'];

    function config($stateProvider) {
        $stateProvider
            .state('efAngularLibrary.efUiGrid', {
                abstract: true,
                url: "/efUiGrid",
                template: "<ui-view />"
            })
            .state('efAngularLibrary.efUiGrid.demo', {
                url: "/demo",
                templateUrl: "/app/components/efUiGrid/demo/efUiGrid.demo.html",
                controller: "EfUiGridDemoCtrl",
                controllerAs: "vm"
            });
    };
})();
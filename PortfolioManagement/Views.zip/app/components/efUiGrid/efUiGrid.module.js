﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc overview
 * @name efAngularLibrary.efUiGrid
 * @description 
 * 
 * efUiGrid module provides an Angular directives, filters, and services that are used to configure and render an angular-ui-grid grid control.
 * 
 * <a href="/app/#/demo/efUiGrid/demo">For complete implmentation details see the demo page.</a>
 * 
 * This module uses features of the <a href="http://ui-grid.info/" target="_blank">angular-ui-grid</a>.  Please visit this control's web site for complete implementation details.
 * 
 * 
**/
(function () {
    angular.module('efAngularLibrary.efUiGrid', [
        'ui.grid',                      // UI.Grid
        'ui.grid.resizeColumns',        // UI.GRid Resize Columns
        'ui.grid.selection',            // UI.Grid Selection
        'ui.grid.edit',                 // UI.Grid Edit
        'ui.grid.rowEdit',              // UI.Grid.RowEdit
        'ui.grid.cellNav',              // UI.Grid Cell Navigation
        'ui.grid.pagination',           // UI.Grid Pagination
        'ui.grid.moveColumns',          // UI.Grid Move Columns
        'ui.grid.pinning',              // UI.Grid Column Pinning
        'ui.grid.exporter'
    ]);
})();
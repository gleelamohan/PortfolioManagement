﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc filter
 * @name efAngularLibrary.efUiGrid.filter:efUiGridTemplateCellSuffixColumn
 * @requires efAngularLibrary.efUiGrid.actionColumnConfig
 * @requires efAngularLibrary.efUiGrid.filter:efUiGridTemplateActionButton
 * @requires efAngularLibrary.efUiGrid.service:efUiGridApi
 * @requires efLibrary
 * @requires angular-ui-grid
 * @description 
 * 
 * efUiGridTemplateCellSuffixColumn is an Angular filter that returns the HTML for rendering the efUiGrid Suffix column.
 * 
 * This filter's config parameter is defined in the {@link efAngularLibrary.efUiGrid.actionColumnConfig actionColumnConfig}.  Example:
 * <pre>
 * { 
 *  "saveRow": {
 *      "displayAction": true,
 *      "callback": "mySaveRowCallbackFunction",
 *      "returnFullDataObject": false
 *  },
 *  "copyRow": {
 *      "displayAction": true,
 *      "callback": "myCopyRowCallbackFunction",
 *      "returnFullDataObject": false
 *  },
 *  "deleteRow": {
 *      "displayAction": true,
 *      "callback": "myDeleteRowCallbackFunction",
 *      "returnFullDataObject": false,
 *      "disableButtonOnEdit": true
 *  },
 *  "cancelRow": {
 *      "displayAction": true,
 *      "callback": "myCancelRowCallbackFunction",
 *      "returnFullDataObject": false
 *  },
 *  "disableOnChangesExistCssClass": "mydisableOnChangesExistCssClass",
 *  "idField": "MyUniqueId",
 *  "tableName": "myUniqueTableName"  
 * } 
 * </pre>
 *  
 * <a href="/app/#/demo/efUiGrid/demo">For complete implmentation details see the demo page.</a>
 * 
 * @param {efAngularLibrary.efUiGrid.actionColumnConfig} config Object containing the suffix render settings. This is defined in the {@link efAngularLibrary.efUiGrid.actionColumnConfig actionColumnConfig}.  Please see this filter's description for an example of the format used.
 * @returns {HTML} HTML for rendering an individual efUiGrid suffix column.
**/
(function () {
    angular
        .module('efAngularLibrary.efUiGrid')
        .filter('efUiGridTemplateCellSuffixColumn', efUiGridTemplateCellSuffixColumn);

    efUiGridTemplateCellSuffixColumn.$inject = ['$sce', '$filter', 'efLibrary', 'efUiGridApi'];

    function efUiGridTemplateCellSuffixColumn($sce, $filter, efLibrary, efUiGridApi) {
        return function (config) {
            var template = "";
            if (efLibrary.isValid(config)) {
                var tableNameText = efLibrary.isValid(config.tableName, true) ? config.tableName : "";
                var idFieldValueText = efLibrary.isValid(config.idField, true) ? "{{row.entity['" + config.idField + "']}}" : "";
                var disableOnChangesExistCssClassText = efLibrary.isValid(config.disableOnChangesExistCssClass, true) ? config.disableOnChangesExistCssClass : "";

                if (efLibrary.isValid(config.saveRow) && efLibrary.toBoolean(config.saveRow.displayAction, false)) {
                    var saveRowConfig = efLibrary.copyObject(efUiGridApi.defaultActionButtonConfig);
                    saveRowConfig.label = "<i class=\"fa fa-floppy-o\"></i>";
                    saveRowConfig.id = tableNameText + "SaveRow";
                    saveRowConfig.onClick = efLibrary.isValid(config.saveRow.callback, true) ? (config.saveRow.callback + "('" + idFieldValueText + "')") : "";
                    var saveRowDisabled = "ng-disabled=\"" +
                        "(row.entity['DataState'] !== undefined && row.entity['DataState'] !== null && (row.entity['DataState'] === 'Modified' || row.entity['DataState'] === 'Created') ? false : true)" +
                        "\"";
                    saveRowConfig.additionalParameters = saveRowDisabled;
                    template += String($filter("efUiGridTemplateActionButton")(saveRowConfig));
                }

                if (efLibrary.isValid(config.copyRow) && efLibrary.toBoolean(config.copyRow.displayAction, false)) {
                    var copyRowConfig = efLibrary.copyObject(efUiGridApi.defaultActionButtonConfig);
                    copyRowConfig.label = "<i class=\"fa fa-copy\"></i>";
                    copyRowConfig.id = tableNameText + "CopyRow";
                    copyRowConfig.class = disableOnChangesExistCssClassText;
                    copyRowConfig.onClick = efLibrary.isValid(config.copyRow.callback, true) ? (config.copyRow.callback + "('" + idFieldValueText + "', true)") : "";
                    template += String($filter("efUiGridTemplateActionButton")(copyRowConfig));
                }

                if (efLibrary.isValid(config.deleteRow) && efLibrary.toBoolean(config.deleteRow.displayAction, false)) {
                    var deleteRowConfig = efLibrary.copyObject(efUiGridApi.defaultActionButtonConfig);
                    deleteRowConfig.label = "<i class=\"fa fa-trash-o\"></i>";
                    deleteRowConfig.id = tableNameText + "DeleteRow";
                    deleteRowConfig.onClick = efLibrary.isValid(config.deleteRow.callback, true) ? (config.deleteRow.callback + "('" + idFieldValueText + "')") : "";
                    var deleteRowDisabled = "ng-disabled=\"";
                    if (efLibrary.toBoolean(config.deleteRow.disableButtonOnEdit, true)) {
                        deleteRowDisabled += "(row.entity['DataState'] != undefined && row.entity['DataState'] != null && (row.entity['DataState'] === 'Unchanged' || row.entity['DataState'] === 'Created') ? false : true)";
                    } else {
                        deleteRowDisabled += "(row.entity['DataState'] != undefined && row.entity['DataState'] != null && (row.entity['DataState'] === 'Unchanged' || row.entity['DataState'] === 'Created' || row.entity['DataState'] === 'Modified') ? false : true)";
                    }
                    deleteRowDisabled += "\"";
                    deleteRowConfig.additionalParameters = deleteRowDisabled;
                    template += String($filter("efUiGridTemplateActionButton")(deleteRowConfig));
                }

                if (efLibrary.isValid(config.cancelRow) && efLibrary.toBoolean(config.cancelRow.displayAction, false)) {
                    var cancelRowConfig = efLibrary.copyObject(efUiGridApi.defaultActionButtonConfig);
                    cancelRowConfig.label = "<i class=\"fa fa-undo\"></i>";
                    cancelRowConfig.id = tableNameText + "CancelRow";
                    cancelRowConfig.onClick = efLibrary.isValid(config.cancelRow.callback, true) ? (config.cancelRow.callback + "('" + idFieldValueText + "')") : "";
                    var cancelRowDisabled = "ng-disabled=\"" +
                        "(row.entity['DataState'] !== undefined && row.entity['DataState'] !== null && (row.entity['DataState'] === 'Modified' || row.entity['DataState'] === 'Created') ? false : true)" +
                        "\"";
                    cancelRowConfig.additionalParameters = cancelRowDisabled;
                    template += String($filter("efUiGridTemplateActionButton")(cancelRowConfig));
                }
            }
            return template;
        };
    }
})();
﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc filter
 * @name efAngularLibrary.efUiGrid.filter:efUiGridTemplateCellEditorEfSelect
 * @requires efAngularLibrary.efSelect.directive:efSelect
 * @requires efLibrary
 * @requires angular-ui-grid
 * @description 
 * 
 * efUiGridTemplateCellEditorEfSelect is an Angular filter that returns the HTML for rendering an individual editable efUiGrid cell with an efSelect control.
 * 
 * This filter uses features of the <a href="http://ui-grid.info/" target="_blank">angular-ui-grid</a>.  Please visit this control's web site for complete implementation details.
 * 
 * <a href="/app/#/demo/efUiGrid/demo">For complete implmentation details see the demo page.</a>
 *   
 * @param {string=} mode This is the efSelect mode parameter.  See {@link efAngularLibrary.efSelect.directive:efSelect efSelect} for complete details.
 * @param {string=} getConfig This is the efSelect getConfig parameter.  See {@link efAngularLibrary.efSelect.directive:efSelect efSelect} for complete details.
 * @param {string=} getOptions This is the efSelect getOptions parameter.  See {@link efAngularLibrary.efSelect.directive:efSelect efSelect} for complete details.
 * @param {string=} additionalParameters This is a string of any additional HTML parameters that will added to the control.  See {@link efAngularLibrary.efSelect.directive:efSelect efSelect} for complete details.
 * @returns {HTML} HTML for rendering an individual editable efUiGrid cell with an efSelect control.
**/
(function () {
    angular
        .module('efAngularLibrary.efUiGrid')
        .filter('efUiGridTemplateCellEditorEfSelect', efUiGridTemplateCellEditorEfSelect);

    efUiGridTemplateCellEditorEfSelect.$inject = ['$sce', '$filter', 'efLibrary'];

    function efUiGridTemplateCellEditorEfSelect($sce, $filter, efLibrary) {
        return function (mode, getConfig, getOptions, additionalParameters) {
            var template = "<div><form name=\"inputForm\">" +
                "<input ef-select " +
                "mode=\"" + (efLibrary.isValid(mode, true) ? mode : "") + "\" " +
                "class=\"ui-grid-cell-custom-control\"" +
                "ng-class=\"'colt' + col.uid\" " +
                "ui-grid-editor " +
                (efLibrary.isValid(getConfig, true) ? "get-config=\"efLibrary.getObjectThroughAngularScope($scope, '" + getConfig + "')\" " : "") +
                "ng-model=\"MODEL_COL_FIELD\" " +
                (efLibrary.isValid(getOptions, true) ? "get-options=\"efLibrary.getObjectThroughAngularScope($scope, '" + getOptions + "')\" " : "") +
                "in-grid=\"true\" " +
                (efLibrary.isValid(additionalParameters, true) ? additionalParameters : "") +
                "/>" +
                "</form></div>";
            return template;
        };
    }
})();
﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc filter
 * @name efAngularLibrary.efUiGrid.filter:efUiGridTemplateCellEditorEfInput
 * @requires efAngularLibrary.efInput.directive:efInput
 * @requires efLibrary
 * @requires angular-ui-grid
 * @description 
 * 
 * efUiGridTemplateCellEditorEfInput is an Angular filter that returns the HTML for rendering an individual editable efUiGrid cell with an efInput control.
 * 
 * This filter uses features of the <a href="http://ui-grid.info/" target="_blank">angular-ui-grid</a>.  Please visit this control's web site for complete implementation details.
 * 
 * <a href="/app/#/demo/efUiGrid/demo">For complete implmentation details see the demo page.</a>
 *   
 * @param {string=} getConfig This is the efInput getConfig parameter.  See {@link efAngularLibrary.efInput.directive:efInput efInput} for complete details.
 * @param {string=} getOptions This is the efInput getOptions parameter.  See {@link efAngularLibrary.efInput.directive:efInput efInput} for complete details.
 * @param {string=} additionalParameters This is a string of any additional HTML parameters that will added to the control.  See {@link efAngularLibrary.efInput.directive:efInput efInput} for complete details.
 * @returns {HTML} HTML for rendering an individual editable efUiGrid cell with an efInput control.
**/
(function () {
    angular
        .module('efAngularLibrary.efUiGrid')
        .filter('efUiGridTemplateCellEditorEfInput', efUiGridTemplateCellEditorEfInput);

    efUiGridTemplateCellEditorEfInput.$inject = ['$sce', '$filter', 'efLibrary'];

    function efUiGridTemplateCellEditorEfInput($sce, $filter, efLibrary) {
        return function (getConfig, getEntity, additionalParameters) {
            var template = "<div><form name=\"inputForm\">" +
                "<ef-input " +
                "class=\"ui-grid-cell-custom-control\"" +
                "ng-class=\"'colt' + col.uid\" " +
                "ef-ui-grid-editable-field " +
                (efLibrary.isValid(getConfig, true) ? "get-config=\"efLibrary.getObjectThroughAngularScope($scope, '" + getConfig + "')\" " : "") +
                (efLibrary.isValid(getEntity, true) ? "get-entity=\"efLibrary.getObjectThroughAngularScope($scope, '" + getEntity + "', true)\" " : "") +
                "ng-model=\"MODEL_COL_FIELD\" " +
                "model-field=\"{{col.field}}\" " +
                "ng-attr-row-data=\"row.entity\" " +
                "set-focus=\"true\" " +
                "in-grid=\"true\" " +
                (efLibrary.isValid(additionalParameters, true) ? additionalParameters : "") +
                "/>" +
                "</form></div>";
            return template;
        };
    }
})();
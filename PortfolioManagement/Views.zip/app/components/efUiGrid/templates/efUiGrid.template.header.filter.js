﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc filter
 * @name efAngularLibrary.efUiGrid.filter:efUiGridTemplateHeader
 * @requires efLibrary
 * @requires angular-ui-grid
 * @description 
 * 
 * efUiGridTemplateHeader is an Angular filter that returns the HTML for rendering an individual efUiGrid column header.  The default template for the column header is based on angular-ui-grid's default header template.
 * 
 * This filter uses features of the <a href="http://ui-grid.info/" target="_blank">angular-ui-grid</a>.  Please visit this control's web site for complete implementation details.
 * 
 * <a href="/app/#/demo/efUiGrid/demo">For complete implmentation details see the demo page.</a>
 *   
 * @param {string=} newValue This is the new HTML you would like merged into the column header.  If not provided, null, or blank, then the default header template will be returned without any changes.  If searchValue is not provided, null, or blank, then newValue will replace the template's column header display text.
 * @param {string=} searchValue This is the HTML you want to search for in the template and replace with the newValue HTML.  If not provided, null, or blank, then the template's column header display text will be replaced.
 * @param {string=} htmlSource This is an alternative template HTML to use instead of angular-ui-grid's default header template.  If not provided, null, or blank, then angular-ui-grid's default header template will be used.
 * @returns {HTML} HTML for rendering an individual efUiGrid column header.
**/
(function () {
    angular
        .module('efAngularLibrary.efUiGrid')
        .filter('efUiGridTemplateHeader', efUiGridTemplateHeader);

    efUiGridTemplateHeader.$inject = ['$sce', '$filter', 'efLibrary'];

    function efUiGridTemplateHeader($sce, $filter, efLibrary) {
        return function (newValue, searchValue, htmlSource) {
            var defaultTemplate = "<div role=\"columnheader\" ng-class=\"{ 'sortable': sortable }\" ui-grid-one-bind-aria-labelledby-grid=\"col.uid + '-header-text ' + col.uid + '-sortdir-text'\" aria-sort=\"{{col.sort.direction == asc ? 'ascending' : ( col.sort.direction == desc ? 'descending' : (!col.sort.direction ? 'none' : 'other'))}}\"><!-- <div class=\"ui-grid-vertical-bar\">&nbsp;</div> --><div role=\"button\" tabindex=\"0\" class=\"ui-grid-cell-contents ui-grid-header-cell-primary-focus\" col-index=\"renderIndex\" title=\"TOOLTIP\"><span ui-grid-one-bind-id-grid=\"col.uid + '-header-text'\">{{ col.displayName CUSTOM_FILTERS }}</span><span ng-if=\"col.sort.direction !== undefined && col.sort.direction !== null && col.sort.direction.length > 0\" ui-grid-one-bind-id-grid=\"col.uid + '-sortdir-text'\" ui-grid-visible=\"col.sort.direction\" aria-label=\"{{getSortDirectionAriaLabel()}}\"><i ng-class=\"{ 'ui-grid-icon-up-dir': col.sort.direction == asc, 'ui-grid-icon-down-dir': col.sort.direction == desc, 'ui-grid-icon-blank': !col.sort.direction }\" title=\"{{col.sort.priority ? i18n.headerCell.priority + ' ' + col.sort.priority : null}}\" aria-hidden=\"true\"> &nbsp; </i></span></div><div role=\"button\" tabindex=\"0\" ui-grid-one-bind-id-grid=\"col.uid + '-menu-button'\" class=\"ui-grid-column-menu-button\" ng-if=\"grid.options.enableColumnMenus && !col.isRowHeader && col.colDef.enableColumnMenu !== false\" ng-click=\"toggleMenu($event)\" ng-class=\"{'ui-grid-column-menu-button-last-col': isLastCol}\" ui-grid-one-bind-aria-label=\"i18n.headerCell.aria.columnMenuButtonLabel\" aria-haspopup=\"true\"><i class=\"ui-grid-icon-angle-down\" aria-hidden=\"true\">&nbsp;</i></div><div ui-grid-filter></div></div>";
            var template = efLibrary.isValid(htmlSource, true) ? htmlSource : defaultTemplate;
            var searchVal = efLibrary.isValid(searchValue, true) ? searchValue : "{{ col.displayName CUSTOM_FILTERS }}";
            template = efLibrary.isValid(newValue, true) ? template.replace(searchVal, newValue) : template;
            return template;
        };
    }
})();
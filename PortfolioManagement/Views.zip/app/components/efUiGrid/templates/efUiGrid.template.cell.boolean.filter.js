﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc filter
 * @name efAngularLibrary.efUiGrid.filter:efUiGridTemplateCellBoolean
 * @requires efAngularLibrary.efUiGrid.filter:efUiGridTemplateCell
 * @requires efLibrary
 * @requires angular-ui-grid
 * @description 
 * 
 * efUiGridTemplateCellBoolean is an Angular filter that returns the HTML for rendering an individual display-only efUiGrid cell for boolean value fields.  When the boolean field is true, then the font-awesome checkmark will be displayed.  When the boolean field is false, then a non-breaking space will be displayed.
 * 
 * This filter uses features of the <a href="http://ui-grid.info/" target="_blank">angular-ui-grid</a>.  Please visit this control's web site for complete implementation details.
 * 
 * <a href="/app/#/demo/efUiGrid/demo">For complete implmentation details see the demo page.</a>
 *   
 * @param {string=} fieldName This is the field name within the row to display as a boolean column.  If not provided, null, or blank, then the default template will be returned without any changes.
 * @returns {HTML} HTML for rendering an individual display-only efUiGrid cell for boolean value fields.
**/
(function () {
    angular
        .module('efAngularLibrary.efUiGrid')
        .filter('efUiGridTemplateCellBoolean', efUiGridTemplateCellBoolean);

    efUiGridTemplateCellBoolean.$inject = ['$sce', '$filter', 'efLibrary'];

    function efUiGridTemplateCellBoolean($sce, $filter, efLibrary) {
        return function (fieldName) {
            var fieldHtml = null;
            if (efLibrary.isValid(fieldName, true)) {
                fieldHtml = '<span ng-if="row.entity.' + fieldName + ' === true"><i class="fa fa-check"></i></span>' +
                    '<span ng-if="row.entity.' + fieldName + ' !== true">&nbsp;</span>';
            }
            return String($filter('efUiGridTemplateCell')(fieldHtml));
        };
    }
})();
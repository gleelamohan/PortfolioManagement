﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc filter
 * @name efAngularLibrary.efUiGrid.filter:efUiGridTemplateActionButton
 * @requires efAngularLibrary.efUiGrid.actionColumnConfig
 * @requires efLibrary
 * @requires angular-ui-grid
 * @description 
 * 
 * efUiGridTemplateActionButton is an Angular filter that returns the HTML for rendering an individual efUiGrid action button.
 * 
 * This filter's config parameter is derived/consolidated from the settings in the {@link efAngularLibrary.efUiGrid.actionColumnConfig actionColumnConfig}.  The following generic object format is used:
 * <pre>
 * { 
 *	"label": "the icon/label to display", 
 *	"class": "any css class to apply", 
 *	"id": "unique id for the action button", 
 *	"onClick": "the function to be called when clicked", 
 *	"additionalParameters": "any additional HTML parameters that will added to the control"
 * } 
 * </pre>
 *  
 * <a href="/app/#/demo/efUiGrid/demo">For complete implmentation details see the demo page.</a>
 * 
 * @param {object} config Object containing the action button render settings. This is derived/consolidated from the settings in the {@link efAngularLibrary.efUiGrid.actionColumnConfig actionColumnConfig}.  Please see this filter's description for a detailed description of the format used.
 * @returns {HTML} HTML for rendering an individual efUiGrid action button.
**/
(function () {
	angular
        .module('efAngularLibrary.efUiGrid')
        .filter('efUiGridTemplateActionButton', efUiGridTemplateActionButton);

	efUiGridTemplateActionButton.$inject = ['$sce', '$filter', 'efLibrary'];

	function efUiGridTemplateActionButton($sce, $filter, efLibrary) {
		return function (config) {
			var template = "";
			if (efLibrary.isValid(config) && efLibrary.isValid(config.label, true)) {
				template = "<a class=\"btn btn-lg btn-link ui-grid-icon-btn" +
                    (efLibrary.isValid(config.class, true) ? (" " + config.class) : "") + "\"" +
                    (efLibrary.isValid(config.id, true) ? (" id=\"" + config.id + "\"") : "") +
                    (efLibrary.isValid(config.onClick, true) ? (" ef-click=\"" + config.onClick + "\"") : "") +
                    (efLibrary.isValid(config.additionalParameters, true) ? (" " + config.additionalParameters) : "") +
                    ">" + config.label + "</a>";
			}
			return template;
		};
	}
})();
﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc filter
 * @name efAngularLibrary.efUiGrid.filter:efUiGridTemplateCellLinkOutColumn
 * @requires efAngularLibrary.efUiGrid.actionColumnConfig
 * @requires efAngularLibrary.efUiGrid.filter:efUiGridTemplateActionButton
 * @requires efAngularLibrary.efUiGrid.service:efUiGridApi
 * @requires efLibrary
 * @requires angular-ui-grid
 * @description 
 * 
 * efUiGridTemplateCellLinkOutColumn is an Angular filter that returns the HTML for rendering the efUiGrid Link Out column.
 * 
 * This filter's config parameter is defined in the {@link efAngularLibrary.efUiGrid.actionColumnConfig actionColumnConfig}.  Example:
 * <pre>
 * { 
 *  "linkOut": {
 *      "displayAction": true,
 *      "callback": "myLinkOutCallbackFunction",
 *      "returnFullDataObject": false,
 *      "alternateLabel": null
 *  },
 *  "idField": "MyUniqueId",
 *  "tableName": "myUniqueTableName"
 * } 
 * </pre>
 *  
 * <a href="/app/#/demo/efUiGrid/demo">For complete implmentation details see the demo page.</a>
 * 
 * @param {efAngularLibrary.efUiGrid.actionColumnConfig} config Object containing the link out render settings. This is defined in the {@link efAngularLibrary.efUiGrid.actionColumnConfig actionColumnConfig}.  Please see this filter's description for an example of the format used.
 * @returns {HTML} HTML for rendering an individual efUiGrid Link Out column.
**/
(function () {
    angular
        .module('efAngularLibrary.efUiGrid')
        .filter('efUiGridTemplateCellLinkOutColumn', efUiGridTemplateCellLinkOutColumn);

    efUiGridTemplateCellLinkOutColumn.$inject = ['$sce', '$filter', 'efLibrary', 'efUiGridApi'];

    function efUiGridTemplateCellLinkOutColumn($sce, $filter, efLibrary, efUiGridApi) {
        return function (config) {
            var template = "";
            if (efLibrary.isValid(config)) {
                var tableNameText = efLibrary.isValid(config.tableName, true) ? config.tableName : "";
                var idFieldValueText = efLibrary.isValid(config.idField, true) ? "{{row.entity['" + config.idField + "']}}" : "";

                if (efLibrary.isValid(config.linkOut) && efLibrary.toBoolean(config.linkOut.displayAction, false)) {
                    var linkOutConfig = efLibrary.copyObject(efUiGridApi.defaultActionButtonConfig);
                    linkOutConfig.label = efLibrary.isValid(config.linkOut.alternateLabel, true) ? config.linkOut.alternateLabel : "<i class=\"fa fa-external-link\"></i>";
                    linkOutConfig.id = tableNameText + "LinkOut";
                    linkOutConfig.onClick = efLibrary.isValid(config.linkOut.callback, true) ? (config.linkOut.callback + "('" + idFieldValueText + "')") : "";
                    template += String($filter("efUiGridTemplateActionButton")(linkOutConfig));
                }
            }
            return template;
        };
    }
})();
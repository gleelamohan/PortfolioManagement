﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc filter
 * @name efAngularLibrary.efUiGrid.filter:efUiGridTemplateCell
 * @requires efLibrary
 * @requires angular-ui-grid
 * @description 
 * 
 * efUiGridTemplateCell is an Angular filter that returns the HTML for rendering an individual display-only efUiGrid cell.  The default template for the cell is based on angular-ui-grid's default cell template.
 * 
 * This filter uses features of the <a href="http://ui-grid.info/" target="_blank">angular-ui-grid</a>.  Please visit this control's web site for complete implementation details.
 * 
 * <a href="/app/#/demo/efUiGrid/demo">For complete implmentation details see the demo page.</a>
 *   
 * @param {string=} newValue This is the new HTML you would like merged into the column.  If not provided, null, or blank, then the default template will be returned without any changes.  If searchValue is not provided, null, or blank, then newValue will replace the template's column display text and filter.
 * @param {string=} searchValue This is the HTML you want to search for in the template and replace with the newValue HTML.  If not provided, null, or blank, then the template's column display text and filter will be replaced.
 * @param {string=} htmlSource This is an alternative template HTML to use instead of angular-ui-grid's default cell template.  If not provided, null, or blank, then angular-ui-grid's default cell template will be used.
 * @param {boolean=} wordWrap This flag will add the appropriate CSS class to display the cell contents with word wrapping turned on.  If not provided, null, or blank, then wordWrap will be true.
 * @returns {HTML} HTML for rendering an individual display-only efUiGrid cell.
**/
(function () {
    angular
        .module('efAngularLibrary.efUiGrid')
        .filter('efUiGridTemplateCell', efUiGridTemplateCell);

    efUiGridTemplateCell.$inject = ['$sce', '$filter', 'efLibrary'];

    function efUiGridTemplateCell($sce, $filter, efLibrary) {
        return function (newValue, searchValue, htmlSource, wordWrap) {
            var defaultTemplate = "<div class=\"ui-grid-cell-contents" +
                (efLibrary.toBoolean(wordWrap, true) ? " ui-grid-cell-contents-word-wrap" : "") +
                "\" title=\"TOOLTIP\">{{COL_FIELD CUSTOM_FILTERS}}</div>";
            var template = efLibrary.isValid(htmlSource, true) ? htmlSource : defaultTemplate;
            var searchVal = efLibrary.isValid(searchValue, true) ? searchValue : "{{COL_FIELD CUSTOM_FILTERS}}";
            template = efLibrary.isValid(newValue, true) ? template.replace(searchVal, newValue) : template;
            return template;
        };
    }
})();
﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc filter
 * @name efAngularLibrary.efUiGrid.filter:efUiGridTemplateCellEditorEfDatetime
 * @requires efAngularLibrary.efDatetime.directive:efDatetime
 * @requires efLibrary
 * @requires angular-ui-grid
 * @description 
 * 
 * efUiGridTemplateCellEditorEfDatetime is an Angular filter that returns the HTML for rendering an individual editable efUiGrid cell with an efDatetime control.
 * 
 * This filter uses features of the <a href="http://ui-grid.info/" target="_blank">angular-ui-grid</a>.  Please visit this control's web site for complete implementation details.
 * 
 * <a href="/app/#/demo/efUiGrid/demo">For complete implmentation details see the demo page.</a>
 *   
 * @param {object=} config This is the efDatetime config parameter.  See {@link efAngularLibrary.efDatetime.directive:efDatetime efDatetime} for complete details.
 * @param {string=} placeholder This is the efDatetime placeholder parameter.  See {@link efAngularLibrary.efDatetime.directive:efDatetime efDatetime} for complete details.
 * @param {string=} additionalParameters This is a string of any additional HTML parameters that will added to the control.  See {@link efAngularLibrary.efDatetime.directive:efDatetime efDatetime} for complete details.
 * @returns {HTML} HTML for rendering an individual editable efUiGrid cell with an efDatetime control.
**/
(function () {
    angular
        .module('efAngularLibrary.efUiGrid')
        .filter('efUiGridTemplateCellEditorEfDatetime', efUiGridTemplateCellEditorEfDatetime);

    efUiGridTemplateCellEditorEfDatetime.$inject = ['$sce', '$filter', 'efLibrary'];

    function efUiGridTemplateCellEditorEfDatetime($sce, $filter, efLibrary) {
        return function (config, placeholder, additionalParameters) {
            var template = "<div><form name=\"inputForm\">" +
                "<input ef-datetime " +
                "class=\"ui-grid-cell-custom-control\"" +
                "ng-class=\"'colt' + col.uid\" " +
                "ui-grid-editor " +
                (efLibrary.isValid(config, true) ? "config=\"" + config + "\" " : "") +
                (efLibrary.isValid(placeholder, true) ? "placeholder=\"" + placeholder + "\" " : "") +
                "ng-model=\"MODEL_COL_FIELD\" " +
                "in-grid=\"true\" " +
                (efLibrary.isValid(additionalParameters, true) ? additionalParameters : "") +
                "/>" +
                "</form></div>";
            return template;
        };
    }
})();
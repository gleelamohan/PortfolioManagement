﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc filter
 * @name efAngularLibrary.efUiGrid.filter:efUiGridTemplateCellPrefixColumn
 * @requires efAngularLibrary.efUiGrid.actionColumnConfig
 * @requires efAngularLibrary.efUiGrid.filter:efUiGridTemplateActionButton
 * @requires efAngularLibrary.efUiGrid.service:efUiGridApi
 * @requires efLibrary
 * @requires angular-ui-grid
 * @description 
 * 
 * efUiGridTemplateCellPrefixColumn is an Angular filter that returns the HTML for rendering the efUiGrid Prefix column.
 * 
 * This filter's config parameter is defined in the {@link efAngularLibrary.efUiGrid.actionColumnConfig actionColumnConfig}.  Example:
 * <pre>
 * { 
 *  "moveRow": {
 *      "displayAction": true,
 *      "callback": "myMoveRowCallbackFunction",
 *      "returnFullDataObject": false,
 *      "moveRowButtonIdPrefix": "myMoveRowUniqueButtonIdPrefix",
 *      "orderPositionField": "OrderNumber"
 *  },
 *  "insertRow": {
 *      "displayAction": true,
 *      "callback": "myInsertRowCallbackFunction",
 *      "returnFullDataObject": false
 *  },
 *  "disableOnChangesExistCssClass": "mydisableOnChangesExistCssClass",
 *  "idField": "MyUniqueId",
 *  "tableName": "myUniqueTableName"
 * } 
 * </pre>
 *  
 * <a href="/app/#/demo/efUiGrid/demo">For complete implmentation details see the demo page.</a>
 * 
 * @param {efAngularLibrary.efUiGrid.actionColumnConfig} config Object containing the prefix render settings. This is defined in the {@link efAngularLibrary.efUiGrid.actionColumnConfig actionColumnConfig}.  Please see this filter's description for an example of the format used.
 * @returns {HTML} HTML for rendering an individual efUiGrid prefix column.
**/
(function () {
    angular
        .module('efAngularLibrary.efUiGrid')
        .filter('efUiGridTemplateCellPrefixColumn', efUiGridTemplateCellPrefixColumn);

    efUiGridTemplateCellPrefixColumn.$inject = ['$sce', '$filter', 'efLibrary', 'efUiGridApi'];

    function efUiGridTemplateCellPrefixColumn($sce, $filter, efLibrary, efUiGridApi) {
        return function (config) {
            var template = "";
            if (efLibrary.isValid(config)) {
                var tableNameText = efLibrary.isValid(config.tableName, true) ? config.tableName : "";
                var idFieldValueText = efLibrary.isValid(config.idField, true) ? "{{row.entity['" + config.idField + "']}}" : "";
                var disableOnChangesExistCssClassText = efLibrary.isValid(config.disableOnChangesExistCssClass, true) ? config.disableOnChangesExistCssClass : "";

                if (efLibrary.isValid(config.moveRow) && efLibrary.toBoolean(config.moveRow.displayAction, false)) {
                    var orderPositionFieldValueText = efLibrary.isValid(config.moveRow.orderPositionField, true) ? "{{row.entity['" + config.moveRow.orderPositionField + "']}}" : "";
                    var orderPositionFieldUpValueText = orderPositionFieldValueText.replace("}}", " - 1}}");
                    var orderPositionFieldDownValueText = orderPositionFieldValueText.replace("}}", " + 1}}");

                    var moveRowUpConfig = efLibrary.copyObject(efUiGridApi.defaultActionButtonConfig);
                    moveRowUpConfig.label = "<i class=\"fa fa-angle-up\"></i>";
                    moveRowUpConfig.id = (efLibrary.isValid(config.moveRow.moveRowButtonIdPrefix, true) ? config.moveRow.moveRowButtonIdPrefix : "") + "MovePrevious" + orderPositionFieldValueText;
                    moveRowUpConfig.class = disableOnChangesExistCssClassText;
                    moveRowUpConfig.onClick = efLibrary.isValid(config.moveRow.callback, true) ? (config.moveRow.callback + "('" + idFieldValueText + "', " + orderPositionFieldUpValueText + ",true)") : "";
                    template += String($filter("efUiGridTemplateActionButton")(moveRowUpConfig));

                    var moveRowDownConfig = efLibrary.copyObject(efUiGridApi.defaultActionButtonConfig);
                    moveRowDownConfig.label = "<i class=\"fa fa-angle-down\"></i>";
                    moveRowDownConfig.id = (efLibrary.isValid(config.moveRow.moveRowButtonIdPrefix, true) ? config.moveRow.moveRowButtonIdPrefix : "") + "MoveNext" + orderPositionFieldValueText;
                    moveRowDownConfig.class = disableOnChangesExistCssClassText;
                    moveRowDownConfig.onClick = efLibrary.isValid(config.moveRow.callback, true) ? (config.moveRow.callback + "('" + idFieldValueText + "', " + orderPositionFieldDownValueText + ",false)") : "";
                    template += String($filter("efUiGridTemplateActionButton")(moveRowDownConfig));
                }

                if (efLibrary.isValid(config.insertRow) && efLibrary.toBoolean(config.insertRow.displayAction, false)) {
                    var insertRowConfig = efLibrary.copyObject(efUiGridApi.defaultActionButtonConfig);
                    insertRowConfig.label = "+";
                    insertRowConfig.id = tableNameText + "InsertRow";
                    insertRowConfig.class = disableOnChangesExistCssClassText;
                    insertRowConfig.onClick = efLibrary.isValid(config.insertRow.callback, true) ? (config.insertRow.callback + "('" + idFieldValueText + "', false)") : "";
                    template += String($filter("efUiGridTemplateActionButton")(insertRowConfig));
                }
            }
            return template;
        };
    }
})();
﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc directive
 * @name efAngularLibrary.efUiGrid.directive:efUiGrid
 * @scope
 * @restrict AEC
 * @requires efAngularLibrary.efUiGrid.service:efUiGridApi
 * @requires angular-ui-grid
 * @requires recursionHelper
 * @requires toastr
 * @description 
 * 
 * efUiGrid is an Angular directive renders a display-only or editable grid using the supplied parameters.  This directive uses features of the <a href="http://ui-grid.info/" target="_blank">angular-ui-grid</a>.  Please visit this control's web site for complete implementation details.
 * 
 * <a href="/app/#/demo/efUiGrid/demo">For complete implmentation details see the demo page.</a>
 * 
 * @param {string} id The unique id for the table.  This value is also used in {@link efAngularLibrary.efUiGrid.actionColumnConfig actionColumnConfig}.
 * @param {string=} mode Rendering/usage mode for the control.  Valid values include "display", "select", "multiselect", "editable", "editableselect", "editablemultiselect", and "custom".
 * @param {object=} config Configuration object for the efUiGrid.  See {@link efAngularLibrary.efUiGrid.service:efUiGridApi efUiGridApi} for complete details.
 * @param {object=} gridApi This is a reference to the angular-ui-grid API object.  efUiGrid will create this API reference and make it avilable via the scope object/variable set in this parameter.  You can then use the gridApi object/variable to directly configure, manage, and manipulate the core angular-ui-grid using the API defined on the <a href="http://ui-grid.info/docs/#/api" target="_blank">angular-ui-grid's API web site</a>.
 * @param {string=} templateUrl This is an alternative HTML template URL to use instead of the default templates that are selected by the supplied mode parameter.
 * @param {Array=} selected This is an array of user-selected values for grid.  The value is determined by the selectedField paramter.  This will only be used when the mode is set to selection-capable value ("select", "multiselect", "editableselect", or "editablemultiselect").
 * @param {string=} selectedField This is row's field name that will returned when selection is turned on.  This will only be used when the mode is set to selection-capable value ("select", "multiselect", "editableselect", or "editablemultiselect").
 * @param {function=} selectedCallback This is the optional method that will be called when a row is selected in the grid.  This will only be used when the mode is set to selection-capable value ("select", "multiselect", "editableselect", or "editablemultiselect").
 * @param {function=} afterCellEditCallback This is the optional method that will be called after a field is edited, regardless if a change was made or not.  The callback method should have the following signature: <pre>myCallback = function (rowEntity, colDef, newValue, oldValue) { ... };</pre>  <a href="http://ui-grid.info/docs/#/api/ui.grid.edit.api:PublicApi" target="_blank">For complete callback details see the angular-ui-grid edit API.</a>
 * @param {function=} afterCellChangedCallback This is the optional method that will be called after a field is edited, but only if the field's value was changed.  The callback method should have the following signature: <pre>myCallback = function (rowEntity, colDef, newValue, oldValue) { ... };</pre>  <a href="http://ui-grid.info/docs/#/api/ui.grid.edit.api:PublicApi" target="_blank">For complete callback details see the angular-ui-grid edit API.</a>
 * @param {function=} beginCellEditCallback This is the optional method that will be called before a field is edited.  The callback method should have the following signature: <pre>myCallback = function (rowEntity, colDef, triggerEvent) { ... };</pre>  <a href="http://ui-grid.info/docs/#/api/ui.grid.edit.api:PublicApi" target="_blank">For complete callback details see the angular-ui-grid edit API.</a>
 * @param {function=} isRowSelectable This is the optional function to be called to determine if the current row can be selected.  The function must return a boolean value as its return value.  This will only be used when the mode is set to selection-capable value ("select", "multiselect", "editableselect", or "editablemultiselect").  The method should have the following signature: <pre>myIsRowSelectable = function (rowEntity) { ... };</pre>
**/
(function () {
    angular
        .module('efAngularLibrary.efUiGrid')
        .directive('efUiGrid', efUiGrid);

    efUiGrid.$inject = ['$sce', '$filter', '$translate', '$timeout', '$compile', '$templateCache', 'toastr', 'recursionHelper', 'efLibrary', 'efUiGridApi'];

    function efUiGrid($sce, $filter, $translate, $timeout, $compile, $templateCache, toastr, recursionHelper, efLibrary, efUiGridApi) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                id: "@",
                mode: "@?",
                config: "=?",
                data: "=?",
                gridApi: "=?",
                templateUrl: "@?",
                selected: "=?",
                selectedField: "@?",
                //view: "@?",
                //onFilterChange: "=?",
                //onPageLengthChange: "=?",
                //onSaveView: "=?",
                //onColumnVisibilityChange: "=?",
                //onExport: "=?",
                selectedCallback: "=?",
                afterCellEditCallback: "=?",
                afterCellChangedCallback: "=?",
                beginCellEditCallback: '=?',
                isRowSelectable: "=?"
                //displayDataCallback: "=?",
                //editorCloseCallback: "=?"
            },
            controller: function ($scope, $element, $attrs, $transclude) {
                var vm = this;
                var featureNotImplemented = String($filter('trustedtranslate')("efAngularLibrary.Common.FeatureNotImplmented"));

                $templateCache.put('ui-grid/selectionRowHeader',
                "<div class=\"ui-grid-disable-selection\"><div class=\"ui-grid-cell-contents\"><ui-grid-selection-row-header-buttons></ui-grid-selection-row-header-buttons></div></div>"
                );

                $templateCache.put('ui-grid/selectionRowHeaderButtons',
                "<div class=\"ui-grid-selection-row-header-buttons\" ng-class=\"{'ui-grid-row-selected': row.isSelected , 'ui-grid-icon-cancel':(!!grid.appScope.isRowSelectable)? !grid.appScope.isRowSelectable(row.entity):false, 'ui-grid-icon-ok':(!!grid.appScope.isRowSelectable)?grid.appScope.isRowSelectable(row.entity):true}\" ng-click=\"selectButtonClick(row, $event)\">&nbsp;</div>"
                );


                vm.defaultTemplateUrls = {};
                vm.defaultTemplateUrls.displayOnly = "/app/components/efUiGrid/efUiGrid.displayOnly.html";
                vm.defaultTemplateUrls.displayOnlySelection = "/app/components/efUiGrid/efUiGrid.displayOnly.selection.html";
                vm.defaultTemplateUrls.editable = "/app/components/efUiGrid/efUiGrid.editable.html";
                vm.defaultTemplateUrls.editableSelection = "/app/components/efUiGrid/efUiGrid.editable.selection.html";
                vm.templateUrl = efLibrary.isValid($scope.templateUrl, true) ? $scope.templateUrl : vm.defaultTemplateUrls.displayOnly;

                vm.currentLanguage = $translate.use();
                vm.callbackTimeout = 0;     //$timeout is used for every callback execution so the call happens asychronously (well as async as Javascript will allow given that it is single threaded).  Even a timeout of 0 milliseconds will occur asychronously after the current block of code is done executing
                vm.gridInitialized = false;

                $scope.gridSelectOptions = {};
                $scope.gridSelectOptions.enableRowSelection = false;              //Enable/disable selction by clicking on the row             
                $scope.gridSelectOptions.enableFullRowSelection = false;          //Enable/disable selction by clicking on the row  
                $scope.gridSelectOptions.enableRowHeaderSelection = false;        //Enable/disable selection row and header
                $scope.gridSelectOptions.noUnselect = false;                      //Enable/disable the abilility to unselect a row (true = no unselect)
                $scope.gridSelectOptions.multiSelect = false;                     //Enable/Disable multi-select
                $scope.gridSelectOptions.enableSelectAll = false;                 //Enable/disable select-all in header
                $scope.gridSelectOptions.modifierKeysToMultiSelect = false;       //Enable/disable the us on ctrl key on multi-selects

                $scope.gridOptions = null;
                $scope.gridData = null;

                $scope.actions = {};
                $scope.actions.select = {};
                $scope.actions.select.displayAction = false;
                $scope.actions.select.selectCount = 0;



                //#region Handle Mode changes

                function handleModeUpdates(newValue) {
                    var mode = "display";
                    var editable = false;
                    if (newValue !== undefined && newValue !== null && newValue.length > 0) {
                        switch (newValue.toLowerCase()) {
                            case "display":
                                mode = "display";
                                vm.templateUrl = efLibrary.isValid($scope.templateUrl, true) ? $scope.templateUrl : vm.defaultTemplateUrls.displayOnly;
                                $scope.actions.select.selectCount = 0;
                                $scope.actions.select.displayAction = false;
                                break;
                            case "select":
                                mode = "select";
                                vm.templateUrl = efLibrary.isValid($scope.templateUrl, true) ? $scope.templateUrl : vm.defaultTemplateUrls.displayOnlySelection;
                                $scope.actions.select.selectCount = 1;
                                $scope.actions.select.displayAction = false;
                                break;
                            case "multiselect":
                                mode = "multiselect";
                                vm.templateUrl = efLibrary.isValid($scope.templateUrl, true) ? $scope.templateUrl : vm.defaultTemplateUrls.displayOnlySelection;
                                $scope.actions.select.selectCount = -1;
                                $scope.actions.select.displayAction = true;
                                break;
                            case "editable":
                                mode = "editable";
                                vm.templateUrl = efLibrary.isValid($scope.templateUrl, true) ? $scope.templateUrl : vm.defaultTemplateUrls.editable;
                                $scope.actions.select.selectCount = 0;
                                $scope.actions.select.displayAction = false;
                                editable = true;
                                break;
                            case "editableselect":
                                mode = "editableselect";
                                vm.templateUrl = efLibrary.isValid($scope.templateUrl, true) ? $scope.templateUrl : vm.defaultTemplateUrls.editableSelection;
                                $scope.actions.select.selectCount = 1;
                                $scope.actions.select.displayAction = true;
                                editable = true;
                                break;
                            case "editablemultiselect":
                                mode = "editablemultiselect";
                                vm.templateUrl = efLibrary.isValid($scope.templateUrl, true) ? $scope.templateUrl : vm.defaultTemplateUrls.editableSelection;
                                $scope.actions.select.displayAction = true;
                                $scope.actions.select.selectCount = -1;
                                editable = true;
                                break;
                            case "custom":
                                mode = "custom";
                                vm.templateUrl = efLibrary.isValid($scope.templateUrl, true) ? $scope.templateUrl : vm.defaultTemplateUrls.displayOnly;
                                $scope.actions.select.displayAction = false;
                                $scope.actions.select.selectCount = -1;
                                break;
                            default:
                                mode = "display";
                                vm.templateUrl = efLibrary.isValid($scope.templateUrl, true) ? $scope.templateUrl : vm.defaultTemplateUrls.displayOnly;
                                $scope.actions.select.selectCount = 0;
                                $scope.actions.select.displayAction = false;
                                break;
                        }
                    }

                    if ($scope.templateUrl !== vm.templateUrl) {
                        $scope.templateUrl = vm.templateUrl;
                    }

                    if ($scope.actions.select.selectCount === 1) {
                        //Single Select
                        $scope.gridSelectOptions.enableRowSelection = true;
                        $scope.gridSelectOptions.enableFullRowSelection = editable ? false : true;
                        if (editable) {
                            $scope.gridSelectOptions.enableRowHeaderSelection = true;
                        }
                    } else if ($scope.actions.select.selectCount === -1) {
                        //Multi-Select
                        $scope.gridSelectOptions.enableRowSelection = true;
                        $scope.gridSelectOptions.enableFullRowSelection = editable ? false : true;
                        $scope.gridSelectOptions.enableRowHeaderSelection = true;
                        $scope.gridSelectOptions.multiSelect = true;
                        $scope.gridSelectOptions.enableSelectAll = true;
                    }

                    vm.mode = mode;

                    handleConfigUpdates(efLibrary.isValid($scope.gridOptions) ? $scope.gridOptions : $scope.config);
                };
                $scope.$watch('mode', handleModeUpdates, true);

                //#endregion

                //#region Handle TargetUrl changes

                function handleTargetUrlUpdates(newValue) {
                    vm.templateUrl = efLibrary.isValid(newValue, true) ? newValue : vm.defaultTemplateUrls.displayOnly;
                    handleModeUpdates($scope.mode);
                };
                $scope.$watch('targetUrl', handleTargetUrlUpdates, true);

                //#endregion

                //#region Handle View changes

                //function handleViewUpdates(newValue) {
                //    var view = "standard";
                //    if (newValue !== undefined && newValue !== null && newValue.length > 0) {
                //        switch (newValue.toLowerCase()) {
                //            case "standard":
                //                view = "standard";
                //                break;
                //            case "user":
                //                view = "user";
                //                toastr.info(featureNotImplemented);
                //                break;
                //            default:
                //                view = "standard";
                //                break;
                //        }
                //    }
                //    vm.view = view;
                //};
                //$scope.$watch('view', handleViewUpdates, true);

                //#endregion

                //#region Handle Events/Callback

                //vm.onFilterChange = function (filterTerm, filterScope) {
                //    //if (filterScope) {
                //    //    vm.gridElement.DataTable().columns((filterScope + ":name")).search(filterTerm).draw();
                //    //} else {
                //    //    vm.gridElement.DataTable().search(filterTerm).draw();
                //    //}
                //}

                //vm.onPageLengthChange = function (pageLength) {
                //    //if (pageLength) {
                //    //    vm.gridElement.DataTable().page.len(pageLength).draw();
                //    //}
                //}

                //vm.onSaveView = function () {
                //    toastr.info(featureNotImplemented);
                //}

                //vm.onExport = function () {
                //    toastr.info(featureNotImplemented);
                //}

                //vm.onColumnVisibilityChange = function (columnVisibilityOptions) {
                //    if (columnVisibilityOptions) {
                //        toastr.info(featureNotImplemented);
                //    }
                //}

                //$scope.onFilterChange = vm.onFilterChange;
                //$scope.onPageLengthChange = vm.onPageLengthChange;
                //$scope.onSaveView = vm.onSaveView;
                //$scope.onExport = vm.onExport;
                //$scope.onColumnVisibilityChange = vm.onColumnVisibilityChange;

                function handleSelectedCallbackUpdates(newValue) {
                    vm.selectedCallback = efLibrary.isValid(newValue) ? newValue : function () { };
                };
                handleSelectedCallbackUpdates();
                $scope.$watch('selectedCallback', handleSelectedCallbackUpdates, true);

                function handleAfterCellEditCallbackUpdates(newValue) {
                    vm.afterCellEditCallback = efLibrary.isValid(newValue) ? newValue : function () { };
                };
                handleAfterCellEditCallbackUpdates();
                $scope.$watch('afterCellEditCallback', handleAfterCellEditCallbackUpdates, true);

                function handleAfterCellChangedCallbackUpdates(newValue) {
                    vm.afterCellChangedCallback = efLibrary.isValid(newValue) ? newValue : function () { };
                };
                handleAfterCellChangedCallbackUpdates();
                $scope.$watch('afterCellChangedCallback', handleAfterCellChangedCallbackUpdates, true);

                function handleBeginCellEditCallbackUpdates(newValue) {
                    vm.beginCellEditCallback = efLibrary.isValid(newValue) ? newValue : function () { };
                };
                handleBeginCellEditCallbackUpdates();
                $scope.$watch('beginCellEditCallback', handleBeginCellEditCallbackUpdates, true);


                function handleisRowSelectableUpdates(newValue) {
                    vm.isRowSelectable = efLibrary.isValid(newValue) ? newValue : function (entity) { return true; };


                };

                handleisRowSelectableUpdates();
                $scope.$watch('isRowSelectable', handleisRowSelectableUpdates, true);



                //function handleDisplayDataCallbackUpdates(newValue) {
                //    vm.displayDataCallback = newValue !== undefined && newValue !== null ? newValue : function () { };
                //};
                //handleDisplayDataCallbackUpdates();
                //$scope.$watch('displayDataCallback', handleDisplayDataCallbackUpdates, true);

                //function handleEditorCloseCallbackUpdates(newValue) {
                //    vm.editorCloseCallback = newValue !== undefined && newValue !== null ? newValue : function () { };
                //};
                //handleEditorCloseCallbackUpdates();
                //$scope.$watch('editorCloseCallback', handleEditorCloseCallbackUpdates, true);

                //#endregion

                //#region Handle Action Callbacks

                //function getDataFromDatatableRow(tableName, trName) {
                //    var returnValue = null;
                //    if (tableName !== undefined && tableName !== null && tableName.length > 0 &&
                //        trName !== undefined && trName !== null && trName.length > 0) {
                //        var rowData = $(tableName).DataTable().rows(trName).data();
                //        if (rowData !== undefined && rowData !== null && rowData.length > 0) {
                //            returnValue = rowData[0];
                //        }
                //    }
                //    return returnValue;
                //}

                //function handleActionCallback(tableName, trName, callback, returnFullDataObject, otherParameters) {
                //    if (tableName !== undefined && tableName !== null && tableName.length > 0 &&
                //        trName !== undefined && trName !== null && trName.length > 0) {
                //        var returnData = null;
                //        var rowData = getDataFromDatatableRow(tableName, trName);
                //        if (rowData !== undefined && rowData !== null) {
                //            if (returnFullDataObject !== undefined && returnFullDataObject !== null && returnFullDataObject === true) {
                //                returnData = rowData;
                //            } else {
                //                returnData = rowData[$scope.idField];
                //            }
                //        }

                //        var callbackFunction = "callback(returnData";

                //        var params = [];
                //        if (otherParameters !== undefined && otherParameters !== null) {
                //            if (!Array.isArray(otherParameters) && otherParameters.length > 0) {
                //                params.push(otherParameters);
                //            } else {
                //                params = otherParameters;
                //            }
                //        }

                //        for (var i = 0; i < params.length; i++) {
                //            callbackFunction += (", " + params[i]);
                //        }

                //        callbackFunction += ");";

                //        $timeout(function () { eval(callbackFunction); }, vm.callbackTimeout);
                //    }
                //}

                //#endregion

                //#region Check and Handle Selected changes

                function handleSelectedUpdatesFromModel(newValue) {
                    var handleSelectedUpdatesFromModelEvent = document.createEvent("Event");
                    handleSelectedUpdatesFromModelEvent.initEvent("handleSelectedUpdatesFromModel", false, true);
                    if ($scope.actions.select.selectCount !== 0) {
                        var newSelectedModel = efLibrary.isValid(newValue) ? (Array.isArray(newValue) ? newValue : [newValue]) : null;
                        var selectedModel = efLibrary.isValid($scope.selectedModel) ? efLibrary.copyObject($scope.selectedModel) : null;
                        if (!efLibrary.isEqual(newSelectedModel, selectedModel) &&
                            efLibrary.isValid($scope.gridApi) &&
                            efLibrary.isValid($scope.gridApi.selection) &&
                            efLibrary.isValid($scope.gridData, true) &&
                            efLibrary.isValid($scope.selectedField, true)) {
                            $scope.gridApi.selection.clearSelectedRows(handleSelectedUpdatesFromModelEvent);
                            if (efLibrary.isValid(newSelectedModel, true)) {
                                for (var i = 0; i < newSelectedModel.length; i++) {
                                    var entity = efLibrary.getFirstObjectById($scope.selectedField, newSelectedModel[i], $scope.gridData);
                                    if (efLibrary.isValid(entity)) {
                                        $scope.gridApi.selection.selectRow(entity, handleSelectedUpdatesFromModelEvent);
                                    }
                                }
                            }
                        }
                    } else {
                        if (efLibrary.isValid($scope.gridApi) && $scope.actions.select.selectCount !== 0) {
                            $scope.gridApi.selection.clearSelectedRows(handleSelectedUpdatesFromModelEvent);
                        }
                    }
                };
                $scope.$watch('selected', handleSelectedUpdatesFromModel, true);

                function handleSelectedUpdatesFromGrid(rows, executeSelectedCallback) {
                    if (efLibrary.isValid(rows) && Array.isArray(rows) && efLibrary.isValid($scope.selectedField, true)) {
                        var selectedModel = efLibrary.isValid($scope.selected) ? ((Array.isArray($scope.selected) ? efLibrary.copyObject($scope.selected) : [efLibrary.copyObject($scope.selected)])) : [];
                        for (var i = 0; i < rows.length; i++) {
                            if (efLibrary.isValid(rows[i]) &&
                                efLibrary.isValid(rows[i].entity) &&
                                efLibrary.isValid(rows[i].entity[$scope.selectedField], true)) {
                                var rowFoundIndex = -1;
                                for (var ii = 0; ii < selectedModel.length; ii++) {
                                    if (rows[i].entity[$scope.selectedField] === selectedModel[ii]) {
                                        rowFoundIndex = ii;
                                        break;
                                    }
                                }
                                if (rows[i].isSelected && rowFoundIndex === -1 && vm.isRowSelectable(rows[i].entity)) {
                                    selectedModel.push(rows[i].entity[$scope.selectedField]);
                                } else if (!rows[i].isSelected && rowFoundIndex > -1) {
                                    selectedModel.splice(rowFoundIndex, 1);
                                }
                            }
                        }

                        $scope.selectedModel = selectedModel.length > 0 ? selectedModel : null;
                        $scope.selected = selectedModel.length > 0 ? selectedModel : null;

                        if (efLibrary.toBoolean(executeSelectedCallback, true)) {
                            $timeout(function () { vm.selectedCallback(); }, vm.callbackTimeout);
                        }
                    }
                }

                //#endregion

                //#region Handle Config changes

                function handleConfigUpdates(newValue) {
                    var config = efLibrary.isValid(newValue) ? angular.copy(newValue) : {};
                    if (!vm.gridInitialized && efLibrary.isValid(vm.mode, true)) {
                        //var config = newValue !== undefined && newValue !== null ? angular.copy(newValue) : {};

                        config.data = "gridData";

                        if (vm.mode.toLowerCase() !== "custom") {
                            //Update grid configuration with mode-based settings

                            config.enableRowSelection = $scope.gridSelectOptions.enableRowSelection;              //Enable/disable selction by clicking on the row             
                            config.enableFullRowSelection = $scope.gridSelectOptions.enableFullRowSelection;          //Enable/disable selction by clicking on the row  
                            config.enableRowHeaderSelection = $scope.gridSelectOptions.enableRowHeaderSelection;        //Enable/disable selection row and header
                            config.noUnselect = $scope.gridSelectOptions.noUnselect;                      //Enable/disable the abilility to unselect a row (true = no unselect)
                            config.multiSelect = $scope.gridSelectOptions.multiSelect;                     //Enable/Disable multi-select
                            config.enableSelectAll = $scope.gridSelectOptions.enableSelectAll;                 //Enable/disable select-all in header
                            config.modifierKeysToMultiSelect = $scope.gridSelectOptions.modifierKeysToMultiSelect;       //Enable/disable the us on ctrl key on multi-selects

                            config.virtualizationThreshold = efUiGridApi.getVirtualizationThreshold(config);
                            config.columnVirtualizationThreshold = efUiGridApi.getColumnVirtualizationThreshold(config);
                        }

                        $scope.gridOptions = angular.copy(config);
                        $scope.gridOptions.rowEditWaitInterval = -1;  // for displaying edited rows with color identifiers

                        $scope.gridOptions.onRegisterApi = function (gridApi) {
                            $scope.gridApi = gridApi;
                            vm.gridApi = $scope.gridApi;
                            if (efLibrary.isValid(gridApi.selection)) {
                                gridApi.selection.on.rowSelectionChanged($scope, function (row, event) {
                                    var executeSelectedCallback = efLibrary.isValid(event) ? (event.type === "handleSelectedUpdatesFromModel" ? false : true) : true;
                                    handleSelectedUpdatesFromGrid([row], executeSelectedCallback);
                                });

                                gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows, event) {
                                    var executeSelectedCallback = efLibrary.isValid(event) ? (event.type === "handleSelectedUpdatesFromModel" ? false : true) : true;
                                    handleSelectedUpdatesFromGrid(rows, executeSelectedCallback);
                                });
                            }

                            if (efLibrary.isValid(gridApi.edit)) {
                                gridApi.edit.on.beginCellEdit($scope, function (rowEntity, colDef, triggerEvent) {
                                    if (efLibrary.isValid(vm.beginCellEditCallback)) {
                                        $timeout(function () { vm.beginCellEditCallback(rowEntity, colDef, triggerEvent); }, vm.callbackTimeout);
                                    }
                                });

                                gridApi.edit.on.afterCellEdit($scope, function (rowEntity, colDef, newValue, oldValue) {
                                    //vm.afterCellEditCallback gets called on every afterCellEdit call
                                    if (efLibrary.isValid(vm.afterCellEditCallback)) {
                                        $timeout(function () { vm.afterCellEditCallback(rowEntity, colDef, newValue, oldValue); }, vm.callbackTimeout);
                                    }
                                    //vm.afterCellChangedCallback gets called on afterCellEdit only when the newValue and oldValue are different
                                    if (efLibrary.isValid(vm.afterCellChangedCallback) && !efLibrary.isEqual(newValue, oldValue)) {
                                        $timeout(function () { vm.afterCellChangedCallback(rowEntity, colDef, newValue, oldValue); }, vm.callbackTimeout);
                                    }
                                });
                            }
                        };

                        vm.gridInitialized = true;
                    }

                };
                $scope.$watch('config', handleConfigUpdates, true);

                //#endregion

                //#region Handle Data changes

                function handleDataUpdates(newValue) {
                    $scope.gridData = efLibrary.isValid(newValue) ? newValue : [];
                    $timeout(function () {
                        handleSelectedUpdatesFromModel($scope.selected);
                    });
                };
                $scope.$watch('data', handleDataUpdates, true);

                //#endregion

            },
            controllerAs: "vm",
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        }
    };
})();

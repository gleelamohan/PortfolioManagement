﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc directive
 * @name efAngularLibrary.efUiGrid.directive:efUiGridEditableField
 * @scope
 * @restrict A
 * @requires efAngularLibrary.efUiGrid.efUiGridConstants
 * @requires angular-ui-grid
 * @requires toastr
 * @description 
 * 
 * efUiGridEditableField is an Angular directive that intercepts change/navigation events in the parent custom control/directive and emits the change/navigation back to angular-ui-grid.  This directive replicatesand customizes the functionality of the angular-ui-grid's ui-grid-editor directive.  This directive must be added as an attribute to any custom control that is to be used for editing within efUiGrid.
 *
 * This filter uses features of the <a href="http://ui-grid.info/" target="_blank">angular-ui-grid</a>.  Please visit this control's web site for complete implementation details.
 * 
 * <a href="/app/#/demo/efUiGrid/demo">For complete implmentation details see the demo page.</a>
 * 
**/
(function () {
    angular
        .module('efAngularLibrary.efUiGrid')
        .directive('efUiGridEditableField', efUiGridEditableField);

    efUiGridEditableField.$inject = ['$sce', '$filter', '$translate', '$timeout', '$compile', 'toastr', 'uiGridConstants', 'uiGridEditConstants', 'efUiGridConstants'];

    function efUiGridEditableField($sce, $filter, $translate, $timeout, $compile, toastr, uiGridConstants, uiGridEditConstants, efUiGridConstants) {
        return {
            scope: true,
            require: ['?^uiGrid', '?^uiGridRenderContainer'],
            compile: function () {
                return {
                    pre: function ($scope, $elm, $attrs) {
                    },
                    post: function ($scope, $elm, $attrs, controllers) {
                        var uiGridCtrl, renderContainerCtrl;
                        if (controllers[0]) { uiGridCtrl = controllers[0]; }
                        if (controllers[1]) { renderContainerCtrl = controllers[1]; }

                        $scope.deepEdit = true;

                        $scope.stopEdit = function (evt) {
                            if ($scope.inputForm && !$scope.inputForm.$valid) {
                                evt.stopPropagation();
                                $scope.$emit(uiGridEditConstants.events.CANCEL_CELL_EDIT);
                            }
                            else {
                                $scope.$emit(uiGridEditConstants.events.END_CELL_EDIT);
                            }
                            $scope.deepEdit = true;
                        };

                        $scope.$on(efUiGridConstants.events.END_UI_GRID_CELL_EDIT, function (evt) {
                            $scope.stopEdit(evt);
                        });

                        $elm.on('click', function (evt) {
                            if ($elm[0].type !== 'checkbox') {
                                $scope.deepEdit = true;
                                $timeout(function () {
                                    $scope.grid.disableScrolling = true;
                                });
                            }
                        });

                        $elm.on('blur', function (evt) {
                            $scope.stopEdit(evt);
                        });

                        $scope.$on('blur', function (evt) {
                            $scope.stopEdit(evt);
                        });

                        $elm.on('keydown', function (evt) {
                            switch (evt.keyCode) {
                                case uiGridConstants.keymap.ESC:
                                    evt.stopPropagation();
                                    $scope.$emit(uiGridEditConstants.events.CANCEL_CELL_EDIT);
                                    break;
                            }

                            if ($scope.deepEdit &&
                                  (evt.keyCode === uiGridConstants.keymap.LEFT ||
                                   evt.keyCode === uiGridConstants.keymap.RIGHT ||
                                   evt.keyCode === uiGridConstants.keymap.UP ||
                                   evt.keyCode === uiGridConstants.keymap.DOWN)) {
                                evt.stopPropagation();
                            }
                                // Pass the keydown event off to the cellNav service, if it exists
                            else if (uiGridCtrl && uiGridCtrl.grid.api.cellNav) {
                                evt.uiGridTargetRenderContainerId = renderContainerCtrl.containerId;
                                if (uiGridCtrl.cellNav.handleKeyDown(evt) !== null) {
                                    $scope.stopEdit(evt);
                                }
                            }
                            else {
                                //handle enter and tab for editing not using cellNav
                                switch (evt.keyCode) {
                                    case uiGridConstants.keymap.ENTER: // Enter (Leave Field)
                                    case uiGridConstants.keymap.TAB:
                                        evt.stopPropagation();
                                        evt.preventDefault();
                                        $scope.stopEdit(evt);
                                        break;
                                }
                            }

                            return true;
                        });
                    }
                };
            }
        };
    };
})();

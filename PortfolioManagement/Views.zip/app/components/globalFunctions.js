
//#region Global Javascript Functions

function bptGetObjectAttributeCount(obj) {
    var count = 0;
    for (var attr in obj) {
        if (obj.hasOwnProperty(attr)) {
            ++count;
        }
    }
    return count;
}

function bptToBoolean(booleanValue, defaultReturnValue) {
    var returnValue = defaultReturnValue !== undefined && defaultReturnValue !== null ? bptToBoolean(defaultReturnValue) : null;
    if (booleanValue !== undefined && booleanValue !== null) {
        if ((isNaN(booleanValue) && (booleanValue.toLowerCase() === "true" || booleanValue.toLowerCase() === "yes")) ||
            (!isNaN(booleanValue) && Number(booleanValue) === 1)) {
            returnValue = true;
        } else if ((isNaN(booleanValue) && (booleanValue.toLowerCase() === "false" || booleanValue.toLowerCase() === "no")) ||
            (!isNaN(booleanValue) && Number(booleanValue) === 0)) {
            returnValue = false;
        }
    }
    return returnValue;
}


function bptValid(obj, checkForLength, checkForNull) {
    var returnValue = false;
    if (obj !== undefined) {
        if (bptToBoolean(checkForNull, true)) {
            if (obj !== null) {
                if (bptToBoolean(checkForLength, false)) {
                    if (obj.length > 0) {
                        returnValue = true;
                    }
                } else {
                    returnValue = true;
                }
            }
        } else {
            returnValue = true;
        }
    }
    return returnValue;
}

function bptSimulateDatatableTabKeyPress() {
    var cell = $('div.DTE').parent();
    if (cell) {
        if (cell.next().length) {
            // One cell to the right
            cell.next().click();
        } else {
            // Down to the next row
            cell.parent().next().children().eq(1).click();
        }
    }
}

function bptGetEditableColumn() {
    var returnValue = null;
    var cell = $('div.DTE div.DTE_Field');
    if (bptValid(cell) && cell.length > 0) {
        var cssClassPrefix = "DTE_Field_Name_";
        var classList = cell[0].className.split(/\s+/);
        for (var i = 0; i < classList.length; i++) {
            if (classList[i].substring(0, cssClassPrefix.length) === cssClassPrefix) {
                returnValue = classList[i].substring(cssClassPrefix.length);
                break;
            }
        }
    }
    return returnValue;
}

function bptGetScopeByElementSelector(elementSelector) {
    var returnValue = null;
    if (elementSelector !== undefined && elementSelector !== null && elementSelector.length > 0 &&
        $(elementSelector) !== undefined && $(elementSelector) !== null &&
        $(elementSelector).scope() !== undefined && $(elementSelector).scope() !== null) {
        returnValue = $(elementSelector).scope();
    }
    return returnValue;
}

function bptGetScopeObject(scope, objectName) {
    var returnValue = null;
    if (scope !== undefined && scope !== null &&
        objectName !== undefined && objectName !== null && objectName.length > 0) {
        var levels = objectName.split(".");
        var model = scope;
        var i = 0;
        while (i < levels.length - 1) {
            if (typeof model[levels[i]] === 'undefined') {
                model[levels[i]] = {};
            }
            model = model[levels[i]];
            i++;
        }
        returnValue = model[levels[levels.length - 1]];
    }
    return returnValue;
}

function bptGetElementSelectorByClosestParentTagName(parentNode, tagName) {
    var returnValue = null;
    if (parentNode !== undefined && parentNode !== null && tagName !== undefined && tagName !== null) {
        var parent = parentNode;
        while (parent) { //Loop through until you find the desired parent tag name
            if (parent.tagName && parent.tagName.toLowerCase() == tagName.toLowerCase()) {
                if (parent.attributes !== undefined && parent.attributes !== null && parent.attributes.length > 0) {
                    for (var i = 0; i < parent.attributes.length; i++) {
                        if (parent.attributes[i].name !== undefined && parent.attributes[i].name !== null && parent.attributes[i].name.toLowerCase() === "id") {
                            returnValue = parent.attributes[i].value !== undefined ? parent.attributes[i].value : null;
                            break;
                        }
                    }
                }
                break;
            }
            else {
                parent = parent.parentNode;
            }
        }
    }
    if (returnValue !== undefined && returnValue !== null && returnValue.length > 0 && returnValue.substring(0, 1) !== "#") {
        returnValue = "#" + returnValue;
    }
    return returnValue;
}

function bptIsValid(val, checkForLength) {
    if (checkForLength === void 0) { checkForLength = false; }
    return val === false ? true : (checkForLength ? ((!!val) && val.length > 0) : (!!val));
}


//#endregion

﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc service
 * @name efAngularLibrary.efEntity
 * @requires toastr
 * @description 
 * 
 * The efEntity provides an Angular Factory that allows for storage, management, and updating of entity/service data, as well as changes, errors, and audits associated with the entity/service data.
 * 
**/
(function () {
    angular
        .module('app')
        .factory('efEntityApi', efEntityApi);

    efEntityApi.$inject = ['$rootScope', '$resource', '$filter', '$modal', 'toastr'];

    function efEntityApi($rootScope, $resource, $filter, $modal, toastr) {
        /**
         * @ngdoc property
         * @name efAngularLibrary.efEntity.#entityApi
         * @propertyOf efAngularLibrary.efEntity
         * @description 
         * 
         * The entityApi object is core object of efAngularLibrary.efEntity.  From this you can create an entityHelper object or entityObject (using a configuration object parameter).
         * 
         * @returns {efAngularLibrary.efEntity.entityApi} Common instance of the entityApi object.
        **/
        var entityApi = {};

        /**
         * @ngdoc method
         * @name efAngularLibrary.efEntity.#entityApi.createEntityHelper
         * @methodOf efAngularLibrary.efEntity
         * @description 
         * 
         * This method creates and returns the entityApi/entityHelper object.  From this entityApi/entityHelper object you will store, manage, and update entity/service data, as well as any changes, errors, and audits associated with the entity/service data.
         * 
         * @param {function} auditPromptCallback This is the callback reference to the function that will be called after an audit is processed.
         * @returns {efAngularLibrary.efEntity.entityApi.entityHelper} Unique instance of an entityHelper object.
        **/
        entityApi.createEntityHelper = function (auditPromptCallback) {

            //#region Initialization Functions

            /**
             * @ngdoc property
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper
             * @propertyOf efAngularLibrary.efEntity
             * @description 
             * 
             * The entityHelper object is core object of efAngularLibrary.efEntity.entityApi.  From this you will store, manage, and update entity/service data, as well as any changes, errors, and audits associated with the entity/service data.
             * 
             * @returns {efAngularLibrary.efEntity.entityApi.entityHelper} Current instance of an entityHelper object.
            **/
            var entityHelper = {};

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.initConfiguration
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method initializes the entityHelper.configuration objectto its default value.
             *
            **/
            entityHelper.initConfiguration = function () {
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.configuration
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.configuration contains the current configurations settings for the entityHelper instance.
                 * 
                 * @returns {object} Current configurations settings for the entityHelper instance
                **/
                entityHelper.configuration = null;
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.initChanges
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method initializes the entityHelper.currentAction, entityHelper.changesExist, and entityHelper.changes objects to their default values.
             * 
             * @param {boolean} initChangesOnly If true, this method will only initialize the entityHelper.changes object.  If missing, null, or false, this method will initialize the entityHelper.currentAction, entityHelper.changesExist, and entityHelper.changes objects.
            **/
            entityHelper.initChanges = function (initChangesOnly) {
                if (!((initChangesOnly === undefined) || (initChangesOnly === null) ? false : ((initChangesOnly === true) || (initChangesOnly === "true") ? true : false))) {
                    /**
                     * @ngdoc property
                     * @name efAngularLibrary.efEntity.#entityApi.entityHelper.currentAction
                     * @propertyOf efAngularLibrary.efEntity
                     * @description 
                     * 
                     * entityHelper.currentAction contains a string identifying the current data operation/action being performed.  Available actions include "create", "edit", and "remove".
                     * 
                     * @returns {String} Current action.
                    **/
                    entityHelper.currentAction = null;
                    /**
                     * @ngdoc property
                     * @name efAngularLibrary.efEntity.#entityApi.entityHelper.changesExist
                     * @propertyOf efAngularLibrary.efEntity
                     * @description 
                     * 
                     * entityHelper.changesExist is a flag that denotes if changes exist or not in the current efEntity instance.
                     * 
                     * @returns {boolean} Flag to determine if changes exists in the current efEntity instance.
                    **/
                    entityHelper.changesExist = false;
                }
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.changes
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.changes contains an array of rows from the entityHelper.data object that have been changed.
                 * 
                 * @returns {Array} Array of rows from the entityHelper.data object that have been changed.
                **/
                entityHelper.changes = [];
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.initErrors
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method initializes the entityHelper.errors, entityHelper.inputErrors, and entityHelper.errorDisplayText objects/variables to their default values.
             * 
            **/
            entityHelper.initErrors = function () {
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.errors
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.errors contains an array of error objects for the current entityHelper instance.
                 * 
                 * @returns {Array} Array of error objects for the current entityHelper instance.
                **/
                entityHelper.errors = [];
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.inputErrors
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.inputErrors contains an array of error objects, formated for display inline with the UX input controls, for the current entityHelper instance.
                 * 
                 * @returns {Array} Array of error objects, formated for display inline with the UX input controls, for the current entityHelper instance.
                **/
                entityHelper.inputErrors = [];
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.errorDisplayText
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.errorDisplayText contains a HTML string of available errors, formated for display within the UX drop-down error panels, for the current entityHelper instance.
                 * 
                 * @returns {string} HTML string of available errors, formated for display within the UX drop-down error panels, for the current entityHelper instance.
                **/
                entityHelper.errorDisplayText = "";
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.initServiceData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method initializes the entityHelper.serviceData object to its default value.
             * 
            **/
            entityHelper.initServiceData = function () {
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.serviceData
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.serviceData contains an array of unchanged data rows for the current entityHelper instance.  Data within entityHelper.serviceData is not modfied by any of the efEntity logic.  It is used to represent a clean/pristine copy of the data that came from the service logic.  Common uses for entityHelper.serviceData include comparing it against entityHelper.data to determine changes, as well as replacing entityHelper.data during cancel opertions.
                 * 
                 * @returns {Array} Array of unchanged data rows for the current entityHelper instance.
                **/
                entityHelper.serviceData = [];
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.initData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method initializes the entityHelper.data object to its default value.
             * 
            **/
            entityHelper.initData = function () {
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.data
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.data contains an array of updateable data rows for the current entityHelper instance.  Data within entityHelper.data is modfied by the efEntity logic.  It is used to represent the current updateable working set of data that came from the service logic.  All efEntity generated changes and errors will be based on the data in entityHelper.data.
                 * 
                 * @returns {Array} Array of updateable data rows for the current entityHelper instance.
                **/
                entityHelper.data = [];
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.initSupplementalData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method initializes the entityHelper.supplementalData object to its default value.
             * 
            **/
            entityHelper.initSupplementalData = function () {
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.supplementalData
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.supplementalData contains an array of discreet, uniquely keyed datasets that can be used as supplemental/reference data for the current entityHelper instance.  Common uses for entityHelper.supplementalData include comparing storing option lists for bound efSelect controls, as well as lookup datasets for the efLookupValue filter.
                 * 
                 * @returns {Array} Array of discreet, uniquely keyed datasets that can be used as supplemental/reference data for the current entityHelper instance.
                **/
                entityHelper.supplementalData = [];
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.initAuditData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method initializes the entityHelper.audit objects and varibales to their default values.
             * 
            **/
            entityHelper.initAuditData = function () {
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.isAuditing
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.isAuditing is a flag that determines if the entityHelper instance is in the process of auditing data.
                 * 
                 * @returns {boolean} Flag that determines if the entityHelper instance is in the process of auditing data.
                **/
                entityHelper.isAuditing = false;
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.auditModalScope
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.auditModalScope contains current modal scope for the current entityHelper instance's audit modal form.
                 * 
                 * @returns {object} Object of the current modal scope for the current entityHelper instance's audit modal form.
                **/
                entityHelper.auditModalScope = undefined;
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.auditPromptData
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.auditPromptData contains an array of data for the audit prompt logic for the current entityHelper instance.
                 * 
                 * @returns {Array} Array of data for the audit prompt logic for the current entityHelper instance.
                **/
                entityHelper.auditPromptData = [];
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.auditPromptReturnData
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.auditPromptReturnData contains an array of data returned from the audit prompt logic for the current entityHelper instance.
                 * 
                 * @returns {Array} Array of data returned from the audit prompt logic for the current entityHelper instance.
                **/
                entityHelper.auditPromptReturnData = [];
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.initAllData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method initializes all entityHelper data-related objects and varibales to their default values.  These include entityHelper.serviceData, entityHelper.data, entityHelper.supplementalData (optional), entityHelper.Changes, entityHelper.errors (all error objects/variables), and entityHelper.auditData (all audit objects/variables).
             * 
             * @param {boolean} initSupplementalData If false, null, or not provided, then entityHelper.supplementalData will not be initilized with the other objects/variables.
            **/
            entityHelper.initAllData = function (initSupplementalData) {
                entityHelper.initServiceData();
                entityHelper.initData();
                if ((initSupplementalData === undefined) || (initSupplementalData === null) ? false : ((initSupplementalData === true) || (initSupplementalData === "true") ? true : false)) {
                    entityHelper.initSupplementalData();
                }
                entityHelper.initChanges();
                entityHelper.initErrors();
                entityHelper.initAuditData();
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.initValidationFunctions
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method initializes the entityHelper.validationFunctions object.
             * 
            **/
            entityHelper.initValidationFunctions = function () {
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.validationFunctions
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.validationFunctions contains an array of objects that contain uniquely keyed, field specific Javascript validation functions that efEntity will use to validate the efEntity data and generate field-level errors.
                 * 
                 * @returns {Array} Array of objects that contain uniquely keyed, field specific Javascript validation functions that efEntity will use to validate the efEntity data and generate field-level errors.
                **/
                entityHelper.validationFunctions = [];
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.initI18nMessages
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method initializes the entityHelper.i18nMessages object.
             * 
            **/
            entityHelper.initI18nMessages = function () {
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.i18nMessages
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.i18nMessages contains an object of user displayed messages that require the developer to supply language specific translation keys for.
                 * 
                 * @returns {efAngularLibrary.efEntity.entityApi.entityHelper.i18nMessages} Object of user displayed messages that require the developer to supply language specific translation keys for.
                **/
                entityHelper.i18nMessages = {
                    /**
                     * @ngdoc property
                     * @name efAngularLibrary.efEntity.#entityApi.entityHelper.i18nMessages.errorTextHeader
                     * @propertyOf efAngularLibrary.efEntity
                     * @description 
                     * 
                     * entityHelper.i18nMessages.errorTextHeader contains the translation key for the preceeding text that gets displayed in the error panel when displaying errors.
                     * 
                     * @returns {string} The translation key for the preceeding text that gets displayed in the error panel when displaying errors.
                    **/
                    "errorTextHeader": "",
                    /**
                     * @ngdoc property
                     * @name efAngularLibrary.efEntity.#entityApi.entityHelper.i18nMessages.errorTextHeaderSuffix
                     * @propertyOf efAngularLibrary.efEntity
                     * @description 
                     * 
                     * entityHelper.i18nMessages.errorTextHeaderSuffix contains the translation key for the text that comes after the errors in the error panel.
                     * 
                     * @returns {string} The translation key for the text that comes after the errors in the error panel.
                    **/
                    "errorTextHeaderSuffix": "",
                    /**
                     * @ngdoc property
                     * @name efAngularLibrary.efEntity.#entityApi.entityHelper.i18nMessages.noErrorsFound
                     * @propertyOf efAngularLibrary.efEntity
                     * @description 
                     * 
                     * entityHelper.i18nMessages.noErrorsFound contains the translation key for the text that gets desplayed when no errors are found.
                     * 
                     * @returns {string} The translation key for the text that gets desplayed when no errors are found.
                    **/
                    "noErrorsFound": ""
                };
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.init
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method initializes all entityHelper objects and varibales to their default values.
            **/
            entityHelper.init = function () {
                entityHelper.initConfiguration();
                entityHelper.initAllData(true);
                entityHelper.initValidationFunctions();
                entityHelper.initI18nMessages();
                
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.defaultDataTemplate
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.defaultDataTemplate contains the default data template object for the current entityHelper instance.  This can be used as a template for new data entries (including deep hierarchy layouts and default values).
                 * 
                 * @returns {object} The default data template object for the current entityHelper instance.
                **/
                entityHelper.defaultDataTemplate = {};
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.idField
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.idField contains the name of the unique id field for the current entityHelper instance.
                 * 
                 * @returns {string} The name of the unique id field for the current entityHelper instance.
                **/
                entityHelper.idField = "";
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.prefixFieldForErrorDisplayText
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.prefixFieldForErrorDisplayText contains the name of the field that will prefix all field-level error messages in entityHelper.errorDisplayText value.  If not provided or null, then no prefix will be added.
                 * 
                 * @returns {string} The name of the field that will prefix all field-level error messages in entityHelper.errorDisplayText value.
                **/
                entityHelper.prefixFieldForErrorDisplayText = null;
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.disableOnChangesExistCssClass
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.disableOnChangesExistCssClass contains the CSS class for the HTML elements that efEntity will search for and disable when changes exist.
                 * 
                 * @returns {string} The CSS class for the HTML elements that efEntity will search for and disable when changes exist.
                **/
                entityHelper.disableOnChangesExistCssClass = null;
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.moveRowButtonIdPrefix
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.moveRowButtonIdPrefix contains the unique prefix text that will be added to the HTML id attribute of any efUiGrid "moveRow" action buttons.  This is required when efUiGrid is being used with "moveRow" action buttons.
                 * 
                 * @returns {string} The unique prefix text that will be added to the HTML id attribute of any efUiGrid "moveRow" action buttons.
                **/
                entityHelper.moveRowButtonIdPrefix = "";
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.orderPositionField
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.orderPositionField contains the name of the field that provides the current ordering postion.  This is required when efUiGrid is being used with "moveRow" action buttons, as well as when efUiGrid insert and copy operations that are postion specific are required.
                 * 
                 * @returns {string} The name of the field that provides the current ordering postion. 
                **/
                entityHelper.auditPromptCallBack = "";
                /**
                 * @ngdoc property
                 * @name efAngularLibrary.efEntity.#entityApi.entityHelper.auditPromptCallBack
                 * @propertyOf efAngularLibrary.efEntity
                 * @description 
                 * 
                 * entityHelper.orderPositionField contains the callback reference to the function that will be called after an audit is processed.  This is defaulted to the value provided when the entityApi.createEntityHelper() function called.
                 * @returns {string} The callback reference to the function that will be called after an audit is processed.
                **/
                entityHelper.auditPromptCallBack = auditPromptCallback;
            }

            //#endregion

            //#region Data Object Support Functions

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.setServiceData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method sets the entityHelper.serviceData to the provided data parameter.
             * 
             * @param {Array|object} data This is the data array/object that the entityHelper.serviceData array will be set to.  It can be either an array of data entry objects or a single data entry object.
            **/
            entityHelper.setServiceData = function (data) {
                if (data !== undefined && data != null) {
                    if (Array.isArray(data)) {
                        entityHelper.serviceData = entityHelper.copyObject(data);
                    } else {
                        entityHelper.initServiceData();
                        entityHelper.serviceData.push(entityHelper.copyObject(data));
                    }
                    entityHelper.initAuditService(data);
                }
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.addToServiceData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method adds the provided data to the existing entityHelper.serviceData array.
             * 
             * @param {Array|object} data This is the data array/object that will be added to the entityHelper.serviceData array.  It can be either an array of data entry objects or a single data entry object.
            **/
            entityHelper.addToServiceData = function (data) {
                if (data !== undefined && data != null) {
                    if (Array.isArray(data)) {
                        for (var i = 0; i < data.length; i++) {
                            entityHelper.serviceData.push(entityHelper.copyObject(data[i]));
                        }
                    } else {
                        entityHelper.serviceData.push(entityHelper.copyObject(data));
                    }
                }
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.replaceServiceData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method replaces an existing entityHelper.serviceData entry, for the provided id, with the provided data.  The udpated entry's DataState fields can also be optionally reset to its default value.
             * 
             * @param {any} id This is the id value for the exiting data entry that is to be replaced.
             * @param {object} data This is the updated data that will be saved to the existing entry.  This must be a single data object and not an array of data entries.
             * @param {boolean} resetDataState If true the entry's DataState field will be reset to the default value.  If false, null, or not  provided, the entry's DataState field will remain as set in the provided data entry object.
            **/
            entityHelper.replaceServiceData = function (id, data, resetDataState) {
                if (id !== undefined && id !== null && data !== undefined && data != null) {
                    for (var i = 0; i < entityHelper.serviceData.length; i++) {
                        if (entityHelper.serviceData[i][entityHelper.idField] === id) {
                            entityHelper.serviceData[i] = entityHelper.copyObject(data);
                            if ((resetDataState === undefined) || (resetDataState === null) ? false : ((resetDataState === true) || (resetDataState === "true") ? true : false)) {
                                entityHelper.serviceData[i].DataState = entityHelper.getDefaultDataState();
                            }
                            break;
                        }
                    }
                }
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.setData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method sets the entityHelper.data to the provided data parameter.
             * 
             * @param {Array|object} data This is the data array/object that the entityHelper.data array will be set to.  It can be either an array of data entry objects or a single data entry object.
            **/
            entityHelper.setData = function (data) {
                if (data !== undefined && data != null) {
                    if (Array.isArray(data)) {
                        entityHelper.data = entityHelper.copyObject(data);
                    } else {
                        entityHelper.initData();
                        entityHelper.data.push(entityHelper.copyObject(data));
                    }
                    entityHelper.initAuditService(data);
                }
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.addToData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method adds the provided data to the existing entityHelper.data array.
             * 
             * @param {Array|object} data This is the data array/object that will be added to the entityHelper.data array.  It can be either an array of data entry objects or a single data entry object.
            **/
            entityHelper.addToData = function (data) {
                if (data !== undefined && data != null) {
                    if (Array.isArray(data)) {
                        for (var i = 0; i < data.length; i++) {
                            entityHelper.data.push(entityHelper.copyObject(data[i]));
                        }
                    } else {
                        entityHelper.data.push(entityHelper.copyObject(data));
                    }
                }
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.replaceData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method replaces an existing entityHelper.data entry, for the provided id, with the provided data.  The udpated entry's DataState fields can also be optionally reset to its default value.
             * 
             * @param {any} id This is the id value for the exiting data entry that is to be replaced.
             * @param {object} data This is the updated data that will be saved to the existing entry.  This must be a single data object and not an array of data entries.
             * @param {boolean} resetDataState If true the entry's DataState field will be reset to the default value.  If false, null, or not  provided, the entry's DataState field will remain as set in the provided data entry object.
            **/
            entityHelper.replaceData = function (id, data, resetDataState) {
                if (id !== undefined && id !== null && data !== undefined && data != null) {
                    for (var i = 0; i < entityHelper.data.length; i++) {
                        if (entityHelper.data[i][entityHelper.idField] === id) {
                            entityHelper.data[i] = entityHelper.copyObject(data);
                            if ((resetDataState === undefined) || (resetDataState === null) ? false : ((resetDataState === true) || (resetDataState === "true") ? true : false)) {
                                entityHelper.data[i].DataState = entityHelper.getDefaultDataState();
                            }
                            break;
                        }
                    }
                }
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.setSupplementalData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method sets the entityHelper.supplementalData to the provided data parameter.
             * 
             * @param {Array|object} data This is the data array/object that the entityHelper.supplementalData array will be set to.  It can be either an array of data entry objects or a single data entry object.
            **/
            entityHelper.setSupplementalData = function (data) {
                if (data !== undefined && data != null) {
                    if (Array.isArray(data)) {
                        entityHelper.supplementalData = entityHelper.copyObject(data);
                    } else {
                        entityHelper.initSupplementalData();
                        entityHelper.supplementalData.push(entityHelper.copyObject(data));
                    }
                }
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.addToSupplementalData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method adds the provided data to the existing entityHelper.supplementalData array.
             * 
             * @param {Array|object} data This is the data array/object that will be added to the entityHelper.supplementalData array.  It can be either an array of data entry objects or a single data entry object.
            **/
            entityHelper.addToSupplementalData = function (data) {
                if (data !== undefined && data != null) {
                    if (Array.isArray(data)) {
                        for (var i = 0; i < data.length; i++) {
                            entityHelper.supplementalData.push(entityHelper.copyObject(data[i]));
                        }
                    } else {
                        entityHelper.supplementalData.push(entityHelper.copyObject(data));
                    }
                }
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.replaceSupplementalData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method replaces an existing entityHelper.supplementalData entry, for the provided idField, with the provided data.
             * 
             * @param {string} idField This is the id value for the exiting data entry that is to be replaced.
             * @param {object} data This is the updated data that will be saved to the existing entry.  This must be a single data object and not an array of data entries.
            **/
            entityHelper.replaceSupplementalData = function (idField, data) {
                if (idField !== undefined && idField !== null && data !== undefined && data != null
                    && data[idField] !== undefined && data[idField] !== null) {
                    for (var i = 0; i < entityHelper.supplementalData.length; i++) {
                        if (entityHelper.supplementalData[i][idField] === data[idField]) {
                            entityHelper.supplementalData[i] = entityHelper.copyObject(data);
                            break;
                        }
                    }
                }
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.setChanges
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method sets the entityHelper.changes to the provided data parameter.
             * 
             * @param {Array|object} data This is the data array/object that the entityHelper.changes array will be set to.  It can be either an array of data entry objects or a single data entry object.
            **/
            entityHelper.setChanges = function (data) {
                if (data !== undefined && data != null) {
                    if (Array.isArray(data)) {
                        entityHelper.changes = entityHelper.copyObject(data);
                    } else {
                        entityHelper.initChanges(true);
                        entityHelper.changes.push(entityHelper.copyObject(data));
                    }
                }
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.addToChanges
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method adds the provided data to the existing entityHelper.changes array.
             * 
             * @param {Array|object} data This is the data array/object that will be added to the entityHelper.changes array.  It can be either an array of data entry objects or a single data entry object.
            **/
            entityHelper.addToChanges = function (data) {
                if (data !== undefined && data != null) {
                    if (Array.isArray(data)) {
                        for (var i = 0; i < data.length; i++) {
                            entityHelper.changes.push(entityHelper.copyObject(data[i]));
                        }
                    } else {
                        entityHelper.changes.push(entityHelper.copyObject(data));
                    }
                }
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.replaceChanges
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method replaces an existing entityHelper.changes entry, for the provided id, with the provided data.
             * 
             * @param {any} id This is the id value for the exiting data entry that is to be replaced.
             * @param {object} data This is the updated data that will be saved to the existing entry.  This must be a single data object and not an array of data entries.
            **/
            entityHelper.replaceChanges = function (id, data) {
                if (id !== undefined && id !== null && data !== undefined && data != null) {
                    for (var i = 0; i < entityHelper.changes.length; i++) {
                        if (entityHelper.changes[i][entityHelper.idField] === id) {
                            entityHelper.changes[i] = entityHelper.copyObject(data);
                            break;
                        }
                    }
                }
            }

            //#endregion

            //#region Audit Functions

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.initAuditService
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method initializes the audit service with the data provided.
             * 
             * @param {object} data This is the updated data that will be used to setup the auditing service.
            **/
            entityHelper.initAuditService = function (data) {
                var isDataAuditable;
                var arrayResults;
                if (Array.isArray(data)) {
                    arrayResults = $.grep(data, function (e) { return e.hasOwnProperty("AuditPrompts") && e["AuditPrompts"] !== null && e["AuditPrompts"].length > 0; });
                    isDataAuditable = (arrayResults !== undefined && arrayResults !== null && arrayResults.length > 0);
                } else {
                    isDataAuditable = (data.hasOwnProperty("AuditPrompts") && data["AuditPrompts"] !== null && data["AuditPrompts"].length > 0);
                }

                if (isDataAuditable == true && entityHelper.isAuditing == false) {
                    entityHelper.isAuditing = true;
                    if (Array.isArray(data)) {
                        for (var i = 0; i < arrayResults.length; i++) {
                            entityHelper.auditPromptData.push({ id: arrayResults[i][entityHelper.idField], data: entityHelper.copyObject(arrayResults[i]["AuditPrompts"]) });
                        }
                    } else {
                        entityHelper.auditPromptData.push({ id: data[entityHelper.idField], data: entityHelper.copyObject(data["AuditPrompts"]) });
                    }
                }
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.clearAuditChangeReasons
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method clears/removes the audit change reasons for an given entityId.
             * 
             * @param {any} entityId This is id of the entity you wish to remove the audit changes for.
            **/
            entityHelper.clearAuditChangeReasons = function (entityId) {
                var idx = -1;
                //Clear out Audit rfc return data
                for (var i = 0; i < entityHelper.auditPromptReturnData.length; i++) {
                    if (entityHelper.auditPromptReturnData[i].id == entityId) {
                        idx = i;
                        break;
                    }
                }
                if (idx >= 0)
                    entityHelper.auditPromptReturnData.splice(idx, 1);
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.openAuditPrompt
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method will open the modal audit prompt window and process the audit results that are returned by the user.
             * 
             * @param {object} fieldPromptData This is data object will be used to prrovide setup/input data to the audit prompt window.
             * @param {object} entityData This is data object cotains the entity data for the audit prompt window.
            **/
            function openAuditPrompt(fieldPromptData, entityData) {
                entityHelper.auditModalScope = $rootScope.$new();
                entityHelper.auditModalScope.modal = {
                    instance: null,
                    data: fieldPromptData
                };
                entityHelper.auditModalScope.entityDeferredData = entityData;
                entityHelper.auditModalScope.onOkCallback = entityHelper.auditPromptCallBack;
                entityHelper.auditModalScope.modal.instance = $modal.open({
                    template: "<ef-Audit-Prompt ng-Model='modal'></ef-Audit-Prompt>",
                    windowClass: "efAuditPromptModalWindow",
                    scope: entityHelper.auditModalScope,
                    backdrop: 'static'
                });

                //Modal Result
                entityHelper.auditModalScope.modal.instance.result.then(function (modalReturnScope) {
                    if (modalReturnScope !== undefined && modalReturnScope !== null) {
                        var found = false;
                        for (var i = 0; i < entityHelper.auditPromptReturnData.length; i++) {
                            if (entityHelper.auditPromptReturnData[i]["id"] == modalReturnScope.EntityId) {
                                entityHelper.auditPromptReturnData[i]["data"].push(entityHelper.copyObject(modalReturnScope));
                                found = true;
                                break;
                            }
                        }
                        if (!found) {
                            entityHelper.auditPromptReturnData.push({ id: modalReturnScope.EntityId, data: [entityHelper.copyObject(modalReturnScope)] });
                        }

                        //Update deffered entity data with new change reason
                        if (entityHelper.auditModalScope.entityDeferredData !== undefined && entityHelper.auditModalScope.entityDeferredData !== null && entityHelper.auditModalScope.entityDeferredData.hasOwnProperty("AuditChangeReasons")) {
                            entityHelper.auditModalScope.entityDeferredData.AuditChangeReasons = entityHelper.copyObject(entityHelper.getFirstValueById('id', modalReturnScope.EntityId, 'data', entityHelper.auditPromptReturnData));
                        }
                        //Run callback function if exists
                        if (entityHelper.auditModalScope.onOkCallback !== undefined && entityHelper.auditModalScope.onOkCallback !== null) {
                            entityHelper.auditModalScope.onOkCallback();
                        }

                        //Update data and changes to signal that a change exists even though it's an exact copy of current data for this entity. This ensures that the rfc(s) are persisted in case the developer ignores change data.
                        entityHelper.replaceData(modalReturnScope.EntityId, entityHelper.auditModalScope.entityDeferredData);
                        var results = $.grep(entityHelper.changes, function (e) { return e[entityHelper.idField] === modalReturnScope.EntityId; });
                        if (results !== undefined && results !== null && results.length > 0) {
                            entityHelper.replaceChanges(modalReturnScope.EntityId, entityHelper.auditModalScope.entityDeferredData);
                        } else {
                            entityHelper.addToChanges(entityHelper.auditModalScope.entityDeferredData);
                        }
                    }
                    entityHelper.initErrors();
                    entityHelper.auditModalScope = undefined;
                }, function () {
                    /*Modal dismissed/cancelled*/
                    entityHelper.auditModalScope = undefined;
                });
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.prepAuditPrompt
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method sets up the audit ptompt process, including comparing incoming data to determine auditing eligibility, determine if audit data has already been provided, and determine if/what audits are to be prompted for.
             * 
             * @param {object} data This is entity data object 
             * @param {string} errorField This returns the field name for error display.
             * @param {boolean} volatileDataCompareForAudit This flag determines is the data comparison is volatile.
             * @returns {boolean} Flag if the audit prompt prep was successful.
            **/
            function prepAuditPrompt(data, errorField, volatileDataCompareForAudit) {
                volatileDataCompareForAudit = volatileDataCompareForAudit == true;
                if (data === undefined || data === null)
                    return true;
                //Step 1a: compare incoming data with prompt data to determine prompt eligibility (Extract appropriate AuditDefinitionIds)
                var auditDefIds = [];
                var currentPromptData = entityHelper.getFirstValueById('id', data[entityHelper.idField], 'data', entityHelper.auditPromptData);
                if (currentPromptData === undefined || currentPromptData == null)
                    return true; //nothing to prompt with
                for (var i = 0; i < currentPromptData.length; i++) {
                    if (data.hasOwnProperty(currentPromptData[i].PropertyName))
                        auditDefIds.push(entityHelper.copyObject(currentPromptData[i].AuditDefinitionId));
                }
                //Step 1b: If number of prompts does not equal the number of matching properties found
                if (currentPromptData.length !== auditDefIds.length) {
                    //missing properties.
                    throw new Error('Entity is missing one or more properties defined for rfc capture.');
                }
                //Step 2: Examine auditPromptReturnData to see if auditDefIds extracted in step 1 already exist (Meaning rfc already entered).
                var currentPromptReturnData = entityHelper.getFirstValueById('id', data[entityHelper.idField], 'data', entityHelper.auditPromptReturnData);
                if (currentPromptReturnData === undefined || currentPromptReturnData === null)
                    currentPromptReturnData = [];
                for (var j = 0; j < auditDefIds.length; j++) {
                    var results = $.grep(currentPromptReturnData, function (e) { return e.AuditDefinitionId == auditDefIds[j]; });
                    if (results === undefined || results === null || results.length == 0) {
                        //No existing rfc data for current property so....
                        //a.First, make sure there are actual changes to the data. Compare current value with latest stored version (changes/data are used if volatileDataCompareForAudit == true otherwise use serviceData)
                        var thisFieldPromptData = currentPromptData.filter(function (obj) {
                            return obj.AuditDefinitionId == auditDefIds[j];
                        });
                        results = [];
                        var changeResults = $.grep(entityHelper.changes, function (e) { return e[entityHelper.idField] == data[entityHelper.idField]; });
                        var dataResults = $.grep(entityHelper.data, function (e) { return e[entityHelper.idField] == data[entityHelper.idField]; });
                        var serviceDataResults = $.grep(entityHelper.serviceData, function (e) { return e[entityHelper.idField] == data[entityHelper.idField]; });
                        if (changeResults.length > 0 && volatileDataCompareForAudit) {
                            if (changeResults[0][thisFieldPromptData[0].PropertyName] !== dataResults[0][thisFieldPromptData[0].PropertyName]) {
                                results = changeResults;
                            } else {
                                results = dataResults;
                            }
                        }
                        if (dataResults.length > 0 && volatileDataCompareForAudit) {
                            if (dataResults[0][thisFieldPromptData[0].PropertyName] !== serviceDataResults[0][thisFieldPromptData[0].PropertyName]) {
                                results = dataResults;
                            } else {
                                results = serviceDataResults;
                            }
                        }
                        if (results.length == 0) {
                            results = serviceDataResults;
                        }
                        if (results[0][thisFieldPromptData[0].PropertyName] == data[thisFieldPromptData[0].PropertyName]) {
                            //No changes to data so continue loop
                            continue;
                        }
                        //Don't prompt for null to empty string or vice versa changes.
                        var nullEmptyCheck1 = results[0][thisFieldPromptData[0].PropertyName] === null ? "" : results[0][thisFieldPromptData[0].PropertyName];
                        var nullEmptyCheck2 = data[thisFieldPromptData[0].PropertyName] === null ? "" : data[thisFieldPromptData[0].PropertyName];
                        if (nullEmptyCheck1 == nullEmptyCheck2) {
                            //One of the vars was originally null and the other was an empty string so conitnue
                            continue;
                        }
                        //b.Resume construction of field prompt data
                        thisFieldPromptData[0].EntityId = data[entityHelper.idField];
                        //c. Compare DataState to Verb
                        if (!data.hasOwnProperty("DataState")) {
                            throw new Error('Entity has no DataState property.');
                        }
                        var showPrompt;
                        switch (data["DataState"]) {
                            case "Created":
                                showPrompt = (thisFieldPromptData[0].Verb == 'Post');
                                break;
                            case "Unchanged":
                            case "Modified":
                                showPrompt = (thisFieldPromptData[0].Verb == 'Put');
                                break;
                            case "Deleted":
                                showPrompt = (thisFieldPromptData[0].Verb == 'Delete');
                                break;
                            default:
                                showPrompt = false;
                        }
                        //If verbs coincide with entity's datastate then show audit modal
                        if (showPrompt == true) {
                            openAuditPrompt(thisFieldPromptData[0], data);
                            errorField = thisFieldPromptData[0].PropertyName; //Return field name for error display
                            return false;
                        } else {
                            return true;
                        }
                    }
                }
                return true;
            }

            //#endregion

            //#region Validation and Error Functions

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.createError
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method creates a generic error object that can be used within efEntity.
             * 
             * The error object has the following format:
             * <pre>
             * {
             *  "cssClass": "has-error",
             *  "id": "3b5eb85c-b700-4923-bcaa-0d44d44bd5d0",
             *  "name": "courierName",
             *  "ststus": "Courier Name must be provided."
             * }
             * </pre>
             * 
             * @param {any} id The unique key/id for the data row/entry this error is associated with.  This is typically the value for the row's entityHelper.idField.  If not provided or null, then the default value will be "".
             * @param {string} name The field name this error is assocaited with.  If not provided or null, then the default value will be "".
             * @param {string} status The error message to display. If not provided or null, then the default value will be "".
             * @param {string} cssClass The CSS class to apply to the error.  If not provided or null, then the default value will be the Bootstrap "has-error" class.
             * @returns {object} JSON Error Object with default and/or supplied values.
            **/
            entityHelper.createError = function (id, name, status, cssClass) {
                return {
                    "cssClass": ((cssClass !== undefined && cssClass !== null) ? cssClass : "has-error"),
                    "id": ((id !== undefined && id !== null) ? id : ""),
                    "name": ((name !== undefined && name !== null) ? name : ""),
                    "status": ((status !== undefined && status !== null) ? status : "")
                };
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.checkForErrors
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method will check for validation errors for each field in the supplied data object and return the errors as an array of error objects.
             * 
             * See entityHelper.createError() for error object details.
             * 
             * @param {object} data The row/data object to check for errors.  This must be a signle row/data object and not an array of rows/data objects.
             * @param {boolean} ignoreDependentValidationRules Flag to tell the validation logic to ignore/skip any validations that are dependent of two or more fields.
             * @returns {Array} Array of error objects found within the supplied data object.  See entityHelper.createError() for error object details.
            **/
            entityHelper.checkForErrors = function (data, ignoreDependentValidationRules) {
                var returnValue = [];
                var ignoreDependentValidations = ((ignoreDependentValidationRules === undefined) || (ignoreDependentValidationRules === null) ? false : ((ignoreDependentValidationRules === true) || (ignoreDependentValidationRules === "true") ? true : false));
                if (data !== undefined && data !== null) {
                    for (var property in data) {
                        if (data.hasOwnProperty(property)) {
                            var fieldErrors = entityHelper.checkForFieldErrors(property, data, ignoreDependentValidations);
                            if (fieldErrors !== undefined && fieldErrors !== null && fieldErrors.length > 0) {
                                for (var i = 0; i < fieldErrors.length; i++) {
                                    returnValue.push(fieldErrors[i]);
                                }
                            }
                        }
                    }
                } else {
                    returnValue.push(entityHelper.createError(null, null, String($filter("trustedtranslate")("efAngularLibrary.efEntity.ValidateDataInvalidInputs")), null));
                }
                return returnValue;
            };

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.checkForFieldErrors
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method will check for validation errors for a specific field in the supplied data object and return the errors as an array of error objects.
             * 
             * See entityHelper.createError() for error object details.
             * 
             * @param {string} field The field name to validate.
             * @param {object} data The row/data object to check for errors.  This must be a signle row/data object and not an array of rows/data objects.
             * @param {boolean} ignoreDependentValidationRules Flag to tell the validation logic to ignore/skip any validations that are dependent of two or more fields.
             * @returns {Array} Array of error objects found within the supplied data object.  See entityHelper.createError() for error object details.
            **/
            entityHelper.checkForFieldErrors = function (field, data, ignoreDependentValidationRules) {
                var returnValue = [];
                var ignoreDependentValidations = ((ignoreDependentValidationRules === undefined) || (ignoreDependentValidationRules === null) ? false : ((ignoreDependentValidationRules === true) || (ignoreDependentValidationRules === "true") ? true : false));
                if (field !== undefined && field !== null && data !== undefined && data !== null) {
                    var validations = $.grep(entityHelper.validationFunctions, function (e) { return e["field"] === field; });
                    if (validations !== undefined && validations !== null && validations.length > 0) {
                        for (var counter = 0; counter < validations.length; counter++) {
                            var errors = validations[counter].validationFunction(data[field], data, ignoreDependentValidations);
                            if (errors !== undefined && errors !== null && errors.length > 0) {
                                for (var i = 0; i < errors.length; i++) {
                                    returnValue.push(entityHelper.createError(null, errors[i]["name"], errors[i]["status"], null));
                                }
                            }
                        }
                    }
                } else {
                    returnValue.push(entityHelper.createError(null, null, String($filter("trustedtranslate")("efAngularLibrary.efEntity.ValidateDataInvalidInputs")), null));
                }
                return returnValue;
            };

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.validateData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method will validate the fields in the supplied data object and return a boolean flag if validation was successful (no errors found) or unsuccessful (errors found).  If errors are found, then the entityHelper.errors object will be updated with the found errors.
             * 
             * @param {boolean} displayOkMessage Flag to diplay a toastr "ok" message when no errors are found.
             * @param {object} data The row/data object to check for errors.  This must be a signle row/data object and not an array of rows/data objects.
             * @param {boolean} ignoreDependentValidationRules Flag to tell the validation logic to ignore/skip any validations that are dependent of two or more fields.
             * @param {boolean} volatileDataCompareForAudit Flag to perform a colatile data comparison during auditing.
             * @returns {boolean} Flag with validation status.  True if validation was successful (no errors found) or False if unsuccessful (errors found).
            **/
            entityHelper.validateData = function (displayOkMessage, data, ignoreDependentValidationRules, volatileDataCompareForAudit) {
                volatileDataCompareForAudit = volatileDataCompareForAudit == true;
                var ignoreDependentValidations = ((ignoreDependentValidationRules === undefined) || (ignoreDependentValidationRules === null) ? false : ((ignoreDependentValidationRules === true) || (ignoreDependentValidationRules === "true") ? true : false));
                var errorsFound = [];
                var id = "";
                if (data !== undefined && data !== null) {
                    id = (data[entityHelper.idField] !== undefined && data[entityHelper.idField] !== null) ? data[entityHelper.idField] : "";
                    var errors = entityHelper.checkForErrors(data, ignoreDependentValidations);
                    if (errors !== undefined && errors !== null && errors.length > 0) {
                        for (var i = 0; i < errors.length; i++) {
                            var error = errors[i];
                            error.id = id;
                            errorsFound.push(error);
                        }
                    }
                }

                if (errorsFound.length == 0 && entityHelper.isAuditing == true) {
                    var errorField = "AuditChangeReasons";
                    if (entityHelper.auditModalScope !== undefined || (entityHelper.auditModalScope === undefined && !prepAuditPrompt(data, errorField, volatileDataCompareForAudit))) {
                        if (entityHelper.auditModalScope !== undefined)
                            errorField = entityHelper.auditModalScope.modal.data.PropertyName; //Get field name from current modal instance
                        var rfcError = entityHelper.createError(null, errorField, String($filter("trustedtranslate")("efAngularLibrary.efEntity.ReasonForChangeRequired")).replace(/_FIELDNAME_/, errorField));
                        rfcError.id = id;
                        errorsFound.push(rfcError);

                    }
                }

                var displayOk = ((displayOkMessage === undefined) || (displayOkMessage === null) ? false : ((displayOkMessage === true) || (displayOkMessage === "true") ? true : false));
                entityHelper.updateErrorProperties(displayOk, id, errorsFound);

                return (errorsFound.length > 0) ? false : true;
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.validateFieldData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method will validate a specific field in the supplied data object and return a boolean flag if validation was successful (no errors found) or unsuccessful (errors found).  If errors are found, then the entityHelper.errors object will be updated with the found errors.
             * 
             * @param {boolean} displayOkMessage Flag to diplay a toastr "ok" message when no errors are found.
             * @param {string} field The field to validate.
             * @param {object} data The row/data object to check for errors.  This must be a signle row/data object and not an array of rows/data objects.
             * @param {boolean} ignoreDependentValidationRules Flag to tell the validation logic to ignore/skip any validations that are dependent of two or more fields.
             * @param {boolean} volatileDataCompareForAudit Flag to perform a colatile data comparison during auditing.
             * @returns {boolean} Flag with validation status.  True if validation was successful (no errors found) or False if unsuccessful (errors found).
            **/
            entityHelper.validateFieldData = function (displayOkMessage, field, data, ignoreDependentValidationRules, volatileDataCompareForAudit) {
                volatileDataCompareForAudit = volatileDataCompareForAudit == true;
                var ignoreDependentValidations = ((ignoreDependentValidationRules === undefined) || (ignoreDependentValidationRules === null) ? false : ((ignoreDependentValidationRules === true) || (ignoreDependentValidationRules === "true") ? true : false));
                var errorsFound = [];
                var id = "";
                if (data !== undefined && data !== null) {
                    id = (data[entityHelper.idField] !== undefined && data[entityHelper.idField] !== null) ? data[entityHelper.idField] : "";
                    var errors = entityHelper.checkForFieldErrors(field, data, ignoreDependentValidations);
                    if (errors !== undefined && errors !== null && errors.length > 0) {
                        for (var i = 0; i < errors.length; i++) {
                            var error = errors[i];
                            error.id = id;
                            errorsFound.push(error);
                        }
                    }

                }

                if (errorsFound.length == 0 && entityHelper.isAuditing == true) {
                    if (entityHelper.auditModalScope !== undefined || (entityHelper.auditModalScope === undefined && !prepAuditPrompt(data, "", volatileDataCompareForAudit))) {
                        var rfcError = entityHelper.createError(null, field, String($filter("trustedtranslate")("efAngularLibrary.efEntity.ReasonForChangeRequired")).replace(/_FIELDNAME_/, field));
                        rfcError.id = id;
                        errorsFound.push(rfcError);
                    }
                }

                var displayOk = ((displayOkMessage === undefined) || (displayOkMessage === null) ? false : ((displayOkMessage === true) || (displayOkMessage === "true") ? true : false));
                entityHelper.updateErrorProperties(displayOk, id, errorsFound);

                return (errorsFound.length > 0) ? false : true;
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.validateAllData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method will validate all fields within all of the rows of the supplied data object and return a boolean flag if validation was successful (no errors found) or unsuccessful (errors found).  If errors are found, then the entityHelper.errors object will be updated with the found errors.
             * 
             * @param {boolean} displayOkMessage Flag to diplay a toastr "ok" message when no errors are found.
             * @param {object} data The data object to check for errors.  This must be an array of rows/data objects and not a single row/data object.
             * @param {boolean} ignoreDependentValidationRules Flag to tell the validation logic to ignore/skip any validations that are dependent of two or more fields.
             * @returns {boolean} Flag with validation status.  True if validation was successful (no errors found) or False if unsuccessful (errors found).
            **/
            entityHelper.validateAllData = function (displayOkMessage, data, ignoreDependentValidationRules) {
                var ignoreDependentValidations = ((ignoreDependentValidationRules === undefined) || (ignoreDependentValidationRules === null) ? false : ((ignoreDependentValidationRules === true) || (ignoreDependentValidationRules === "true") ? true : false));
                var displayOk = ((displayOkMessage === undefined) || (displayOkMessage === null) ? false : ((displayOkMessage === true) || (displayOkMessage === "true") ? true : false));
                var returnValue = true;
                if (data !== undefined && data !== null && Array.isArray(data) && data.length > 0) {
                    entityHelper.initErrors();
                    for (var i = 0; i < data.length; i++) {
                        if (!entityHelper.validateData(displayOk, data[i], ignoreDependentValidations)) {
                            returnValue = false;
                        }
                    }
                }
                return returnValue;
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.createInputErrors
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method returns an array of inputErrors for the supplied array of errir objects.  
             * 
             * See entityHelper.inputErrors for inputError details.  See entityHelper.createError() for error object details.
             * 
             * @param {Array} errors An array of error objects that will be transformed into inputErrors.  See entityHelper.createError() for error object details.
             * @returns {Array} Array on inputError objects.  See entityHelper.inputErrors for inputError details.
            **/
            entityHelper.createInputErrors = function (errors) {
                var inputErrors = [];
                if (errors !== undefined && errors !== null) {
                    entityHelper.copyObject(errors).forEach(function (error) {
                        var fieldErrorExists = false;
                        inputErrors.forEach(function (inputError) {
                            if (inputError.name === error.name) {
                                fieldErrorExists = true;
                                inputError.status += ("  " + error.status);
                            }
                        });
                        if (!fieldErrorExists) {
                            inputErrors.push(error);
                        }
                    });
                }
                return inputErrors;
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.updateErrorProperties
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method will update the entityHelper error properties with the supplied errors.  This will included adding/updating any entity.errors data, udpating the entity.errorDisplayText, and updating the entityHelper.inputErrors.
             * 
             * See entityHelper.errors, entityHelper.inputErrors, and entityHelper.errorDisplayText for their respective details.
             * 
             * @param {boolean} displayOkMessage Flag to diplay a toastr "ok" message when no errors are found.
             * @param {any} id The unique key/id that the errors are associated with.  This has to be the value for the row's entityHelper.idField.  This can be null when non row-level error updating is required.
             * @param {Array} errors An array of error objects that will processed for updates.  
            **/
            entityHelper.updateErrorProperties = function (displayOkMessage, id, errors) {
                if (errors !== undefined && errors !== null) {
                    //Remove any existing errors for the id
                    entityHelper.errors = entityHelper.errors.filter(function (obj) {
                        return obj.id !== ((id != undefined && id !== null) ? id : "");
                    });
                    //Add any existing errors for the id
                    for (var i = 0; i < errors.length; i++) {
                        entityHelper.errors.push(errors[i]);
                    }
                }

                entityHelper.inputErrors = entityHelper.createInputErrors(entityHelper.errors);

                var errorText = "";
                if (entityHelper.errors.length > 0) {
                    if ((entityHelper.i18nMessages.errorTextHeader !== undefined && entityHelper.i18nMessages.errorTextHeader !== null && entityHelper.i18nMessages.errorTextHeader.length > 0) ||
                        (entityHelper.i18nMessages.errorTextHeaderSuffix !== undefined && entityHelper.i18nMessages.errorTextHeaderSuffix !== null && entityHelper.i18nMessages.errorTextHeaderSuffix.length > 0)) {
                        errorText += "<p>";
                        if (entityHelper.i18nMessages.errorTextHeader !== undefined && entityHelper.i18nMessages.errorTextHeader !== null && entityHelper.i18nMessages.errorTextHeader.length > 0) {
                            errorText += String($filter("trustedtranslate")(entityHelper.i18nMessages.errorTextHeader)) + " ";
                        }
                        if (entityHelper.i18nMessages.errorTextHeaderSuffix !== undefined && entityHelper.i18nMessages.errorTextHeaderSuffix !== null && entityHelper.i18nMessages.errorTextHeaderSuffix.length > 0) {
                            errorText += String($filter("trustedtranslate")(entityHelper.i18nMessages.errorTextHeaderSuffix));
                        }
                        errorText += "</p>";
                    }
                    errorText += "<ul>";
                    entityHelper.errors.forEach(function (error) {
                        var errorPrefix = "";
                        if (entityHelper.prefixFieldForErrorDisplayText !== undefined && entityHelper.prefixFieldForErrorDisplayText !== null && entityHelper.prefixFieldForErrorDisplayText.length > 0) {
                            //Check for prefix Value in data first!
                            var prefixValueFromData = entityHelper.getFirstValueById(entityHelper.idField, error.id, entityHelper.prefixFieldForErrorDisplayText, entityHelper.data);
                            var prefixValueFromChanges = entityHelper.getFirstValueById(entityHelper.idField, error.id, entityHelper.prefixFieldForErrorDisplayText, entityHelper.changes);
                            var prefixValue = (prefixValueFromChanges !== undefined &&
                                prefixValueFromChanges !== null &&
                                String(prefixValueFromChanges).length > 0) ? String(prefixValueFromChanges) : (
                                    (prefixValueFromData !== undefined &&
                                    prefixValueFromData !== null &&
                                    String(prefixValueFromData).length > 0) ? String(prefixValueFromData) : "");
                            if (prefixValue !== undefined && prefixValue !== null && prefixValue.length > 0) {
                                errorPrefix = String(prefixValue) + ": ";
                            }
                        }
                        errorText += ("<li>" + errorPrefix + error.status + "</li>");
                    });
                    errorText += "</ul>";
                } else {
                    if (displayOkMessage !== undefined && displayOkMessage !== null && displayOkMessage == true &&
                        entityHelper.i18nMessages.noErrorsFound !== undefined && entityHelper.i18nMessages.noErrorsFound !== null && entityHelper.i18nMessages.noErrorsFound.length > 0) {
                        toastr.success(String($filter("trustedtranslate")(entityHelper.i18nMessages.noErrorsFound)));
                    }
                }
                entityHelper.errorDisplayText = errorText;

                for (var i = 0; i < entityHelper.data.length; i++) {
                    var rowErrors = entityHelper.getErrors(entityHelper.data[i][entityHelper.idField]);
                    if (rowErrors !== undefined && rowErrors !== null && rowErrors.length > 0) {
                        $('#' + entityHelper.data[i][entityHelper.idField]).addClass('text-danger');
                        entityHelper.data[i].IsError = true;
                    } else {
                        $('#' + entityHelper.data[i][entityHelper.idField]).removeClass('text-danger');
                        entityHelper.data[i].IsError = false;
                    }
                }
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.getInputError
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method will return the entityHelper.inputErrors object for the supplied field name.  If no entityHelper.inputErrors for the field, then an empty error object is returned.
             * 
             * See entityHelper.inputErrors for more details.
             * 
             * @param {string} inputName Field name to retrieve entityHelper.inputErrors for.
             * @returns {object} entityHelper.inputErrors object for the supplied field name.  If no entityHelper.inputErrors for the field, then an empty error object is returned.
            **/
            entityHelper.getInputError = function (inputName) {
                var returnValue = entityHelper.createError("", "", "", "");  //Need empty issue - including cssClass
                if ((inputName !== undefined && inputName !== null && inputName.length > 0) &&
                    (entityHelper.inputErrors) && (entityHelper.inputErrors.length > 0)) {
                    for (var i = 0; i < entityHelper.inputErrors.length; i++) {
                        if (entityHelper.inputErrors[i].name == inputName) {
                            returnValue = entityHelper.inputErrors[i];
                            break;
                        }
                    }
                }
                return returnValue;
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.getErrors
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method will return an array error objects from entityHelper.errors for the supplied id.  
             * 
             * See entityHelper.errors for more details.
             * 
             * @param {any} id The unique key/id that the errors are associated with.  This typically is the value for the row's entityHelper.idField.
             * @returns {Array} Array of found entityHelper.errors objects for the supplied id.
            **/
            entityHelper.getErrors = function (id) {
                return entityHelper.errors.filter(function (obj) {
                    return obj.id === ((id != undefined && id !== null) ? id : "");
                });
            }

            //#endregion

            //#region Data Update Functions

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.checkForChanges
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method will return a boolean flag for the existence of changes in the entityHelper.changes object for the supplied id.
             * 
             * This method will also enable/disable any current HTML elements that have been assigned the entityHelper.disableOnChangesExistCssClass CSS class, as well as the relevant moveRow buttons when efUiGrid is available.
             * 
             * @param {any} id The unique key/id that the errors are associated with.  This has to be the value for the row's entityHelper.idField.
             * @returns {boolean} Flag for the existence of changes for the supplied id.  True when changes exist.  False when no changes exist.
            **/
            entityHelper.checkForChanges = function (id) {
                var returnValue = false;
                if (id !== undefined && id !== null) {
                    var rows = $.grep(entityHelper.changes, function (e) { return e[entityHelper.idField] === id; });
                    if (rows !== undefined && rows !== null && rows.length > 0) {
                        returnValue = true;
                    }
                } else {
                    if (entityHelper.changes.length > 0) {
                        returnValue = true;
                    }
                }
                entityHelper.changesExist = returnValue;
                entityHelper.disablePrefixSuffixButtons(entityHelper.changesExist);
                return returnValue;
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.disablePrefixSuffixButtons
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method will enable/disable any current HTML elements that have been assigned the entityHelper.disableOnChangesExistCssClass CSS class, as well as the relevant moveRow buttons when efUiGrid is available.
             * 
             * @param {boolean} changesExist Flag if changes exist for the entity.
            **/
            entityHelper.disablePrefixSuffixButtons = function (changesExist) {
                var parameter = efLibrary.toBoolean(changesExist, false);
                if (entityHelper.disableOnChangesExistCssClass !== undefined && entityHelper.disableOnChangesExistCssClass !== null && entityHelper.disableOnChangesExistCssClass.length > 0) {
                    $('.' + entityHelper.disableOnChangesExistCssClass).prop('disabled', parameter);
                }
                if (!!entityHelper.orderPositionField && entityHelper.orderPositionField.length > 0) {
                    var orderPositions = [];
                    for (var i = 0; i < entityHelper.data.length; i++) {
                        if (!!entityHelper.data[i][entityHelper.orderPositionField] && !isNaN(entityHelper.data[i][entityHelper.orderPositionField])) {
                            orderPositions.push(Number(entityHelper.data[i][entityHelper.orderPositionField]));
                        }
                    }
                    if (orderPositions.length > 0) {
                        var minOrderPosition = Math.min.apply(null, orderPositions);
                        var maxOrderPosition = Math.max.apply(null, orderPositions);
                        var disabledMovePreviousButtonId = '#' + (!!entityHelper.moveRowButtonIdPrefix ? entityHelper.moveRowButtonIdPrefix : "") + "MovePrevious" + String(minOrderPosition);
                        var disabledMoveNextButtonId = '#' + (!!entityHelper.moveRowButtonIdPrefix ? entityHelper.moveRowButtonIdPrefix : "") + "MoveNext" + String(maxOrderPosition);
                        $(disabledMovePreviousButtonId).prop('disabled', true);
                        var prevBtn = $(disabledMovePreviousButtonId);
                        $(disabledMoveNextButtonId).prop('disabled', true);
                    }
                }
            }


            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.changeData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method will look for any changes within the supplied data object, validate any found changes, and then add the changes to the entityHelper.changes object.
             * 
             * @param {object} data The data object to check for changes.  This must be a single row/data object and not an array of rows/data objects.
             * @param {string} action The action to be performed.  Valid values are "create", "edit", "remove".
             * @param {boolean} forceChange Flag to ignore checking for available changes and process the supplied data.
             * @param {boolean} ignoreDependentValidationRules Flag to tell the validation logic to ignore/skip any validations that are dependent of two or more fields.
             * @param {boolean} volatileDataCompareForAudit Flag to perform a colatile data comparison during auditing.
             * @returns {boolean} Flag that determines if change of data was successful.
            **/
            entityHelper.changeData = function (data, action, forceChange, ignoreDependentValidationRules, volatileDataCompareForAudit) {
                volatileDataCompareForAudit = volatileDataCompareForAudit == true;
                var returnValue = false;
                var ignoreDependentValidations = ((ignoreDependentValidationRules === undefined) || (ignoreDependentValidationRules === null) ? false : ((ignoreDependentValidationRules === true) || (ignoreDependentValidationRules === "true") ? true : false));
                var id = "";
                if (data !== undefined && data !== null &&
                    action !== undefined && action !== null) {

                    id = data[entityHelper.idField];

                    var changesExist = ((forceChange === undefined) || (forceChange === null) ? false : ((forceChange === true) || (forceChange === "true") ? true : false));

                    if (!changesExist) {
                        var rows = $.grep(entityHelper.data, function (e) { return e[entityHelper.idField] === id; });
                        if (rows !== undefined && rows !== null && rows.length > 0) {
                            for (var property in data) {
                                if (data.hasOwnProperty(property)) {
                                    if (rows[0][property] !== undefined && rows[0][property] !== data[property]) {
                                        changesExist = true;
                                        break;
                                    }
                                }
                            }
                        }
                    }

                    if (changesExist) {
                        if (entityHelper.validateData(false, data, ignoreDependentValidations, volatileDataCompareForAudit)) {
                            if (data.DataState !== undefined && data.DataState !== "Created") {
                                data.DataState = entityHelper.convertActionToDataState(action);
                            }
                            var dataFound = false;
                            for (var i = 0; i < entityHelper.changes.length; i++) {
                                if (entityHelper.changes[i][entityHelper.idField] === id) {
                                    //Current changes may be more up-to-date because of Audit rfc prompt (i.e. if incoming data is from datatable 
                                    //then AuditChangeReasons may not be included or outdated) so make sure the change reasons are persisted to current data object
                                    if (entityHelper.changes[i].hasOwnProperty("AuditChangeReasons")
                                        && entityHelper.changes[i].AuditChangeReasons.length > 0 && data.hasOwnProperty("AuditChangeReasons")
                                        && entityHelper.changes[i].AuditChangeReasons !== data.AuditChangeReasons) {
                                        data.AuditChangeReasons = entityHelper.copyObject(entityHelper.changes[i].AuditChangeReasons);
                                    }
                                    entityHelper.changes[i] = data;
                                    dataFound = true;
                                    break;
                                }
                            }
                            if (!dataFound) {
                                entityHelper.changes.push(data);
                            }
                            returnValue = true;
                        }
                    } else {
                        entityHelper.updateErrorProperties(false, id, []);
                    }
                } else {
                    entityHelper.updateErrorProperties(false, null, entityHelper.createError(null, null, String($filter("trustedtranslate")("efAngularLibrary.efEntity.ChangeDataInvalidInputs")), null));
                }

                return returnValue;
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.changeFieldData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method will look for specific field changes within the supplied data object, validate any found changes, and then add the changes to the entityHelper.changes object.
             * 
             * @param {string} field Field name to check for changes.
             * @param {object} data The data object to check for changes.  This must be a single row/data object and not an array of rows/data objects.
             * @param {string} action The action to be performed.  Valid values are "create", "edit", "remove".
             * @param {boolean} forceChange Flag to ignore checking for available changes and process the supplied data.
             * @param {boolean} ignoreDependentValidationRules Flag to tell the validation logic to ignore/skip any validations that are dependent of two or more fields.
             * @returns {boolean} Flag that determines if change of data was successful.
            **/
            entityHelper.changeFieldData = function (field, data, action, forceChange, ignoreDependentValidationRules) {
                var returnValue = false;
                var ignoreDependentValidations = ((ignoreDependentValidationRules === undefined) || (ignoreDependentValidationRules === null) ? false : ((ignoreDependentValidationRules === true) || (ignoreDependentValidationRules === "true") ? true : false));
                var id = "";
                if (field !== undefined && field !== null &&
                    data !== undefined && data !== null &&
                    action !== undefined && action !== null) {

                    id = data[entityHelper.idField];

                    var changesExist = ((forceChange === undefined) || (forceChange === null) ? false : ((forceChange === true) || (forceChange === "true") ? true : false));

                    if (!changesExist) {
                        var rows = $.grep(entityHelper.data, function (e) { return e[entityHelper.idField] === id; });
                        if (rows !== undefined && rows !== null && rows.length > 0) {
                            for (var property in data) {
                                if (data.hasOwnProperty(property)) {
                                    if (rows[0][property] !== undefined && rows[0][property] != data[property]) {
                                        changesExist = true;
                                        break;
                                    }
                                }
                            }
                        }
                    }

                    if (changesExist) {
                        if (entityHelper.validateFieldData(false, field, data, ignoreDependentValidations)) {
                            if (data.DataState != undefined && data.DataState !== "Created") {
                                data.DataState = entityHelper.convertActionToDataState(action);
                            }
                            var dataFound = false;
                            for (var i = 0; i < entityHelper.changes.length; i++) {
                                if (entityHelper.changes[i][entityHelper.idField] === id) {
                                    entityHelper.changes[i] = data;
                                    dataFound = true;
                                    break;
                                }
                            }
                            if (!dataFound) {
                                entityHelper.changes.push(data);
                            }
                            returnValue = true;
                        }
                    } else {
                        entityHelper.updateErrorProperties(false, id, []);
                    }
                } else {
                    entityHelper.updateErrorProperties(false, null, entityHelper.createError(null, null, String($filter("trustedtranslate")("efAngularLibrary.efEntity.ChangeDataInvalidInputs")), null));
                }

                return returnValue;
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.removeChanges
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method will remove any changes from the entityHelper.changes object for the supplied id.  This method can optionally remove the data from the entityHelper.data object as well. 
             * 
             * @param {any} id The unique key/id for the changes to be removed.  This typically is the value for the row's entityHelper.idField.
             * @param {boolean} removeData Flag to remove data from the enitityHelper.data object.  If false, not provided, or null, then no data will be remvoed from the enitityHelper.data object.
            **/
            entityHelper.removeChanges = function (id, removeData) {
                var deleteData = (removeData !== undefined && removeData !== null ? removeData : true);

                if (id !== undefined && id !== null && id.length > 0) {
                    entityHelper.changes = entityHelper.changes.filter(function (obj) {
                        return obj[entityHelper.idField] !== id;
                    });
                    entityHelper.errors = entityHelper.errors.filter(function (obj) {
                        return obj["id"] !== id;
                    });
                    if (deleteData) {
                        entityHelper.data = entityHelper.data.filter(function (obj) {
                            return obj[entityHelper.idField] !== id;
                        });
                    }
                } else {
                    entityHelper.initChanges();
                    entityHelper.initErrors();
                    if (deleteData) {
                        entityHelper.data = entityHelper.data.filter(function (obj) {
                            return obj["DataState"] !== "Created" && obj[entityHelper.idField] !== null && obj[entityHelper.idField] !== "";
                        });
                    }
                }
                entityHelper.checkForChanges();
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.removeData
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method will remove any data from the entityHelper.data object for the supplied id.
             * 
             * @param {any} id The unique key/id for the data to be removed.  This typically is the value for the row's entityHelper.idField.
            **/
            entityHelper.removeData = function (id) {
                if (id !== undefined && id !== null && id.length > 0) {
                    entityHelper.data = entityHelper.data.filter(function (obj) {
                        return obj[entityHelper.idField] !== id;
                    });

                }
            }

            //#endregion

            //#region Misc Support Functions

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.removeChanges
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This support method returns a copy of the entityHelper.serviceData with any relevant entityHelper.changes applied to it.
             * 
             * @returns {Array} Copy of the entityHelper.serviceData with any relevant entityHelper.changes applied to it.
            **/
            entityHelper.getDataToPersist = function () {
                var data = entityHelper.copyObject(entityHelper.serviceData);


                for (var i = 0; i < entityHelper.changes.length; i++) {
                    for (var j = 0; j < data.length; j++) {
                        if (entityHelper.changes[i][entityHelper.idField] === data[j][entityHelper.idField]) {
                            data[j] = entityHelper.copyObject(entityHelper.changes[i]);

                        }
                    }
                }

                return data;

            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.getLabelValueArrayFromObject
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This support method return an array of label/value objects from the supplied data object.  Each property of the supplied data object, as well as, its value will be converted to an entry in the label/value object array.
             * 
             * @param {object} data The object that will be converted into a label/value array object.
             * @returns {Array} Array of label/value objects.
            **/
            entityHelper.getLabelValueArrayFromObject = function (data) {
                var returnValue = [];
                if (data !== undefined && data !== null) {
                    for (var property in data) {
                        if (data.hasOwnProperty(property) && property.indexOf('$') == -1) {
                            returnValue.push({
                                "label": data[property],
                                "value": property
                            });
                        }
                    }
                }
                return returnValue;
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.getLabelValueArray
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This support method returns an array of label/value objects from the supplied data object array.  You can specifiy which fields in the data object array will become the label and value fields, respectively.
             * 
             * @param {string} labelField The field in the data object array that will be used as the label field.
             * @param {string} valueField The field in the data object array that will be used as the value field.
             * @param {Array} data An array of object that will be converted into a label/value array object.  This must be an array of objects and not a single object.
             * @returns {Array} Array of label/value objects.
            **/
            entityHelper.getLabelValueArray = function (labelField, valueField, data) {
                var returnValue = [];
                if (labelField !== undefined && labelField !== null && labelField.length > 0 &&
                    valueField !== undefined && valueField !== null && valueField.length > 0 &&
                    data !== undefined && data !== null && data.length > 0) {
                    for (var i = 0; i < data.length; i++) {
                        returnValue.push({
                            "label": data[i][labelField] !== undefined ? data[i][labelField] : null,
                            "value": data[i][valueField] !== undefined ? data[i][valueField] : null
                        });
                    }
                }
                return returnValue;
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.getAllValuesById
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This support method returns an array of field values for a specified id within a data object array.
             * 
             * @param {string} idField The field in the data object to search for the id in.
             * @param {any} id The id to search for in the idField.
             * @param {string} valueField The field in the data object to return when the id is found.
             * @param {Array} data An array of objects that will be searched.  This must be an array of objects and not a single object.
             * @returns {Array} Array of values found.
            **/
            entityHelper.getAllValuesById = function (idField, id, valueField, data) {
                var returnValue = [];
                if (idField !== undefined && idField !== null && idField.length > 0 &&
                    id !== undefined &&
                    valueField !== undefined && valueField !== null && valueField.length > 0 &&
                    data !== undefined && data !== null && data.length > 0) {
                    var rows = $.grep(data, function (e) { return e[idField] === id; });
                    if (rows !== undefined && rows !== null && rows.length > 0) {
                        for (var i = 0; i < rows.length; i++) {
                            returnValue.push(eval("rows[i]." + valueField));
                        }
                    }
                }
                return returnValue;
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.getFirstValueById
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This support method returns the first field value for a specified id within a data object array.
             * 
             * @param {string} idField The field in the data object to search for the id in.
             * @param {any} id The id to search for in the idField.
             * @param {string} valueField The field in the data object to return when the id is found.
             * @param {Array} data An array of objects that will be searched.  This must be an array of objects and not a single object.
             * @returns {any} Value found.  Null if nothing is found.
            **/
            entityHelper.getFirstValueById = function (idField, id, valueField, data) {
                var returnValue = null;
                var foundValues = entityHelper.getAllValuesById(idField, id, valueField, data);
                if (foundValues.length > 0) {
                    returnValue = foundValues[0];
                }
                return returnValue;
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.convertActionToDataState
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This support method returns a DataState value for the supplied action value.  Default value when no coversion is possible is "Unchanged".
             * 
             * @param {string} action The action to convert to a DataState.  Valid values are "create", "edit", or "remove".  If not supplied or null, then "Unchanged" will be returned.
             * @returns {string} DataState value.  Valid values are "Unchanged", "Created", "Modified", or "Deleted".
            **/
            entityHelper.convertActionToDataState = function (action) {
                var returnValue = "Unchanged";
                if (action !== undefined && action !== null) {
                    switch (action) {
                        case "create":
                            returnValue = "Created";
                            break;
                        case "edit":
                            returnValue = "Modified";
                            break;
                        case "remove":
                            returnValue = "Deleted";
                            break;
                        default:
                            returnValue = "Unchanged";
                            break;
                    }
                }
                return returnValue;
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.getDefaultDataState
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This support method returns the default DataState from entityHelper.convertActionToDataState().
             * 
             * @returns {string} Default DataState from entityHelper.convertActionToDataState().
            **/
            entityHelper.getDefaultDataState = function () {
                return entityHelper.convertActionToDataState(null);
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.convertDataStateToAction
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This support method returns a Action value for the supplied dataState value.  Default value when no coversion is possible is null.
             * 
             * @param {string} dataState The dataState to convert to an action.  Valid values are "Unchanged", "Created", "Modified", or "Deleted".  If not supplied or null, then null will be returned.
             * @returns {string} DataState value.  Valid values are null, "create", "edit", or "remove".
            **/
            entityHelper.convertDataStateToAction = function (dataState) {
                var returnValue = null;
                if (dataState !== undefined && dataState !== null) {
                    switch (dataState) {
                        case "Created":
                            returnValue = "create";
                            break;
                        case "Modified":
                            returnValue = "edit";
                            break;
                        case "Deleted":
                            returnValue = "remove";
                            break;
                        default:
                            returnValue = null;
                            break;
                    }
                }
                return returnValue;
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.copyObject
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This support method returns a copy fo the supplied sourceObject.  This methods uses JSON-based logic to perform the copy.  This will not copy Angular state.  Use efLibrary.copyObject() to copy Angular state.
             * 
             * This method copies/clones a Javascript object.  Please note that the copied/cloned object no longer references the orignal object.
             * 
             * @param {object} sourceObject The object that will be copied.
             * @returns {object} Copied/cloned object.
            **/
            entityHelper.copyObject = function (sourceObject) {
                var returnValue = null;
                if (sourceObject !== undefined && sourceObject !== null) {
                    returnValue = JSON.parse(JSON.stringify(sourceObject));
                }
                return returnValue;
            }

            /**
             * @ngdoc method
             * @name efAngularLibrary.efEntity.#entityApi.entityHelper.setModelObjectByName
             * @methodOf efAngularLibrary.efEntity
             * @description 
             * 
             * This method sets an object, by its string-based name, to a provided value within a scpecified scope.
             * 
             * @param {object|scope} scope Model/Scope/Object to search for the variable in.
             * @param {string} variableName Variable/object name to set.  This must be a string.  The value can include dot-based notation if desired (see example above).
             * @param {Any} value Value to be set.
            **/
            entityHelper.setModelObjectByName = function (scope, variableName, value) {
                var levels = variableName.split(".");
                var model = scope;
                var i = 0;
                while (i < levels.length - 1) {
                    if (typeof model[levels[i]] === 'undefined') {
                        model[levels[i]] = {};
                    }
                    model = model[levels[i]];
                    i++;
                }
                model[levels[levels.length - 1]] = value;
            }

            //#endregion

            entityHelper.init();
            return entityHelper;
        }

        /**
         * @ngdoc method
         * @name efAngularLibrary.efEntity.#entityApi.createEntity
         * @methodOf efAngularLibrary.efEntity
         * @description 
         * 
         * This method creates and returns the entityApi/entityHelper object, setting the default entityHelper values from the supplied entityConfig object.  From this entityApi/entityHelper object you will store, manage, and update entity/service data, as well as any changes, errors, and audits associated with the entity/service data.
         * 
         * Example entityConfig format:
         * <pre>
         * {
         *  "idField": "courierTypeId",
         *  "prefixFieldForErrorDisplayText": "courierTypeName",
         *  "orderPositionField": "orderNumber",
         *  "disableOnChangesExistCssClass": "courierTypeDisableOnChange",
         *  "moveRowButtonIdPrefix": "courierTypeMoveRowButton",
         *  "errorTextHeader": "Translated Error Text for Header",
         *  "errorTextHeaderSuffix": "Translated Error Text Suffix for Header",
         *  "noErrorsFound": "Translated No Errors Found Text",
         *  "validationFunctions": [{ "field": "courierTypeName", "validationFunction": function (val, data, ignoreDependentRules) {...} }],    //Array of field specific validation functions
         *  "defaultDataTemplate": { courierTypeId: null, courierTypeName: null }  //Default courierType object layout with default values
         * }
         * </pre>
         * 
         * @param {object} entityConfig This object contains the default entityHelper values.
         * @returns {efAngularLibrary.efEntity.entityApi.entityHelper} Unique instance of an entityHelper object, configure with the entityConfig values.
        **/
        entityApi.createEntity = function (entityConfig) {
            var entityHelper = entityApi.createEntityHelper();
            entityHelper.idField = entityConfig.idField;
            entityHelper.prefixFieldForErrorDisplayText = entityConfig.prefixFieldForErrorDisplayText;
            entityHelper.orderPositionField = entityConfig.orderPositionField;
            entityHelper.disableOnChangesExistCssClass = entityConfig.disableOnChangesExistCssClass;
            entityHelper.moveRowButtonIdPrefix = entityConfig.moveRowButtonIdPrefix;
            entityHelper.i18nMessages.errorTextHeader = entityConfig.errorTextHeader;
            entityHelper.i18nMessages.errorTextHeaderSuffix = entityConfig.errorTextHeaderSuffix;
            entityHelper.i18nMessages.noErrorsFound = entityConfig.noErrorsFound;
            if (!!entityConfig.validationFunctions) {
                entityHelper.validationFunctions = entityConfig.validationFunctions;
            }
            entityHelper.defaultDataTemplate = entityConfig.defaultDataTemplate;
            return entityHelper;
        }
        return entityApi;
    }
})();
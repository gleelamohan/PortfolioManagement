﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc directive
 * @name efAngularLibrary.efIboxTools.directive:efIboxTools
 * @scope
 * @restrict AEC
 * @requires recursionHelper
 * @description 
 * 
 * efIboxTools module provides an Angular directive for displaying, interacting, and decorating Inspinia iBox panels.
 * 
 * <a href="/app/#/demo/efIboxTools/demo">For complete implmentation details see the demo page.</a>   
 * 
 * @param {boolean=} showhidevisible Flag to show/hide the the panel content visible icon.
 * @param {boolean=} showcontent Flag to show/hide the the panel content from outside the directive.
 * @param {boolean=} disabled Flag to enable/disbale the panel and the efIboxTools icons.
 * @param {boolean=} infovisible Flag to show/hide the info icon.
 * @param {boolean=} infotoggledexternally Flag to toggle the display of the info icon from outside the directive.
 * @param {function=} infocallback External function to call when the info icon has been clicked.
 * @param {boolean=} refreshvisible Flag to show/hide the refresh icon.
 * @param {function=} refreshcallback External function to call when the refresh icon has been clicked.
 * @param {boolean=} validationvisible Flag to show/hide the validation icon.
 * @param {boolean=} validationtoggledexternally Flag to toggle the display of the validation icon from outside the directive.
 * @param {function=} validationcallback External function to call when the validation icon has been clicked. 
 * @param {boolean=} filtervisible Flag to show/hide the filter icon.
 * @param {function=} filtercallback External function to call when the filter icon has been clicked.
 * @param {boolean=} settingsvisible Flag to show/hide the settings icon.
 * @param {function=} settingscallback External function to call when the settings icon has been clicked.
 * @param {boolean=} helpvisible Flag to show/hide the help icon.
 * @param {boolean=} helptoggledexternally Flag to toggle the display of the help icon from outside the directive.
 * @param {function=} helpcallback External function to call when the help icon has been clicked. 
 * @param {boolean=} closevisible Flag to show/hide the close panel icon.
 * @param {function=} closecallback External function to call when the close panel icon has been clicked.
 * @param {boolean=} ticketvisible Flag to show/hide the ticket icon.
 * @param {function=} toggleticketcallback External function to call when the ticket icon has been clicked.
 * @param {boolean=} fullscreenvisible Flag to show/hide the full screen icon.
 * @param {function=} fullscreencallback External function to call when the full screen icon has been clicked.
**/
(function () {
    angular
        .module('efAngularLibrary.efIboxTools')
        .directive('efIboxTools', efIboxTools);

    efIboxTools.$inject = ['$sce', '$timeout', 'recursionHelper'];

    function efIboxTools($sce, $timeout, recursionHelper) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                showHideVisible: "=?showhidevisible",
                showContent: "=?showcontent",
                contentDisabled: "=?disabled",
                infoVisible: "=?infovisible",
                infoToggledExternally: "=?infotoggledexternally",
                toggleInfoCallback: "=?infocallback",
                refreshVisible: "=?refreshvisible",
                toggleRefreshCallback: "=?refreshcallback",
                validationVisible: "=?validationvisible",
                validationToggledExternally: "=?validationtoggledexternally",
                toggleValidationCallback: "=?validationcallback",
                filterVisible: "=?filtervisible",
                toggleFilterCallback: "=?filtercallback",
                settingsVisible: "=?settingsvisible",
                toggleSettingsCallback: "=?settingscallback",
                helpVisible: "=?helpvisible",
                helpToggledExternally: "=?helptoggledexternally",
                toggleHelpCallback: "=?helpcallback",
                closeVisible: "=?closevisible",
                toggleCloseCallback: "=?closecallback",
                ticketVisible: "=?ticketvisible",
                toggleTicketCallback: "=?toggleticketcallback",
                fullScreenVisible: "=fullscreenvisible",
                fullScreenCallback: "=fullscreencallback"
            },
            controller: function ($scope, $element, $attrs, $transclude) {
                var vm = this;

                vm.templateUrl = "/app/components/efIboxTools/efIboxTools.html";

                vm.showContent = true;
                vm.showContentClass = "fa fa-chevron-up";

                $scope.$watch('showContent', handleShowContentUpdates, true);
                function handleShowContentUpdates(newData) {
                    vm.showContent = (newData === undefined) || (newData === null) ? true : ((newData === true) || (newData === "true") ? true : false);
                    vm.toggleShowHide();
                };

                vm.updateScopeShowContent = function (value) {
                    $scope.showContent = (value === undefined) || (value === null) ? true : ((value === true) || (value === "true") ? true : false);
                }

                vm.contentDisabled = false;
                vm.contentDisabledClass = "iboxDisabled";

                $scope.$watch('contentDisabled', handleContentDisabledUpdates, true);
                function handleContentDisabledUpdates(newData) {
                    vm.contentDisabled = (newData === undefined) || (newData === null) ? false : ((newData === true) || (newData === "true") ? true : false);
                    if (vm.contentDisabled) {
                        vm.showContent = false;
                        vm.toggleShowHide();
                    }

                };

                vm.showHideVisible = $scope.showHideVisible || false;
                vm.refreshVisible = $scope.refreshVisible || false;
                vm.infoVisible = $scope.infoVisible || false;
                vm.validationVisible = $scope.validationVisible || false;
                vm.filterVisible = $scope.filterVisible || false;
                vm.settingsVisible = $scope.settingsVisible || false;
                vm.helpVisible = $scope.helpVisible || false;
                vm.closeVisible = $scope.closeVisible || false;
                vm.ticketVisible = $scope.ticketVisible || false;
                vm.fullScreenVisible = $scope.fullScreenVisible || false;

                $scope.$watch('infoToggledExternally', handleInfoToggledExternallyUpdates, true);
                $scope.$watch('infoVisible', handleInfoVisibleUpdates, true);
                $scope.$watch('helpToggledExternally', handleHelpToggledExternallyUpdates, true);
                $scope.$watch('helpVisible', handleHelpVisibleUpdates, true);
                $scope.$watch('validatioToggledExternally', handleValidationToggledExternallyUpdates, true);
                $scope.$watch('validationVisible', handleValidationVisibleUpdates, true);
                $scope.$watch('ticketVisible', handleTicketVisibleUpdates, true);

                function handleInfoToggledExternallyUpdates(newData) {
                    vm.infoToggledExternally = newData || false;
                };

                function handleInfoVisibleUpdates(newData) {
                    vm.infoVisible = newData || false;
                };

                function handleHelpToggledExternallyUpdates(newData) {
                    vm.helpToggledExternally = newData || false;
                };

                function handleHelpVisibleUpdates(newData) {
                    vm.helpVisible = newData || false;
                };

                function handleTicketVisibleUpdates(newData) {
                    vm.ticketVisible = newData || false;
                };
                function handleValidationToggledExternallyUpdates(newData) {
                    vm.validationToggledExternally = newData || false;
                };

                function handleValidationVisibleUpdates(newData) {
                    vm.validationVisible = newData || false;
                };

                // Function for collapse ibox
                vm.toggleShowHide = function () {
                    if (vm.showContent !== undefined && vm.showContent !== null) {
                        var ibox = $element.closest('div.ibox');
                        var content = ibox.find('div.ibox-content');
                        if (vm.showContent) {
                            vm.showContentClass = "fa fa-chevron-up";
                            content.slideDown(200);
                        } else {
                            vm.showContentClass = "fa fa-chevron-down";
                            content.slideUp(200);
                        }
                        $timeout(function () {
                            ibox.resize();
                            ibox.find('[id^=map-]').resize();
                        }, 50);
                        vm.showContent = !vm.showContent;
                    }
                };

                vm.toggleInfoCallback = $scope.toggleInfoCallback || function () { };
                vm.toggleInfo = function () {
                    var ibox = $element.closest('div.ibox');
                    var openIcon = ibox.find('i:first');
                    var toggleOk = true;
                    if ((openIcon) && (openIcon.length > 0) && (openIcon[0].classList.contains('fa-chevron-down'))) {
                        toggleOk = false;
                    }
                    if (toggleOk) {
                        var icon = ibox.find('i.fa-info');
                        icon.toggleClass('text-primary').toggleClass('text-info');
                        vm.toggleInfoCallback();
                    }
                };

                vm.toggleRefreshCallback = $scope.toggleRefreshCallback || function () { };
                vm.toggleRefresh = function () {
                    var ibox = $element.closest('div.ibox');
                    var openIcon = ibox.find('i:first');
                    var toggleOk = true;
                    if ((openIcon) && (openIcon.length > 0) && (openIcon[0].classList.contains('fa-chevron-down'))) {
                        toggleOk = false;
                    }
                    if (toggleOk) {
                        vm.toggleRefreshCallback();
                    }
                };

                vm.toggleValidationCallback = $scope.toggleValidationCallback || function () { };
                vm.toggleValidation = function () {
                    var ibox = $element.closest('div.ibox');
                    var openIcon = ibox.find('i:first');
                    var toggleOk = true;
                    if ((openIcon) && (openIcon.length > 0) && (openIcon[0].classList.contains('fa-chevron-down'))) {
                        toggleOk = false;
                    }
                    if (toggleOk) {
                        //var icon = ibox.find('i.fa-check');
                        //icon.toggleClass('text-primary').toggleClass('text-info');
                        vm.toggleValidationCallback();
                    }
                };

                vm.toggleFilterCallback = $scope.toggleFilterCallback || function () { };
                vm.toggleFilter = function () {
                    var ibox = $element.closest('div.ibox');
                    var openIcon = ibox.find('i:first');
                    var toggleOk = true;
                    if ((openIcon) && (openIcon.length > 0) && (openIcon[0].classList.contains('fa-chevron-down'))) {
                        toggleOk = false;
                    }
                    if (toggleOk) {
                        var icon = ibox.find('i.fa-filter');
                        icon.toggleClass('text-primary').toggleClass('text-info');
                        vm.toggleFilterCallback();
                    }
                };

                vm.toggleSettingsCallback = $scope.toggleSettingsCallback || function () { };
                vm.toggleSettings = function () {
                    var ibox = $element.closest('div.ibox');
                    var openIcon = ibox.find('i:first');
                    var toggleOk = true;
                    if ((openIcon) && (openIcon.length > 0) && (openIcon[0].classList.contains('fa-chevron-down'))) {
                        toggleOk = false;
                    }
                    if (toggleOk) {
                        var icon = ibox.find('i.fa-wrench');
                        icon.toggleClass('text-primary').toggleClass('text-info');
                        vm.toggleSettingsCallback();
                    }
                };

                vm.toggleHelpCallback = $scope.toggleHelpCallback || function () { };
                vm.toggleHelp = function () {
                    var ibox = $element.closest('div.ibox');
                    var openIcon = ibox.find('i:first');
                    var toggleOk = true;
                    if ((openIcon) && (openIcon.length > 0) && (openIcon[0].classList.contains('fa-chevron-down'))) {
                        toggleOk = false;
                    }
                    if (toggleOk) {
                        var icon = ibox.find('i.fa-question');
                        icon.toggleClass('text-primary').toggleClass('text-info');
                        vm.toggleHelpCallback();
                    }
                };

                vm.toggleCloseCallback = $scope.toggleCloseCallback || function () { };
                vm.toggleClose = function () {
                    vm.toggleCloseCallback();
                }

                vm.toggleTicketCallback = $scope.toggleTicketCallback || function () { };
                vm.toggleTicket = function () {
                    var ibox = $element.closest('div.ibox');
                    var openIcon = ibox.find('i:first');
                    var toggleOk = true;
                    if ((openIcon) && (openIcon.length > 0) && (openIcon[0].classList.contains('fa-chevron-down'))) {
                        toggleOk = false;
                    }
                    if (toggleOk) {
                        var icon = ibox.find('i.fa-ticket');
                        icon.toggleClass('text-primary').toggleClass('text-info');
                        vm.toggleTicketCallback();
                    }
                };

                var fullScreenMode = 'normal';
                vm.fullScreenCallback = $scope.fullScreenCallback;

                vm.toggleFullScreen = function ($event) {
                    var current = $event.currentTarget;
                    if (!current) return;

                    var parent = $(current).parents("div.ibox");
                    if (parent.length > 0) {
                        parent = parent[0];
                    };

                    switch (fullScreenMode) {
                        case 'normal':
                            fullscreen(parent);
                            $(current).html("<i class='fa fa-compress'></i>");
                            break;
                        case 'fullScreen':
                            normalScreen(parent);
                            $(current).html("<i class='fa fa-expand'></i>");
                            break;
                    };
                    if (vm.fullScreenCallback) {
                        vm.fullScreenCallback(fullScreenMode);
                    };
                };
                var revertCss;
                function fullscreen(elem) {
                    revertCss = $(elem).css(["position", "z-index", "top", "left", "width", "height", "background-color"]);

                    var marginX = setScreenMargin(window.innerWidth),
                        marginY = setScreenMargin(window.innerHeight);

                    var newStyles = {
                        "position": "fixed",
                        "z-index": "999999",
                        "top": marginY,
                        "left": marginX,
                        "width": window.innerWidth - (2 * marginX),
                        "height": window.innerHeight - (2 * marginY),
                        "background-color": "#FFF"
                    },
                        overlayStyles = {
                            "position": "fixed",
                            "z-index": "999998",
                            "top": 0,
                            "left": 0,
                            "width": "100%",
                            "height": "100%",
                            "opacity": "25%"
                        };

                    $("body").append("<div id='#overlay'></div>");
                    $("#overlay").css(overlayStyles);
                    $(elem).css(newStyles);
                    fullScreenMode = 'fullScreen';
                };
                function normalScreen(elem) {
                    $(elem).css(revertCss);
                    $("#overlay").remove();
                    fullScreenMode = 'normal';
                };
                function setScreenMargin(currentValue) {
                    if (currentValue > 800) return 50;
                    if (currentValue > 600) return 40;
                    if (currentValue > 400) return 30;
                    if (currentValue > 200) return 20;
                    return 10;
                };
            },
            controllerAs: "vm",
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }

        }
    };
})();


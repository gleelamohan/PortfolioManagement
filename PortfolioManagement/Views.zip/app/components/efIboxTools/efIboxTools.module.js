﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc overview
 * @name efAngularLibrary.efIboxTools
 * @description 
 * 
 * efIboxTools module provides an Angular directive for displaying, interacting, and decorating Inspinia iBox panels.
 * 
 * <a href="/app/#/demo/efIboxTools/demo">For complete implmentation details see the demo page.</a>
 * 
 * 
**/
(function () {
    angular.module('efAngularLibrary.efIboxTools', []);
})();
﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efIboxTools')
        .controller('EfIboxToolsDemoCtrl', EfIboxToolsDemoCtrl);

    EfIboxToolsDemoCtrl.$inject = ['$scope', '$state', '$sanitize', '$parse', '$filter', '$timeout', 'toastr'];

    function EfIboxToolsDemoCtrl($scope, $state, $sanitize, $parse, $filter, $timeout, toastr) {
        var vm = this;

        vm.showhidevisible = true;
        vm.showcontent = true;
        vm.contentdisabled = false;

        vm.infovisible = true;
        vm.infotoggledexternally = false;
        vm.infocallback = function() {
            toastr.info("Info icon clicked.", "efIboxTools Demo");
        }
        vm.toggleInfoExternally = function () {
            vm.infotoggledexternally = !vm.infotoggledexternally;
        }

        vm.refreshvisible = true;
        vm.refreshcallback = function () {
            toastr.info("Refresh icon clicked.", "efIboxTools Demo");
        }

        vm.validationvisible = true;
        vm.validationtoggledexternally = false;
        vm.validationcallback = function () {
            toastr.info("Validation icon clicked.", "efIboxTools Demo");
        }
        vm.toggleValidationExternally = function () {
            vm.validationtoggledexternally = !vm.validationtoggledexternally;
        }

        vm.filtervisible = true;
        vm.filtercallback = function () {
            toastr.info("Filter icon clicked.", "efIboxTools Demo");
        }

        vm.settingsvisible = true;
        vm.settingscallback = function () {
            toastr.info("Settings icon clicked.", "efIboxTools Demo");
        }

        vm.helpvisible = true;
        vm.helptoggledexternally = false;
        vm.helpcallback = function () {
            toastr.info("Validation icon clicked.", "efIboxTools Demo");
        }
        vm.toggleHelpExternally = function () {
            vm.helptoggledexternally = !vm.helptoggledexternally;
        }

        vm.closevisible = true;
        vm.closecallback = function () {
            toastr.info("Close icon clicked.", "efIboxTools Demo");
        }

        vm.ticketvisible = true;
        vm.ticketcallback = function () {
            toastr.info("Ticket icon clicked.", "efIboxTools Demo");
        }

        vm.fullscreenvisible = true;
        vm.fullscreencallback = function () {
            toastr.info("Full screen icon clicked.", "efIboxTools Demo");
        }
    };
})();

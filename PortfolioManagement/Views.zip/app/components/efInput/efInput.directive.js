﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc directive
 * @name efAngularLibrary.efInput.directive:efInput
 * @scope
 * @restrict AEC
 * @requires efAngularLibrary.efInput.efInputConfig
 * @requires efAngularLibrary.efDatetime.directive:efDatetime
 * @requires efAngularLibrary.efSelect.directive:efSelect
 * @requires efAngularLibrary.efRichTextInput.directive:efRichTextInput
 * @requires efAngularLibrary.efFocus.directive:efFocus
 * @requires efAngularLibrary.efUiGrid.efUiGridConstants
 * @requires efAngularLibrary.efEntity
 * @requires efLibrary
 * @requires recursionHelper
 * @requires toastr
 * @description 
 * 
 * efInput is an Angular directive input control that can render any number of allowed efAngularLibrary input controls.
 * 
 * <a href="/app/#/demo/efInput/demo">For complete implmentation details see the demo page.</a>
 * 
 * @param {object=} config JSON Object with configuration options.  See {@link efAngularLibrary.efInput.efInputConfig efInputConfig} for complete details.
 * @param {string=} getConfig A string-based name for the 'config' object to use.  When 'config' is not provided, the directive will search through the Angular scope hierarchy for the value provided here.  When it is found, it will be used as the directive's 'config'.  When 'config' is provided, this is ignored.  See {@link efAngularLibrary.efInput.efInputConfig efInputConfig} for complete details.
 * @param {object=} entity Entity object to optionally update with data changes, or to validate the field data on display/changes.  See {@link efAngularLibrary.efEntity efEntity} for complete details.
 * @param {string=} getEntity A string-based name for the entity object to optionally update with data changes, or to validate the field data on display/changes.  When 'entity' is not provided, the directive will search through the Angular scope hierarchy for the value provided here.  When it is found, it will be used as the directive's 'entity'.  When 'entity' is provided, this is ignored.  See {@link efAngularLibrary.efEntity efEntity} for complete details.
 * @param {object|string} ngModel The Angular model for the control.
 * @param {string=} modelField The field name for the model.
 * @param {object=} rowData The data for the current row.  Used with validateAfterEdit.
 * @param {any=} rowIdValue The row ID value (not the field name but the actual field value).
 * @param {expression|method=} ngChange The method to execute when the model has been changed.
 * @param {expression|boolean=} ngDisabled Flag to enable/disable the field.  If not provided, then the control is enabled.
 * @param {string=} width The HTML valid width for the control.  Default is 'auto'.
 * @param {boolean=} setFocus Flag to determine if the input should have focus (typically used/set within grids)
 * @param {boolean=} validateAfterModelChange Flag to validate value for errors within the directive on a model change via the supplied entity object.
 * @param {boolean=} validateAfterEdit Flag to validate value for errors within the directive on an internal change via the supplied entity object.
 * @param {boolean=} updateEntity Flag to update the supplied entity object with any found errors or changes.
 * @param {boolean=} displayError Flag to display any errors.
 * @param {boolean=} updateModelOnError Flag to update the model and call ngChange on Error (validateAfterEdit must be true).
 * @param {boolean=} inGrid Flag that tells the control if it is being rendered within a grid.  This parameter should not be set by the developer, but rather let the grid/parent control determine its value.
**/
(function () {
    angular
        .module('efAngularLibrary.efInput')
        .directive('efInput', efInput);

    efInput.$inject = ['$sce', '$filter', '$translate', '$timeout', 'recursionHelper', 'toastr', 'efLibrary', 'efUiGridConstants'];

    function efInput($sce, $filter, $translate, $timeout, recursionHelper, toastr, efLibrary, efUiGridConstants) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                config: "=?",                   //Config object that contain the input definition(s) to be rendered
                getConfig: "@?",                //String name of the config (or function to get the config) - this will be evaluated inline to get the config if the config parameter is not supplied.
                entity: "=?",                   //Entity object
                getEntity: "@?",                //String name of the entity (or function to get the entity) - this will be evaluated inline to get the entity if the entity parameter is not supplied.
                ngModel: "=",                   //Bound model value for the field
                modelField: "@?",               //Field name for the model
                rowData: "=?",                  //Data for the current row.  Used with validateAfterEdit.
                rowIdValue: "=?",               //Row ID value (not the field name but the actual field value) 
                ngChange: "&",                  //On change call back function
                ngDisabled: "=?",               //Disabled flag
                width: "@?",                    //Sets the width of the directive.  The width of the individual input controls can be set in the config.
                setFocus: "@?",                 //Boolean to determine if the input should have focus (typically used/set within grids)
                validateAfterModelChange: "@?", //Validate value for errors within the directive on a model change via the supplied entity object
                validateAfterEdit: "@?",        //Validate value for errors within the directive on an internal change via the supplied entity object
                updateEntity: "@?",             //Update the supplied entity object with any found errors or changes
                displayError: "@?",             //Display any errors
                updateModelOnError: "@?",       //Update the model and call ngChange on Error (validateAfterEdit must be true)
                inGrid: "@?"                    //Set this to true when running in the grid (this is done automatically for you)
            },
            controller: function ($scope, $element) {
                var vm = this;
                $scope.grid = {};   //Added to support UI.grid

                vm.templateUrl = "/app/components/efInput/efInput.html";
                vm.currentLanguage = $translate.use();
                vm.modelEdited = false;
                vm.callbackTimeout = 100;
                vm.model = null;
                vm.entity = null;
                vm.modelField = null;
                vm.setFocus = false;
                vm.error = null;
                vm.validateAfterModelChange = false;
                vm.validateAfterEdit = false;
                vm.updateEntity = false;
                vm.displayError = false;
                vm.updateModelOnError = false;

                //To get ROW from grid by using {{row.entity}}
                //To get field from grid by using {{row.entity[col.field]}}

                function handleConfigUpdates(newConfig) {
                    var config = efLibrary.isValid(newConfig) ? newConfig : (efLibrary.isValid($scope.getConfig, true) ? eval($scope.getConfig) : { "type": "label" });
                    var configArray = [];
                    if (efLibrary.isValid(config)) {
                        if (Array.isArray(config)) {
                            configArray = config;
                        } else {
                            configArray.push(config);
                        }
                    }

                    vm.config = configArray;
                    vm.setFocus = efLibrary.toBoolean($scope.setFocus, false);
                }
                $scope.$watch('config', handleConfigUpdates, true);

                function handleModelUpdates(newModel) {
                    vm.model = efLibrary.isValid(newModel) ? efLibrary.copyObject(newModel) : null;
                    if (!vm.modelEdited) {
                        if (vm.validateAfterModelChange) {
                            vm.validateInput();
                        } else {
                            vm.getInputErrorFromEntity();
                        }
                    } else {
                        vm.modelEdited = false;
                    }
                }
                $scope.$watch('ngModel', handleModelUpdates, true);

                function handleModelFieldUpdates(newModelField) {
                    vm.modelField = efLibrary.isValid(newModelField, true) ? newModelField : null;
                    if (!vm.modelEdited) {
                        handleModelUpdates($scope.ngModel);
                    }
                }
                $scope.$watch('modelField', handleModelFieldUpdates, true);

                function handleEntityUpdates(newEntity) {
                    vm.entity = efLibrary.isValid(newEntity) ? newEntity : (efLibrary.isValid($scope.getEntity, true) ? eval($scope.getEntity) : null);
                    if (vm.displayError && efLibrary.isValid(vm.entity)) {
                        vm.getInputErrorFromEntity();
                    }
                    if (!vm.modelEdited) {
                        handleModelUpdates($scope.ngModel);
                    }
                }
                $scope.$watch('entity', handleEntityUpdates, true);

                function handleRowDataUpdates(newRowData) {
                    vm.rowData = efLibrary.isValid(newRowData) ? newRowData : null;
                }
                $scope.$watch('rowData', handleRowDataUpdates, true);

                function handleRowIdValueUpdates(newRowIdValue) {
                    vm.rowIdValue = efLibrary.isValid(newRowIdValue) ? newRowIdValue : null;
                }
                $scope.$watch('rowIdValue', handleRowIdValueUpdates, true);

                function handleChangeCallbackUpdates(newChangeCallback) {
                    vm.changeCallback = efLibrary.isValid(newChangeCallback) ? newChangeCallback : function () { };
                }
                handleChangeCallbackUpdates($scope.ngChange);
                $scope.$watch('ngChange', handleChangeCallbackUpdates, true);

                function handleDisabledUpdates(newValue) {
                    vm.disabled = efLibrary.toBoolean(newValue, false);
                }
                $scope.$watch('ngDisabled', handleDisabledUpdates, true);

                function handleWidthUpdates(newValue) {
                    vm.widthStyle = efLibrary.isValid(newValue, true) ? JSON.parse("{\"width\": \"" + newValue + "\"}") : "";
                }
                $scope.$watch('width', handleWidthUpdates, true);

                function handleValidateAfterModelChangeUpdates(newValue) {
                    vm.validateAfterModelChange = efLibrary.toBoolean(newValue, false);
                    if (!vm.modelEdited) {
                        handleModelUpdates($scope.ngModel);
                    }
                }
                $scope.$watch('validateAfterModelChange', handleValidateAfterModelChangeUpdates, true);

                function handleValidateAfterEditUpdates(newValue) {
                    vm.validateAfterEdit = efLibrary.toBoolean(newValue, false);
                }
                $scope.$watch('validateAfterEdit', handleValidateAfterEditUpdates, true);

                function handleUpdateEntityUpdates(newValue) {
                    vm.updateEntity = efLibrary.toBoolean(newValue, false);
                }
                $scope.$watch('updateEntity', handleUpdateEntityUpdates, true);

                function handledisplayErrorUpdates(newValue) {
                    vm.displayError = efLibrary.toBoolean(newValue, false);
                }
                $scope.$watch('displayError', handledisplayErrorUpdates, true);

                function handleUpdateModelOnErrorUpdates(newValue) {
                    vm.updateModelOnError = efLibrary.toBoolean(newValue, false);
                }
                $scope.$watch('updateModelOnError', handleUpdateModelOnErrorUpdates, true);

                vm.textboxModelOptions = { updateOn: 'default' };

                //#region inGrid Functions and logic

                if (efLibrary.toBoolean($scope.inGrid, false)) {
                    vm.textboxModelOptions = { updateOn: 'default blur', debounce: { 'default': 0, 'blur': 0 } };
                }

                vm.inGridUpdates = function (fieldType) {
                    if (efLibrary.toBoolean($scope.inGrid, false)) {
                        var broadcastEndCellEditEvent = false;
                        if (efLibrary.isValid(fieldType, true)) {
                            switch (fieldType.toLowerCase()) {
                                case "text":
                                case "password":
                                case "email":
                                case "number":
                                    broadcastEndCellEditEvent = false;
                                    break;
                                case "range":
                                case "checkbox":
                                case "radio":
                                case "efdatetime":
                                case "efselect":
                                case "efrichtextinput":
                                    broadcastEndCellEditEvent = true;
                                    break;
                            }
                        }

                        if (broadcastEndCellEditEvent) {
                            $timeout(function () {
                                $scope.$broadcast(efUiGridConstants.events.END_UI_GRID_CELL_EDIT);
                            }, vm.callbackTimeout);
                        }
                    }
                }

                //#endregion

                //#region UpdateModel Handler

                vm.updateModel = function (fieldType) {
                    if (!efLibrary.isEqual($scope.ngModel, vm.model)) {
                        vm.modelEdited = true;
                        var updateModel = false;
                        if (vm.validateAfterEdit) {
                            updateModel = vm.validateInput() ? true : vm.updateModelOnError;
                        } else {
                            updateModel = true;
                        }

                        if (updateModel) {
                            $scope.ngModel = vm.model;
                            if (vm.updateEntity) {
                                var updateOk = vm.updateEntityObject();
                            }
                            if (!efLibrary.toBoolean($scope.inGrid, false)) {
                                if (efLibrary.isValid(vm.changeCallback)) {
                                    $timeout(function () {
                                        vm.changeCallback();
                                    }, vm.callbackTimeout);
                                }
                            } else {
                                vm.inGridUpdates(fieldType);
                            }
                        } else {
                            vm.modelEdited = false;
                        }
                    }
                }

                //#endregion

                //#region Validation and Entity Functions

                vm.validateInput = function () {
                    var returnValue = false;
                    if (efLibrary.isValid(vm.entity) && efLibrary.isValid(vm.modelField, true)) {
                        var data = {};
                        var ignoreDependentValidationRules = true;
                        if (efLibrary.isValid(vm.rowData)) {
                            data = efLibrary.copyObject(vm.rowData);
                            ignoreDependentValidationRules = false;
                        }
                        data[vm.modelField] = vm.model;
                        var errors = vm.entity.checkForFieldErrors(vm.modelField, data, ignoreDependentValidationRules);
                        var inputError = null;
                        if (efLibrary.isValid(errors, true)) {
                            var inputErrors = vm.entity.createInputErrors(errors);
                            if (efLibrary.isValid(inputErrors, true)) {
                                inputError = inputErrors[0];
                            }
                        } else {
                            returnValue = true;
                        }
                        vm.error = inputError;
                    }
                    return returnValue;
                }

                vm.getInputErrorFromEntity = function () {
                    if (efLibrary.isValid(vm.entity) && efLibrary.isValid(vm.modelField, true)) {
                        var error = vm.entity.getInputError(vm.modelField);
                        if (efLibrary.isValid(error) && efLibrary.isValid(error.status, true)) {
                            vm.error = error;
                        } else {
                            vm.error = null;
                        }
                    }
                }

                vm.updateEntityObject = function () {
                    var returnValue = false;
                    if (efLibrary.isValid(vm.entity) && efLibrary.isValid(vm.modelField, true) && efLibrary.isValid(vm.rowData)) {
                        var data = data = efLibrary.copyObject(vm.rowData);
                        data[vm.modelField] = vm.model;
                        returnValue = vm.entity.changeFieldData(vm.modelField, data, true, true);
                    }
                    return returnValue;
                }

                //#endregion

            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        };
    }
})();

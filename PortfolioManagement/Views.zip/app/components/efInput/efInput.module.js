﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc overview
 * @name efAngularLibrary.efInput
 * @description 
 * 
 * efInput module provides an Angular directive input control that can render any number of allowed efAngularLibrary input controls.
 * 
 * <a href="/app/#/demo/efInput/demo">For complete implmentation details see the demo page.</a>
 * 
 * 
**/
(function () {
    angular.module('efAngularLibrary.efInput', []);
})();
﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efInput')
        .controller('EfInputDemoCtrl', EfInputDemoCtrl);

    EfInputDemoCtrl.$inject = ['$scope', '$state', '$sanitize', '$parse', '$filter', '$timeout', '$compile', '$http', 'toastr', 'efLibrary', 'efInputDemoApi'];

    function EfInputDemoCtrl($scope, $state, $sanitize, $parse, $filter, $timeout, $compile, $http, toastr, efLibrary, efInputDemoApi) {
        var vm = this;

        //#region Example Setup Options

        vm.disabled = false;

        vm.ngChangeToastrEnabled = false;

        vm.changedCallback = function (inputType) {
            if (vm.ngChangeToastrEnabled) {
                var message = "efInput ngChange was called.<br/>" +
                    "type: " + (efLibrary.isValid(inputType, true) ? inputType : "") + "<br/>";
                toastr.info(message);
            }
        }

        //See the efSelect.config.json file for all available options
        vm.taskTemplateNameSelectConfig = {
            "mode": "select",
            "placeholder": String($filter("trustedtranslate")("efAngularLibrary.efInput.Demo.TaskTemplate.Name.SelectPlaceholder")),
            "options": [],  //This is set below after the list of TaskTemplates is retrieved (but before the editable DT is configured)
            "optionsListMaxWidth": "300px",
            "optionsListMaxHeight": "200px",
            "optionsListScrollOnWideOptions": true,
            "width": "100%"
        };

        vm.entity = efLibrary.copyObject(efInputDemoApi.taskListTemplate);
        vm.taskTemplateNameSelectConfig.options = efLibrary.copyObject(efInputDemoApi.taskTemplates);

        //#endregion

        //#region Setup efInput Configs

        vm.configs = {};

        //All configs can have the following options:
        //"class":          This is a space delimited list of classes to apply to the input control
        //"prefixHTML":     This is a string of any HTML that will come before the input control
        //"suffixHTML":     This is a string of any HTML that will come after the input control

        vm.configs.label = {
            "type": "label"
        };

        vm.configs.labelPrefixSuffix = {
            "type": "label",
            "prefixHTML": "<label>",
            "suffixHTML": "</label>"
        };

        vm.configs.labelStyled = {
            "type": "label",
            "class": "label label-primary"
        };

        vm.configs.text = {
            "type": "text",
            "placeholder": String($filter("trustedtranslate")("efAngularLibrary.efInput.Demo.TaskTemplate.Name.InputPlaceholder")),
            //"maxlength": 64,
            //"ng-model-options": { updateOn: 'blur' },     //Update on blur only
            //"ng-model-options": { updateOn: 'default blur', debounce: { 'default': 2000, 'blur': 0 } },     //Update after 2 seconds of wait time or immediately on blur
        };

        //Please note that all options for text and password are the same
        vm.configs.password = {
            "type": "password",
            "placeholder": String($filter("trustedtranslate")("efAngularLibrary.efInput.Demo.TaskTemplate.Name.InputPlaceholder")),
            //"maxlength": 64,
            //"ng-model-options": { updateOn: 'blur' },     //Update on blur only
            //"ng-model-options": { updateOn: 'default blur', debounce: { 'default': 2000, 'blur': 0 } },     //Update after 2 seconds of wait time or immediately on blur
        };

        //Please note that all options for text and email are the same
        vm.configs.email = {
            "type": "email",
            "placeholder": "Enter Email Address",
            //"maxlength": 64,
            "ng-model-options": { updateOn: 'blur' },     //Update on blur only
            //"ng-model-options": { updateOn: 'default blur', debounce: { 'default': 2000, 'blur': 0 } },     //Update after 2 seconds of wait time or immediately on blur
        };

        vm.configs.number = {
            "type": "number",
            "placeholder": String($filter("trustedtranslate")("efAngularLibrary.efInput.Demo.TaskTemplate.TimeDuration.InputPlaceholder")),
            //"ng-model-options": { updateOn: 'blur' },     //Update on blur only
            //"ng-model-options": { updateOn: 'default blur', debounce: { 'default': 2000, 'blur': 0 } },     //Update after 2 seconds of wait time or immediately on blur
            "min": 0,
            "max": 999.99,
        };

        vm.configs.range = {
            "type": "range",
            "placeholder": String($filter("trustedtranslate")("efAngularLibrary.efInput.Demo.TaskTemplate.OrderNumber.InputPlaceholder")),
            //"ng-model-options": { updateOn: 'blur' },     //Update on blur only
            //"ng-model-options": { updateOn: 'default blur', debounce: { 'default': 2000, 'blur': 0 } },     //Update after 2 seconds of wait time or immediately on blur
            "min": 0,
            "max": 10,
            "step": 1
        };

        vm.configs.checkbox = {
            "type": "checkbox",
            "placeholder": String($filter("trustedtranslate")("efAngularLibrary.efInput.Demo.TaskTemplate.IsTimeDependent.FormText"))
        };

        vm.configs.radio = [
            {
                "type": "radio",
                "placeholder": "Hours",
                "name": "TimeUnit",
                "value": "Hours",
                "suffixHTML": "&nbsp;&nbsp;&nbsp;"
            },
            {
                "type": "radio",
                "placeholder": "Days",
                "name": "TimeUnit",
                "value": "Days"
            }
        ];

        vm.configs.radioVertical = [
            {
                "type": "radio",
                "placeholder": "Hours",
                "name": "TimeUnitVertical",
                "value": "Hours",
                "suffixHTML": "<br/>"
            },
            {
                "type": "radio",
                "placeholder": "Days",
                "name": "TimeUnitVertical",
                "value": "Days"
            }
        ];

        //See efDatetime.directive.js and efDatetime.examples for the available configuration options - all HTML paramters options are accepted
        vm.configs.efDatetime = {
            "type": "efDatetime",
            "config": { startView: 'day', minView: 'minute', minuteStep: 1 },
            "placeholder": "Select Task Date Time",
            "width": "100%"
        };

        //See efSelect.directive.js for the available configuration options - all HTML paramters options are accepted
        vm.configs.efSelect = {
            "type": "efSelect",
            "mode": "select",
            "config": vm.taskTemplateNameSelectConfig,
            "width": "100%"
        };


        //See efRichTextInput.directive.js for the available configuration options - all HTML paramters options are accepted
        vm.configs.efRichTextInput = {
            "type": "efRichTextInput",
            "width": "100%",
            "config": {
                "placeholder": "Enter Results",
                "textMaxLength": 256,
                "width": "100%"
            }
        };
        //#endregion

    };
})();

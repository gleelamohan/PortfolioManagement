﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efInput')
        .factory('efInputDemoApi', efInputDemoApi);

    efInputDemoApi.$inject = ['$resource', '$filter'];

    function efInputDemoApi($resource, $filter) {
        var service = {};

        service.taskListTemplate = {
            "TaskListTemplateTaskTemplateId": "ce05d1ae-8224-491a-ae9d-84ad3f44e67c",
            "TaskListTemplateId": "8eb52ddc-27a2-4f15-930b-5ec1f05bd027",
            "TaskTemplateId": "a38451f4-821d-4d64-b2f0-08c2fb634220",
            "TaskTemplate": {
                "TaskTemplateId": "a38451f4-821d-4d64-b2f0-08c2fb634220",
                "Name": "Chrm-Impurity Data Proc",
                "Description": null,
                "DataState": "Unchanged"
            },
            "OrderNumber": 4,
            "IsTimeDependent": false,
            "TimeDuration": null,
            "TimeUnit": null,
            "DataState": "Unchanged",
            "TaskStartDateTime": "2015-09-30T14:23:19.581Z",
            "TaskEmail": null
        };

        service.taskTemplates = [
            {
                "label": "Chrm-A/R Data Proc",
                "value": "023148bd-b192-498e-9ae9-bed062117cbb"
            },
            {
                "label": "Chrm-Impurity Data Proc",
                "value": "a38451f4-821d-4d64-b2f0-08c2fb634220"
            },
            {
                "label": "Chrm-Reagent & GW Prep",
                "value": "fa169443-2c0c-4d9a-a741-bf8bdbca9ba8"
            },
            {
                "label": "Chrm-Reference Std Prep",
                "value": "ad6d4a71-7f7c-4d1f-90e2-51731886dffa"
            },
            {
                "label": "GenChem-Data Reporting",
                "value": "e656d845-98f3-4a02-9ffd-28b29f023171"
            },
            {
                "label": "GenChem-Prep (difficult)",
                "value": "46ee04f2-1825-4fca-8c31-33e848c4111c"
            },
            {
                "label": "GenChem-Prep (typical)",
                "value": "0dcf0504-6b35-4fbe-aa6f-96db3e77cf71"
            },
            {
                "label": "Inst- HPLC Impurities-RI",
                "value": "d1eb43a1-d6d3-4ab9-a505-a55c954e472c"
            },
            {
                "label": "Inst- volumetric Karl Fisher",
                "value": "8ebd0ea8-f5dd-44d5-bf42-0e22acffae29"
            },
            {
                "label": "Inst-Autotitration",
                "value": "f69d0a4c-60a7-4ed4-b07e-5a152b903527"
            },
            {
                "label": "Inst-coulometric Karl Fisher ",
                "value": "f8c5a679-8b43-42be-bacd-c2bd2affc9b4"
            },
            {
                "label": "Inst-GC Direct A/R - FID",
                "value": "e2222382-6c2e-4b16-9741-93de8922e517"
            },
            {
                "label": "Inst-GC Direct A/R - TCD",
                "value": "f70a11f5-2aea-4300-8e97-ea4f4c3aee33"
            },
            {
                "label": "Inst-GC Direct Impur-FID",
                "value": "661cc5c8-ef05-41d5-9a91-ff179943359a"
            },
            {
                "label": "Inst-GC Direct Impur-TCD",
                "value": "3edf35c6-a9d1-4ba4-a6dc-4ad8afae6e22"
            },
            {
                "label": "Inst-GC Headspace A/R - FID",
                "value": "dfe51b12-3e39-4317-9f13-9bdc6c19de36"
            },
            {
                "label": "Inst-GC Headspace A/R - TCD",
                "value": "d8a5ef40-be68-4da9-bad2-cd4f6aae5f97"
            },
            {
                "label": "Inst-HPLC A/R - ELSD",
                "value": "e7d7b7cb-6305-4445-84a5-14d60486753a"
            },
            {
                "label": "Inst-HPLC A/R - RI",
                "value": "0620edfa-8dd0-43d6-b251-94945ec89009"
            },
            {
                "label": "Inst-HPLC Impurities-ELSD",
                "value": "7bd47f7f-aaef-4baf-a2af-eaa1eebe85f8"
            },
            {
                "label": "Inst-HPLC Impurities-uv",
                "value": "b2ffdcf7-048a-4add-a07b-f4805fc1e0f9"
            },
            {
                "label": "Inst-HPLCA/R - uv",
                "value": "af32954b-8693-4351-974d-0c57291e6704"
            },
            {
                "label": "Inst-Karl Fischer oven",
                "value": "25e46770-f5a5-4ea1-b157-b76fcd3aded4"
            },
            {
                "label": "Micro-Colony Morphology",
                "value": "6fda93e7-da87-4fad-a259-3f13b8ef7018"
            },
            {
                "label": "Micro-ID by MicroSEQ",
                "value": "56f43b44-85c0-48b1-8751-1818fdff90c9"
            },
            {
                "label": "Micro-Incubate",
                "value": "ab74d67d-40dd-41f4-bd51-2cbb1a1fe50f"
            },
            {
                "label": "Micro-Plate Count",
                "value": "6b964c68-68f7-4b83-857b-1337bfe33f98"
            },
            {
                "label": "Micro-Prep (Streak)",
                "value": "0bab66a1-7233-43ba-9bac-89161c33f52b"
            },
            {
                "label": "Micro-Prep (Transfer)",
                "value": "9a17904f-15e5-414a-a501-f4095e5e62f5"
            },
            {
                "label": "Micro-Prep (Weigh&Dilute)",
                "value": "0cf840ef-26eb-4e90-840f-0beac4518c6a"
            },
            {
                "label": "Micro-Read MAC Plates",
                "value": "68486aec-eb3f-4e77-9b3d-d193afc208f7"
            },
            {
                "label": "Micro-Sample Prep (Plating)",
                "value": "ed25951e-9d89-4ad9-866d-767b2398b4f9"
            },
            {
                "label": "New Task Template",
                "value": "c96c8a47-f4de-4c52-abe0-0456d39cb025"
            },
            {
                "label": "task temp[late",
                "value": "7a05fc7e-8e54-4aff-a8d7-64494f43ee3a"
            },
            {
                "label": "Task Templa 10",
                "value": "1cd3dfa5-a05b-49bc-a70f-0d42325186c4"
            },
            {
                "label": "Task Template - Sample Reg",
                "value": "fe60149e-7639-4b52-879f-3b33e13cc598"
            },
            {
                "label": "Task Template TED Testing Scenario 1",
                "value": "868a7dae-117c-42d2-a033-88d9b442d853"
            },
            {
                "label": "TaskTemplate1",
                "value": "d62f5b34-196d-4a20-bba5-3c0ccf113296"
            },
            {
                "label": "TaskTemplate2",
                "value": "2066c00e-3d4c-4569-bfe7-273b1854f308"
            },
            {
                "label": "testte",
                "value": "12e111b7-8253-46d2-ba7f-e421b302eeaf"
            },
            {
                "label": "UDJ3-04-09-TT",
                "value": "c373f288-dd2a-4da5-b6bf-5106695794b9"
            },
            {
                "label": "UDJ3-08-20",
                "value": "433a7a25-3a3f-46ba-96a3-d35ee34113f9"
            },
            {
                "label": "US_QA_Task_Template",
                "value": "24b3f9ac-e439-4d1b-88f2-5feb3e634434"
            }
        ];
        return service;
    }
})();
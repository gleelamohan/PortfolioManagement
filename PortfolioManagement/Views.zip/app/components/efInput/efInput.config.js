﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efInput')
        .config(config);

    config.$inject = ['$stateProvider'];

    function config($stateProvider) {
        $stateProvider
            .state('efAngularLibrary.efInput', {
                abstract: true,
                url: "/efInput",
                template: "<ui-view />"
            })
            .state('efAngularLibrary.efInput.demo', {
                url: "/demo",
                templateUrl: "/app/components/efInput/demo/efInput.demo.html",
                controller: "EfInputDemoCtrl",
                controllerAs: "vm"
            });
    };
})();
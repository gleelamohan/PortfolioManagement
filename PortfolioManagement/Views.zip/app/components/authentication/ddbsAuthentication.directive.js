/// <reference path="authentication.html" />
(function () {
	angular
        .module('app')
        .directive('ddbsAuthentication', ddbsAuthentication);

	ddbsAuthentication.$inject = ['$sce', '$filter', 'recursionHelper', '$stateParams'];
	function ddbsAuthentication($sce, $filter, recursionHelper, $stateParams) {
		return {
			restrict: 'AEC',
			replace: false,
			controller: function ($scope, $stateParams) {
				var vm = this;
				vm.isAuthenticated = false;
				vm.errorDesc = "";
				vm.SubmitButtonText = "";
				vm.statusMessage = "";

				vm.status = $stateParams.inputScope.status;
				vm.statusText = $stateParams.inputScope.statusText;

				var userName = "";
			    var emailId = "";
			    if ($stateParams.inputScope.data != null) {
			        userName = $stateParams.inputScope.data.FirstName + ' ' + $stateParams.inputScope.data.LastName;
			        if ($stateParams.inputScope.data.EmailId !== undefined || $stateParams.inputScope.data.EmailId !== null) {
			            emailId = $stateParams.inputScope.data.EmailId.toLowerCase();
			        }
			    }
			   
			    if (vm.status != null) {

					if (vm.statusText == 200) {
						vm.statusText = "";
						vm.isAuthenticated = true;
						vm.statusMessage = "Welcome";
					}
					else if (vm.statusText == 401) {
						vm.statusMessage = "Unauthorized Access";
						vm.errorDesc = "Access is denied due to invalid credentials. For getting Access to LIMS application please submit request by clicking on the below button.";
						vm.SubmitButtonText = "Submit Access Request";
						
					}
					else if (vm.statusText == 501) {
						vm.statusMessage = "Unauthorized Access";
						vm.errorDesc = "Your account has been de-activated. Please contact Administrator.";
						vm.SubmitButtonText = "Contact Admin";
					}
					else
					{
						vm.statusMessage = "Failed To Connect: Connection Refused";
					}
					
				}
				vm.requestForLimsAccess = function () {

					var to = window.app.config.eLimsSupportEmail;
					var puid = window.app.puid;

					if (vm.statusText == 401) {
						var subject = "Request for eLIMS Application Access.";
						var bodyText = [];

						bodyText.push("Hi DDBS Support,");
						bodyText.push("\n");
						bodyText.push("\n\t Please add my user account to access LIMS application. ");
						bodyText.push("\n\t Account Information-");
						bodyText.push("\n\t\t PUID: " + puid);
						bodyText.push("\n\t\t Email: " + emailId);
						bodyText.push("\n\t\t Role: ?");
						bodyText.push("\n\t\t Business Reason: ?");
						bodyText.push("\n");
						bodyText.push("\nThanks");
						bodyText.push("\n" + userName);
					}

					if (vm.statusText == 501) {
						var subject = "Request to Re-Activate the account.";
						var bodyText = [];

						bodyText.push("Hi DDBS Support,");
						bodyText.push("\n");
						bodyText.push("\n\t As my account is currently de-activated, please provide me access to LIMS application. ");
						bodyText.push("\n\t Account Information-");
						bodyText.push("\n\t\t PUID: " + puid);
						bodyText.push("\n\t\t Email: " + emailId);
						bodyText.push("\n\t\t Role: ?");
						bodyText.push("\n\t\t Business Reason: ?");
						bodyText.push("\n");
						bodyText.push("\nThanks");
						bodyText.push("\n" + userName);
					}
					var emailBody = "";

					for (var i = 0; i < bodyText.length; i++) {
						emailBody += bodyText[i];
					}
					emailBody = encodeURIComponent(emailBody);
					href = "mailto:" + to + "?Subject=" + subject + "&body=" + emailBody;
					window.location.href = href;

				};
				
			},
			controllerAs: 'vm',
			templateUrl: '/app/components/authentication/ddbsAuthentication.html',
			compile: function (element) {
				return recursionHelper.compile(element);
			}
		};
	}
})();
﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc service
 * @name efLibrary
 * @description 
 * 
 * The efLibrary provides a set of common Javascript utlity/helper functions that can used within Eurofins applications, as well as they are used within the efAngularLibrary itself.
 * 
 * As an AngularJS best practice, this library should be setup as an injectable resource by defining it as an Angular constant within the root application module:
 * <pre>
 * (function () {
 *      angular.module('app').constant('efLibrary', efLibrary);
 * })();
 * </pre>
 * 
**/
module efLibrary {

    declare var $: any;
    declare var angular: any;

    //#region Object/Type Validation Functions


/**
 * @ngdoc method
 * @name isValid
 * @methodOf efLibrary
 * @description 
 * 
 * This method validates if an object/value is not undefined or null, as well as optionally check if the object/value has a length greater than 0.
 * 
 * @param {object|any} val The object/value to validate.
 * @param {boolean=} checkForLength Flag to optionally check the length object/value.  If set to true and the object/value has a length of zero, then the object/value is considered invalid. 
 * @returns {boolean} If true, then the object/value is valid.  If false, then the object/value is invalid.  
**/
    export function isValid(val: any, checkForLength: boolean = false): boolean {
        return val === false || val === 0 ? true : (checkForLength ? ((!!val) && val.length > 0) : (!!val));
    }

/**
 * @ngdoc method
 * @name isEqual
 * @methodOf efLibrary
 * @description 
 * 
 * This method compares two object/values to determine if they are equal.  Please note that this method uses deep inspection of the object/values to judge equality.
 * 
 * @param {object|any} val1 The first object/value to judge equality on.
 * @param {object|any} val2 The second object/value to judge equality on.
 * @returns {boolean} If true, then the two object/values are equal.  If false, then the two object/values are not equal.  
**/
    export function isEqual(val1: any, val2: any): boolean {
        return (isValid(val1) || isValid(val2)) ? ((isValid(val1) ? JSON.stringify(val1) : null) === (isValid(val2) ? JSON.stringify(val2) : null)) : ((val1 !== undefined && val2 !== undefined) ? (val1 === val2) : false);
    }

/**
 * @ngdoc method
 * @name toBoolean
 * @methodOf efLibrary
 * @description 
 * 
 * This method converts an object/value to a native Javascript boolean type.  You can optioanlly provide a default boolean value to use should the object/value be either invalid or not an allowed boolean type. 
 * 
 * @param {object|any} val The object/value to convert to a Javascript boolean value.
 * @param {boolean=} defaultValue Default value to return if the object/value is invalid, or if the object/value cannot be converted to a boolean value. 
 * @returns {boolean} The converted value of object/value.  If no defaultValue is et and the obejct cannot be convert, this methids returns false.
**/
    export function toBoolean(val: any, defaultValue: boolean = null): boolean {
        var returnValue = (isValid(defaultValue)) ? defaultValue : false;
        if (isValid(val) && val !== "") {
            if ((isNaN(val) && (val.toLowerCase() === "true" || val.toLowerCase() === "yes")) ||
                (!isNaN(val) && Number(val) === 1)) {
                returnValue = true;
            } else if ((isNaN(val) && (val.toLowerCase() === "false" || val.toLowerCase() === "no")) ||
                (!isNaN(val) && Number(val) === 0)) {
                returnValue = false;
            }
        }
        return returnValue;
    }

    //Returns True if a field is undefined or null
    export function isNotSet(field: any): boolean {
        if (field === undefined || field === null) {
            return true;
        }

        return false;
    }
    //#endregion

    //#region JSON Object Handling Functions

/**
 * @ngdoc method
 * @name copyObject
 * @methodOf efLibrary
 * @description 
 * 
 * This method copies/clones a Javascript object.  Please note that the copied/cloned object no longer references the orignal object.
 * You can select whether the to use a JSON-based copy method (default) or to use an Angular-based copy method.  The Angular methiod takes longer, but it will preserve any Angular attributes, state, and methods.  In general the JSON method (default) should be used for simple data objects.  The Angular method should be used for more complex objects with methods, events, or Angular state.
 * 
 * @param {object} obj The object to copy.
 * @param {boolean=} useAngularCopy Flag to use the Angular copy method over the default JSON-based method.  If not provided, or if this is set to false, then the method with perform a JSON-based copy. 
 * @returns {object} Copied/cloned object.
**/
    export function copyObject(obj: any, useAngularCopy: boolean = false) {
        return isValid(obj) ? (useAngularCopy ? angular.copy(obj) : JSON.parse(JSON.stringify(obj))) : null;
    }

/**
 * @ngdoc method
 * @name mergeObjects
 * @methodOf efLibrary
 * @description 
 * 
 * This method merges an array objects into one combined object.  Common object properties/methods and combined with the last value having precedence.  Uniquep roperties/methods contain the initial value.
 * 
 * @param {object|Array} objs Comma separated list of objects to merge.
 * @returns {object} Merged object.
**/
    export function mergeObjects(...objs: any[]) {
        var objectsToMerge: any[] = copyObject(objs, true);
        objectsToMerge.unshift({});
        return copyObject(angular.extend.apply(this, objectsToMerge), true);
    }

/**
 * @ngdoc method
 * @name setModelObjectByName
 * @methodOf efLibrary
 * @description 
 * 
 * This method sets an object, by its string-based name, to a provided value within a scpecified scope.
 * 
 * Simple object-based example:
 * <pre>
 * efLibrary.setModelObjectByName(myObject, "myVariable", "NewValue");
 * </pre>
 * 
 * Scope example with dot-notation variable name:
 * <pre>
 * efLibrary.setModelObjectByName($scope, "myObject.myVariable", "NewValue");
 * </pre>
 * 
 * @param {object|scope} scope Model/Scope/Object to search for the variable in.
 * @param {string} variableName Variable/object name to set.  This must be a string.  The value can include dot-based notation if desired (see example above).
 * @param {Any} value Value to be set.
**/
    export function setModelObjectByName(scope: any, variableName: string, value: any) {
        var levels = variableName.split(".");
        var model = scope;
        var i = 0;
        while (i < levels.length - 1) {
            if (typeof model[levels[i]] === 'undefined') {
                model[levels[i]] = {};
            }
            model = model[levels[i]];
            i++;
        }
        model[levels[levels.length - 1]] = value;
    }

/**
 * @ngdoc method
 * @name getAllObjectsById
 * @methodOf efLibrary
 * @description 
 * 
 * This method searches an array of objects, returning all objects equal to the provided id field and value.
 * 
 * @param {string} idField The field name within the array of objects to search on.
 * @param {any} id The field value to search for.
 * @param {Array} objectArray The array of objects to search in.
 * @returns {Array} Array of matching objects.  If no mathcing objects are found, then the method will return null.
**/
    export function getAllObjectsById(idField: string, id: any, objectArray: any[]) {
        var returnValue: any[] = [];
        if (isValid(idField, true) && id !== undefined && isValid(objectArray, true)) {
            for (var i = 0; i < objectArray.length; i++) {
                if (isValid(objectArray[i]) && objectArray[i][idField] === id) {
                    returnValue.push(objectArray[i]);
                }
            }
        }
        return returnValue.length > 0 ? returnValue : null;
    }

/**
 * @ngdoc method
 * @name getFirstObjectById
 * @methodOf efLibrary
 * @description 
 * 
 * This method searches an array of objects, returning the first object equal to the provided id field and value.
 * 
 * @param {string} idField The field name within the array of objects to search on.
 * @param {any} id The field value to search for.
 * @param {Array} objectArray The array of objects to search in.
 * @returns {object} First matching object.  If no mathcing object is found, then the method will return null.
**/
    export function getFirstObjectById(idField: string, id: any, objectArray: any[]) {
        var returnValue: any[] = null;
        var foundValues = getAllObjectsById(idField, id, objectArray);
        if (isValid(foundValues, true)) {
            returnValue = foundValues[0];
        }
        return returnValue;
    }

/**
 * @ngdoc method
 * @name getAllValuesById
 * @methodOf efLibrary
 * @description 
 * 
 * This method searches an array of objects, returning a specific field's value for all objects equal to the provided id field and value.
 * 
 * @param {string} idField The field name within the array of objects to search on.
 * @param {any} id The field value to search for.
 * @param {string} valueField The field name within the array of objects to return.
 * @param {Array} objectArray The array of objects to search in.
 * @returns {Array} Array of matching values.  If no mathcing objects are found, then the method will return null.
**/
    export function getAllValuesById(idField: string, id: any, valueField: string, objectArray: any[]) {
        var returnValue: any[] = [];
        if (isValid(idField, true) && id !== undefined && isValid(valueField, true) && isValid(objectArray, true)) {
            for (var i = 0; i < objectArray.length; i++) {
                if (isValid(objectArray[i]) && objectArray[i][idField] === id) {
                    returnValue.push(objectArray[i][valueField]);
                }
            }
        }
        return returnValue.length > 0 ? returnValue : null;
    }

/**
 * @ngdoc method
 * @name getFirstValueById
 * @methodOf efLibrary
 * @description 
 * 
 * This method searches an array of objects, returning a specific field's value for the first object equal to the provided id field and value.
 * 
 * @param {string} idField The field name within the array of objects to search on.
 * @param {any} id The field value to search for.
 * @param {string} valueField The field name within the array of objects to return.
 * @param {Array} objectArray The array of objects to search in.
 * @returns {Array} First matching value.  If no mathcing object is found, then the method will return null.
**/
    export function getFirstValueById(idField: string, id: any, valueField: string, objectArray: any[]) {
        var returnValue: any[] = null;
        var foundValues = getAllValuesById(idField, id, valueField, objectArray);
        if (isValid(foundValues, true)) {
            returnValue = foundValues[0];
        }
        return returnValue;
    }

    //#endregion

    //#region Angular Object Handling Functions

/**
 * @ngdoc method
 * @name getObjectInScope
 * @methodOf efLibrary
 * @description 
 * 
 * This method returns an object/value, by its string-based name, from within a scpecified scope.  
 *
 * Please note that by default this methods returns a copy of the found object/value.  You can optionally return a reference to the found object/value by setting the "returnObjectReference" parameter.
 * 
 * Simple object-based example returning a copy of the found object:
 * <pre>
 * var returnValue = efLibrary.getObjectInScope(myObject, "myChildObject");
 * </pre>
 * 
 * Simple object-based example returning a reference to the found object:
 * <pre>
 * var returnValue = efLibrary.getObjectInScope(myObject, "myChildObject", true);
 * </pre>
 * 
 * Dot-notation variable name example:
 * <pre>
 * var returnValue = efLibrary.getObjectInScope(myObject, "myChildObject.myVariable");
 * </pre>
 * 
 * @param {object|scope} scope Model/Scope/Object to search for the variable in.
 * @param {string} variableName Variable/object name to retrieve.  This must be a string.  The value can include dot-based notation if desired (see example above).
 * @param {boolean=} returnObjectReference Flag to return a reference to the object/value.  If not provided, this value is false.
 * @returns {object|any} Copy of the found object/value if "returnObjectReference" is not provided or set to false. Reference to the found object/value if "returnObjectReference" is provided and set to true.
**/
    export function getObjectInScope(scope: any, objectName: string, returnObjectReference: boolean = false) {
        var returnValue: any = null;
        if (isValid(scope) && isValid(objectName, true)) {
            var levels = objectName.split(".");
            var model = scope;
            var i = 0;
            while (i < levels.length - 1) {
                if (typeof model[levels[i]] !== 'undefined') {
                    model = model[levels[i]];
                } else {
                    break;
                }
                i++;
            }
            if (returnObjectReference) {
                returnValue = model[levels[levels.length - 1]];
            } else {
                returnValue = copyObject(model[levels[levels.length - 1]]);
            }
        }
        return returnValue;
    }

/**
 * @ngdoc method
 * @name getObjectThroughAngularScope
 * @methodOf efLibrary
 * @description 
 * 
 * This method returns an object/value, by its string-based name, from within a scpecified Angular scope.  The method will continue to navigate through the Angular parent scope objects until the object is found.
 *
 * Please note that by default this methods returns a copy of the found object/value.  You can optionally return a reference to the found object/value by setting the "returnObjectReference" parameter.
 * 
 * Simple example returning a copy of the found object:
 * <pre>
 * var returnValue = efLibrary.getObjectThroughAngularScope($scope, "myChildObject");
 * </pre>
 * 
 * Simple example returning a reference to the found object:
 * <pre>
 * var returnValue = efLibrary.getObjectThroughAngularScope($scope, "myChildObject", true);
 * </pre>
 * 
 * Dot-notation variable name example:
 * <pre>
 * var returnValue = efLibrary.getObjectThroughAngularScope($scope, "myChildObject.myVariable");
 * </pre>
 * 
 * @param {object|scope} scope Angular/Javascript scopeto search for the variable in.  The method will continue to navigate through the parent scope objects until the object is found.
 * @param {string} variableName Variable/object name to retrieve.  This must be a string.  The value can include dot-based notation if desired (see example above).
 * @param {boolean=} returnObjectReference Flag to return a reference to the object/value.  If not provided, this value is false.
 * @returns {object|any} Copy of the found object/value if "returnObjectReference" is not provided or set to false. Reference to the found object/value if "returnObjectReference" is provided and set to true.
**/
    export function getObjectThroughAngularScope(scope: any, objectName: string, returnObjectReference: boolean = false) {
        var returnValue: any = null;
        if (isValid(scope) && isValid(objectName, true)) {
            var object = getObjectInScope(scope, objectName, returnObjectReference);
            if (isValid(object)) {
                if (returnObjectReference) {
                    returnValue = object;
                } else {
                    returnValue = copyObject(object, true);
                }
            } else if (isValid(scope.$parent)) {
                returnValue = getObjectThroughAngularScope(scope.$parent, objectName, returnObjectReference);
            }
        }
        return returnValue;
    }

/**
 * @ngdoc method
 * @name executeFunctionThroughAngularScope
 * @methodOf efLibrary
 * @description 
 * 
 * This method executes a function, by its string-based name, from within a scpecified Angular scope.  The method will continue to navigate through the Angular parent scope objects until the function is found.
 *
 * Example:
 * <pre>
 * efLibrary.executeFunctionThroughAngularScope($scope, "myFunction('myInputParameter')");
 * </pre>
 * 
 * Dot-notation variable name example:
 * <pre>
 * efLibrary.executeFunctionThroughAngularScope($scope, "myObject.myFunction('myInputParameter')");
 * </pre>
 * 
 * @param {object|scope} scope Angular/Javascript scopeto search for the variable in.  The method will continue to navigate through the parent scope objects until the object is found.
 * @param {string} functionName Function name (including any input parameters) to execute.  This must be a string.  The value can include dot-based notation if desired (see example above).
**/
    export function executeFunctionThroughAngularScope(scope: any, functionName: string) {
        if (isValid(scope) && isValid(functionName, true)) {
            var parenthesisStartPosition = functionName.indexOf("(");
            if (parenthesisStartPosition > -1) {
                var objectName = functionName.substring(0, parenthesisStartPosition);
                if (isValid(objectName, true)) {
                    var object = getObjectInScope(scope, objectName, true);
                    if (isValid(object)) {
                        scope.$eval(functionName);
                    } else if (isValid(scope.$parent)) {
                        executeFunctionThroughAngularScope(scope.$parent, functionName);
                    }
                }
            }
        }
    }

/**
 * @ngdoc method
 * @name executeFunctionWithReturnThroughAngularScope
 * @methodOf efLibrary
 * @description 
 * 
 * This method executes a function and returns the function value, by its string-based name, from within a scpecified Angular scope.  The method will continue to navigate through the Angular parent scope objects until the function is found.
 *
 * Example:
 * <pre>
 * var returnValue = efLibrary.executeFunctionThroughAngularScope($scope, "myFunction('myInputParameter')");
 * </pre>
 * 
 * Dot-notation variable name example:
 * <pre>
 * var returnValue =  efLibrary.executeFunctionThroughAngularScope($scope, "myObject.myFunction('myInputParameter')");
 * </pre>
 * 
 * @param {object|scope} scope Angular/Javascript scopeto search for the variable in.  The method will continue to navigate through the parent scope objects until the object is found.
 * @param {string} functionName Function name (including any input parameters) to execute.  This must be a string.  The value can include dot-based notation if desired (see example above).
 * @returns {object|any} Found function return value.  
**/
    export function executeFunctionWithReturnThroughAngularScope(scope: any, functionName: string) {
        if (isValid(scope) && isValid(functionName, true)) {
            var parenthesisStartPosition = functionName.indexOf("(");
            if (parenthesisStartPosition > -1) {
                var objectName = functionName.substring(0, parenthesisStartPosition);
                if (isValid(objectName, true)) {
                    var object = getObjectInScope(scope, objectName, true);
                    if (isValid(object)) {
                        return scope.$eval(functionName);
                    } else if (isValid(scope.$parent)) {
                        return executeFunctionWithReturnThroughAngularScope(scope.$parent, functionName);
                    }
                }
            }
        }
    };

    //#endregion

    //#region Type Conversions
/**
 * @ngdoc method
 * @name getLabelValueArrayFromObject
 * @methodOf efLibrary
 * @description 
 * 
 * This method returns an array of label/value objects from the supplied data object.  Each property of the supplied data object, as well as, its value will be converted to an entry in the label/value object array.
 * 
 * @param {object} data The object that will be converted into a label/value array object.
 * @returns {Array} Array of label/value objects.
**/
    export function getLabelValueArrayFromObject(data: any) {
        var returnValue = [];
        if (data !== undefined && data !== null) {
            for (let property in data) {
                if (data.hasOwnProperty(property) && property.indexOf('$') === -1) {
                    returnValue.push({
                        "label": data[property],
                        "value": property
                    });
                }
            }
        }
        return returnValue;
    }

    //#endregion

    //#region Miscellaneous functions

    function guidGenerator() {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    };

/**
 * @ngdoc method
 * @name newGuid
 * @methodOf efLibrary
 * @description 
 * 
 * This method generates and returns a GUID.
 * 
 * @returns {GUID} GUID as a string.
**/
    export function newGuid(): string {
        return (guidGenerator() + guidGenerator() + "-" + guidGenerator() + "-4" + guidGenerator().substr(0, 3) + "-" + guidGenerator() + "-" + guidGenerator() + guidGenerator() + guidGenerator()).toLowerCase();
    }
    //#endregion

    //#region Deprecated functions
/**
 * @ngdoc method
 * @name simulateDatatableTabKeyPress
 * @methodOf efLibrary
 * @deprecated 
 * @description 
 * 
 * <span style="color: red">DEPRECATED!  </span>This method, when called from a control/code executing within a Datatable-based grid, will simulate the tab key being pressed.
 *
 */
    export function simulateDatatableTabKeyPress() {
        var cell = $('div.DTE').parent();
        if (cell) {
            if (cell.next().length) {
                // One cell to the right
                cell.next().click();
            } else {
                // Down to the next row
                cell.parent().next().children().eq(1).click();
            }
        }
    }

    //#endregion

}
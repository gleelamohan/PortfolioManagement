var bptLibrary;
(function (bptLibrary) {
    function isValid(val, checkForLength) {
        if (checkForLength === void 0) { checkForLength = false; }
        return val === false ? true : (checkForLength ? ((!!val) && val.length > 0) : (!!val));
    }
    bptLibrary.isValid = isValid;
    function isEqual(val1, val2) {
        return (isValid(val1) || isValid(val2)) ? ((isValid(val1) ? JSON.stringify(val1) : null) === (isValid(val2) ? JSON.stringify(val2) : null)) : ((val1 !== undefined && val2 !== undefined) ? (val1 === val2) : false);
    }
    bptLibrary.isEqual = isEqual;
    function toBoolean(val, defaultValue) {
        if (defaultValue === void 0) { defaultValue = null; }
        var returnValue = (!!defaultValue) ? toBoolean(defaultValue) : null;
        if (isValid(val)) {
            if ((isNaN(val) && (val.toLowerCase() === "true" || val.toLowerCase() === "yes")) || (!isNaN(val) && Number(val) === 1)) {
                returnValue = true;
            }
            else if ((isNaN(val) && (val.toLowerCase() === "false" || val.toLowerCase() === "no")) || (!isNaN(val) && Number(val) === 0)) {
                returnValue = false;
            }
        }
        return returnValue;
    }
    bptLibrary.toBoolean = toBoolean;
    function copyObject(obj) {
        return isValid(obj) ? JSON.parse(JSON.stringify(obj)) : null;
    }
    bptLibrary.copyObject = copyObject;
    function setModelObjectByName(scope, variableName, value) {
        var levels = variableName.split(".");
        var model = scope;
        var i = 0;
        while (i < levels.length - 1) {
            if (typeof model[levels[i]] === 'undefined') {
                model[levels[i]] = {};
            }
            model = model[levels[i]];
            i++;
        }
        model[levels[levels.length - 1]] = value;
    }
    bptLibrary.setModelObjectByName = setModelObjectByName;
    function getAllObjectsById(idField, id, objectArray) {
        var returnValue = [];
        if (isValid(idField, true) && id !== undefined && isValid(objectArray, true)) {
            for (var i = 0; i < objectArray.length; i++) {
                if (isValid(objectArray[i]) && objectArray[i][idField] === id) {
                    returnValue.push(objectArray[i]);
                }
            }
        }
        return returnValue.length > 0 ? returnValue : null;
    }
    bptLibrary.getAllObjectsById = getAllObjectsById;
    function getFirstObjectById(idField, id, objectArray) {
        var returnValue = null;
        var foundValues = getAllObjectsById(idField, id, objectArray);
        if (isValid(foundValues, true)) {
            returnValue = foundValues[0];
        }
        return returnValue;
    }
    bptLibrary.getFirstObjectById = getFirstObjectById;
    function getAllValuesById(idField, id, valueField, objectArray) {
        var returnValue = [];
        if (isValid(idField, true) && id !== undefined && isValid(valueField, true) && isValid(objectArray, true)) {
            for (var i = 0; i < objectArray.length; i++) {
                if (isValid(objectArray[i]) && objectArray[i][idField] === id) {
                    returnValue.push(objectArray[i][valueField]);
                }
            }
        }
        return returnValue.length > 0 ? returnValue : null;
    }
    bptLibrary.getAllValuesById = getAllValuesById;
    function getFirstValueById(idField, id, valueField, objectArray) {
        var returnValue = null;
        var foundValues = getAllValuesById(idField, id, valueField, objectArray);
        if (isValid(foundValues, true)) {
            returnValue = foundValues[0];
        }
        return returnValue;
    }
    bptLibrary.getFirstValueById = getFirstValueById;
    function getObjectInScope(scope, objectName) {
        var returnValue = null;
        if (isValid(scope) && isValid(objectName, true)) {
            var levels = objectName.split(".");
            var model = scope;
            var i = 0;
            while (i < levels.length - 1) {
                if (typeof model[levels[i]] !== 'undefined') {
                    model = model[levels[i]];
                }
                else {
                    break;
                }
                i++;
            }
            returnValue = copyObject(model[levels[levels.length - 1]]);
        }
        return returnValue;
    }
    bptLibrary.getObjectInScope = getObjectInScope;
    function getObjectThroughAngularScope(scope, objectName) {
        var returnValue = null;
        if (isValid(scope) && isValid(objectName, true)) {
            var object = getObjectInScope(scope, objectName);
            if (isValid(object)) {
                returnValue = copyObject(object);
            }
            else if (isValid(scope.$parent)) {
                returnValue = getObjectThroughAngularScope(scope.$parent, objectName);
            }
        }
        return returnValue;
    }
    bptLibrary.getObjectThroughAngularScope = getObjectThroughAngularScope;
})(bptLibrary || (bptLibrary = {}));
//# sourceMappingURL=bptLibrary.js.map
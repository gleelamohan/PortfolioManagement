(function () {
    angular
        .module('app')
        .directive('breadcrumb', breadcrumb);

    breadcrumb.$inject = ['navigationGate'];

    function breadcrumb(navigationGate) {
        breadcrumbController.$inject = ['$scope', '$state'];

        return {
            restrict: 'E',
            replace: false,
            templateUrl: "/app/components/breadcrumb/breadcrumb.html",
            //template:'<h1>hello bread cum</h1>',
            controller: breadcrumbController,
            controllerAs: 'vm',
            scope: true
        };

        function breadcrumbController($scope, $state) {
            var vm = this;
            //console.log($state.$current);
            vm.breadcrumbs = [];
            navigationGate.getData().then(function (menu) {
                vm.updateBreadcrumb = function () {
                    vm.breadcrumbs = [];

                    var current = $state.$current,                  

                        temp = [];
                    //console.log(current);
                    while (current) {
                        temp.push(new crumb(getCrumbTitle(current.self.name, menu) || "Home", current.self.abstract ? "" : current.url.sourcePath, current === $state.$current));
                        current = current.parent;
                    }
                    while (temp.length > 0) {
                        vm.breadcrumbs.push(temp.pop());
                    }
                };
                vm.updateBreadcrumb();
                $scope.$on("$stateChangeSuccess", vm.updateBreadcrumb);
            });
        }

        function crumb(name, link, isActive) {
            return {
                name: name,
                link: link,
                isActive: isActive
            };
        }

        function getCrumbTitle(crumbState, navNode) {
            //console.log(crumbState);
            //console.log(navNode);

            if (crumbState === navNode.Sref) {
                return navNode.TranslationLabel;
            }
            if (!navNode.Children) {
                return null;
            }
            //console.log('123');
            var result;
            navNode.Children.forEach(function(n) {
                var tmp = getCrumbTitle(crumbState, n);
                if (tmp) {
                    result = tmp;
                    return;
                }
            });
            
            return result;
        }
    }
})();
﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc filter
 * @name efAngularLibrary.efLabelValuePanel.filter:eflabelvaluepanel
 * @requires efAngularLibrary.efLabelValuePanel.filterScope
 * @description 
 * 
 * eflabelvaluepanel is an Angular filter that displays one-to-many label/values entries, each bound within a Bootstrap row with separately styled div columns for each of the label and value entries.
 * 
 * <a href="/app/#/demo/efLabelValuePanel/demo">For complete implmentation details see the demo page.</a>
 * 
 * Example:
 * <pre>
 * <div ng-bind-html="vm.filterScope | eflabelvaluepanel"></div>
 * </pre>
 * 
 * @param {object|efAngularLibrary.efLabelValuePanel.filterScope} filterScope Valid object containing the filter's column styles, as well as the label/value data to render.
 * @returns {string|HTML} Label/Value panel's HTML.
**/
(function () {
    angular
        .module('efAngularLibrary.efLabelValuePanel')
        .filter('eflabelvaluepanel', efLabelValuePanel);

    efLabelValuePanel.$inject = ['$sce', '$filter'];

    function efLabelValuePanel($sce, $filter) {
        return function (filterScope) {
            var html = "";
            if ((filterScope !== undefined) && (filterScope !== null)) {
                if ((filterScope.data !== undefined) && (filterScope.data !== null)) {
                    for (var row in filterScope.data) {
                        html += "<div class=\"row\">" +
                            "<label class=\"" +
                            (((filterScope.labelClass !== undefined) && (filterScope.labelClass !== null)) ? filterScope.labelClass : "") +
                            " control-label\">" +
                            (((filterScope.data[row].label !== undefined) && (filterScope.data[row].label !== null) && (filterScope.data[row].label.length > 0)) ? filterScope.data[row].label : "&nbsp;") +
                            "</label>" +
                            "<div class=\"" +
                            (((filterScope.valueClass !== undefined) && (filterScope.valueClass !== null)) ? filterScope.valueClass : "") +
                            "\">" +
                            "<span>" + (((filterScope.data[row].value !== undefined) && (filterScope.data[row].value !== null) && (filterScope.data[row].value.length > 0)) ? filterScope.data[row].value : "&nbsp;") + "</span>" +
                            "</div></div>";
                    }
                }
            }
            return $sce.trustAsHtml(html);
        };
    }
})();
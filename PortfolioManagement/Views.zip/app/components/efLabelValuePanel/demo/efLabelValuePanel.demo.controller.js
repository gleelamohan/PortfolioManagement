﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efLabelValuePanel')
        .controller('EfLabelValuePanelDemoCtrl', EfLabelValuePanelDemoCtrl);

    EfLabelValuePanelDemoCtrl.$inject = ['$scope', '$state', '$sanitize', '$parse', '$filter', '$timeout', 'efLabelValuePanelDemoApi'];

    function EfLabelValuePanelDemoCtrl($scope, $state, $sanitize, $parse, $filter, $timeout, efLabelValuePanelDemoApi) {
        var vm = this;

        var courierTypes = efLabelValuePanelDemoApi.courierTypes;
        var data = [];
        for (var i = 0; i < courierTypes.length; i++) {
            var dataItem = {
                "label": courierTypes[i].Value,
                "value": courierTypes[i].CourierTypeId
            };
            data.push(dataItem);
        }
        vm.filterScope = {
            "labelClass": "col-sm-4",
            "valueClass": "col-sm-8",
            "data": data
        };
    };
})();

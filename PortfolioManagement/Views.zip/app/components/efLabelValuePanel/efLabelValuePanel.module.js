﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc overview
 * @name efAngularLibrary.efLabelValuePanel
 * @description 
 * 
 * efLabelValuePanel module provides an Angular filter that displays one-to-many label/values entries, each bound within a Bootstrap row with separately styled div columns for each of the label and value entries.
 * 
 * <a href="/app/#/demo/efLabelValuePanel/demo">For complete implmentation details see the demo page.</a>
**/
(function () {
    angular.module('efAngularLibrary.efLabelValuePanel', []);
})();
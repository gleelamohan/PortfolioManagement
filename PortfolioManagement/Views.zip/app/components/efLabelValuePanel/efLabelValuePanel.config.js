﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efLabelValuePanel')
        .config(config);

    config.$inject = ['$stateProvider'];

    function config($stateProvider) {
        $stateProvider
            .state('efAngularLibrary.efLabelValuePanel', {
                abstract: true,
                url: "/efLabelValuePanel",
                template: "<ui-view />"
            })
            .state('efAngularLibrary.efLabelValuePanel.demo', {
                url: "/demo",
                templateUrl: "/app/components/efLabelValuePanel/demo/efLabelValuePanel.demo.html",
                controller: "EfLabelValuePanelDemoCtrl",
                controllerAs: "vm"
            });
    };
})();
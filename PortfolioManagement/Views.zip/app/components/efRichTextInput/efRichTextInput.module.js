﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc overview
 * @name efAngularLibrary.efRichTextInput
 * @description 
 * 
 * efRichTextInput module provides an Angular directive input control for opening the efRichTextEditor and displaying rich text models.
 * 
**/
(function () {
    angular.module('efAngularLibrary.efRichTextInput', []);
})();
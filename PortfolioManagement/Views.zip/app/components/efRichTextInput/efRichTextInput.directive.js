﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.


/**
 * @ngdoc directive
 * @name efAngularLibrary.efRichTextInput.directive:efRichTextInput
 * @scope
 * @restrict AEC
 * @requires efAngularLibrary.efRichTextInput.efRichTextInputConfig
 * @requires efAngularLibrary.efRichTextEditor.controller:efRichTextEditorCtrl
 * @requires efAngularLibrary.efRichTextEditor.directive:efRichTextEditor
 * @requires efAngularLibrary.efFocus.directive:efFocus 
 * @requires efLibrary
 * @requires recursionHelper
 * @requires toastr
 * @description 
 * 
 * efRichTextInput is an Angular directive input control for opening the efRichTextEditor and displaying entered rich text models.  
 * 
 * @param {object|string} ngModel The Angular model for the control.
 * @param {expression|method=} ngChange The method to execute when the model has been changed.
 * @param {expression|boolean=} ngDisabled Flag to enable/disable the field.  If not provided, then the control is enabled.
 * @param {object=} config JSON Object with configuration options.  See {@link efAngularLibrary.efRichTextInput.efRichTextInputConfig efRichTextInputConfig} for complete details.
 * @param {string=} getConfig A string-based name for the 'config' object to use.  When 'config' is not provided, the directive will search through the Angular scope hierarchy for the value provided here.  When it is found, it will be used as the directive's 'config'.  When 'config' is provided, this is ignored.
 * @param {string=} width The HTML valid width for the control.  Default is 'auto'.
 * @param {boolean=} setFocus Flag that tells the control it should set focus to itself.
 * @param {boolean=} inGrid Flag that tells the control if it is being rendered within a grid.  This parameter should not be set by the developer, but rather let the grid/parent control determine its value.
**/
(function () {
    angular
        .module('efAngularLibrary.efRichTextInput')
        .directive('efRichTextInput', efRichTextInput);

    efRichTextInput.$inject = ['$sce', '$filter', '$translate', '$modal', '$timeout', '$injector', 'recursionHelper', 'toastr', 'efLibrary'];

    function efRichTextInput($sce, $filter, $translate, $modal, $timeout, $injector, recursionHelper, toastr, efLibrary) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                ngModel: "=",
                ngChange: "&",
                ngDisabled: "=?",
                config: "=?",
                getConfig: "@?",
                width: "@?",
                setFocus: "@?",
                inGrid: "@?"
            },
            controller: function ($scope) {
                var vm = this;
                $scope.grid = {};   //Added to support UI.grid

                vm.templateUrl = "/app/components/efRichTextInput/efRichTextInput.html";
                vm.currentLanguage = $translate.use();
                vm.changeCallbackTimeout = 100;

                vm.inputModel = "";
                if ($scope.ngModel !== undefined && $scope.ngModel !== null && $scope.ngModel.length > 0) {
                    vm.inputModel = String($scope.ngModel).replace(/<[^>]+>/gm, '');
                }

                //#region modelChanged function/event
                function modelChanged() {
                    $timeout(function () {
                        vm.changeCallback();
                    }, vm.changeCallbackTimeout);
                    if (vm.inGrid) {
                        $timeout(function () {
                            efLibrary.simulateDatatableTabKeyPress();
                        }, vm.changeCallbackTimeout);
                    }
                }
                //#endregion

                //#region Directive Setup

                function handleDisabledUpdates(newValue) {
                    vm.disabled = newValue !== undefined && newValue !== null ? newValue : null;
                }
                $scope.$watch('ngDisabled', handleDisabledUpdates, true);


                function handleModelUpdates(newModel) {
                    vm.model = newModel !== undefined && newModel !== null ? JSON.parse(JSON.stringify(newModel)) : null;
                }
                $scope.$watch('ngModel', handleModelUpdates, true);


                vm.updateModel = function () {
                    $scope.ngModel = vm.inputModel;
                    vm.inputModel = String(vm.inputModel).replace(/<[^>]+>/gm, '');

                    $timeout(function () {
                        vm.changeCallback();
                    }, vm.changeCallbackTimeout);

                }

                function updateDirectiveModel(model, data) {
                    modelChanged();
                    $scope.ngModel = data.htmlRichText;
                    vm.inputModel = String(data.htmlRichText).replace(/<[^>]+>/gm, '');

                    return true;
                }

                function handleChangeCallbackUpdates(newChangeCallback) {
                    vm.changeCallback = newChangeCallback !== undefined && newChangeCallback !== null ? newChangeCallback : function () { };
                }
                $scope.$watch('ngChange', handleChangeCallbackUpdates, true);

                function handleConfigUpdates(newConfig) {
                    var config = efLibrary.isValid(newConfig) ? newConfig : (efLibrary.isValid($scope.getConfig, true) ? eval($scope.getConfig) : null);
                    vm.config = config !== undefined && config !== null ? config : {};
                    vm.placeholder = vm.config !== undefined && vm.config !== null && vm.config.placeholder !== undefined && vm.config.placeholder !== null && vm.config.placeholder.length > 0 ? (String($filter("trustedtranslate")(vm.config.placeholder))) : "";

                    //vm.inGrid is set from HTML attribute
                    vm.inGrid = efLibrary.toBoolean($scope.inGrid, false);

                    //vm.width is set from HTML attribute first, then the config
                    vm.width = $scope.width !== undefined && $scope.width !== null ? $scope.width : (vm.config !== undefined && vm.config !== null && vm.config.width !== undefined && vm.config.width !== null ? vm.config.width : "");
                    vm.widthStyle = vm.width !== undefined && vm.width !== null && vm.width.length > 0 ? JSON.parse("{\"width\": \"" + vm.width + "\"}") : "";

                    //vm.maxLength is set from config
                    vm.maxLength = !!vm.config && !!vm.config.textMaxLength ? vm.config.textMaxLength : "";

                }
                handleConfigUpdates($scope.config);
                $scope.$watch('config', handleConfigUpdates, true);

                vm.textboxModelOptions = { updateOn: 'default' };


                if (efLibrary.toBoolean($scope.inGrid, false)) {
                    //    vm.textboxModelOptions = { updateOn: 'default blur', debounce: { 'default': 0, 'blur': 0 } };
                    vm.textboxModelOptions = { updateOn: 'blur' };
                }

                vm.inputHasFocus = false;
                vm.setInputHasFocus = function () {
                    if (vm.enableTextInput) {
                        vm.inputHasFocus = true;
                    }
                }

                vm.retrievingData = false;

                if (efLibrary.toBoolean($scope.setFocus, false)) {
                    vm.setInputHasFocus();
                }

                //#endregion


                //#Rich Editor Popup open
                vm.actionClick = function (inputText) {

                    var modalScope = {
                        "htmlText": inputText || "",
                        "maxLength": vm.maxLength
                    };

                    var modalInstance = $modal.open({
                        size: 'lg',
                        template: '<div class="modal-body"><ef-rich-text-editor inputscope="vm.inputScope" appcallback="vm.appCallback"></ef-rich-text-editor></div>',
                        controller: 'efRichTextEditorCtrl as vm',
                        windowClass: "efRichTextEditorModalWindow",
                        scope: function () {
                            var scope = $scope.$new();
                            scope.inputScope = modalScope;
                            return scope;
                        }()
                    });

                    modalInstance.result.then(function (modalReturnScope) {
                        if (modalReturnScope !== undefined && modalReturnScope !== null) {
                            vm.setInputHasFocus();
                            updateDirectiveModel(modalReturnScope, modalReturnScope);
                        }

                    }, function () {
                    });
                }
                //#endregion
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        };
    }
})();


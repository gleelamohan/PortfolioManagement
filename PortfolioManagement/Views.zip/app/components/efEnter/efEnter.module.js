﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc overview
 * @name efAngularLibrary.efEnter
 * @description 
 * 
 * efEnter module provides an Angular directive that allows a user input focused HTML tag to execute an expression/method when the enter key is pressed.
 * 
**/
(function () {
    angular.module('efAngularLibrary.efEnter', []);
})();
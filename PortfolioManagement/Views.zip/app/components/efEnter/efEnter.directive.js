﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc directive
 * @name efAngularLibrary.efEnter.directive:efEnter
 * @scope
 * @restrict AC
 * @description 
 * 
 * efEnter is an Angular directive that allows a user input focused HTML tag to execute a method when the enter key is pressed.
 * 
 * Example:
 * <pre>
 * <input type="text" ef-enter="vm.MyFunction('MyFunctionInputValue')">
 * </pre>
 * 
 * @param {method|string} efEnter The string-based representation of the method (inlcuding input parameters), that will be executed when the HTML tag has focus and the enter key is pressed.
**/
(function () {
    angular
        .module('efAngularLibrary.efEnter')
        .directive('efEnter', efEnter);

    function efEnter() {
        return {
            restrict: 'AC',
            link: function (scope, element, attrs) {
                element.bind("keydown keypress", function (event) {
                    if (event.which === 13) {
                        scope.$apply(function () {
                            scope.$eval(attrs.efEnter);
                        });

                        event.preventDefault();
                    }
                });
            }
        };
    }
})();
// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
 function globalSearchEntry($sce, $filter, recursionHelper) {
     return {
         restrict: 'AEC',
         replace: true,
         scope: {
             isModal: "=ismodal",
             refreshresults: "=refreshresults",
             templateUrl: '=templateurl',
             optionsTemplateUrl: '=optionstemplateurl',
             getResultsCallback: '=getresultscallback',
             config: '=config',
             appCallback: '=appcallback', //used for modal
             addCallback: "=addcallback",
             panelTitle: '=paneltitle',
             infoVisible: "=infovisible",
             infoText: "=infotext",
             infoClass: "=infoclass",
             addNewText: "=addnewtext",
             addNew: "=addnew"
         },
         controller: function ($scope) {
                var vm = this;
                vm.isModal = (($scope.isModal === undefined) || ($scope.isModal === null) ? false : (($scope.isModal === true) || ($scope.isModal === "true") ? true : false));
                vm.templateUrl = $scope.templateUrl;
                vm.panelTitle = $scope.panelTitle;
                vm.searchEntryConfig = $scope.config;
                vm.appCallback = $scope.appCallback,
                vm.displaySearchTermLabel = vm.searchEntryConfig.displaySearchTermLabel || false;
                vm.defaultSearchTermLabel = vm.searchEntryConfig.defaultSearchTermLabel || "";
                vm.searchTerm = vm.searchEntryConfig.defaultSearchTerm || "";
                vm.searchTermPlaceholder = vm.searchEntryConfig.defaultSearchTermPlaceholder || "";
                vm.searchTermMinLength = vm.searchEntryConfig.searchTermMinLength || 0;
                vm.searchTermMaxLength = vm.searchEntryConfig.searchTermMaxLength || 524288;    //524288 is the HTML5 max length for a input tag
                vm.searchScope = vm.searchEntryConfig.defaultSearchScope || {};
               
                //Advance search
                vm.includeSearchEntryOptions = vm.searchEntryConfig.includeSearchEntryOptions || false;
                vm.enableSearchEntryOptionsToggle = vm.searchEntryConfig.enableSearchEntryOptionsToggle || false;
                vm.searchEntryOptionsTitle = vm.searchEntryConfig.defaultSearchEntryOptionsTitle || "";
                vm.optionsTemplateUrl = vm.searchEntryConfig.searchEntryOptionsTemplateUrl;

                //extended Advance search
                vm.loadDefaultSearchResult = vm.searchEntryConfig.loadDefaultSearchResult || false;
                vm.searchScopeConfig = vm.searchEntryConfig.SearchEntryOptionsConfig || {};
                vm.loadConfigApi = vm.includeSearchEntryOptions && (vm.searchScopeConfig.ConfigServices !== undefined && vm.searchScopeConfig.ConfigServices.length > 0);

                vm.searchEntryOptionsVisible = !vm.enableSearchEntryOptionsToggle;
                vm.helpText = vm.searchEntryConfig.helpText || "";
                vm.addCallback = $scope.addCallback;
                vm.addNewText = $scope.addNewText;
                vm.addNew = $scope.addNew;

                vm.iboxToolsShowHideVisible = true;
                vm.iboxToolsInfoVisible = false;
                vm.iboxToolsInfoToggledExternally = false;
                vm.iboxToolsFilterVisible = false;
                vm.iboxToolsSettingsVisible = false;
                vm.iboxToolsHelpVisible = true;
                vm.iboxToolsShowHideVisible = true;
                vm.iboxToolsCloseVisible = vm.isModal;
                vm.getResultsCallback = $scope.getResultsCallback;

                //#region functions

                function handleInfoVisibleUpdates(newData) {
                    vm.toggleInfoVisibility(newData || false);
                };

                function handleInfoTextUpdates(newData) {
                    vm.infoText = newData || "";
                };

                function handleInfoClassUpdates(newData) {
                    vm.infoClass = newData || "alert alert-info";
                };


                //#endregion

                vm.toggleInfoVisibility = function (visible) {
                    vm.infoVisible = visible || false;
                    vm.iboxToolsInfoVisible = vm.infoVisible;
                    vm.iboxToolsInfoToggledExternally = vm.infoVisible;
                }


                vm.toggleHelpVisibility = function (visible) {
                    vm.helpVisible = visible || false;
                    vm.iboxToolsHelpToggledExternally = vm.helpVisible;
                }




                vm.resetInfo = function () {
                    vm.infoText = "";
                    vm.infoClass = "alert alert-info";
                    vm.toggleInfoVisibility(false);
                }
             
                vm.iboxToolsToggleInfo = function () {
                    vm.infoVisible = !vm.infoVisible;
                };

                vm.iboxToolsToggleHelp = function () {
                    vm.helpVisible = !vm.helpVisible;
                };

                vm.iboxToolsToggleClose = function () {
                    vm.appCallback("close", {});
                };


                vm.toggleSearchEntryOptions = function () {
                    vm.searchEntryOptionsVisible = !vm.searchEntryOptionsVisible;
                }

                vm.searchScopeCallback = function (searchScope, searchTermPlaceholder) {
                    if (searchScope) {
                        vm.searchScope = searchScope;
                    } else {
                        vm.searchScope = {};
                    }
                    if (searchTermPlaceholder) {
                        vm.searchTermPlaceholder = String($filter('trustedtranslate')(searchTermPlaceholder));;
                        vm.defaultSearchTermLabel = searchTermPlaceholder;
                        

                    }
                }
                                
                $scope.refreshresults = function () {
                    vm.getResultsCallback(vm.searchTerm, vm.searchScope);
                }

                if (vm.loadDefaultSearchResult) {
                    vm.getResultsCallback(vm.searchTerm, vm.searchScope);
                }

                $scope.$watch('infoVisible', handleInfoVisibleUpdates, true);
                $scope.$watch('infoText', handleInfoTextUpdates, true);
                $scope.$watch('infoClass', handleInfoClassUpdates, true);
                vm.toggleHelpVisibility(vm.searchEntryConfig.autoDisplayHelpText || false);


            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        }
    };

    angular.module('app.globalSearch')
        .directive('globalSearchEntry', globalSearchEntry);
    globalSearchEntry.$inject = ['$sce', '$filter', 'recursionHelper'];

})();

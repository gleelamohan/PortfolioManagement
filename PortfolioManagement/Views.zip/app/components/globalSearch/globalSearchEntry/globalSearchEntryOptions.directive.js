
(function () {
    angular
        .module('app.globalSearch')
        .directive('globalSearchEntryOptions', globalSearchEntryOptions);

    globalSearchEntryOptions.$inject = ['$sce', 'recursionHelper'];

    function globalSearchEntryOptions($sce, recursionHelper) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                appCallback: "=appcallback",
                templateUrl: "=templateurl",
                searchScope: "=searchscope",
                loadConfigApi : "=loadconfigapi",
                searchScopeConfig: "=searchscopeconfig",
                searchScopeCallback: "=searchscopecallback"
            },
            controller: function ($scope, $element, $attrs, $transclude) {
                var vm = this;
                vm.appCallback = $scope.appCallback;
                vm.templateUrl = $scope.templateUrl;
                vm.searchScope = $scope.searchScope;
                vm.searchScopeConfig = $scope.searchScopeConfig;
                vm.searchScopeCallback = $scope.searchScopeCallback;
                vm.IsVisible = false;

                // More search options inside of serach entry options template
                if (vm.searchScope) {
                    vm.enableSearchEntryOptionsToggle = vm.searchScope.enableSearchEntryOptionsToggle || false;
                    vm.searchEntryOptionsVisible = !vm.searchScope.enableSearchEntryOptionsToggle;
                    vm.searchEntryOptionsTitle = vm.searchScope.defaultSearchEntryOptionsTitle || "";
                }

             

                function loadConfigServices() {
                    for (var index = 0; index < vm.searchScopeConfig.ConfigServices.length; index++) {
                        vm.searchScopeConfig.ConfigServices[index].query(null).then(function (response) {
                            vm.searchScopeConfig.ConfigServiceResults[0] = response.results;
                        });
                    }
                }

                vm.toggleSearchEntryOptions = function () {
                    vm.searchEntryOptionsVisible = !vm.searchEntryOptionsVisible;

                    vm.IsVisible = vm.IsVisible ? false : true;
                }

                //vm.searchScope.LoadCourierData();
                if ($scope.loadConfigApi) {
                    loadConfigServices();
                    $scope.loadConfigApi = false;
                }

                //function handleScopeDataUpdates(newData) {

                //    vm.searchScope = newData;
                //}
                //$scope.$watch('$scope.searchScope', handleScopeDataUpdates, true);


            },
            controllerAs: "vm",
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        }
    };
})();

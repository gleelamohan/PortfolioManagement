angular
    .module('app.globalSearch', []);
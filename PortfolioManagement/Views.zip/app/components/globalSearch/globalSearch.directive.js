(function() {
    function globalSearch($sce, $filter, $translate, recursionHelper) {
        return {
            restrict: 'AEC',
            replace: false,
            scope: {
                isModal: "@ismodal",
                inputScope: "=inputscope",
                searchService: "=searchservice",
                refreshGrid: "=refreshgrid"
            },
            controller: function ($scope) {

                var vm = this;
                vm.isModal = (($scope.isModal === undefined) || ($scope.isModal === null) ? false : (($scope.isModal === true) || ($scope.isModal === "true") ? true : false));
                vm.inputScope = $scope.inputScope || { "defaultSearchTerm": "" };
                vm.searchService = $scope.searchService;
                vm.searchResults = [];
                $scope.refreshGrid = function () { };

                //#region functions

                function resetInfo() {
                    vm.infoText = "";
                    vm.infoClass = "alert alert-danger";
                    vm.infoVisible = false;
                };

                function getSearchConfig() {
                    vm.globalSearchConfig = null;
                    vm.globalSearchGridConfig = null;
                    if (vm.searchService !== undefined || vm.searchService != null) {
                        vm.globalSearchConfig = vm.searchService.globalSearchConfig();
                        vm.globalSearchGridConfig = vm.searchService.globalSearchGridConfig();
                    }

                    if (vm.globalSearchConfig !== null && vm.globalSearchGridConfig !== null) {
                        vm.templateUrl = "/app/components/globalSearch/globalSearch.html";
                        vm.searchEntryTemplateUrl = "/app/components/globalSearch/globalSearchEntry/globalSearchEntry.html";
                        vm.searchResultsTemplateUrl = "/app/components/globalSearch/globalSearchResult/globalSearchResult.html";
                        vm.searchResultsSettingsTemplateUrl = "/app/components/globalSearch/globalSearchSettings/globalSearchSettings.html";
                        vm.searchEntryConfig = vm.globalSearchConfig.searchEntryConfig;
                        vm.pagetitle = vm.globalSearchConfig.templateConfig.pageTitle;
                        vm.searchEntryPanelTitle = vm.globalSearchConfig.searchEntryConfig.searchEntryPanelTitle;
                        vm.searchEntryOptionsTemplateUrl = vm.globalSearchConfig.templateConfig.searchEntryOptionsTemplateUrl;
                        vm.addNewText = vm.globalSearchConfig.templateConfig.addNewText;
                        vm.searchEntryOptionsVisible = !vm.globalSearchConfig.searchEntryConfig.includeSearchEntryOptions;
                        if (vm.addNewText === undefined || vm.addNewText === null || vm.addNewText.length === 0) {
                            vm.addNew = false;
                        } else {
                            vm.addNew = true;
                        }
                    }
                };

                function setResults(results) {
                    vm.searchResults = results;
                    $scope.refreshGrid = vm.refreshResults;
                    if (vm.searchResults.length === 0) {
                        vm.infoText = String($filter("trustedtranslate")(vm.globalSearchConfig.templateConfig.searchResultsNoResultsText));
                        vm.infoVisible = true;
                    }
                }

                //#endregion

                vm.getSearchResults = function(searchTerm, searchScope) {

                    if (vm.inputScope.defaultSearchScope !== null && vm.inputScope.defaultSearchScope !== undefined) {
                        for (var attr in vm.inputScope.defaultSearchScope) {
                            if (vm.inputScope.defaultSearchScope.hasOwnProperty(attr)) {
                                if (!searchScope[attr]) {
                                    searchScope[attr] = vm.inputScope.defaultSearchScope[attr];
                                }
                            }
                        }
                    }
                    vm.searchService.query({ searchTerm: searchTerm, searchScope: searchScope }).then(function (response) {
                        if (response.data !== undefined)
                            setResults(response.data);
                        else {
                            setResults(response.results);
                        }
                    }).catch(function (error) {
                        console.log(error);
                        var results = [];
                        setResults(results);
                    });
                    resetInfo();
                };

                getSearchConfig();
                resetInfo();

            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function(element) {
                return recursionHelper.compile(element);
            }
        };
    }
    angular.module('app.globalSearch')
        .directive('globalSearch', globalSearch);
    globalSearch.$inject = ['$sce', '$filter', '$translate', 'recursionHelper'];
})();
// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    function globalSearchResults($sce, $timeout, recursionHelper, $translate, $filter, uiGridExporterConstants, toastr) {
		return {
			restrict: 'AEC',
			replace: true,
			scope: {
				isModal: "=ismodal",
				templateUrl: "=templateurl",
				settingsTemplateUrl: "=settingstemplateurl",
				config: "=config",
                templateConfig: "=templateconfig",
                results: "=results",
                addNew: "=addnew"
			},
			controller: function ($scope) {
			    var vm = this;
			    var featureNotImplemented = String($filter('trustedtranslate')("Common.FeatureNotImplmented"));
				vm.isModal = (($scope.isModal === undefined) || ($scope.isModal === null) ? false : (($scope.isModal === true) || ($scope.isModal === "true") ? true : false));
				vm.templateUrl = $scope.templateUrl;
				vm.settingsTemplateUrl = $scope.settingsTemplateUrl;
				vm.templateConfig = $scope.templateConfig;
			    vm.addNew = $scope.addNew;
				vm.iboxToolsShowHideVisible = true;
				vm.iboxToolsFilterVisible = true;
				vm.iboxToolsSettingsVisible = true;
				vm.iboxToolsHelpVisible = true;
				vm.filterVisible = false;
				vm.settingsVisible = false;
				vm.helpVisible = false;
				vm.searchUiGridconfig = null;
				vm.gridApi = null;
				vm.uiGridOptions = null;

			    //#region local functions

				function updateFilterVisibility() {
				    $(".ui-grid-filter-input").css("display", vm.filterVisible ? "" : "none");
				}

				function handleConfigUpdates(newData) {
				    var data = newData || null;
				    if (data) {
				        vm.searchResultsConfig = data;
				        if (vm.searchResultsConfig.helpText === undefined || vm.searchResultsConfig.helpText === null) {
				            vm.bindUiGrid = true; //remove this line once ui grid refactor done.
				            vm.uiGridOptions = vm.searchResultsConfig;
				            $timeout(updateFilterVisibility, 100);

				        } else {
				            vm.filterVisible = (vm.searchResultsConfig.filterVisible === undefined || vm.searchResultsConfig.filterVisible === null || vm.searchResultsConfig.filterVisible === "") ? false : ((vm.searchResultsConfig.filterVisible === true) || (vm.searchResultsConfig.filterVisible === "true") ? true : false);
				            vm.rowSelect = ((vm.searchResultsConfig.rowSelect === undefined) || (vm.searchResultsConfig.rowSelect === null) ? false : ((vm.searchResultsConfig.rowSelect === true) || (vm.searchResultsConfig.rowSelect === "true") ? true : false));
				            vm.helpText = vm.searchResultsConfig.helpText || "";
				            vm.viewType = vm.searchResultsConfig.viewType;
				            vm.pageLength = vm.searchResultsConfig.datatableConfig.pageLength;
				            vm.pageLengthOptions = vm.searchResultsConfig.pageLengthOptions;
				            //TODO columnVisibilityOptions processing has not been implemented at this time
				            vm.columnVisibilityOptions = vm.searchResultsConfig.datatableConfig.columnDefs;
				        }
				    }
				};

				function handleResultsUpdates(newData) {
				    var data = newData || null;
				    if (data) {
				        vm.searchResults = data;
				    }
				};

				function handleTemplateConfigUpdates(newData) {
				    var templateConfig = newData || null;
				    if (templateConfig) {
				        vm.panelTitle = templateConfig.searchResultPanelTitle;
				        vm.addNewText = templateConfig.addNewText;
				        vm.helpText = templateConfig.searchResultsHelpText;
				    }
				};
                
			    //#endregion

				vm.iboxToolsToggleSettings = function () {
				    vm.settingsVisible = !vm.settingsVisible;
				};

				vm.iboxToolsToggleHelp = function () {
				    vm.helpVisible = !vm.helpVisible;
				};

				vm.iboxToolsToggleFilter = function () {
				    vm.filterVisible = !vm.filterVisible;
				    if (vm.gridApi !== undefined && vm.gridApi !== null) {
				        vm.gridApi.core.clearAllFilters();
				    }
				    updateFilterVisibility();
				};

				vm.PrintCallback=function() {
				    toastr.info(featureNotImplemented);
			    }

			    vm.exportPdfCallback=function() {
			        var myElement = angular.element(document.querySelectorAll(".custom-csv-link-location"));
			        vm.gridApi.exporter.pdfExport(uiGridExporterConstants.ALL, uiGridExporterConstants.ALL, myElement);
			    }

			    vm.exportExcelCallback = function () {
			        var myElement = angular.element(document.querySelectorAll(".custom-csv-link-location"));
			        vm.gridApi.exporter.csvExport(uiGridExporterConstants.ALL, uiGridExporterConstants.ALL, myElement);
			    }

			   
				$scope.$watch('config', handleConfigUpdates, true);
				$scope.$watch('results', handleResultsUpdates, true);
				$scope.$watch('templateConfig', handleTemplateConfigUpdates, true);
			},
			controllerAs: 'vm',
			template: '<div ng-include="vm.templateUrl"></div>',
			compile: function (element) {
				return recursionHelper.compile(element);
			}
		}
	};
    angular.module('app.globalSearch')
        .directive('globalSearchResults', globalSearchResults);
	globalSearchResults.$inject = ['$sce', '$timeout', 'recursionHelper','$translate', '$filter', "uiGridExporterConstants", "toastr"];

})();

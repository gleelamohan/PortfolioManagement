// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    function globalSearchSettings($sce, recursionHelper) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                templateUrl: "=templateurl",
                printCallback: "=printcallback",
                exportPdfCallback: "=exportpdfcallback",
                exportExcelCallback: "=exportexcelcallback",
                changeFilterVisibility: "=changefiltervisibility"
            },
            controller: function($scope) {
                var vm = this;
                vm.templateUrl = $scope.templateUrl;
                vm.printCallback = $scope.printCallback;
                vm.exportPdfCallback = $scope.exportPdfCallback;
                vm.exportExcelCallback = $scope.exportExcelCallback;
                vm.changeFilterVisibility = $scope.changeFilterVisibility;
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function(element) {
                return recursionHelper.compile(element);
            }
        }
    };
    angular.module('app')
        .directive('globalSearchSettings', globalSearchSettings);
    globalSearchSettings.$inject = ['$sce', 'recursionHelper'];
})();

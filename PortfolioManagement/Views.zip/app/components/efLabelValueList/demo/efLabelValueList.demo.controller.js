﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efLabelValueList')
        .controller('EfLabelValueListDemoCtrl', EfLabelValueListDemoCtrl);

    EfLabelValueListDemoCtrl.$inject = ['$scope', '$state', '$sanitize', '$parse', '$filter', '$timeout', 'efLabelValueListDemoApi'];

    function EfLabelValueListDemoCtrl($scope, $state, $sanitize, $parse, $filter, $timeout, efLabelValueListDemoApi) {
        var vm = this;

        var courierTypes = efLabelValueListDemoApi.courierTypes;
        var data = [];
        for (var i = 0; i < courierTypes.length; i++) {
            var dataItem = {
                "label": courierTypes[i].Value,
                "value": courierTypes[i].CourierTypeId
            };
            data.push(dataItem);
        }
        vm.filterScope = {
            "labelClass": "font-bold",
            "valueClass": "font-blue",
            "data": data
        };
    };
})();

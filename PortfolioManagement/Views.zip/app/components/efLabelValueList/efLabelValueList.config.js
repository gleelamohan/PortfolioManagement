﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efLabelValueList')
        .config(config);

    config.$inject = ['$stateProvider'];

    function config($stateProvider) {
        $stateProvider
            .state('efAngularLibrary.efLabelValueList', {
                abstract: true,
                url: "/efLabelValueList",
                template: "<ui-view />"
            })
            .state('efAngularLibrary.efLabelValueList.demo', {
                url: "/demo",
                templateUrl: "/app/components/efLabelValueList/demo/efLabelValueList.demo.html",
                controller: "EfLabelValueListDemoCtrl",
                controllerAs: "vm"
            });
    };
})();
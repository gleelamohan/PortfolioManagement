﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc overview
 * @name efAngularLibrary.efLabelValueList
 * @description 
 * 
 * efLabelValueList module provides an Angular filter that displays one-to-many label/values entries, each bound within a Bootstrap row with separately styled spans for each of the label and value entries, with a defined seperator between them.
 * 
 * <a href="/app/#/demo/efLabelValueList/demo">For complete implmentation details see the demo page.</a>
**/
(function () {
    angular.module('efAngularLibrary.efLabelValueList', []);
})();
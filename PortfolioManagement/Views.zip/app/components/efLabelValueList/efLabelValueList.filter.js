﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc filter
 * @name efAngularLibrary.efLabelValueList.filter:eflabelvaluelist
 * @requires efAngularLibrary.efLabelValueList.filterScope
 * @description 
 * 
 * efLabelValueList is an Angular filter that displays one-to-many label/values entries, each bound within a Bootstrap row with separately styled spans for each of the label and value entries, with a defined seperator between them.
 * <a href="/app/#/demo/efLabelValueList/demo">For complete implmentation details see the demo page.</a>
 * 
 * Example:
 * <pre>
 * <div ng-bind-html="vm.filterScope | eflabelvaluelist:': '"></div>
 * </pre>
 * 
 * @param {object|efAngularLibrary.efLabelValueList.filterScope} filterScope Valid object containing the filter's column styles, as well as the label/value data to render.
 * @param {string} seperator Seperator string to place between the Label and Value rendered spans.
 * @returns {string|HTML} Label/Value panel's HTML.
**/
(function () {
    angular
        .module('efAngularLibrary.efLabelValueList')
        .filter('eflabelvaluelist', efLabelValueList);

    efLabelValueList.$inject = ['$sce', '$filter'];

    function efLabelValueList($sce, $filter) {
        return function (filterScope, seperator) {
            var html = "";
            var labelValueSeperator = ((seperator !== undefined) && (seperator !== null)) ? seperator : " ";
            if ((filterScope !== undefined) && (filterScope !== null)) {
                if ((filterScope.data !== undefined) && (filterScope.data !== null)) {
                    for (var row in filterScope.data) {
                        html += "<div class=\"row\">" +
                            "<span class=\"" +
                            (((filterScope.labelClass !== undefined) && (filterScope.labelClass !== null)) ? filterScope.labelClass : "") +
                            "\">" +
                            (((filterScope.data[row].label !== undefined) && (filterScope.data[row].label !== null) && (filterScope.data[row].label.length > 0)) ? filterScope.data[row].label : "&nbsp;") +
                            "</span>" +
                            labelValueSeperator +
                            "<span class=\"" +
                            (((filterScope.valueClass !== undefined) && (filterScope.valueClass !== null)) ? filterScope.valueClass : "") +
                            "\">" +
                            (((filterScope.data[row].value !== undefined) && (filterScope.data[row].value !== null) && (filterScope.data[row].value.length > 0)) ? filterScope.data[row].value : "&nbsp;") + "</span>" +
                            "</span></div>";
                    }
                }
            }
            return $sce.trustAsHtml(html);
        };
    }
})();
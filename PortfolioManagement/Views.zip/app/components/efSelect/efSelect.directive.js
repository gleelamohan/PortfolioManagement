﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc directive
 * @name efAngularLibrary.efSelect.directive:efSelect
 * @scope
 * @restrict AEC
 * @requires efAngularLibrary.efSelect.efSelectConfig
 * @requires efAngularLibrary.efEnter.directive:efEnter
 * @requires efAngularLibrary.efFocus.directive:efFocus
 * @requires efLibrary
 * @requires recursionHelper
 * @requires toastr
 * @description 
 * 
 * efSelect is an Angular directive input control for selecting, searching, and inputing custom list entries.
 * 
 * <a href="/app/#/demo/efSelect/demo">For complete implmentation details see the demo page.</a>
 * 
 * @param {string} mode Rendering/usage mode for the control.  Valid values include "truefalse", "truefalsenull", "select", "multiselect", "search", "multisearch", "custommodal", "customselect", "custommultiselect", and "customlist".
 * @param {object|string} ngModel The Angular model for the control.
 * @param {expression|method=} ngChange The method to execute when the model has been changed.
 * @param {expression|boolean=} ngDisabled Flag to enable/disable the field.  If not provided, then the control is enabled.
 * @param {object=} config JSON Object with configuration options.  See {@link efAngularLibrary.efSelect.efSelectConfig efSelectConfig} for complete details.
 * @param {string=} getConfig A string-based name for the 'config' object to use.  When 'config' is not provided, the directive will search through the Angular scope hierarchy for the value provided here.  When it is found, it will be used as the directive's 'config'.  When 'config' is provided, this is ignored.
 * @param {Array=} options Array of option objects used in the 'select' modes top populate the options panel.
 * @param {string=} getOptions A string-based name for the 'options' object to use.  When 'options' is not provided, the directive will search through the Angular scope hierarchy for the value provided here.  When it is found, it will be used as the directive's 'options'.  When 'options' is provided, this is ignored.
 * @param {object=} modelData Single object containing the ngModel data.  Format is: <pre>{ "data": ngModel }</pre>.
 * @param {string=} getModelData A string-based name for the 'modelData' object to use.  When 'modelData' is not provided, the directive will search through the Angular scope hierarchy for the value provided here.  When it is found, it will be used as the directive's 'modelData'.  When 'modelData' is provided, this is ignored.
 * @param {boolean=} allowDuplicates Allows duplicate values within 'multi' modes. Missing or Null = false.
 * @param {boolean=} allowNull Allows a null value to be returned. Missing or Null = false.
 * @param {string=} sort This will determine the sort order direction (if any) of the selections in multi and list modes. Missing or Null = no sorting.  Possible values are null/missing, 'asc', 'desc'.
 * @param {string=} width The HTML valid width for the control.  Default is 'auto'.
 * @param {boolean=} inGrid Flag that tells the control if it is being rendered within a grid.  This parameter should not be set by the developer, but rather let the grid/parent control determine its value.
**/
(function () {
    angular
        .module('efAngularLibrary.efSelect')
        .directive('efSelect', efSelect);

    efSelect.$inject = ['$sce', '$filter', '$translate', '$modal', '$timeout', '$injector', 'recursionHelper', 'toastr', 'efLibrary'];

    function efSelect($sce, $filter, $translate, $modal, $timeout, $injector, recursionHelper, toastr, efLibrary) {
        return {
            restrict: 'AEC',
            replace: true,
            scope: {
                mode: "@mode",
                ngModel: "=",
                ngChange: "&",
                ngDisabled: "=?",
                config: "=?",
                getConfig: "@?",
                options: "=?",
                getOptions: "@?",
                modelData: "=?",
                getModelData: "@?",
                allowDuplicates: "@?",
                allowNull: "@?",
                sort: "@?",
                width: "@?",
                setFocus: "@?",
                inGrid: "@?"
            },
            controller: function ($scope) {
                var vm = this;
                $scope.grid = {};   //Added to support UI.grid

                //TODO Add color prefix addon with label

                //#region modelChanged function/event

                function modelChanged() {
                    $timeout(function () {
                        vm.changeCallback();
                    }, vm.changeCallbackTimeout);
                    if (vm.inGrid) {
                        $timeout(function () {
                            efLibrary.simulateDatatableTabKeyPress();
                        }, vm.changeCallbackTimeout);
                    }
                }

                //#endregion

                //#region support functions

                vm.createValueLabelObject = function (value, label) {
                    var returnValue = null;
                    if (value !== undefined && value !== null) {
                        returnValue = {
                            "value": value,
                            "label": (label !== undefined && label !== null ? label : "")
                        }
                    }
                    return returnValue;
                }

                vm.validateModel = function (model) {
                    var returnValue = true;

                    if (vm.allowNull == false &&
                        model !== undefined && (model === null || (Array.isArray(model) && model.length === 0))) {
                        returnValue = false;
                        vm.displayErrorMessage(String($filter("trustedtranslate")("efAngularLibrary.efSelect.NullModelError")));
                    }

                    return returnValue;
                }

                //#endregion

                //#region Directive Setup

                $scope.displayModel = [];

                vm.currentLanguage = $translate.use();
                vm.changeCallbackTimeout = 100;

                function handleDisabledUpdates(newValue) {
                    vm.disabled = newValue !== undefined && newValue !== null ? newValue : null;
                }
                $scope.$watch('ngDisabled', handleDisabledUpdates, true);

                function updateDisplayModel(options) {
                    var displayModel = [];

                    var model = null;
                    if ($scope.ngModel !== undefined && $scope.ngModel !== null) {
                        if (vm.allowDelimitedModel && vm.delimitedModel) {
                            var delimitedModel = $scope.ngModel.split(vm.delimiter);
                            if (delimitedModel !== undefined && delimitedModel !== null && delimitedModel.length > 0) {
                                model = [];
                                for (var i = 0; i < delimitedModel.length; i++) {
                                    var value = String(delimitedModel[i]).trim();
                                    if (vm.delimitedModelIsNumeric) {
                                        if (!isNaN(value)) {
                                            model.push(Number(value));
                                        }
                                    } else {
                                        model.push(value);
                                    }
                                }
                            }
                        } else {
                            model = JSON.parse(JSON.stringify($scope.ngModel));
                        }
                    }

                    var opts = (options !== undefined && options !== null ? options : ($scope.options !== undefined && $scope.options !== null ? $scope.options : (vm.options !== undefined && vm.options !== null ? vm.options : [])));
                    if (model !== undefined && model !== null) {
                        if (Array.isArray(model)) {
                            for (var i = 0; i < model.length; i++) {
                                displayModel.push(vm.validateDisplayModelItem(vm.createValueLabelObject(model[i], vm.getFirstValueById(vm.optionsValueField, model[i], vm.optionsLabelField, opts))));
                            }
                        } else {
                            displayModel.push(vm.validateDisplayModelItem(vm.createValueLabelObject(model, vm.getFirstValueById(vm.optionsValueField, model, vm.optionsLabelField, opts))));
                        }
                    }

                    if (vm.displayFirstItemInInputField && displayModel.length === 1) {
                        vm.enableTextInput = false;
                    } else {
                        vm.resetEnableTextInput();
                    }

                    if (vm.sort !== undefined && vm.sort !== null && (vm.sort.toLowerCase() === "asc" || vm.sort.toLowerCase() === "desc")) {
                        displayModel.sort(function (a, b) { return a.label.localeCompare(b.label); });
                        if (vm.sort.toLowerCase() === "desc") {
                            displayModel.reverse();
                        }
                    }

                    $scope.displayModel = JSON.parse(JSON.stringify(displayModel));
                }

                function handleDisplayModelUpdates(newDisplayModel) {
                    vm.displayModel = newDisplayModel !== undefined && newDisplayModel !== null ? JSON.parse(JSON.stringify(newDisplayModel)) : [];
                }
                $scope.$watch('displayModel', handleDisplayModelUpdates, true);

                function handleModelUpdates(newModel) {
                    vm.model = newModel !== undefined && newModel !== null ? JSON.parse(JSON.stringify(newModel)) : null;
                    updateDisplayModel();
                }
                $scope.$watch('ngModel', handleModelUpdates, true);

                function initModelData() {
                    $scope.modelData = { "data": null };
                }

                function updateExternalModeDataObject(data) {
                    if (data !== undefined && efLibrary.isValid($scope.getModelData, true)) {
                        var externalModelDataObject = eval($scope.getModelData);
                        if (efLibrary.isValid(externalModelDataObject)) {
                            externalModelDataObject.data = data !== null ? efLibrary.copyObject(data) : null;
                        }
                    }
                }

                function updateModelData(data) {
                    var modelData = efLibrary.isValid(data) ? JSON.parse(JSON.stringify(data)) : null;

                    if (!efLibrary.isValid($scope.modelData)) {
                        initModelData();
                    }

                    if ((vm.allowDelimitedModel && vm.delimitedModel) || vm.returnArray) {
                        if ($scope.modelData.data === undefined || $scope.modelData.data === null || !Array.isArray($scope.modelData.data)) {
                            $scope.modelData.data = [];
                        }
                        if (efLibrary.isValid(modelData)) {
                            var newModelData = JSON.parse(JSON.stringify($scope.modelData.data));
                            newModelData.push(modelData);
                            $scope.modelData.data = newModelData;
                        }
                    } else {
                        if (efLibrary.isValid(modelData)) {
                            $scope.modelData.data = modelData;
                        } else {
                            $scope.modelData.data = null;
                        }
                    }
                    updateExternalModeDataObject($scope.modelData.data);
                }

                function updateDirectiveModel(model, data) {
                    var returnValue = false;
                    var updatedModel = model !== undefined && model !== null ? JSON.parse(JSON.stringify(model)) : null;

                    if ($scope.ngModel !== undefined) {
                        if (vm.allowDelimitedModel && vm.delimitedModel) {
                            if (updatedModel !== null) {
                                if (!vm.allowDuplicates && $scope.ngModel !== null && $scope.ngModel.indexOf(updatedModel) >= 0) {
                                    vm.displayErrorMessage(String($filter("trustedtranslate")("efAngularLibrary.efSelect.DuplicateExistsError")));
                                } else {
                                    var delimitedModel = ($scope.ngModel !== null ? $scope.ngModel : "") + ($scope.ngModel !== null && $scope.ngModel.length > 0 ? vm.delimiter : "") + updatedModel;
                                    updateModelData(data);
                                    $scope.ngModel = delimitedModel;
                                    returnValue = true;
                                    modelChanged();
                                }
                            }
                        } else {
                            if (!vm.allowDuplicates && vm.valueExists(updatedModel, $scope.ngModel, vm.returnArray)) {
                                vm.displayErrorMessage(String($filter("trustedtranslate")("efAngularLibrary.efSelect.DuplicateExistsError")));
                            } else {
                                if (vm.returnArray) {
                                    updateModelData(data);
                                    if (Array.isArray($scope.ngModel)) {
                                        var newModel = [];
                                        if ($scope.ngModel !== null) {
                                            newModel = JSON.parse(JSON.stringify($scope.ngModel));
                                        }
                                        newModel.push(updatedModel);
                                        $scope.ngModel = JSON.parse(JSON.stringify(newModel));
                                    } else {
                                        var newModel = [];
                                        newModel.push(updatedModel);
                                        $scope.ngModel = JSON.parse(JSON.stringify(newModel));
                                    }
                                } else {
                                    updateModelData(data);
                                    $scope.ngModel = updatedModel;
                                }

                                returnValue = true;
                                modelChanged();
                            }
                        }
                    } else {
                        vm.displayErrorMessage(String($filter("trustedtranslate")("efAngularLibrary.efSelect.ModelUndefinedError")));
                    }
                    return returnValue;
                }

                function handleOptionsUpdates(newOptions) {
                    var options = newOptions !== undefined && newOptions !== null ? JSON.parse(JSON.stringify(newOptions)) : (vm.config !== undefined && vm.config !== null && vm.config.options !== undefined && vm.config.options !== null && vm.config.options.length > 0 ? JSON.parse(JSON.stringify(vm.config.options)) : []);
                    vm.options = efLibrary.isValid(options, true) ? options : (efLibrary.isValid($scope.getOptions, true) ? eval($scope.getOptions) : []);
                    updateDisplayModel();
                }
                $scope.$watch('options', handleOptionsUpdates, true);

                function handleChangeCallbackUpdates(newChangeCallback) {
                    vm.changeCallback = newChangeCallback !== undefined && newChangeCallback !== null ? newChangeCallback : function () { };
                }
                $scope.$watch('ngChange', handleChangeCallbackUpdates, true);

                function handleSortUpdates(newSort) {
                    vm.sort = newSort !== undefined && newSort !== null && newSort.length > 0 ? newSort.toLowerCase() : (vm.config !== undefined && vm.config !== null && vm.config.sort !== undefined && vm.config.sort !== null && vm.config.sort.length > 0 ? vm.config.sort.toLowerCase() : null);
                    updateDisplayModel();
                }
                $scope.$watch('sort', handleSortUpdates, true);

                function handleConfigUpdates(newConfig) {
                    var config = efLibrary.isValid(newConfig) ? newConfig : (efLibrary.isValid($scope.getConfig, true) ? eval($scope.getConfig) : null);
                    vm.config = config !== undefined && config !== null ? config : {};
                    vm.templateUrl = vm.config !== undefined && vm.config !== null && vm.config.templateUrl !== undefined && vm.config.templateUrl !== null && vm.config.templateUrl.length > 0 ? vm.config.templateUrl : "/app/components/efSelect/efSelect.html";
                    vm.placeholder = vm.config !== undefined && vm.config !== null && vm.config.placeholder !== undefined && vm.config.placeholder !== null && vm.config.placeholder.length > 0 ? (String($filter("trustedtranslate")(vm.config.placeholder))) : "";
                    vm.defaultSearchScope = vm.config !== undefined && vm.config !== null && vm.config.defaultSearchScope !== undefined && vm.config.defaultSearchScope !== null ? vm.config.defaultSearchScope : null;
                    vm.trueFalseOptions = [];
                    vm.trueFalseTrueValue = vm.config !== undefined && vm.config !== null && vm.config.trueFalseTrueValue !== undefined && vm.config.trueFalseTrueValue !== null ? vm.config.trueFalseTrueValue : true;
                    vm.trueFalseFalseValue = vm.config !== undefined && vm.config !== null && vm.config.trueFalseFalseValue !== undefined && vm.config.trueFalseFalseValue !== null ? vm.config.trueFalseFalseValue : false;
                    vm.trueFalseOptions.push(vm.createValueLabelObject(vm.trueFalseTrueValue, String($filter("trustedtranslate")("efAngularLibrary.efSelect.TrueFalse.TrueText"))));
                    vm.trueFalseOptions.push(vm.createValueLabelObject(vm.trueFalseFalseValue, String($filter("trustedtranslate")("efAngularLibrary.efSelect.TrueFalse.FalseText"))));

                    //vm.mode is set from HTML attribute first, then the config
                    vm.mode = $scope.mode !== undefined && $scope.mode !== null ? $scope.mode : (vm.config !== undefined && vm.config !== null && vm.config.mode !== undefined && vm.config.mode !== null && vm.config.mode.length > 0 ? vm.config.mode : "");

                    //vm.allowDuplicates is set from HTML attribute first, then the config
                    vm.allowDuplicates = efLibrary.toBoolean($scope.allowDuplicates, (vm.config !== undefined && vm.config !== null ? efLibrary.toBoolean(vm.config.allowDuplicates, false) : false));

                    //vm.allowNull is set from HTML attribute first, then the config
                    vm.allowNull = efLibrary.toBoolean($scope.allowNull, (vm.config !== undefined && vm.config !== null ? efLibrary.toBoolean(vm.config.allowNull, true) : true));

                    //vm.sort is set from HTML attribute first, then the config
                    vm.sort = $scope.sort !== undefined && $scope.sort !== null && $scope.sort.length > 0 ? $scope.sort.toLowerCase() : (vm.config !== undefined && vm.config !== null && vm.config.sort !== undefined && vm.config.sort !== null && vm.config.sort.length > 0 ? vm.config.sort.toLowerCase() : null);

                    //vm.inGrid is set from HTML attribute
                    vm.inGrid = efLibrary.toBoolean($scope.inGrid, false);

                    //vm.width is set from HTML attribute first, then the config
                    vm.width = $scope.width !== undefined && $scope.width !== null ? $scope.width : (vm.config !== undefined && vm.config !== null && vm.config.width !== undefined && vm.config.width !== null ? vm.config.width : "");
                    vm.widthStyle = vm.width !== undefined && vm.width !== null && vm.width.length > 0 ? JSON.parse("{\"width\": \"" + vm.width + "\"}") : "";

                    //vm.maxLength is set from config
                    vm.maxLength = !!vm.config && !!vm.config.maxLength ? vm.config.maxLength : "";

                    vm.delimitedModel = vm.config !== undefined && vm.config !== null && vm.config.delimitedModel !== undefined && vm.config.delimitedModel !== null ? vm.config.delimitedModel : false;
                    vm.delimiter = vm.config !== undefined && vm.config !== null && vm.config.delimiter !== undefined && vm.config.delimiter !== null && vm.config.delimiter.length > 0 ? vm.config.delimiter : ",";
                    vm.delimitedModelIsNumeric = vm.config !== undefined && vm.config !== null && vm.config.delimitedModelIsNumeric !== undefined && vm.config.delimitedModelIsNumeric !== null ? vm.config.delimitedModelIsNumeric : false;

                    //vm.options is set from HTML attribute first, then the config
                    if (!($scope.getOptions !== undefined && $scope.getOptions !== null && $scope.getOptions.length > 0)) {
                        vm.options = $scope.options !== undefined && $scope.options !== null ? JSON.parse(JSON.stringify($scope.options)) : (vm.config !== undefined && vm.config !== null && vm.config.options !== undefined && vm.config.options !== null && vm.config.options.length > 0 ? JSON.parse(JSON.stringify(vm.config.options)) : []);
                        if (vm.options !== undefined && vm.options != null && ($scope.options === undefined || $scope.options === null)) {
                            $scope.options = JSON.parse(JSON.stringify(vm.options));
                        }
                    }
                    vm.optionsValueField = vm.config !== undefined && vm.config !== null && vm.config.optionsValueField !== undefined && vm.config.optionsValueField !== null && vm.config.optionsValueField.length > 0 ? vm.config.optionsValueField : "value";
                    vm.optionsLabelField = vm.config !== undefined && vm.config !== null && vm.config.optionsLabelField !== undefined && vm.config.optionsLabelField !== null && vm.config.optionsLabelField.length > 0 ? vm.config.optionsLabelField : "label";
                    vm.optionsListMaxWidth = vm.config !== undefined && vm.config !== null && vm.config.optionsListMaxWidth !== undefined && vm.config.optionsListMaxWidth !== null && vm.config.optionsListMaxWidth.length > 0 ? vm.config.optionsListMaxWidth : "";
                    vm.optionsListMaxHeight = vm.config !== undefined && vm.config !== null && vm.config.optionsListMaxHeight !== undefined && vm.config.optionsListMaxHeight !== null && vm.config.optionsListMaxHeight.length > 0 ? vm.config.optionsListMaxHeight : "";
                    vm.optionsListScrollOnWideOptions = vm.config !== undefined && vm.config !== null && vm.config.optionsListScrollOnWideOptions !== undefined && vm.config.optionsListScrollOnWideOptions !== null ? vm.config.optionsListScrollOnWideOptions : true;

                    vm.optionsListStyle = JSON.parse("{" +
                        (vm.optionsListScrollOnWideOptions ? "\"overflow-x\": \"auto\"" : "\"overflow-x\": \"hidden\"") +
                        (vm.optionsListMaxWidth.length > 0 ? (", \"max-width\": \"" + vm.optionsListMaxWidth + "\"") : "") +
                        (vm.optionsListMaxHeight.length > 0 ? (", \"max-height\": \"" + vm.optionsListMaxHeight + "\"") : "") +
                        "}");

                    vm.searchTemplate = vm.config !== undefined && vm.config !== null && vm.config.searchTemplate !== undefined && vm.config.searchTemplate !== null && vm.config.searchTemplate.length > 0 ? vm.config.searchTemplate : "";
                    vm.searchController = vm.config !== undefined && vm.config !== null && vm.config.searchController !== undefined && vm.config.searchController !== null && vm.config.searchController.length > 0 ? vm.config.searchController : "";
                    vm.searchModalSize = vm.config !== undefined && vm.config !== null && vm.config.searchModalSize !== undefined && vm.config.searchModalSize !== null && vm.config.searchModalSize.length > 0 ? vm.config.searchModalSize : "lg";
                    vm.searchModalReturnScopeValueField = vm.config !== undefined && vm.config !== null && vm.config.searchModalReturnScopeValueField !== undefined && vm.config.searchModalReturnScopeValueField !== null && vm.config.searchModalReturnScopeValueField.length > 0 ? vm.config.searchModalReturnScopeValueField : "";

                    vm.searchModalReturnLookupService = null;
                    var searchModalReturnLookupService = vm.config !== undefined && vm.config !== null && vm.config.searchModalReturnLookupService !== undefined && vm.config.searchModalReturnLookupService !== null ? vm.config.searchModalReturnLookupService : null;
                    if (searchModalReturnLookupService !== null) {
                        if (typeof searchModalReturnLookupService === "string") {
                            vm.searchModalReturnLookupService = $injector.get(searchModalReturnLookupService);
                        } else {
                            vm.searchModalReturnLookupService = searchModalReturnLookupService;
                        }
                    }
                    vm.searchModalReturnLookupFunction = vm.config !== undefined && vm.config !== null && vm.config.searchModalReturnLookupFunction !== undefined && vm.config.searchModalReturnLookupFunction !== null && vm.config.searchModalReturnLookupFunction.length > 0 ? vm.config.searchModalReturnLookupFunction : "get";
                    vm.searchModalReturnLookupValueField = vm.config !== undefined && vm.config !== null && vm.config.searchModalReturnLookupValueField !== undefined && vm.config.searchModalReturnLookupValueField !== null && vm.config.searchModalReturnLookupValueField.length > 0 ? vm.config.searchModalReturnLookupValueField : vm.searchModalReturnScopeValueField;
                    vm.searchModalReturnLookupLabelField = vm.config !== undefined && vm.config !== null && vm.config.searchModalReturnLookupLabelField !== undefined && vm.config.searchModalReturnLookupLabelField !== null && vm.config.searchModalReturnLookupLabelField.length > 0 ? vm.config.searchModalReturnLookupLabelField : "";
                }
                handleConfigUpdates($scope.config);
                $scope.$watch('config', handleConfigUpdates, true);

                vm.customModalTemplate = !!vm.config && !!vm.config.customModalTemplate && vm.config.customModalTemplate.length > 0 ? vm.config.customModalTemplate : "";
                vm.customModalController = !!vm.config && !!vm.config.customModalController && vm.config.customModalController.length > 0 ? vm.config.customModalController : "";
                vm.customModalReturnLookupLabelField = !!vm.config && !!vm.config.customModalReturnLookupLabelField && vm.config.customModalReturnLookupLabelField.length > 0 ? vm.config.customModalReturnLookupLabelField : "Text";
                vm.canDeleteCustomModal = !!vm.config && vm.config.canDeleteCustomModal !== undefined && vm.config.canDeleteCustomModal !== null ? vm.config.canDeleteCustomModal : true;
                vm.canTrimCustomModalLabelField = !!vm.config && vm.config.canTrimCustomModalLabelField !== undefined && vm.config.canTrimCustomModalLabelField !== null ? vm.config.canTrimCustomModalLabelField : false;
                vm.customModalMaxLabelFieldLength = !!vm.config && !!vm.config.customModalMaxLabelFieldLength ? vm.config.customModalMaxLabelFieldLength : 60;

                vm.displayError = false;
                vm.errorMessage = "";

                vm.inputValue = "";

                //Must use the EXACT $scope.status for the ui.bootstrap.dropdown to work
                $scope.status = {
                    isopen: false
                };

                //Must use the EXACT $scope.toggleDropdown for the ui.bootstrap.dropdown to work
                $scope.toggleDropdown = function ($event) {
                    $event.preventDefault();
                    $event.stopPropagation();
                    $scope.status.isopen = !$scope.status.isopen;
                };

                vm.inputHasFocus = false;
                vm.setInputHasFocus = function () {
                    if (vm.enableTextInput) {
                        vm.inputHasFocus = true;
                    }
                }

                vm.displayCustomEntryAction = function () {
                    return ((vm.mode.toLowerCase() === "customselect" || vm.mode.toLowerCase() === "custommultiselect" || vm.mode.toLowerCase() === "customlist") && vm.inputValue.length > 0);
                }

                vm.resetEnableTextInput = function () {
                    switch (vm.mode.toLowerCase()) {
                        case "search":
                            vm.enableTextInput = true;
                            break;
                        case "multisearch":
                            vm.enableTextInput = true;
                            break;
                        case "customselect":
                            vm.enableTextInput = true;
                            break;
                        case "custommultiselect":
                            vm.enableTextInput = true;
                            break;
                        case "customlist":
                            vm.enableTextInput = true;
                            break;
                        case "custommodal":
                            vm.enableTextInput = false;
                            break;
                        default:
                            vm.enableTextInput = false;
                            break;
                    }
                }
                vm.resetEnableTextInput();

                vm.enableDelete = true;
                vm.enableDropdown = false;
                vm.customEntryIcon = "fa-plus fa-fw";
                switch (vm.mode.toLowerCase()) {
                    case "truefalse":
                        vm.actionIcon = "fa-caret-down fa-fw";
                        vm.returnArray = false;
                        vm.enableDelete = false;
                        vm.enableDropdown = true;
                        vm.displayFirstItemInInputField = true;
                        vm.allowDelimitedModel = false;
                        $scope.options = JSON.parse(JSON.stringify(vm.trueFalseOptions));
                        break;
                    case "truefalsenull":
                        vm.actionIcon = "fa-caret-down fa-fw";
                        vm.returnArray = false;
                        vm.enableDropdown = true;
                        vm.displayFirstItemInInputField = true;
                        vm.allowDelimitedModel = false;
                        $scope.options = JSON.parse(JSON.stringify(vm.trueFalseOptions));
                        break;
                    case "select":
                        vm.actionIcon = "fa-caret-down fa-fw";
                        vm.enableDelete = vm.allowNull;
                        vm.returnArray = false;
                        vm.enableDropdown = true;
                        vm.displayFirstItemInInputField = true;
                        vm.allowDelimitedModel = false;
                        break;
                    case "multiselect":
                        vm.actionIcon = "fa-caret-down fa-fw";
                        vm.returnArray = true;
                        vm.enableDropdown = true;
                        vm.displayFirstItemInInputField = true;
                        vm.allowDelimitedModel = true;
                        break;
                    case "search":
                        vm.actionIcon = "fa-search fa-fw";
                        vm.enableDelete = vm.allowNull;
                        vm.returnArray = false;
                        vm.displayFirstItemInInputField = true;
                        vm.allowDelimitedModel = false;
                        break;
                    case "multisearch":
                        vm.actionIcon = "fa-search fa-fw";
                        vm.returnArray = true;
                        vm.displayFirstItemInInputField = false;
                        vm.allowDelimitedModel = true;
                        break;
                    case "custommodal":
                        vm.actionIcon = vm.customEntryIcon;
                        vm.returnArray = true;
                        vm.displayFirstItemInInputField = false;
                        vm.allowDelimitedModel = true;
                        vm.enableDelete = vm.canDeleteCustomModal;
                        break;
                    case "customselect":
                        vm.actionIcon = "fa-caret-down fa-fw";
                        vm.returnArray = false;
                        vm.enableDropdown = true;
                        vm.displayFirstItemInInputField = vm.allowNull ? true : false;
                        vm.allowDelimitedModel = false;
                        break;
                    case "custommultiselect":
                        vm.actionIcon = "fa-caret-down fa-fw";
                        vm.returnArray = true;
                        vm.enableDropdown = true;
                        vm.displayFirstItemInInputField = false;
                        vm.allowDelimitedModel = true;
                        break;
                    case "customlist":
                        vm.actionIcon = vm.customEntryIcon;
                        vm.returnArray = true;
                        vm.displayFirstItemInInputField = false;
                        vm.allowDelimitedModel = true;
                        break;
                    default:
                        vm.actionIcon = "fa-exclamation fa-fw";
                        vm.returnArray = false;
                        vm.enableDelete = true;
                        vm.enableDropdown = false;
                        vm.displayError = true;
                        vm.displayFirstItemInInputField = true;
                        vm.allowDelimitedModel = false;
                        vm.errorMessage = String($filter("trustedtranslate")("efAngularLibrary.efSelect.ModeError"));
                        break;
                }


                vm.retrievingData = false;

                if (efLibrary.toBoolean($scope.setFocus, false)) {
                    vm.setInputHasFocus();
                }

                //#endregion

                //#region Button/Link Functions

                vm.actionClick = function (currentDisplayModel) {
                    if (vm.mode.toLowerCase() === "search" || vm.mode.toLowerCase() === "multisearch") {
                        vm.openModalSearch(currentDisplayModel);
                    }
                    else if (vm.mode.toLowerCase() === "custommodal" || vm.mode.toLowerCase() === "custommodal") {
                        vm.openCustomModal(currentDisplayModel);
                    }
                    else if (vm.mode.toLowerCase() === "customselect" || vm.mode.toLowerCase() === "custommultiselect" || vm.mode.toLowerCase() === "customlist") {
                        if (vm.inputValue !== undefined && vm.inputValue !== null && vm.inputValue.length > 0) {
                            vm.setInputHasFocus();
                            updateDirectiveModel(vm.inputValue);
                            vm.inputValue = "";
                        }
                    } else {
                        vm.setInputHasFocus();
                    }
                }

                vm.optionClick = function (value) {
                    updateDirectiveModel(value);
                }

                function trimLabel(label, maximumLength) {
                    if (vm.canTrimCustomModalLabelField) {
                        if (label.length <= maximumLength) {
                            return label;
                        }
                        return label.substring(0, maximumLength) + "...";
                    }
                    return label;
                }

                vm.updateCustomModal = function (index) {
                    if (vm.mode.toLowerCase() === "custommodal" || vm.mode.toLowerCase() === "custommodal") {
                        var modalScope = vm.displayModel[index].value;
                        var dataState = modalScope.DataState;
                        var modalInstance = $modal.open({
                            size: vm.searchModalSize,
                            template: vm.customModalTemplate,
                            controller: vm.customModalController,
                            windowClass: "efSelectModalWindow",
                            scope: function () {
                                var scope = $scope.$new();
                                scope.inputScope = modalScope;
                                return scope;
                            }()
                        });

                        modalInstance.result.then(function (modalReturnScope) {
                            if (modalReturnScope !== undefined && modalReturnScope !== null) {
                                vm.inputValue = "";
                                //user can update the in memory created modal so we need to check that DataState 
                                if (dataState != undefined && dataState != null && dataState.toLowerCase() === "created") {
                                    modalReturnScope.DataState = "Created";
                                } else {
                                    modalReturnScope.DataState = "Modified";
                                }
                                vm.displayModel[index].value = modalReturnScope;
                                vm.displayModel[index].label = trimLabel(eval("modalReturnScope." + vm.customModalReturnLookupLabelField), vm.customModalMaxLabelFieldLength);

                                if (vm.returnArray) {
                                    var newModel = [];
                                    if ($scope.ngModel !== null) {
                                        newModel = JSON.parse(JSON.stringify($scope.ngModel));
                                    }
                                    newModel[index] = modalReturnScope;
                                    $scope.ngModel = JSON.parse(JSON.stringify(newModel));
                                }
                                modelChanged();
                            }
                        }, function () {
                        });
                    }
                }

                function deleteModelData(field, value) {
                    if (efLibrary.isValid($scope.modelData)) {
                        var modelData = efLibrary.isValid($scope.modelData.data) ? JSON.parse(JSON.stringify($scope.modelData.data)) : null;
                        if (field !== undefined && field !== null && field.length > 0 &&
                            value !== undefined && value !== null && value.length > 0) {
                            if (modelData !== undefined && modelData !== null &&
                                Array.isArray(modelData)) {
                                var index = -1;
                                for (var i = 0; i < modelData.length; i++) {
                                    if (modelData[i] !== undefined && modelData[i] !== null &&
                                        modelData[i][field] !== undefined &&
                                        modelData[i][field] === value) {
                                        index = i;
                                        break;
                                    }
                                }
                                if (index >= 0) {
                                    modelData.splice(index, 1);
                                }
                            } else {
                                modelData = null;
                            }
                        }
                        $scope.modelData.data = modelData;
                    } else {
                        initModelData();
                    }
                    updateExternalModeDataObject($scope.modelData.data);
                }

                vm.delete = function (index) {
                    var unsortedIndex = index;
                    var deleteValue = null;
                    if ($scope.ngModel !== undefined && $scope.ngModel !== null) {
                        if (vm.allowDelimitedModel && vm.delimitedModel) {
                            var delimitedModel = $scope.ngModel.split(vm.delimiter);
                            if (delimitedModel !== undefined && delimitedModel !== null && delimitedModel.length > 0) {
                                if (vm.sort !== null) {
                                    unsortedIndex = delimitedModel.indexOf(vm.displayModel[index].value);
                                }
                                if (unsortedIndex >= 0) {
                                    deleteValue = JSON.parse(JSON.stringify(delimitedModel[unsortedIndex]));
                                    delimitedModel.splice(unsortedIndex, 1);
                                    var model = null;
                                    for (var i = 0; i < delimitedModel.length; i++) {
                                        model = (model !== null && model.length > 0 ? model : "") + (model !== null && model.length > 0 ? vm.delimiter : "") + delimitedModel[i];
                                    }
                                    if (vm.validateModel(model)) {
                                        deleteModelData(vm.searchModalReturnScopeValueField, deleteValue);
                                        $scope.ngModel = model;
                                        modelChanged();
                                    }
                                }
                            }
                        } else {
                            if (vm.returnArray) {
                                if (vm.sort !== null) {
                                    unsortedIndex = $scope.ngModel.indexOf(vm.displayModel[index].value);
                                }
                                if (unsortedIndex >= 0) {
                                    var newModel = [];
                                    newModel = JSON.parse(JSON.stringify($scope.ngModel));
                                    deleteValue = JSON.parse(JSON.stringify(newModel[unsortedIndex]));
                                    newModel.splice(unsortedIndex, 1);
                                    if (vm.validateModel(newModel)) {
                                        deleteModelData(vm.searchModalReturnScopeValueField, deleteValue);
                                        $scope.ngModel = JSON.parse(JSON.stringify(newModel));
                                        modelChanged();
                                    }
                                }
                            } else {
                                if (vm.validateModel(null)) {
                                    initModelData();
                                    updateExternalModeDataObject(null);
                                    $scope.ngModel = null;
                                    modelChanged();
                                }
                            }
                        }
                    }
                }

                vm.openModalSearch = function (currentDisplayModel) {
                    var input = (vm.inputValue !== undefined && vm.inputValue !== null && vm.inputValue.length > 0 ? vm.inputValue : (currentDisplayModel !== undefined && currentDisplayModel !== null ? currentDisplayModel : ""));
                    var modalScope = { "defaultSearchTerm": input, "defaultSearchScope": vm.defaultSearchScope };
                    var modalInstance = $modal.open({
                        size: vm.searchModalSize,
                        template: vm.searchTemplate,
                        controller: vm.searchController,
                        windowClass: "efSelectModalWindow",
                        scope: function () {
                            var scope = $scope.$new();
                            scope.inputScope = modalScope;
                            return scope;
                        }()
                    });

                    modalInstance.result.then(function (modalReturnScope) {
                        if (modalReturnScope !== undefined && modalReturnScope !== null &&
                            vm.searchModalReturnScopeValueField !== undefined && vm.searchModalReturnScopeValueField !== null && vm.searchModalReturnScopeValueField.length > 0) {
                            vm.inputValue = "";
                            var value = eval("modalReturnScope." + vm.searchModalReturnScopeValueField);
                            if (value !== undefined && value !== null && value.length > 0) {
                                vm.setInputHasFocus();
                                updateDirectiveModel(value, modalReturnScope);
                            }
                        }
                    }, function () { });
                }

                vm.openCustomModal = function (currentDisplayModel) {
                    var modalScope = {};
                    var modalInstance = $modal.open({
                        size: vm.searchModalSize,
                        template: vm.customModalTemplate,
                        controller: vm.customModalController,
                        windowClass: "efSelectModalWindow",
                        scope: function () {
                            var scope = $scope.$new();
                            scope.inputScope = modalScope;
                            return scope;
                        }()
                    });

                    modalInstance.result.then(function (modalReturnScope) {
                        if (modalReturnScope !== undefined && modalReturnScope !== null) {
                            vm.inputValue = "";
                            vm.setInputHasFocus();
                            modalReturnScope.DataState = "Created";
                            updateDirectiveModel(modalReturnScope, modalReturnScope);
                        }
                    }, function () { });
                }

                vm.lookupData = function (value) {
                    if (value !== undefined &&
                        vm.searchModalReturnLookupService !== undefined && vm.searchModalReturnLookupService !== null &&
                        vm.searchModalReturnLookupFunction !== undefined && vm.searchModalReturnLookupFunction !== null && vm.searchModalReturnLookupFunction.length > 0 &&
                        vm.searchModalReturnLookupValueField !== undefined && vm.searchModalReturnLookupValueField !== null && vm.searchModalReturnLookupValueField.length > 0 &&
                        vm.searchModalReturnLookupLabelField !== undefined && vm.searchModalReturnLookupLabelField !== null && vm.searchModalReturnLookupLabelField.length > 0) {

                        if (!vm.valueExistsInObjectArray("value", value, $scope.options)) {
                            var parameters = "{ \"" + vm.searchModalReturnLookupValueField + "\": " + (value !== null ? ("\"" + value + "\"") : "null") + " }";
                            vm.retrievingData = true;
                            var objParams = JSON.parse(parameters);

                            vm.searchModalReturnLookupService[vm.searchModalReturnLookupFunction](objParams).$promise.then(function (response) {
                                vm.retrievingData = false;
                                if (response !== undefined && response !== null) {
                                    var label = eval("response." + vm.searchModalReturnLookupLabelField);
                                    if (label !== undefined && label !== null && label.length > 0) {
                                        var option = vm.createValueLabelObject(value, label);
                                        if (option !== undefined && option !== null) {
                                            var options = [];
                                            if ($scope.options !== undefined && $scope.options !== null) {
                                                options = JSON.parse(JSON.stringify($scope.options));
                                            }
                                            options.push(option);
                                            $scope.options = options;
                                        }
                                    }
                                }
                            });
                        }
                    }
                }

                //#endregion

                //#region support functions

                vm.displayErrorMessage = function (message) {
                    toastr.error(message);
                }

                vm.validateDisplayModelItem = function (displayModelItem) {
                    var returnValue = displayModelItem;
                    if (returnValue !== undefined && returnValue !== null && returnValue.label !== undefined && returnValue.label !== null && returnValue.label.length === 0) {
                        if (vm.mode.toLowerCase() === "search" || vm.mode.toLowerCase() === "multisearch") {
                            vm.lookupData(returnValue.value);
                            returnValue.label = (vm.retrievingData ? String($filter("trustedtranslate")("efAngularLibrary.efSelect.RetrievingLookupData")) : String($filter("trustedtranslate")("efAngularLibrary.efSelect.LabelNotFound")));
                        } else if (vm.mode.toLowerCase() === "customselect" || vm.mode.toLowerCase() === "custommultiselect" || vm.mode.toLowerCase() === "customlist") {
                            returnValue.label = returnValue.value;
                        } else if (vm.mode.toLowerCase() === "custommodal") {
                            returnValue.label = trimLabel(eval("returnValue.value." + vm.customModalReturnLookupLabelField), vm.customModalMaxLabelFieldLength);
                        } else {
                            returnValue.label = String($filter("trustedtranslate")("efAngularLibrary.efSelect.LabelNotFound"));
                        }
                    }
                    return returnValue;
                }

                vm.getAllValuesById = function (idField, id, valueField, data) {
                    var returnValue = [];
                    if (idField !== undefined && idField !== null && idField.length > 0 &&
                        id !== undefined &&
                        valueField !== undefined && valueField !== null && valueField.length > 0 &&
                        data !== undefined && data !== null && data.length > 0) {
                        var rows = $.grep(data, function (e) { return e[idField] === id; });
                        if (rows !== undefined && rows !== null && rows.length > 0) {
                            for (var i = 0; i < rows.length; i++) {
                                returnValue.push(eval("rows[i]." + valueField));
                            }
                        }
                    }
                    return returnValue;
                }

                vm.getFirstValueById = function (idField, id, valueField, data) {
                    var returnValue = null;
                    var foundValues = vm.getAllValuesById(idField, id, valueField, data);
                    if (foundValues.length > 0) {
                        returnValue = foundValues[0];
                    }
                    return returnValue;
                }

                vm.valueExistsInArray = function (value, data) {
                    var returnValue = false;
                    if (value !== undefined &&
                        data !== undefined && data !== null && data.length > 0) {
                        for (var i = 0; i < data.length; i++) {
                            if (data[i] === value) {
                                returnValue = true;
                                break;
                            }
                        }
                    }
                    return returnValue;
                }

                vm.valueExistsInObjectArray = function (valueField, value, data) {
                    var returnValue = false;
                    if (valueField !== undefined && valueField !== null && valueField.length > 0 &&
                        value !== undefined &&
                        data !== undefined && data !== null && data.length > 0) {
                        for (var i = 0; i < data.length; i++) {
                            if (data[i][valueField] === value) {
                                returnValue = true;
                                break;
                            }
                        }
                    }
                    return returnValue;
                }

                vm.valueExists = function (value, data, returnArray) {
                    var returnValue = false;
                    if (value !== undefined &&
                        data !== undefined && data !== null && data.length > 0) {
                        if (efLibrary.toBoolean(returnArray, false)) {
                            returnValue = vm.valueExistsInArray(value, data);
                        } else {
                            if (data === value) {
                                returnValue = true;
                            }
                        }
                    }
                    return returnValue;
                }

                vm.setModelObjectByName = function (scope, variableName, value) {
                    var levels = variableName.split(".");
                    var model = scope;
                    var i = 0;
                    while (i < levels.length - 1) {
                        if (typeof model[levels[i]] === 'undefined') {
                            model[levels[i]] = {};
                        }
                        model = model[levels[i]];
                        i++;
                    }
                    model[levels[levels.length - 1]] = value;
                }

                //#endregion
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        };
    }
})();

﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efSelect')
        .config(config);

    config.$inject = ['$stateProvider'];

    function config($stateProvider) {
        $stateProvider
            .state('efAngularLibrary.efSelect', {
                abstract: true,
                url: "/efSelect",
                template: "<ui-view />"
            })
            .state('efAngularLibrary.efSelect.demo', {
                url: "/demo",
                templateUrl: "/app/components/efSelect/demo/efSelect.demo.html",
                controller: "EfSelectDemoCtrl",
                controllerAs: "vm"
            });
    };
})();
﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc overview
 * @name efAngularLibrary.efSelect
 * @description 
 * 
 * efSelect module provides an Angular directive input control for selecting, searching, and inputing custom list entries.
 * 
 * <a href="/app/#/demo/efSelect/demo">For complete implmentation details see the demo page.</a>
 * 
 * 
**/
(function () {
    angular.module('efAngularLibrary.efSelect', []);
})();
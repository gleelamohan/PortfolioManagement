﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efSelect')
        .factory('efSelectDemoApi', efSelectDemoApi);

    efSelectDemoApi.$inject = ['$resource', '$filter'];

    function efSelectDemoApi($resource, $filter) {
        var service = {};

        service.courierTypes = [
            {
                "CourierTypeId": "3b5eb85c-b700-4923-bcaa-0d44d44bd5d0",
                "Value": "CDO",
                "DataState": "Unchanged"
            },
            {
                "CourierTypeId": "2747bc5b-e546-4046-8dda-66bfeffc6051",
                "Value": "DHL",
                "DataState": "Unchanged"
            },
            {
                "CourierTypeId": "f33aa541-848e-4e1b-8c39-a39ef145797d",
                "Value": "FedEx",
                "DataState": "Unchanged"
            },
            {
                "CourierTypeId": "fa8e42e5-8ddc-4c94-b33d-e4342b34f206",
                "Value": "Internal Courier",
                "DataState": "Unchanged"
            },
            {
                "CourierTypeId": "2db04b70-1982-41b3-972d-3554dd5f4ae4",
                "Value": "Marken",
                "DataState": "Unchanged"
            },
            {
                "CourierTypeId": "362ee905-6a47-48ba-bde9-1dbfe5d793bc",
                "Value": "UPS",
                "DataState": "Unchanged"
            },
            {
                "CourierTypeId": "4313ec13-019c-4484-92cc-0a8fff883af5",
                "Value": "US Air",
                "DataState": "Unchanged"
            },
            {
                "CourierTypeId": "c6d55946-d490-4dc3-966e-6764a2c05ed9",
                "Value": "World Courier",
                "DataState": "Unchanged"
            }
        ];
        return service;
    }
})();
﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efSelect')
        .controller('EfSelectDemoCtrl', EfSelectDemoCtrl);

    EfSelectDemoCtrl.$inject = ['$scope', '$state', '$sanitize', '$parse', '$filter', '$timeout', 'toastr', 'efSelectDemoApi'];

    function EfSelectDemoCtrl($scope, $state, $sanitize, $parse, $filter, $timeout, toastr, efSelectDemoApi) {
        var vm = this;

        vm.disabled = false;
        vm.sort = null;

        vm.sortConfig = {
            "allowDuplicates": false,
            "placeholder": "Select sort option...",
            "options": [
                { "value": "asc", "label": "Sort Ascending" },
                { "value": "desc", "label": "Sort Descending" }
            ],
            "width": "100%"
        };

        //#region efSelect Search 
        var administrativeCustomerFrameworksApi = "administrativeCustomerFrameworksApi";

        vm.searchConfig = {
            "allowDuplicates": false,
            "placeholder": "Select ACF...",
            "searchTemplate": '<div class="modal-body"><ef-search ismodal="true" inputscope="vm.inputScope" appcallback="vm.appCallback" templateurl="vm.templateUrl" searchservice="vm.searchService" pagetitle="vm.pagetitle" searchentrypaneltitle="vm.searchEntryPanelTitle" searchresultspaneltitle="vm.searchResultsPanelTitle" searchentrytemplateurl="vm.searchEntryTemplateUrl" searchentryoptionstemplateurl="vm.searchEntryOptionsTemplateUrl" searchresultstemplateurl="vm.searchResultsTemplateUrl" searchresultssettingstemplateurl="vm.searchResultsSettingsTemplateUrl" searchresultsfiltertemplateurl="vm.searchResultsFilterTemplateUrl" addnew="vm.addNew" addnewtext="vm.addNewText" refreshresults="vm.refreshResults"></ef-search></div>',
            "searchController": 'AdministrativeCustomerFrameworkSearchModalCtrl as vm',
            "searchModalReturnScopeValueField": "AdministrativeCustomerFrameworkId",
            "searchModalReturnLookupService": administrativeCustomerFrameworksApi,
            "searchModalReturnLookupFunction": "get",
            "searchModalReturnLookupValueField": "administrativeCustomerFrameworkId",
            "searchModalReturnLookupLabelField": "Name",
            "width": "100%"
        };

        vm.searchChangeCallback = function (message) {
            if (message !== undefined && message !== null && message.length > 0) {
                toastr.info(message);
            } else {
                toastr.info("efSelect ngChange Called");
            }
        }

        vm.searchOptions = [];
        vm.searchModelData = {};
        vm.searchModel = null;
        //vm.searchModel = "12ff6dee-73ad-43e0-bb42-f1942cbdda9e";

        vm.multiSearchConfig = {
            "allowDuplicates": false,
            "placeholder": "Select ACF...",
            "searchTemplate": '<div class="modal-body"><ef-search ismodal="true" inputscope="vm.inputScope" appcallback="vm.appCallback" templateurl="vm.templateUrl" searchservice="vm.searchService" pagetitle="vm.pagetitle" searchentrypaneltitle="vm.searchEntryPanelTitle" searchresultspaneltitle="vm.searchResultsPanelTitle" searchentrytemplateurl="vm.searchEntryTemplateUrl" searchentryoptionstemplateurl="vm.searchEntryOptionsTemplateUrl" searchresultstemplateurl="vm.searchResultsTemplateUrl" searchresultssettingstemplateurl="vm.searchResultsSettingsTemplateUrl" searchresultsfiltertemplateurl="vm.searchResultsFilterTemplateUrl" addnew="vm.addNew" addnewtext="vm.addNewText" refreshresults="vm.refreshResults"></ef-search></div>',
            "searchController": 'AdministrativeCustomerFrameworkSearchModalCtrl as vm',
            "searchModalReturnScopeValueField": "AdministrativeCustomerFrameworkId",
            "searchModalReturnLookupService": administrativeCustomerFrameworksApi,
            "searchModalReturnLookupFunction": "get",
            "searchModalReturnLookupValueField": "administrativeCustomerFrameworkId",
            "searchModalReturnLookupLabelField": "Name",
            "width": "100%"
        };

        vm.customModalConfig = {
            "allowDuplicates": false,
            "placeholder": "Create Note...",
            "customModalTemplate": '<div class="modal-body"><note-maintenance ismodal="true" inputscope="vm.inputScope" appcallback="vm.appCallback" infovisible="vm.infoVisible" infotext="vm.infoText" infoclass="vm.infoClass"></note-maintenance></div>',
            "customModalController": 'NoteMaintenanceModalCtrl as vm',
            "canDeleteCustomModal": false,
            "customModalReturnLookupLabelField": "Text",
            "canTrimCustomModalLabelField": true,
            "customModalMaxLabelFieldLength": 50,
            "width": "100%"
        };

        vm.multiSearchChangeCallback = function (message) {
            if (message !== undefined && message !== null && message.length > 0) {
                toastr.info(message);
            } else {
                toastr.info("efSelect ngChange Called");
            }
        }

        vm.multiSearchOptions = [];
        vm.multiSearchModelData = {};
        vm.multiSearchModel = null;

        vm.customModals = [
            {
                "AnalyticalNoteId": null,
                "NoteTypeId": "8fbf2fe5-ad30-4202-bd94-938c0a818e32",
                "NoteType": null,
                "Text": "Note 01",
                "EntryDate": "2015-08-11T07:01:53.143Z",
                "DataState": "unchanged"
            }
        ];
        //vm.multiSearchModel = ["12ff6dee-73ad-43e0-bb42-f1942cbdda9e"];

        //#endregion

        //#region efSelect Select 

        vm.selectConfig = {
            "allowDuplicates": false,
            "placeholder": "Select Courier Type...",
            "optionsValueField": "CourierTypeId",
            "optionsLabelField": "Value",
            "optionsListMaxWidth": "300px",
            "optionsListMaxHeight": "200px",
            "optionsListScrollOnWideOptions": true,
            "width": "100%"
        };

        vm.selectChangeCallback = function (message) {
            if (message !== undefined && message !== null && message.length > 0) {
                toastr.info(message);
            } else {
                toastr.info("efSelect ngChange Called");
            }
        }

        vm.selectOptions = efLibrary.copyObject(efSelectDemoApi.courierTypes);

        vm.selectModel = null;
        //vm.selectModel = "f33aa541-848e-4e1b-8c39-a39ef145797d";

        vm.multiSelectConfig = {
            "allowDuplicates": false,
            "placeholder": "Select Courier Type...",
            "sortDirection": "desc",
            "optionsValueField": "CourierTypeId",
            "optionsLabelField": "Value",
            "optionsListMaxWidth": "300px",
            "optionsListMaxHeight": "200px",
            "optionsListScrollOnWideOptions": true,
            "width": "100%"
        };

        vm.multiSelectChangeCallback = function (message) {
            if (message !== undefined && message !== null && message.length > 0) {
                toastr.info(message);
            } else {
                toastr.info("efSelect ngChange Called");
            }
        }

        vm.multiSelectOptions = efLibrary.copyObject(efSelectDemoApi.courierTypes);

        vm.multiSelectModel = null;
        //vm.multiSelectModel = ["f33aa541-848e-4e1b-8c39-a39ef145797d", "2747bc5b-e546-4046-8dda-66bfeffc6051"];

        vm.multiSelectDelimitedConfig = {
            "allowDuplicates": false,
            "placeholder": "Select Courier Type...",
            "sortDirection": "desc",
            "optionsValueField": "CourierTypeId",
            "optionsLabelField": "Value",
            "optionsListMaxWidth": "300px",
            "optionsListMaxHeight": "200px",
            "optionsListScrollOnWideOptions": true,
            "width": "100%",
            "delimitedModel": true,
            "delimiter": ", ",
            "delimitedModelIsNumeric": false
        };

        vm.multiSelectDelimitedChangeCallback = function (message) {
            if (message !== undefined && message !== null && message.length > 0) {
                toastr.info(message);
            } else {
                toastr.info("efSelect ngChange Called");
            }
        }

        vm.multiSelectDelimitedOptions = efLibrary.copyObject(efSelectDemoApi.courierTypes);

        vm.multiSelectDelimitedModel = null;
        //vm.multiSelectDelimitedModel = "f33aa541-848e-4e1b-8c39-a39ef145797d, 2747bc5b-e546-4046-8dda-66bfeffc6051";

        //#endregion

        //#region efSelect Custom

        vm.customSelectConfig = {
            "allowDuplicates": false,
            "placeholder": "Enter or Select Courier Type...",
            "optionsValueField": "Value",
            "optionsLabelField": "Value",
            "optionsListMaxWidth": "300px",
            "optionsListMaxHeight": "200px",
            "optionsListScrollOnWideOptions": true,
            "width": "100%"
        };

        vm.customSelectChangeCallback = function (message) {
            if (message !== undefined && message !== null && message.length > 0) {
                toastr.info(message);
            } else {
                toastr.info("efSelect ngChange Called");
            }
        }

        vm.customSelectOptions = efLibrary.copyObject(efSelectDemoApi.courierTypes);

        vm.customSelectModel = null;

        vm.customMultiSelectConfig = {
            "allowDuplicates": false,
            "placeholder": "Enter or Select Courier Type...",
            "optionsValueField": "Value",
            "optionsLabelField": "Value",
            "optionsListMaxWidth": "300px",
            "optionsListMaxHeight": "200px",
            "optionsListScrollOnWideOptions": true,
            "width": "100%"
        };

        vm.customMultiSelectChangeCallback = function (message) {
            if (message !== undefined && message !== null && message.length > 0) {
                toastr.info(message);
            } else {
                toastr.info("efSelect ngChange Called");
            }
        }

        vm.customMultiSelectOptions = efLibrary.copyObject(efSelectDemoApi.courierTypes);

        vm.customMultiSelectModel = null;

        vm.customListConfig = {
            "allowDuplicates": false,
            "placeholder": "Enter a Custom List...",
            "width": "100%"
        };

        vm.customListChangeCallback = function (message) {
            if (message !== undefined && message !== null && message.length > 0) {
                toastr.info(message);
            } else {
                toastr.info("efSelect ngChange Called");
            }
        }

        vm.customListModel = null;

        //#endregion

        //#region efSelect TrueFalse 

        vm.trueFalseConfig = {
            "placeholder": "Select Boolean...",
            "width": "100%"
        };

        vm.trueFalseChangeCallback = function (message) {
            if (message !== undefined && message !== null && message.length > 0) {
                toastr.info(message);
            } else {
                toastr.info("efSelect ngChange Called");
            }
        }

        vm.trueFalseModel = true;

        vm.trueFalseNullConfig = {
            "placeholder": "Select Boolean...",
            "width": "100%"
        };

        vm.trueFalseNullChangeCallback = function (message) {
            if (message !== undefined && message !== null && message.length > 0) {
                toastr.info(message);
            } else {
                toastr.info("efSelect ngChange Called");
            }
        }

        vm.trueFalseNullModel = null;

        //#endregion


        //CSD - Remove this
        $timeout(function () {
            $('#alertTest').on('change', function () {
                alert("hello");
            });
        }, 500);
    };
})();

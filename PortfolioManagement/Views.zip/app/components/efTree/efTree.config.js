﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efTree')
        .config(config);

    config.$inject = ['$stateProvider'];

    function config($stateProvider) {
        $stateProvider
            .state('efAngularLibrary.efTree', {
                abstract: true,
                url: "/efTree",
                template: "<ui-view />"
            })
            .state('efAngularLibrary.efTree.demo', {
                url: "/demo",
                templateUrl: "/app/components/efTree/demo/efTree.demo.html",
                controller: "EfTreeDemoCtrl",
                controllerAs: "vm"
            });
    };
})();
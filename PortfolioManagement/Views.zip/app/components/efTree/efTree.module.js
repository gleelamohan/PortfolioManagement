﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.
/**
 * @ngdoc overview
 * @name efAngularLibrary.efTree
 * @description 
 * 
 * efTree module provides an Angular directive tree view control.
 * 
 * <a href="/app/#/demo/efTree/demo">For complete implmentation details see the demo page.</a>
 * 
 * 
**/
(function () {
    angular.module('efAngularLibrary.efTree', [
        'treeControl'       // angular-tree-control
    ]);
})();
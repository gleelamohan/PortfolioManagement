﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

/**
 * @ngdoc directive
 * @name efAngularLibrary.efTree.directive:efTree
 * @scope
 * @restrict AEC
 * @requires efLibrary
 * @requires recursionHelper
 * @requires toastr
 * @requires angular-tree-control
 * @description 
 * 
 * efDatetime is an Angular directive that renders an input control that allows the user to select Date & Time, Date, or Time.
 * 
 * <a href="/app/#/demo/efTree/demo">For complete implmentation details see the demo page.</a>   
 * 
 * See <a href="https://wix.github.io/angular-tree-control/" target="_blank">https://wix.github.io/angular-tree-control/</a> for complete angular-tree-control details.
 * 
 * @param {string=} id Unique ID for the rendered control to use to identify itself.
 * @param {object=} config JSON Object with configuration options.  See <a href="https://wix.github.io/angular-tree-control/" target="_blank">https://wix.github.io/angular-tree-control/</a> for complete details.
 * @param {object} ngModel The Angular model for the control.
 * @param {expression|boolean=} ngDisabled Flag to enable/disable the field.  If not provided, then the control is enabled.
 * @param {object=} selectedNode The selected node for the tree view.
 * @param {expression|method=} onSelect The method to execute when an item in the tree view is selected.
 * @param {string=} nodeTemplate The HTML template to use for each tree view node.
 * @param {boolean=} expandNodesOnAdd Flag to automatucally expand the new of an add operation.
 * @param {function=} addNode This is a reference to efTree.addNode() method that a parent/calling component can use add a node to the tree.
 * @param {Array|function=} menuItemCallbacks This is an array of callback functions that are to be executed menu/items are shown.
**/
(function () {
    angular
        .module('efAngularLibrary.efTree')
        .directive('efTree', efTree);

    efTree.$inject = ['$compile', '$sce', '$filter', '$translate', '$timeout', 'recursionHelper', 'toastr', 'efLibrary'];

    function efTree($compile, $sce, $filter, $translate, $timeout, recursionHelper, toastr, efLibrary) {
        return {
            restrict: 'AEC',
            replace: true,
            priority: 1,
            terminal: true,
            scope: {
                id: "@?",
                config: "=?",
                ngModel: "=",
                ngDisabled: "=?",
                selectedNode: "=?",
                onSelect: "&",
                nodeTemplate: "@?",
                expandNodesOnAdd: "@?",
                addNode: "=?",
                menuItemCallbacks: "=?" //Format detailed below
            },
            controller: function ($scope) {
                var vm = this;
                vm.selected = undefined;
                vm.config = {}
                vm.expandedNodes = [];
                vm.model = [];
                vm.currentLanguage = $translate.use();
                vm.templateUrl = "/app/components/efTree/efTree.html";
                $scope.$watch('ngModel', handleModelUpdates, true);
                $scope.$watch('config', handleConfigUpdates, true);
                $scope.$watch('ngDisabled', handleDisabledUpdates, true);
                $scope.$watch('selectedNode', handleSelectedNode, true);
                $scope.$watch('onSelect', handleSelectNode, true);
                $scope.$watch('menuItemCallbacks', handleMenuItemCallbacks, true);

                vm.id = $scope.id !== undefined && $scope.id !== null ? $scope.id : ('eftree' + String(Math.floor((Math.random() * 1000000) + 1)));
                //TODO: Figure out how to apply vm.nodeTemplate to the treecontrol dynamically
                vm.nodeTemplate = $scope.nodeTemplate !== undefined && $scope.nodeTemplate !== null ? $scope.nodeTemplate : "<span>{{node.label}}</span>";
                vm.expandNodesOnAdd = $scope.expandNodesOnAdd !== undefined && $scope.expandNodesOnAdd !== null ? ($scope.expandNodesOnAdd == 'true') : false;

                vm.width = $scope.width !== undefined && $scope.width !== null ? $scope.width : "";
                vm.widthStyle = vm.width !== undefined && vm.width !== null && vm.width.length > 0 ? JSON.parse("{\"width\": \"" + vm.width + "\"}") : "";

                //#region  Watch Handlers
                function handleModelUpdates(newModel) {
                    vm.model = newModel !== undefined && newModel !== null ? newModel : null;
                    if (vm.expandNodesOnAdd == true) {
                        vm.expandedNodes = [];
                        autoExpandNodes(vm.model);
                    }
                }

                function handleDisabledUpdates(newValue) {
                    vm.disabled = newValue !== undefined && newValue !== null ? newValue : false;
                    //TODO: Find elegant way of disabling tree visually
                }

                function handleConfigUpdates(newConfig) {
                    var cfg = newConfig !== undefined && newConfig !== null ? newConfig : {};
                    vm.config = cfg;
                }

                function handleSelectedNode(newSelectedNode) {
                    vm.selected = newSelectedNode !== undefined && newSelectedNode !== null && vm.disabled !== true ? newSelectedNode : undefined;
                }

                function handleSelectNode(newSelectCallback) {
                    vm.selectNodeCallback = newSelectCallback !== undefined && newSelectCallback !== null ? newSelectCallback : function () { };
                }

                function handleMenuItemCallbacks(newMenuItemCallbacks) {
                    var callbacks = newMenuItemCallbacks !== undefined && newMenuItemCallbacks !== null ? newMenuItemCallbacks : [];
                    vm.menuItemCallbacks = callbacks;
                    if (vm.menuItemCallbacks.length > 0) {
                        if (!vm.config.injectClasses)
                            vm.config.injectClasses = {
                                "ul": "efTreeUl",
                                "labelSelected": "panel panel-default"
                            };
                        else {
                            vm.config.injectClasses.ul = "efTreeUl";
                            vm.config.injectClasses.labelSelected = "panel panel-default";
                        }
                    }

                }
                //#endregion

                //#region support functions
                vm.addNode = function (node) {
                    if (vm.selected !== undefined) {
                        vm.selected.children.push(node);

                        //Expand current node
                        if (vm.expandNodesOnAdd == true) {
                            vm.expandedNodes.push(vm.selected);
                        }

                        //Update selected node to newly added child
                        var numChildren = vm.selected.children.length;
                        vm.selectNode(vm.selected.children[numChildren - 1], true);
                    } else {
                        vm.model.push(node);
                        //Update selected node to newly added child
                        vm.selectNode(vm.model[vm.model.length - 1], true);
                    }
                };

                $scope.addNode = vm.addNode;

                vm.selectNode = function (node, selected) {
                    if ((selected == true && node === vm.selected) || vm.disabled == true)
                        return;

                    vm.selected = selected == true ? node : null;
                    vm.selectNodeCallback({ node: node, selected: selected });
                }

                vm.displayErrorMessage = function (message) {
                    toastr.error(message);
                }

                function autoExpandNodes(data) {
                    if (data !== undefined && data !== null && data.length > 0) {
                        for (var i = 0; i < data.length; i++) {
                            if (data[i].children && data[i].children.length > 0) {
                                vm.expandedNodes.push(data[i]);
                                autoExpandNodes(data[i].children);
                            }
                        }
                    }
                }

                vm.menuItemClick = function (e) {
                    e.stopPropagation();

                };

                vm.showMenu = function (node) {
                    if (node && vm.menuItemCallbacks && vm.menuItemCallbacks.length > 0) {
                        var found = false;
                        for (var i = 0; i < vm.menuItemCallbacks.length; i++) {
                            if (vm.menuItemCallbacks[i].criteriaCallback && vm.menuItemCallbacks[i].criteriaCallback(node) == true) {
                                found = true;
                                break;
                            }
                        }
                        return found;
                    }

                    return false;
                };

                vm.menuItems = function (node) {
                    var items = [];
                    for (var i = 0; i < vm.menuItemCallbacks.length; i++) {
                        if (vm.menuItemCallbacks[i].criteriaCallback && vm.menuItemCallbacks[i].criteriaCallback(node) == true) {
                            for (var j = 0; j < vm.menuItemCallbacks[i].callbackList.length; j++) {
                                items.push(vm.menuItemCallbacks[i].callbackList[j]);
                            }
                        }
                    }
                    return items;
                }

                vm.runMenuItemCallback = function (opt, node) {
                    if (opt && opt.menuItemCallback) {
                        opt.menuItemCallback(node);
                    }
                };

                vm.togglePosition = function (element) {
                    var currentPosition = $(element).css('position');
                    if (!currentPosition)
                        $(element).css('position', 'fixed');
                }
                //#endregion
            },
            controllerAs: 'vm',
            template: '<div ng-include="vm.templateUrl"></div>',
            compile: function (element) {
                return recursionHelper.compile(element);
            }
        };
    }
})();

//Format for menuItemCallbacks:
/*


*/
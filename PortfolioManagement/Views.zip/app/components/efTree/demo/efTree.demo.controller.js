﻿// Copyright 2015 Eurofins Scientific Ltd, Ireland
// Usage reserved to Eurofins Global Franchise Model subscribers.

(function () {
    angular
        .module('efAngularLibrary.efTree')
        .controller('EfTreeDemoCtrl', EfTreeDemoCtrl);

    EfTreeDemoCtrl.$inject = ['$scope'];

    function EfTreeDemoCtrl($scope) {
        var vm = this;
        vm.selectedNode = undefined;
        vm.selectedNode2 = undefined;
        vm.disabled = false;
        //Tree options
        vm.treeConfig = {
            nodeChildren: "children",
            dirSelectable: true,
            multiSelection: false,
            equality: function (node1, node2) {
                return node1 === node2;
            }
        };

        //Grid config
        vm.gridApi = null;
        vm.gridOptions = {
            enableSorting: false,
            enableHorizontalScrollbar: 0, //0=never, 1 = always, 2 = when needed
            enableVerticalScrollbar: 0, //0=never, 1 = always, 2 = when needed

            columnDefs: [
                {
                    name: 'id',
                    field: 'id',
                    displayName: 'id',
                    headerTooltip: false,
                    cellTooltip: false,
                    enableColumnMenu: false,
                    enableFiltering: false,
                    enableHiding: false,
                    enableSorting: false,
                    suppressRemoveSort: true,
                    allowCellFocus: true,
                    visible: false,
                    width: '0%'
                },
                {
                    name: 'label',
                    field: 'label',
                    displayName: 'Batch',
                    headerTooltip: false,
                    cellTooltip: false,
                    enableColumnMenu: false,
                    enableFiltering: false,
                    enableHiding: false,
                    enableSorting: false,
                    suppressRemoveSort: true,
                    allowCellFocus: true,
                    visible: true,
                    width: '100%'
                }
            ]
        }

        //Grid row select function
        vm.selectedCallback = function () {
            if (vm.gridSelected && vm.gridSelected.length > 0) {
                var result = $.grep(vm.treeModel, function (e) { return e.label.indexOf('Batch') == 0 && e.id == vm.gridSelected[0]; });
                if (result.length > 0) {
                    $("#example2log").append('row ' + result[0].label + ', id: ' + result[0].id + ', was selected in the grid.' + "<br />");
                    vm.selectNode2(result[0], true, true);
                    $scope.$apply();
                }
            } else {
                vm.selectedNode2 = undefined;
            }
        }

        //Original copy of data
        vm.originalTreeModel = [
            {
                "label": "Batch1",
                "id": "21",
                "children": [
                    { "label": "Sample1", "id": "42", "children": [] },
                    {
                        "label": "Sample2",
                        "id": "43",
                        "children": [
                            {
                                "label": "Aliquot1",
                                "id": "23",
                                "children": [
                                    { "label": "Test1", "id": "32", "children": [] },
                                    { "label": "Test2", "id": "34", "children": [] }
                                ]
                            },
                            { "label": "Test3", "id": "35", "children": [] }
                        ]
                    }
                ]
            },
            { "label": "Batch2", "id": "33", "children": [] },
            { "label": "Batch3", "id": "29", "children": [] }
        ];

        //Sets the currently selected node in the tree (Example 1)
        vm.selectNode = function (node, selected) {
            $("#example1log").append(node.label + ', id: ' + node.id + ', was ' + (selected == true ? 'selected' : 'unselected') + "<br />");
            vm.selectedNode = selected == true ? node : undefined;
        }

        //Sets the currently selected node in the tree (Example 1)
        vm.selectNode2 = function (node, selected) {
            $("#example2log").append(node.label + ', id: ' + node.id + ', was ' + (selected == true ? 'selected' : 'unselected') + "<br />");
            vm.selectedNode2 = selected == true ? node : undefined;
            if (vm.selectedNode2)
                vm.gridSelected = [vm.selectedNode2.id];
            else
                vm.gridSelected = [];
        }

        //Add child node function
        vm.addNode = function () {
            if (vm.selectedNode !== undefined && vm.selectedNode != null) {
                var numChildren = vm.selectedNode.children.length;
                var label;
                var sequence = 0;
                if (numChildren > 0) {
                    //If parent is sample then randomly pick either Test or Aliquot as a child and keep the sequence # incremental with its type
                    var parent = vm.selectedNode.label.match(/[A-Za-z]+/);
                    switch (parent[0]) {
                        case "Sample":
                            label = Math.floor((Math.random() * 10) + 1) % 2 === 0 ? "Test" : "Aliquot";
                            for (var i = numChildren - 1; i > -1; i--) {
                                var thisLabel = vm.selectedNode.children[i].label.match(/[A-Za-z]+/);
                                if (thisLabel[0] === label) {
                                    sequence = vm.selectedNode.children[i].label.match(/\d+/);
                                    break;
                                }
                            }
                            break;
                        default:
                            label = vm.selectedNode.children[numChildren - 1].label.match(/[A-Za-z]+/);
                            sequence = vm.selectedNode.children[numChildren - 1].label.match(/\d+/);
                    }
                } else {
                    label = vm.selectedNode.label.match(/[A-Za-z]+/);
                    switch (label[0]) {
                        case "Batch":
                            label = "Sample";
                            break;
                        case "Sample":
                            label = Math.floor((Math.random() * 10) + 1) % 2 === 0 ? "Test" : "Aliquot";
                            break;
                        case "Aliquot":
                            label = "Test";
                            break;
                        default:
                            label = "Child";
                            sequence = Math.floor(Math.random() * 100) + 1;
                    }
                }
                sequence++;
                //Add new child node to tree
                vm.addItem({ label: label + sequence, id: sequence, children: [] });
                $("#example1log").append(vm.selectedNode.label + ', id: ' + Math.floor(Math.random() * 100) + vm.selectedNode.id + ', was added' + "<br />");
            } else {
                var batchSequence = vm.treeModel[vm.treeModel.length - 1].label.match(/\d+/);;
                batchSequence++;
                //Add new child node to tree
                var newId = Math.floor(Math.random() * 100) + batchSequence;
                vm.addItem({ label: 'Batch' + batchSequence, id: newId, children: [] });
            }
        }

        //Determines equality between treeview model and original data
        vm.isOriginalData = function () {
            return (angular.toJson(vm.treeModel) == angular.toJson(vm.originalTreeModel));
        }

        //Reset functions
        vm.initExample1 = function () {
            vm.selectedNode = undefined;
            vm.treeModel = JSON.parse(JSON.stringify(vm.originalTreeModel));
        }
        vm.clearLog1 = function () {
            $("#example1log").empty();
        }
        vm.clearLog2 = function () {
            $("#example2log").empty();
        }

        //Init Example 1 and tree Model
        vm.initExample1();

        vm.menuItemCallbacks = [
            {
                criteriaCallback: function (node) { return node.label.indexOf('Batch') > -1; },
                callbackList: [
                                {
                                    menuItemLabel: "Batch Example 1",
                                    menuItemCallback: function (node) { alert('Hello, you are clicking on Batch Example 1 for node ' + node.id + '!'); }
                                }
                ]
            },
            {
                criteriaCallback: function (node) { return node.label.indexOf('Sample') > -1; },
                callbackList: [
                                {
                                    menuItemLabel: "Sample Example 1",
                                    menuItemCallback: function (node) { alert('Hello, you are clicking on Sample Example 1 for node ' + node.id + '!'); }
                                },
                                {
                                    menuItemLabel: "Sample Example 2",
                                    menuItemCallback: function (node) { alert('Hey now, you just clicked on Sample Example 2 for node ' + node.id + '!'); }
                                }
                ]
            }
        ];

    };
})();

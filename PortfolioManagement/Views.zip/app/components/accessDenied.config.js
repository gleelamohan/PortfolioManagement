(function () {
    angular
        .module('app')
        .config(config);

    config.$inject = ['$stateProvider', '$urlRouterProvider'];

    function config($stateProvider, $urlRouterProvider) {

        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('accessdenied', {
                url: "/accessdenied",
                template: '<div>401</div>'
            });
    }
})();